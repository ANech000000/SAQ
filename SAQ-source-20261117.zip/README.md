# SAQ: Shape-Aligned Lookup Table Quantization

Research code for **SAQ: Shape-Aligned Lookup Table Quantization for Efficient LLM Inference**, developed from [Any4](https://github.com/facebookresearch/any4). Historical identifiers in the implementation include **CSD-LUT**, **Method30**, and **Post-AWQ 22A**.

This package contains the archived experiment source and the November 16, 2026 HellaSwag reevaluation. It excludes model weights, datasets, activation/Fisher caches, compiled extensions, environments, and historical debug logs.

## Layout

```text
code/any4/                  Original source layout and experiment entry points
code/any4/tinygemm_lib/      TinyGemm and CUDA source
code/any4/server_eval/       Unified HellaSwag reevaluation scripts
docs/REPRODUCTION.md         Inputs, environment notes, and reproduction entry points
docs/EXPERIMENT_INDEX.md     Historical experiment/result locations
docs/KNOWN_LIMITATIONS.md    Reproduction and reporting boundaries
results/hellaswag_20261116/  Corrected HellaSwag results and provenance
results/historical/         Selected older comparison/ablation/system summaries
SOURCE_MANIFEST.json        SHA256 inventory
LICENSE                     Original Any4 license, retained unchanged
```

## Main implementation

Paths below are relative to `code/any4/`.

| Component | Entry point |
|---|---|
| Shape metric and equivalent channel scaling | `experiments/method24_shape_w2/method24_shape.py` |
| Scaling candidate search | `experiments/method25_linear_recon_shape/full_search.py` |
| Output + CSD selection | `experiments/llama3_8b_reproduction/select_alpha.py` |
| Structured outliers and shared LUT quantization | `experiments/method30_outlier/method30_outlier_quant.py` |
| Alternating refinement and cached state reconstruction | `experiments/method30_postawq_refine/` |
| Packed inference and system evaluation | `experiments/method30_outlier/packed_runtime/` |
| Weight-only comparison | `experiments/method30_weightonly_1b/scripts/` |
| Scaling, outlier, group-size, and architecture experiments | `experiments/method30_csd_ablation/`, `experiments/paper_additional_20260818_v1/` |

## Running experiments

The research runtime is Linux with NVIDIA CUDA. Read [REPRODUCTION.md](docs/REPRODUCTION.md) before running a script. `code/any4/requirements.txt` is the historical dependency list, not a complete environment lock. Model files, evaluation datasets, calibration statistics, and cached quantization states must be prepared separately.

Original scripts preserve `/data/lsz/any4` and other server paths. Adapt paths in a separate working copy and use fresh output directories. The archived source has been syntax-checked; this release does not claim a fresh-machine end-to-end reproduction.

## Corrected HellaSwag evaluation

The main result is zero-shot **unnormalized accuracy**, evaluated with the original Table I lm-eval 0.4.5 entry, all 10,042 validation examples, batch size 8, and maximum length 2048. Normalized accuracy is retained as a secondary field in the result JSON/CSV.

| Method | HellaSwag accuracy (%) |
|---|---:|
| FP16 | 47.73 |
| RTN | 45.08 |
| GPTQ | 46.14 |
| AWQ | 46.38 |
| Any4 | 46.37 |
| CSD-LUT / SAQ | **46.86** |

The FP16 result exactly reproduces Table I. GPTQ was reconstructed in its historical runtime, checked against historical PPL, and transferred through an in-memory pipe with all 112 layers' packed tensors hash-verified before evaluation in the common runtime. See [validation.json](results/hellaswag_20261116/validation.json) and [comparison.csv](results/hellaswag_20261116/comparison.csv).

Older result files under `results/historical/` retain their original evaluation protocols and must not be substituted for this corrected HellaSwag column. The two historical Any4 tables used different quantization results; their remaining two-example discrepancy is documented in [KNOWN_LIMITATIONS.md](docs/KNOWN_LIMITATIONS.md).

## Attribution

The original Any4 code and its Attribution-NonCommercial 4.0 International license are retained. See [NOTICE](NOTICE) and [LICENSE](LICENSE). No model or dataset license is granted by this repository.
