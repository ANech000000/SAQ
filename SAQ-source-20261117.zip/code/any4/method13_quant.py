import gc
import hashlib
import json
import math
import time

import torch


METHOD13_NAME = "method13_rht_hlut"
METHOD13_VERSION = "method13_rht_hlut_v1"
_METHOD13_LAYER_STATS = {}


def reset_method13_stats():
    _METHOD13_LAYER_STATS.clear()


def get_method13_stats():
    return json.loads(json.dumps(_METHOD13_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD13_LAYER_STATS[layer_name or "<tensor>"] = stats


def _is_power_of_two(value):
    return value > 0 and (value & (value - 1)) == 0


def hadamard_transform(value):
    if not _is_power_of_two(value.shape[-1]):
        raise ValueError(
            f"Hadamard dimension must be a power of two, got {value.shape[-1]}."
        )
    original_shape = value.shape
    width = original_shape[-1]
    transformed = value.reshape(-1, width)
    step = 1
    while step < width:
        blocks = transformed.reshape(-1, width // (2 * step), 2 * step)
        left = blocks[..., :step]
        right = blocks[..., step:]
        transformed = torch.cat((left + right, left - right), dim=-1).reshape(-1, width)
        step *= 2
    return transformed.reshape(original_shape) / math.sqrt(width)


def rotation_signs(width, layer_name, seed, device, dtype):
    digest = hashlib.sha256(
        f"{METHOD13_VERSION}:{seed}:{layer_name}:{width}".encode("utf-8")
    ).digest()
    generator_seed = int.from_bytes(digest[:8], "little") % (2**63 - 1)
    generator = torch.Generator(device="cpu")
    generator.manual_seed(generator_seed)
    signs = torch.randint(
        0,
        2,
        (width,),
        generator=generator,
        dtype=torch.int8,
    )
    signs = signs.float().mul_(2.0).sub_(1.0)
    return signs.to(device=device, dtype=dtype)


def rotate_weight_right(W, signs):
    return hadamard_transform(W * signs)


def inverse_rotate_weight_right(W_rotated, signs):
    return hadamard_transform(W_rotated) * signs


def method13_rht_quantize_tensor(
    W,
    n_bit=2,
    q_group_size=128,
    layer_name=None,
    model_path=None,
    method13_seed=0,
    method13_cache_dir=None,
    method13_use_cache=True,
    method13_parallel_jobs=32,
    method13_max_iter=8,
    parallelize=True,
):
    if n_bit != 2:
        raise ValueError("method13 requires n_bit=2.")
    if W.dim() != 2 or W.shape[1] % q_group_size != 0:
        raise ValueError(
            f"method13 expects 2D weights divisible by group size, got {tuple(W.shape)}."
        )
    if not _is_power_of_two(W.shape[1]):
        raise ValueError("method13 requires power-of-two input features.")

    import quantize

    started = time.time()
    signs = rotation_signs(
        W.shape[1],
        layer_name,
        method13_seed,
        W.device,
        torch.float32,
    )
    rotated = rotate_weight_right(W.detach().float(), signs).to(dtype=W.dtype)
    state = quantize.method11_hlut_quantize_tensor(
        rotated,
        n_bit=2,
        q_group_size=q_group_size,
        per_row=True,
        scale_only=False,
        sample_weight=None,
        fisher_sample_weight=False,
        method11_num_tables=4,
        method11_table_size=4,
        method11_joint_affine=True,
        method11_max_iter=int(method13_max_iter),
        method11_tol=1e-6,
        method11_ridge=1e-6,
        method11_scale_eps=1e-6,
        method11_parallel_jobs=int(method13_parallel_jobs),
        method11_cache_dir=method13_cache_dir,
        method11_use_cache=bool(method13_use_cache),
        method11_overwrite_cache=False,
        method11_return_stats=False,
        parallelize=parallelize,
        layer_name=layer_name,
        model_path=f"{model_path}|rht_seed={method13_seed}",
    )
    quantized_rotated = quantize.method11_hlut_dequantize_tensor(
        state,
        dtype=torch.float32,
        device=W.device,
    )
    reconstructed = inverse_rotate_weight_right(
        quantized_rotated,
        signs,
    ).to(dtype=W.dtype)
    stats = dict(state["stats"])
    stats.update({
        "method_name": METHOD13_NAME,
        "layer_name": layer_name,
        "rotation": "randomized_hadamard_right",
        "rotation_seed": int(method13_seed),
        "rotation_dimension": int(W.shape[1]),
        "elapsed_seconds_with_rotation": float(time.time() - started),
    })
    _record_stats(layer_name, stats)
    return reconstructed, state, stats


def method13_rht_reconstruct_tensor(W, **kwargs):
    reconstructed, state, stats = method13_rht_quantize_tensor(W, **kwargs)
    del state, stats
    torch.cuda.empty_cache()
    gc.collect()
    return reconstructed

