import gc
import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from joblib import Parallel, delayed


METHOD12_NAME = "method12_guided_hlut"
METHOD12_VERSION = "method12_guided_hlut_v1"
_METHOD12_LAYER_STATS = {}


def reset_method12_stats():
    _METHOD12_LAYER_STATS.clear()


def get_method12_stats():
    return json.loads(json.dumps(_METHOD12_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD12_LAYER_STATS[layer_name or "<tensor>"] = stats


def _array_hash(value):
    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        value = value.detach().cpu().contiguous().numpy()
    array = np.ascontiguousarray(value)
    digest = hashlib.sha256()
    digest.update(str(array.shape).encode("utf-8"))
    digest.update(str(array.dtype).encode("utf-8"))
    digest.update(memoryview(array).cast("B"))
    return digest.hexdigest()


def _storage_stats(rows, cols, group_size, num_tables=4, table_size=4):
    groups = rows * (cols // group_size)
    code_bytes = (rows * cols * 2 + 7) // 8
    route_bytes = (groups * 2 + 7) // 8
    lut_bytes = rows * num_tables * table_size * 2
    affine_bytes = groups * 2 * 2
    total_bytes = code_bytes + route_bytes + lut_bytes + affine_bytes
    return {
        "logical_weight_count": int(rows * cols),
        "logical_code_bytes": int(code_bytes),
        "logical_route_bytes": int(route_bytes),
        "fp16_lut_bytes": int(lut_bytes),
        "fp16_scale_zero_bytes": int(affine_bytes),
        "logical_total_bytes": int(total_bytes),
        "effective_bits_per_weight": float(total_bytes * 8.0 / (rows * cols)),
    }


def _prepare_hessian(hessian, rows, cols, group_size):
    if not isinstance(hessian, dict):
        raise ValueError("method12 requires a Hessian entry dictionary.")
    if "diag" not in hessian or "factors" not in hessian:
        raise ValueError("method12 Hessian entry must contain diag and factors.")

    diag = hessian["diag"]
    factors = hessian["factors"]
    if isinstance(diag, torch.Tensor):
        diag = diag.detach().cpu().float().numpy()
    if isinstance(factors, torch.Tensor):
        factors = factors.detach().cpu().float().numpy()
    diag = np.asarray(diag, dtype=np.float64)
    factors = np.asarray(factors, dtype=np.float64)

    if diag.ndim != 3:
        raise ValueError(f"method12 diag must have shape [output_groups, blocks, block_size], got {diag.shape}.")
    if factors.ndim != 4:
        raise ValueError(
            f"method12 factors must have shape [output_groups, blocks, block_size, rank], got {factors.shape}."
        )
    if factors.shape[:3] != diag.shape:
        raise ValueError(f"method12 factors shape {factors.shape} is incompatible with diag {diag.shape}.")
    output_groups, blocks, block_size = diag.shape
    if blocks * block_size != cols:
        raise ValueError(
            f"method12 Hessian covers {blocks * block_size} columns but weight has {cols}."
        )
    if group_size % block_size != 0:
        raise ValueError(
            f"method12 group_size={group_size} must be divisible by Hessian block_size={block_size}."
        )
    if rows % output_groups != 0:
        raise ValueError(
            f"method12 rows={rows} must be divisible by output_groups={output_groups}."
        )

    diag = np.nan_to_num(diag, nan=0.0, posinf=0.0, neginf=0.0)
    factors = np.nan_to_num(factors, nan=0.0, posinf=0.0, neginf=0.0)
    diag = np.maximum(diag, 0.0)
    empty = (diag.sum(axis=(1, 2)) + np.square(factors).sum(axis=(1, 2, 3))) <= 0
    if np.any(empty):
        diag[empty] = 1.0
        factors[empty] = 0.0
    return diag, factors


def _quadratic_block_loss(error, diag, factors, group_size):
    blocks, block_size = diag.shape
    blocks_per_group = group_size // block_size
    error_blocks = np.asarray(error, dtype=np.float64).reshape(blocks, block_size)
    diagonal_loss = np.sum(diag * error_blocks * error_blocks, axis=1)
    projection = np.einsum("nbr,nb->nr", factors, error_blocks, optimize=True)
    block_loss = diagonal_loss + np.sum(projection * projection, axis=1)
    return block_loss.reshape(-1, blocks_per_group).sum(axis=1)


def _assign_routes_nearest(w_row, scales, offsets, lut, diag, factors, group_size):
    groups = scales.shape[0]
    tables, table_size = lut.shape
    blocks, block_size = diag.shape
    blocks_per_group = group_size // block_size

    w_groups = w_row.reshape(groups, group_size)
    levels = scales[:, None, None] * lut[None, :, :] + offsets[:, None, None]
    diff = w_groups[:, :, None, None] - levels[:, None, :, :]
    candidate_codes = np.argmin(np.abs(diff), axis=3)
    candidate_error = np.take_along_axis(
        diff,
        candidate_codes[:, :, :, None],
        axis=3,
    ).squeeze(3)

    error_blocks = candidate_error.reshape(blocks, block_size, tables)
    diagonal_loss = np.sum(
        diag[:, :, None] * error_blocks * error_blocks,
        axis=1,
    )
    projection = np.einsum(
        "nbr,nbt->nrt",
        factors,
        error_blocks,
        optimize=True,
    )
    block_loss = diagonal_loss + np.sum(projection * projection, axis=1)
    table_loss = block_loss.reshape(groups, blocks_per_group, tables).sum(axis=1)
    table_ids = np.argmin(table_loss, axis=1)
    codes = np.take_along_axis(
        candidate_codes,
        table_ids[:, None, None],
        axis=2,
    ).squeeze(2)
    group_loss = table_loss[np.arange(groups), table_ids]
    return codes.astype(np.uint8), table_ids.astype(np.uint8), group_loss


def _cyclic_cd_selected(
    w_row,
    codes,
    table_ids,
    scales,
    offsets,
    lut,
    diag,
    factors,
    group_size,
    sweeps,
):
    if sweeps <= 0:
        loss = _quadratic_block_loss(
            w_row - (
                scales[:, None] * lut[table_ids.astype(np.int64)[:, None], codes.astype(np.int64)]
                + offsets[:, None]
            ).reshape(-1),
            diag,
            factors,
            group_size,
        )
        return codes, loss

    groups = scales.shape[0]
    blocks, block_size = diag.shape
    blocks_per_group = group_size // block_size
    block_to_group = np.arange(blocks, dtype=np.int64) // blocks_per_group
    w_blocks = w_row.reshape(blocks, block_size)
    code_blocks = codes.reshape(blocks, block_size).astype(np.int64, copy=True)
    selected_lut = lut[table_ids.astype(np.int64)]
    levels = scales[:, None] * selected_lut + offsets[:, None]
    reconstruction = levels[block_to_group[:, None], code_blocks]
    error = w_blocks - reconstruction
    projection = np.einsum("nbr,nb->nr", factors, error, optimize=True)
    hessian_diag = diag + np.sum(factors * factors, axis=2)

    for _ in range(int(sweeps)):
        changed = False
        for column in range(block_size):
            gradient = (
                diag[:, column] * error[:, column]
                + np.sum(factors[:, column, :] * projection, axis=1)
            )
            candidate_error = (
                w_blocks[:, column, None]
                - levels[block_to_group]
            )
            delta = candidate_error - error[:, column, None]
            objective_delta = (
                2.0 * delta * gradient[:, None]
                + delta * delta * hessian_diag[:, column, None]
            )
            best = np.argmin(objective_delta, axis=1)
            new_error = candidate_error[np.arange(blocks), best]
            update = new_error - error[:, column]
            if np.any(update != 0):
                changed = True
                projection += update[:, None] * factors[:, column, :]
                error[:, column] = new_error
                code_blocks[:, column] = best
        if not changed:
            break

    block_loss = np.sum(diag * error * error, axis=1)
    projection = np.einsum("nbr,nb->nr", factors, error, optimize=True)
    block_loss += np.sum(projection * projection, axis=1)
    group_loss = block_loss.reshape(groups, blocks_per_group).sum(axis=1)
    return code_blocks.reshape(groups, group_size).astype(np.uint8), group_loss


def _assign_and_refine(
    w_row,
    scales,
    offsets,
    lut,
    diag,
    factors,
    group_size,
    cd_sweeps,
):
    codes, table_ids, _ = _assign_routes_nearest(
        w_row,
        scales,
        offsets,
        lut,
        diag,
        factors,
        group_size,
    )
    codes, group_loss = _cyclic_cd_selected(
        w_row,
        codes,
        table_ids,
        scales,
        offsets,
        lut,
        diag,
        factors,
        group_size,
        cd_sweeps,
    )
    return codes, table_ids, float(group_loss.sum()), group_loss


def _update_lut(
    w_row,
    codes,
    table_ids,
    scales,
    offsets,
    lut,
    diag,
    factors,
    group_size,
    ridge,
):
    groups = scales.shape[0]
    blocks, block_size = diag.shape
    blocks_per_group = group_size // block_size
    updated = lut.copy()
    empty_tables = 0

    w_blocks = w_row.reshape(blocks, block_size)
    code_blocks = codes.reshape(blocks, block_size).astype(np.int64)
    for table in range(lut.shape[0]):
        matrix = np.zeros((lut.shape[1], lut.shape[1]), dtype=np.float64)
        target = np.zeros(lut.shape[1], dtype=np.float64)
        used = False
        for block in range(blocks):
            group = block // blocks_per_group
            if int(table_ids[group]) != table:
                continue
            used = True
            one_hot = np.eye(lut.shape[1], dtype=np.float64)[code_blocks[block]]
            design = scales[group] * one_hot
            centered = w_blocks[block] - offsets[group]
            weighted_design = diag[block, :, None] * design
            matrix += design.T @ weighted_design
            factor_design = factors[block].T @ design
            matrix += factor_design.T @ factor_design
            weighted_target = diag[block] * centered
            target += design.T @ weighted_target
            factor_target = factors[block].T @ centered
            target += factor_design.T @ factor_target

        if not used:
            empty_tables += 1
            continue
        matrix.flat[:: matrix.shape[0] + 1] += ridge
        try:
            candidate = np.linalg.solve(matrix, target)
        except np.linalg.LinAlgError:
            candidate = np.linalg.lstsq(matrix, target, rcond=None)[0]
        if np.isfinite(candidate).all():
            updated[table] = np.sort(candidate).astype(np.float32)
    return updated, empty_tables


def _qform(left, right, diag, factors):
    value = float(np.sum(diag * left * right))
    left_projection = factors.T @ left
    right_projection = factors.T @ right
    return value + float(np.dot(left_projection, right_projection))


def _update_affine(
    w_row,
    codes,
    table_ids,
    scales,
    offsets,
    lut,
    diag,
    factors,
    group_size,
    ridge,
    scale_eps,
):
    groups = scales.shape[0]
    blocks, block_size = diag.shape
    blocks_per_group = group_size // block_size
    w_groups = w_row.reshape(groups, group_size)
    accepted = 0

    for group in range(groups):
        centroid = lut[
            int(table_ids[group]),
            codes[group].astype(np.int64),
        ].astype(np.float64)
        target = w_groups[group]
        c_h_c = 0.0
        c_h_1 = 0.0
        one_h_one = 0.0
        c_h_w = 0.0
        one_h_w = 0.0
        old_loss = 0.0
        for local_block in range(blocks_per_group):
            block = group * blocks_per_group + local_block
            start = local_block * block_size
            end = start + block_size
            c = centroid[start:end]
            w = target[start:end]
            ones = np.ones(block_size, dtype=np.float64)
            c_h_c += _qform(c, c, diag[block], factors[block])
            c_h_1 += _qform(c, ones, diag[block], factors[block])
            one_h_one += _qform(ones, ones, diag[block], factors[block])
            c_h_w += _qform(c, w, diag[block], factors[block])
            one_h_w += _qform(ones, w, diag[block], factors[block])
            old_error = w - (scales[group] * c + offsets[group])
            old_loss += _qform(old_error, old_error, diag[block], factors[block])

        system = np.array(
            [[c_h_c + ridge, c_h_1], [c_h_1, one_h_one + ridge]],
            dtype=np.float64,
        )
        rhs = np.array([c_h_w, one_h_w], dtype=np.float64)
        try:
            candidate_scale, candidate_offset = np.linalg.solve(system, rhs)
        except np.linalg.LinAlgError:
            continue
        if not np.isfinite(candidate_scale) or not np.isfinite(candidate_offset):
            continue
        if candidate_scale <= scale_eps:
            continue

        new_loss = 0.0
        for local_block in range(blocks_per_group):
            block = group * blocks_per_group + local_block
            start = local_block * block_size
            end = start + block_size
            error = target[start:end] - (
                candidate_scale * centroid[start:end] + candidate_offset
            )
            new_loss += _qform(error, error, diag[block], factors[block])
        tolerance = max(1e-12, abs(old_loss) * 1e-9)
        if new_loss <= old_loss + tolerance:
            scales[group] = candidate_scale
            offsets[group] = candidate_offset
            accepted += 1
    return accepted


def _optimize_row(
    row_index,
    w_row,
    initial_lut,
    initial_scales,
    initial_offsets,
    diag,
    factors,
    output_groups,
    total_rows,
    group_size,
    max_iter,
    cd_sweeps,
    joint_affine,
    ridge,
    scale_eps,
):
    hessian_group = min(row_index * output_groups // total_rows, output_groups - 1)
    row_diag = diag[hessian_group]
    row_factors = factors[hessian_group]
    lut = np.asarray(initial_lut, dtype=np.float64).copy()
    scales = np.asarray(initial_scales, dtype=np.float64).copy()
    offsets = np.asarray(initial_offsets, dtype=np.float64).copy()

    codes, table_ids, current_loss, group_loss = _assign_and_refine(
        w_row,
        scales,
        offsets,
        lut,
        row_diag,
        row_factors,
        group_size,
        cd_sweeps,
    )
    initial_loss = current_loss
    best_loss = current_loss
    best_state = (
        codes.copy(),
        table_ids.copy(),
        lut.copy(),
        scales.copy(),
        offsets.copy(),
    )
    loss_history = [float(current_loss)]
    empty_tables = 0
    affine_updates = 0

    for _ in range(int(max_iter)):
        previous = (
            codes.copy(),
            table_ids.copy(),
            lut.copy(),
            scales.copy(),
            offsets.copy(),
        )
        previous_loss = current_loss
        previous_routes = table_ids.copy()

        lut, empty = _update_lut(
            w_row,
            codes,
            table_ids,
            scales,
            offsets,
            lut,
            row_diag,
            row_factors,
            group_size,
            ridge,
        )
        empty_tables += empty
        codes, table_ids, current_loss, group_loss = _assign_and_refine(
            w_row,
            scales,
            offsets,
            lut,
            row_diag,
            row_factors,
            group_size,
            cd_sweeps,
        )
        if joint_affine:
            affine_updates += _update_affine(
                w_row,
                codes,
                table_ids,
                scales,
                offsets,
                lut,
                row_diag,
                row_factors,
                group_size,
                ridge,
                scale_eps,
            )
            codes, table_ids, current_loss, group_loss = _assign_and_refine(
                w_row,
                scales,
                offsets,
                lut,
                row_diag,
                row_factors,
                group_size,
                cd_sweeps,
            )

        tolerance = max(1e-12, abs(previous_loss) * 1e-8)
        if not np.isfinite(current_loss) or current_loss > previous_loss + tolerance:
            codes, table_ids, lut, scales, offsets = previous
            current_loss = previous_loss
            loss_history.append(float(current_loss))
            break

        loss_history.append(float(current_loss))
        if current_loss < best_loss:
            best_loss = current_loss
            best_state = (
                codes.copy(),
                table_ids.copy(),
                lut.copy(),
                scales.copy(),
                offsets.copy(),
            )
        relative = (previous_loss - current_loss) / max(abs(previous_loss), 1e-12)
        if np.array_equal(previous_routes, table_ids) or relative < 1e-6:
            break

    codes, table_ids, lut, scales, offsets = best_state
    usage = np.bincount(table_ids.astype(np.int64), minlength=lut.shape[0])
    stats = {
        "initial_loss": float(initial_loss),
        "final_loss": float(best_loss),
        "iterations": int(max(len(loss_history) - 1, 0)),
        "empty_tables": int(empty_tables),
        "affine_updates": int(affine_updates),
        "table_usage": [int(value) for value in usage],
        "loss_monotonic": bool(
            all(
                loss_history[index + 1]
                <= loss_history[index] + max(1e-12, abs(loss_history[index]) * 1e-8)
                for index in range(len(loss_history) - 1)
            )
        ),
    }
    return codes, table_ids, lut, scales, offsets, stats


def _cache_metadata(
    W,
    hessian,
    layer_name,
    model_path,
    group_size,
    max_iter,
    cd_sweeps,
    joint_affine,
    ridge,
    scale_eps,
):
    return {
        "algorithm": METHOD12_VERSION,
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(W.shape),
        "weight_dtype": str(W.dtype),
        "weight_hash": _array_hash(W),
        "hessian_diag_hash": _array_hash(hessian["diag"]),
        "hessian_factors_hash": _array_hash(hessian["factors"]),
        "group_size": int(group_size),
        "max_iter": int(max_iter),
        "cd_sweeps": int(cd_sweeps),
        "joint_affine": bool(joint_affine),
        "ridge": float(ridge),
        "scale_eps": float(scale_eps),
    }


def _cache_file(cache_dir, layer_name, metadata):
    safe = (layer_name or "tensor").replace(".", "__").replace("/", "_")
    digest = hashlib.sha256(
        json.dumps(metadata, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]
    return Path(cache_dir) / f"{safe}.{digest}.pt"


def _load_cache(cache_dir, layer_name, metadata, overwrite):
    if not cache_dir or overwrite:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("metadata") != metadata:
        return None
    if not isinstance(payload.get("lut"), torch.Tensor):
        return None
    if not isinstance(payload.get("scales_and_zeros"), torch.Tensor):
        return None
    return payload


def _save_cache(cache_dir, layer_name, metadata, state, stats):
    if not cache_dir:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return path
    payload = {
        "metadata": metadata,
        "lut": state["lut"].detach().cpu().float(),
        "scales_and_zeros": state["scales_and_zeros"].detach().cpu().float(),
        "stats": stats,
    }
    torch.save(payload, path)
    return path


def _load_method11_initial_state(
    cache_dir,
    layer_name,
    W,
    init_importance,
    model_path,
    group_size,
):
    if not cache_dir or not layer_name:
        return None
    safe = layer_name.replace(".", "__").replace("/", "_")
    path = Path(cache_dir) / f"{safe}.pt"
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    metadata = payload.get("metadata", {})
    required = {
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name),
        "weight_shape": list(W.shape),
        "weight_dtype": str(W.dtype),
        "weight_hash": _array_hash(W),
        "sample_weight_hash": _array_hash(init_importance),
        "n_bit": 2,
        "group_size": int(group_size),
        "num_tables": 4,
        "table_size": 4,
        "joint_affine": True,
        "fisher_sample_weight": True,
        "max_iter": 8,
        "tol": 1e-6,
        "ridge": 1e-6,
        "scale_eps": 1e-6,
        "init": "global_dp_farthest",
    }
    if any(metadata.get(key) != value for key, value in required.items()):
        return None
    if not isinstance(payload.get("lut"), torch.Tensor):
        return None
    if not isinstance(payload.get("scales_and_zeros"), torch.Tensor):
        return None
    return payload

def method12_hlut_quantize_tensor(
    W,
    hessian,
    n_bit=2,
    q_group_size=128,
    per_row=True,
    scale_only=False,
    layer_name=None,
    model_path=None,
    init_importance=None,
    method11_init_cache_dir=None,
    method12_cache_dir=None,
    method12_use_cache=True,
    method12_overwrite_cache=False,
    method12_max_iter=1,
    method12_cd_sweeps=1,
    method12_joint_affine=True,
    method12_ridge=1e-6,
    method12_scale_eps=1e-6,
    method12_parallel_jobs=8,
    method12_parallel_backend="threads",
    parallelize=True,
):
    if n_bit != 2:
        raise ValueError("method12 requires n_bit=2.")
    if not per_row:
        raise ValueError("method12 requires per_row=True.")
    if scale_only:
        raise ValueError("method12 requires asymmetric scale and zero.")
    if not isinstance(q_group_size, int) or q_group_size <= 1:
        raise ValueError("method12 requires a fixed positive integer group size.")
    if W.dim() != 2 or W.shape[1] % q_group_size != 0:
        raise ValueError(
            f"method12 expects 2D weights divisible by group size, got {tuple(W.shape)}."
        )
    parallel_backend = str(method12_parallel_backend).lower()
    if parallel_backend not in {"threads", "loky"}:
        raise ValueError(
            "method12_parallel_backend must be either 'threads' or 'loky'."
        )

    import quantize

    started = time.time()
    original_device = W.device
    original_dtype = W.dtype
    W_cpu = W.detach().cpu().contiguous()
    rows, cols = W_cpu.shape
    diag, factors = _prepare_hessian(
        hessian,
        rows,
        cols,
        q_group_size,
    )
    output_groups = diag.shape[0]

    if init_importance is None:
        full_diag = diag + np.sum(factors * factors, axis=3)
        init_importance = torch.from_numpy(
            full_diag.mean(axis=0).reshape(-1).astype(np.float32)
        )
        init_is_fisher = False
    else:
        if not isinstance(init_importance, torch.Tensor):
            init_importance = torch.as_tensor(init_importance)
        init_importance = init_importance.detach().cpu().float().reshape(-1)
        if init_importance.numel() != cols:
            raise ValueError(
                f"method12 init importance has {init_importance.numel()} values, expected {cols}."
            )
        init_is_fisher = True

    metadata = _cache_metadata(
        W_cpu,
        hessian,
        layer_name,
        model_path,
        q_group_size,
        method12_max_iter,
        method12_cd_sweeps,
        method12_joint_affine,
        method12_ridge,
        method12_scale_eps,
    )
    cached = _load_cache(
        method12_cache_dir if method12_use_cache else None,
        layer_name,
        metadata,
        method12_overwrite_cache,
    )

    if cached is None:
        direct_state = None
        if init_is_fisher:
            direct_state = _load_method11_initial_state(
                method11_init_cache_dir,
                layer_name,
                W_cpu,
                init_importance,
                model_path,
                q_group_size,
            )
        method11_init_cache_hit = direct_state is not None
        base_state = direct_state or quantize.method11_hlut_quantize_tensor(
            W_cpu,
            n_bit=2,
            q_group_size=q_group_size,
            per_row=True,
            scale_only=False,
            sample_weight=init_importance,
            fisher_sample_weight=init_is_fisher,
            method11_num_tables=4,
            method11_table_size=4,
            method11_joint_affine=True,
            method11_max_iter=8,
            method11_tol=1e-6,
            method11_ridge=1e-6,
            method11_scale_eps=1e-6,
            method11_parallel_jobs=max(1, int(method12_parallel_jobs)),
            method11_cache_dir=method11_init_cache_dir,
            method11_use_cache=bool(method11_init_cache_dir),
            method11_overwrite_cache=False,
            method11_return_stats=False,
            parallelize=parallelize,
            layer_name=layer_name,
            model_path=model_path,
        )
        if not method11_init_cache_hit:
            method11_init_cache_hit = bool(base_state["stats"].get("cache_hit"))
        initial_lut = base_state["lut"].detach().cpu().float().numpy()
        initial_affine = (
            base_state["scales_and_zeros"]
            .detach()
            .cpu()
            .float()
            .transpose(0, 1)
            .contiguous()
            .numpy()
        )
        del base_state
        optimize_iterations = int(method12_max_iter)
        cache_hit = False
    else:
        initial_lut = cached["lut"].detach().cpu().float().numpy()
        initial_affine = (
            cached["scales_and_zeros"]
            .detach()
            .cpu()
            .float()
            .transpose(0, 1)
            .contiguous()
            .numpy()
        )
        optimize_iterations = 0
        cache_hit = True
        method11_init_cache_hit = None

    initial_scales = initial_affine[:, :, 0].astype(np.float64)
    initial_offsets = (
        initial_affine[:, :, 1] - 2.0 * initial_affine[:, :, 0]
    ).astype(np.float64)
    W_numpy = W_cpu.float().numpy().astype(np.float64, copy=False)

    jobs = min(
        max(1, int(method12_parallel_jobs if parallelize else 1)),
        rows,
    )
    worker = delayed(_optimize_row)
    if jobs == 1:
        optimized = [
            _optimize_row(
                row,
                W_numpy[row],
                initial_lut[row],
                initial_scales[row],
                initial_offsets[row],
                diag,
                factors,
                output_groups,
                rows,
                q_group_size,
                optimize_iterations,
                int(method12_cd_sweeps),
                bool(method12_joint_affine),
                float(method12_ridge),
                float(method12_scale_eps),
            )
            for row in range(rows)
        ]
    else:
        parallel_options = {
            "n_jobs": jobs,
            "pre_dispatch": jobs,
            "batch_size": 4,
        }
        if parallel_backend == "threads":
            parallel_options.update(prefer="threads", require="sharedmem")
        else:
            parallel_options.update(
                backend="loky",
                max_nbytes="1M",
                mmap_mode="r",
            )
        optimized = Parallel(
            **parallel_options
        )(
            worker(
                row,
                W_numpy[row],
                initial_lut[row],
                initial_scales[row],
                initial_offsets[row],
                diag,
                factors,
                output_groups,
                rows,
                q_group_size,
                optimize_iterations,
                int(method12_cd_sweeps),
                bool(method12_joint_affine),
                float(method12_ridge),
                float(method12_scale_eps),
            )
            for row in range(rows)
        )

    codes = np.stack([entry[0] for entry in optimized], axis=0).reshape(rows, cols)
    table_ids = np.stack([entry[1] for entry in optimized], axis=0)
    lut = np.stack([entry[2] for entry in optimized], axis=0)
    scales = np.stack([entry[3] for entry in optimized], axis=0)
    offsets = np.stack([entry[4] for entry in optimized], axis=0)
    row_stats = [entry[5] for entry in optimized]
    zeros = offsets + 2.0 * scales
    scales_and_zeros = quantize.pack_scales_and_zeros(
        torch.from_numpy(scales.astype(np.float32)),
        torch.from_numpy(zeros.astype(np.float32)),
        W_cpu.shape,
    )
    table_usage = np.sum(
        np.asarray([entry["table_usage"] for entry in row_stats], dtype=np.int64),
        axis=0,
    )
    stats = {
        "method_name": METHOD12_NAME,
        "layer_name": layer_name,
        "cache_hit": bool(cache_hit),
        "method11_init_cache_hit": method11_init_cache_hit,
        "hessian_output_groups": int(output_groups),
        "hessian_blocks": int(diag.shape[1]),
        "hessian_block_size": int(diag.shape[2]),
        "hessian_rank": int(factors.shape[3]),
        "max_iter": int(method12_max_iter),
        "cd_sweeps": int(method12_cd_sweeps),
        "joint_affine": bool(method12_joint_affine),
        "parallel_backend": parallel_backend,
        "parallel_jobs": int(jobs),
        "initial_loss": float(sum(entry["initial_loss"] for entry in row_stats)),
        "final_loss": float(sum(entry["final_loss"] for entry in row_stats)),
        "mean_iterations": float(np.mean([entry["iterations"] for entry in row_stats])),
        "max_iterations": int(max(entry["iterations"] for entry in row_stats)),
        "empty_tables": int(sum(entry["empty_tables"] for entry in row_stats)),
        "affine_updates": int(sum(entry["affine_updates"] for entry in row_stats)),
        "table_usage": [int(value) for value in table_usage],
        "loss_monotonic": bool(all(entry["loss_monotonic"] for entry in row_stats)),
        "elapsed_seconds": float(time.time() - started),
    }

    state = {
        "codes": torch.from_numpy(codes.astype(np.uint8)),
        "table_ids": torch.from_numpy(table_ids.astype(np.uint8)),
        "lut": torch.from_numpy(lut.astype(np.float32)),
        "scales_and_zeros": scales_and_zeros.float(),
        "stats": stats,
    }
    stats.update(_storage_stats(rows, cols, q_group_size))
    if cached is None and method12_use_cache:
        cache_path = _save_cache(
            method12_cache_dir,
            layer_name,
            metadata,
            state,
            stats,
        )
        stats["cache_path"] = str(cache_path) if cache_path else None
    elif cached is not None:
        stats["cache_path"] = str(
            _cache_file(method12_cache_dir, layer_name, metadata)
        )
    _record_stats(layer_name, stats)
    state["original_device"] = str(original_device)
    state["original_dtype"] = str(original_dtype)
    return state


def method12_hlut_dequantize_tensor(state, dtype=torch.float32, device="cpu"):
    codes = state["codes"].long().cpu()
    table_ids = state["table_ids"].long().cpu()
    lut = state["lut"].float().cpu()
    affine = state["scales_and_zeros"].float().cpu().transpose(0, 1).contiguous()
    rows, cols = codes.shape
    groups = table_ids.shape[1]
    group_size = cols // groups
    row_index = torch.arange(rows).view(rows, 1)
    selected_lut = lut[row_index, table_ids]
    centroid = torch.gather(
        selected_lut,
        dim=2,
        index=codes.reshape(rows, groups, group_size),
    )
    scales = affine[:, :, 0].unsqueeze(-1)
    zeros = affine[:, :, 1].unsqueeze(-1)
    reconstructed = (centroid - 2.0) * scales + zeros
    return reconstructed.reshape(rows, cols).to(device=device, dtype=dtype)


def method12_hlut_reconstruct_tensor(W, **kwargs):
    state = method12_hlut_quantize_tensor(W, **kwargs)
    reconstructed = method12_hlut_dequantize_tensor(
        state,
        dtype=W.dtype,
        device=W.device,
    )
    del state
    torch.cuda.empty_cache()
    gc.collect()
    return reconstructed

