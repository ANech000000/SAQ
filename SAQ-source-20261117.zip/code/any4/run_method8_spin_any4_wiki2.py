import argparse
import gc
import json
import math
import os
import random
import subprocess
import sys
import time
from pathlib import Path

import torch
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

from calibrate import calibrate
from data_gptq import get_loaders, llama_eval
from quantize import quant_methods, quantize_model


BASELINES = {
    "fp16_ppl": 9.750678062438965,
    "original_any4_4bit_ppl": 10.618475914001465,
    "method2_dp_ppl": 10.555562973022461,
}


def run_cmd(cmd):
    try:
        return subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT).strip()
    except Exception as exc:
        return f"unavailable: {exc}"


def current_gpu_index():
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    return visible if visible else "all-visible"


def is_pow2(n):
    return n > 0 and (n & (n - 1)) == 0


def fwht_last_dim(x):
    n = x.shape[-1]
    if not is_pow2(n):
        raise ValueError(f"Hadamard dimension must be power of 2, got {n}")
    y = x.contiguous()
    orig_shape = y.shape
    y = y.reshape(-1, n)
    h = 1
    while h < n:
        y = y.reshape(-1, n // (2 * h), 2, h)
        a = y[:, :, 0, :].clone()
        b = y[:, :, 1, :].clone()
        y[:, :, 0, :] = a + b
        y[:, :, 1, :] = a - b
        y = y.reshape(-1, n)
        h *= 2
    y = y / math.sqrt(n)
    return y.reshape(orig_shape)


def right_random_hadamard(x, signs):
    return fwht_last_dim(x * signs.to(device=x.device, dtype=x.dtype))


def left_random_hadamard(weight, signs):
    rotated = fwht_last_dim((weight.T * signs.to(device=weight.device, dtype=weight.dtype))).T
    return rotated


def right_hadamard(x):
    return fwht_last_dim(x)


def left_hadamard(weight):
    return fwht_last_dim(weight.T).T


def apply_head_random_hadamard(weight, signs, head_dim, output):
    dtype = weight.dtype
    if output:
        transposed = weight.T.contiguous()
        shape = transposed.shape
        temp = transposed.reshape(-1, shape[-1] // head_dim, head_dim)
        temp = right_random_hadamard(temp, signs)
        return temp.reshape(shape).T.contiguous().to(dtype)
    shape = weight.shape
    temp = weight.contiguous().reshape(-1, shape[-1] // head_dim, head_dim)
    temp = right_random_hadamard(temp, signs)
    return temp.reshape(shape).contiguous().to(dtype)


class OnlineHadamardWrapper(torch.nn.Module):
    def __init__(self, module):
        super().__init__()
        self.module = module

    def forward(self, x):
        x_dtype = x.dtype
        x = fwht_last_dim(x.float()).to(x_dtype)
        return self.module(x)


def set_submodule(model, name, module):
    parent_name, child_name = name.rsplit(".", 1)
    parent = model.get_submodule(parent_name)
    setattr(parent, child_name, module)


def clone_tied_lm_head(model):
    if getattr(model.config, "tie_word_embeddings", False):
        old = model.lm_head
        new_head = torch.nn.Linear(old.in_features, old.out_features, bias=old.bias is not None, device=old.weight.device, dtype=old.weight.dtype)
        new_head.weight.data.copy_(old.weight.data)
        if old.bias is not None:
            new_head.bias.data.copy_(old.bias.data)
        model.lm_head = new_head
        model.config.tie_word_embeddings = False


def fuse_ln_linear(layernorm, linear_layers):
    for linear in linear_layers:
        dtype = linear.weight.data.dtype
        w = linear.weight.data.double()
        linear.weight.data = (w * layernorm.weight.data.double()).to(dtype)
        if getattr(layernorm, "bias", None) is not None:
            if linear.bias is None:
                linear.bias = torch.nn.Parameter(torch.zeros(linear.out_features, device=linear.weight.device, dtype=dtype))
            linear.bias.data = (linear.bias.data.double() + torch.matmul(w, layernorm.bias.data.double())).to(dtype)


def fuse_layer_norms(model):
    embed = model.model.embed_tokens
    embed.weight.data = (embed.weight.data.double() - embed.weight.data.double().mean(dim=-1, keepdim=True)).to(embed.weight.data.dtype)
    for layer in model.model.layers:
        fuse_ln_linear(layer.post_attention_layernorm, [layer.mlp.up_proj, layer.mlp.gate_proj])
        fuse_ln_linear(layer.input_layernorm, [layer.self_attn.q_proj, layer.self_attn.k_proj, layer.self_attn.v_proj])
        layer.post_attention_layernorm.weight.data = torch.ones_like(layer.post_attention_layernorm.weight.data)
        layer.input_layernorm.weight.data = torch.ones_like(layer.input_layernorm.weight.data)
    fuse_ln_linear(model.model.norm, [model.lm_head])
    model.model.norm.weight.data = torch.ones_like(model.model.norm.weight.data)


def apply_method8_rotation(model, seed):
    with torch.no_grad():
        clone_tied_lm_head(model)
        fuse_layer_norms(model)

        cfg = model.config
        hidden = cfg.hidden_size
        head_dim = hidden // cfg.num_attention_heads
        intermediate = cfg.intermediate_size
        if not (is_pow2(hidden) and is_pow2(head_dim) and is_pow2(intermediate)):
            raise ValueError(f"Method8 requires pow2 dimensions, got hidden={hidden}, head_dim={head_dim}, intermediate={intermediate}")

        generator = torch.Generator(device="cpu")
        generator.manual_seed(seed)
        r1_signs = (torch.randint(0, 2, (hidden,), generator=generator, dtype=torch.int8).float() * 2 - 1)

        def rotate_inplace(linear, mode, signs=None, head_output=None):
            dtype = linear.weight.data.dtype
            device = linear.weight.data.device
            w = linear.weight.data.float()
            if mode == "right_r1":
                rotated = right_random_hadamard(w, signs)
            elif mode == "left_r1":
                rotated = left_random_hadamard(w, signs)
            elif mode == "right_h":
                rotated = right_hadamard(w)
            elif mode == "head_r2":
                rotated = apply_head_random_hadamard(w, signs, head_dim, output=head_output)
            else:
                raise ValueError(mode)
            linear.weight.data = rotated.to(device=device, dtype=dtype).clone()

        rotate_inplace(model.model.embed_tokens, "right_r1", r1_signs)
        rotate_inplace(model.lm_head, "right_r1", r1_signs)

        for layer_idx, layer in enumerate(model.model.layers):
            r2_signs = (torch.randint(0, 2, (head_dim,), generator=generator, dtype=torch.int8).float() * 2 - 1)

            for linear in (layer.self_attn.q_proj, layer.self_attn.k_proj, layer.self_attn.v_proj, layer.mlp.up_proj, layer.mlp.gate_proj):
                rotate_inplace(linear, "right_r1", r1_signs)

            rotate_inplace(layer.self_attn.o_proj, "left_r1", r1_signs)
            rotate_inplace(layer.mlp.down_proj, "left_r1", r1_signs)

            rotate_inplace(layer.self_attn.v_proj, "head_r2", r2_signs, head_output=True)
            rotate_inplace(layer.self_attn.o_proj, "head_r2", r2_signs, head_output=False)
            rotate_inplace(layer.mlp.down_proj, "right_h")

        return {"seed": seed, "hidden_size": hidden, "head_dim": head_dim, "intermediate_size": intermediate}


def wrap_down_proj_online_hadamard(model):
    wrapped = []
    for name, module in list(model.named_modules()):
        if name.endswith("mlp.down_proj") and not isinstance(module, OnlineHadamardWrapper):
            set_submodule(model, name, OnlineHadamardWrapper(module))
            wrapped.append(name)
    return wrapped


def load_model_and_tokenizer(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
    ).to("cuda")
    model.eval()
    return model, tokenizer


def eval_wiki2(model, tokenizer, loader_samples, seqlen):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=loader_samples,
    )
    return llama_eval(model, testloader, "cuda", seqlen=seqlen)


def orthogonality_smoke(device):
    signs = torch.ones(64, device=device)
    eye = torch.eye(64, device=device)
    mat = right_random_hadamard(eye, signs)
    err = torch.max(torch.abs(mat.T @ mat - eye)).item()
    return err


def shape_smoke(device):
    linear = torch.nn.Linear(2048, 1024, bias=False, device=device, dtype=torch.float16)
    before = tuple(linear.weight.shape), linear.weight.dtype
    signs = torch.ones(2048)
    linear.weight.data = right_random_hadamard(linear.weight.data.float(), signs).to(linear.weight.dtype)
    after = tuple(linear.weight.shape), linear.weight.dtype
    return {"before": str(before), "after": str(after), "ok": before == after}


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--rotate-smoke-threshold", type=float, default=0.5)
    parser.add_argument("--skip-rotate-smoke", action="store_true")
    args = parser.parse_args()

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "command.txt").write_text(" ".join(sys.argv) + "\n")

    summary = {
        "method": "method8_spin_random_hadamard_any4",
        "baselines": BASELINES,
        "gpu": current_gpu_index(),
        "nvidia_smi_before": run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"]),
        "smoke": {},
        "results": {},
    }
    write_json(log_dir / "summary.json", summary)

    summary["smoke"]["orthogonality_max_error"] = orthogonality_smoke("cuda")
    summary["smoke"]["shape"] = shape_smoke("cuda")

    cfg = AutoConfig.from_pretrained(args.model_path, local_files_only=True, trust_remote_code=True)
    summary["smoke"]["config"] = {
        "hidden_size": cfg.hidden_size,
        "intermediate_size": cfg.intermediate_size,
        "num_hidden_layers": cfg.num_hidden_layers,
        "num_attention_heads": cfg.num_attention_heads,
        "head_dim": cfg.hidden_size // cfg.num_attention_heads,
        "tie_word_embeddings": cfg.tie_word_embeddings,
    }
    write_json(log_dir / "summary.json", summary)

    if not args.skip_rotate_smoke:
        started = time.time()
        model, tokenizer = load_model_and_tokenizer(args.model_path)
        rotation_meta = apply_method8_rotation(model, args.seed)
        wrapped = wrap_down_proj_online_hadamard(model)
        rotate_ppl = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
        rotate_elapsed = time.time() - started
        summary["results"]["rotate_only_fp16"] = {
            "ppl": rotate_ppl,
            "elapsed_sec": rotate_elapsed,
            "rotation": rotation_meta,
            "wrapped_down_proj": len(wrapped),
        }
        write_json(log_dir / "summary.json", summary)
        del model, tokenizer
        torch.cuda.empty_cache()
        gc.collect()
        if abs(rotate_ppl - BASELINES["fp16_ppl"]) > args.rotate_smoke_threshold:
            summary["status"] = "stopped_after_rotate_smoke"
            summary["reason"] = f"rotate-only PPL {rotate_ppl} differs from FP16 baseline by more than {args.rotate_smoke_threshold}"
            summary["nvidia_smi_after"] = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"])
            write_json(log_dir / "summary.json", summary)
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return

    started = time.time()
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    rotation_meta = apply_method8_rotation(model, args.seed)
    q_started = time.time()
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=quant_methods["anyq"],
        tokenizer=tokenizer,
        n_bit=4,
        skip_modules="lm_head",
        sample_weight=calibrate,
        scale_sample_weight=True,
    )
    q_elapsed = time.time() - q_started
    wrapped = wrap_down_proj_online_hadamard(model)
    model.eval()
    ppl = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
    elapsed = time.time() - started

    result = {
        "method": "method8_spin_random_hadamard_any4",
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "gpu": current_gpu_index(),
        "rotation": rotation_meta,
        "quant_args": {
            "n_bit": 4,
            "skip_modules": "lm_head",
            "sample_weight": "calibrate",
            "scale_sample_weight": True,
        },
        "wrapped_down_proj": len(wrapped),
        "quant_elapsed_sec": q_elapsed,
        "elapsed_sec": elapsed,
        "ppl": ppl,
    }
    summary["results"]["method8_4bit"] = result
    summary["status"] = "complete"
    summary["nvidia_smi_after"] = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"])
    write_json(log_dir / "results.json", result)
    write_json(log_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
