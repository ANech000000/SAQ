import gc
import hashlib
import json
import math
import os
import time
from pathlib import Path

import torch


METHOD14_NAME = "method14_aqlm_lite"
METHOD14_VERSION = "method14_aqlm_lite_v1"
_METHOD14_LAYER_STATS = {}


def reset_method14_stats():
    _METHOD14_LAYER_STATS.clear()


def get_method14_stats():
    return json.loads(json.dumps(_METHOD14_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD14_LAYER_STATS[layer_name or "<tensor>"] = stats


def _tensor_hash(tensor):
    value = tensor.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(value.shape)).encode("utf-8"))
    digest.update(str(value.dtype).encode("utf-8"))
    digest.update(memoryview(value.numpy()).cast("B"))
    return digest.hexdigest()


def _stable_seed(layer_name, seed):
    payload = f"{layer_name or '<tensor>'}:{int(seed)}".encode("utf-8")
    return int(hashlib.sha256(payload).hexdigest()[:8], 16)


def _nearest_indices(points, centroids, batch_size):
    if points.ndim != 2 or centroids.ndim != 2:
        raise ValueError("points and centroids must both be rank-2 tensors.")
    if points.shape[1] != centroids.shape[1]:
        raise ValueError("points and centroids must have the same vector dimension.")
    centroid_norm = (centroids * centroids).sum(dim=1).view(1, -1)
    labels = torch.empty(points.shape[0], dtype=torch.long, device=points.device)
    loss = torch.zeros((), dtype=torch.float64, device=points.device)
    for start in range(0, points.shape[0], batch_size):
        stop = min(start + batch_size, points.shape[0])
        batch = points[start:stop]
        distances = (
            (batch * batch).sum(dim=1, keepdim=True)
            + centroid_norm
            - 2.0 * batch @ centroids.t()
        )
        batch_loss, batch_labels = distances.min(dim=1)
        labels[start:stop] = batch_labels
        loss += batch_loss.double().sum()
    return labels, float(loss.item())


def _fit_kmeans(
    points,
    num_centroids,
    max_iter,
    seed,
    batch_size,
    tol=1e-5,
):
    if points.shape[0] == 0:
        raise ValueError("Cannot fit k-means on an empty tensor.")
    if num_centroids <= 0 or num_centroids > 256:
        raise ValueError("method14 supports between 1 and 256 centroids.")
    generator = torch.Generator(device="cpu").manual_seed(int(seed))
    if points.shape[0] >= num_centroids:
        initial = torch.randperm(
            points.shape[0], generator=generator
        )[:num_centroids]
    else:
        initial = torch.arange(num_centroids) % points.shape[0]
    centroids = points[initial.to(points.device)].clone()
    labels = None
    iterations = 0
    empty_total = 0
    for iteration in range(max(1, int(max_iter))):
        labels, _ = _nearest_indices(points, centroids, batch_size)
        sums = torch.zeros_like(centroids)
        sums.index_add_(0, labels, points)
        counts = torch.bincount(labels, minlength=num_centroids)
        nonempty = counts > 0
        updated = centroids.clone()
        updated[nonempty] = (
            sums[nonempty] / counts[nonempty].to(points.dtype).unsqueeze(1)
        )
        empty = (~nonempty).nonzero(as_tuple=False).flatten()
        empty_total += int(empty.numel())
        if empty.numel():
            replacement = (
                empty
                + iteration * max(1, empty.numel())
                + int(seed)
            ) % points.shape[0]
            updated[empty] = points[replacement]
        shift = float((updated - centroids).square().sum().sqrt().item())
        centroids = updated
        iterations = iteration + 1
        if shift <= tol:
            break
    labels, _ = _nearest_indices(points, centroids, batch_size)
    return centroids, labels, iterations, empty_total


def _reconstruct_vectors(codebooks, codes):
    reconstructed = torch.zeros(
        codes.shape[0],
        codebooks.shape[2],
        device=codebooks.device,
        dtype=codebooks.dtype,
    )
    for codebook_index in range(codebooks.shape[0]):
        reconstructed += codebooks[codebook_index][codes[:, codebook_index]]
    return reconstructed


def _assign_additive(points, codebooks, batch_size, sweeps, initial_codes=None):
    num_codebooks = codebooks.shape[0]
    if initial_codes is None:
        codes = torch.zeros(
            points.shape[0],
            num_codebooks,
            dtype=torch.long,
            device=points.device,
        )
        running = torch.zeros_like(points)
        for codebook_index in range(num_codebooks):
            labels, _ = _nearest_indices(
                points - running,
                codebooks[codebook_index],
                batch_size,
            )
            codes[:, codebook_index] = labels
            running += codebooks[codebook_index][labels]
    else:
        codes = initial_codes.clone()

    for _ in range(max(0, int(sweeps))):
        reconstructed = _reconstruct_vectors(codebooks, codes)
        for codebook_index in range(num_codebooks):
            selected = codebooks[codebook_index][codes[:, codebook_index]]
            target = points - (reconstructed - selected)
            labels, _ = _nearest_indices(
                target,
                codebooks[codebook_index],
                batch_size,
            )
            reconstructed += codebooks[codebook_index][labels] - selected
            codes[:, codebook_index] = labels
    return codes


def _update_codebooks(points, codebooks, codes):
    updated = codebooks.clone()
    reconstructed = _reconstruct_vectors(updated, codes)
    empty_total = 0
    for codebook_index in range(updated.shape[0]):
        selected = updated[codebook_index][codes[:, codebook_index]]
        target = points - (reconstructed - selected)
        sums = torch.zeros_like(updated[codebook_index])
        sums.index_add_(0, codes[:, codebook_index], target)
        counts = torch.bincount(
            codes[:, codebook_index],
            minlength=updated.shape[1],
        )
        nonempty = counts > 0
        replacement = updated[codebook_index].clone()
        replacement[nonempty] = (
            sums[nonempty] / counts[nonempty].to(points.dtype).unsqueeze(1)
        )
        empty_total += int((~nonempty).sum().item())
        reconstructed += replacement[codes[:, codebook_index]] - selected
        updated[codebook_index] = replacement
    return updated, empty_total


def _sample_vectors(points, max_samples, seed):
    if points.shape[0] <= max_samples:
        return points
    generator = torch.Generator(device="cpu").manual_seed(int(seed))
    indices = torch.randperm(points.shape[0], generator=generator)[:max_samples]
    return points[indices.to(points.device)]


def _usage_summary(codes, codebook_size):
    summaries = []
    for codebook_index in range(codes.shape[1]):
        counts = torch.bincount(
            codes[:, codebook_index],
            minlength=codebook_size,
        ).double()
        probabilities = counts[counts > 0] / counts.sum()
        entropy = float(
            (-(probabilities * probabilities.log2()).sum()).item()
        )
        summaries.append({
            "nonempty": int((counts > 0).sum().item()),
            "min_count": int(counts[counts > 0].min().item()),
            "max_count": int(counts.max().item()),
            "entropy_bits": entropy,
        })
    return summaries


def _storage_stats(rows, cols, in_group_size, num_codebooks, codebook_size):
    weights = rows * cols
    vectors = rows * (cols // in_group_size)
    code_bytes = vectors * num_codebooks
    codebook_bytes = (
        num_codebooks * codebook_size * in_group_size * 2
    )
    scale_bytes = rows * 2
    total_bytes = code_bytes + codebook_bytes + scale_bytes
    return {
        "logical_weight_count": int(weights),
        "code_bytes": int(code_bytes),
        "codebook_bytes": int(codebook_bytes),
        "scale_bytes": int(scale_bytes),
        "logical_total_bytes": int(total_bytes),
        "effective_bits_per_weight": float(total_bytes * 8.0 / weights),
    }


def _cache_metadata(
    weight,
    layer_name,
    model_path,
    in_group_size,
    num_codebooks,
    codebook_size,
    kmeans_iter,
    outer_iter,
    assignment_sweeps,
    seed,
):
    return {
        "algorithm": METHOD14_VERSION,
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(weight.shape),
        "weight_dtype": str(weight.dtype),
        "weight_hash": _tensor_hash(weight),
        "in_group_size": int(in_group_size),
        "out_group_size": 1,
        "num_codebooks": int(num_codebooks),
        "codebook_size": int(codebook_size),
        "kmeans_iter": int(kmeans_iter),
        "outer_iter": int(outer_iter),
        "assignment_sweeps": int(assignment_sweeps),
        "seed": int(seed),
    }


def _cache_file(cache_dir, layer_name, metadata):
    safe = (layer_name or "tensor").replace(".", "__").replace("/", "_")
    digest = hashlib.sha256(
        json.dumps(metadata, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]
    return Path(cache_dir) / f"{safe}.{digest}.pt"


def _load_cache(cache_dir, layer_name, metadata, overwrite):
    if not cache_dir or overwrite:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("metadata") != metadata:
        return None
    if not isinstance(payload.get("codebooks"), torch.Tensor):
        return None
    if not isinstance(payload.get("scales"), torch.Tensor):
        return None
    return payload


def _save_cache(cache_dir, layer_name, metadata, codebooks, scales, stats):
    if not cache_dir:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "metadata": metadata,
        "codebooks": codebooks.detach().cpu().float(),
        "scales": scales.detach().cpu().float(),
        "stats": stats,
    }, temporary)
    os.replace(temporary, path)
    return path


def method14_aqlm_quantize_tensor(
    weight,
    *,
    in_group_size=8,
    num_codebooks=2,
    codebook_size=256,
    max_samples=32768,
    kmeans_iter=12,
    outer_iter=2,
    assignment_sweeps=1,
    batch_size=32768,
    seed=0,
    layer_name=None,
    model_path=None,
    cache_dir=None,
    use_cache=True,
    overwrite_cache=False,
):
    if weight.ndim != 2:
        raise ValueError("method14 expects a rank-2 weight tensor.")
    rows, cols = weight.shape
    if cols % in_group_size != 0:
        raise ValueError("Input features must be divisible by in_group_size.")
    if num_codebooks <= 0:
        raise ValueError("num_codebooks must be positive.")
    if codebook_size <= 1 or codebook_size > 256:
        raise ValueError("codebook_size must be in [2, 256].")
    if max_samples < codebook_size:
        raise ValueError("max_samples must be at least codebook_size.")
    if batch_size <= 0:
        raise ValueError("batch_size must be positive.")

    started = time.time()
    original_device = weight.device
    original_dtype = weight.dtype
    metadata = _cache_metadata(
        weight,
        layer_name,
        model_path,
        in_group_size,
        num_codebooks,
        codebook_size,
        kmeans_iter,
        outer_iter,
        assignment_sweeps,
        seed,
    )
    cached = _load_cache(
        cache_dir if use_cache else None,
        layer_name,
        metadata,
        overwrite_cache,
    )

    working = weight.detach().to(device=original_device, dtype=torch.float32)
    scales = working.norm(dim=1, keepdim=True).clamp_min(1e-8)
    points = (
        working / scales
    ).reshape(rows, cols // in_group_size, in_group_size).reshape(-1, in_group_size)
    layer_seed = _stable_seed(layer_name, seed)
    kmeans_iterations = []
    empty_clusters = 0

    if cached is None:
        sample = _sample_vectors(points, max_samples, layer_seed)
        residual = sample
        initialized = []
        for codebook_index in range(num_codebooks):
            centroids, labels, iterations, empty = _fit_kmeans(
                residual,
                codebook_size,
                kmeans_iter,
                layer_seed + 104729 * codebook_index,
                batch_size,
            )
            initialized.append(centroids)
            residual = residual - centroids[labels]
            kmeans_iterations.append(int(iterations))
            empty_clusters += int(empty)
        codebooks = torch.stack(initialized, dim=0)
        codes = _assign_additive(
            points,
            codebooks,
            batch_size,
            assignment_sweeps,
        )
        initial_reconstruction = _reconstruct_vectors(codebooks, codes)
        initial_loss = float(
            (points - initial_reconstruction).square().sum().item()
        )
        best_loss = initial_loss
        best_codebooks = codebooks.clone()
        best_codes = codes.clone()
        loss_history = [initial_loss]
        accepted_iterations = 0

        for _ in range(max(0, int(outer_iter))):
            candidate_codebooks, empty = _update_codebooks(
                points,
                codebooks,
                codes,
            )
            empty_clusters += int(empty)
            candidate_codes = _assign_additive(
                points,
                candidate_codebooks,
                batch_size,
                assignment_sweeps,
                initial_codes=codes,
            )
            candidate_reconstruction = _reconstruct_vectors(
                candidate_codebooks,
                candidate_codes,
            )
            candidate_loss = float(
                (points - candidate_reconstruction).square().sum().item()
            )
            tolerance = max(1e-12, best_loss * 1e-8)
            if not math.isfinite(candidate_loss) or candidate_loss > best_loss + tolerance:
                break
            codebooks = candidate_codebooks
            codes = candidate_codes
            loss_history.append(candidate_loss)
            accepted_iterations += 1
            if candidate_loss < best_loss:
                best_loss = candidate_loss
                best_codebooks = codebooks.clone()
                best_codes = codes.clone()
            relative = (loss_history[-2] - candidate_loss) / max(
                loss_history[-2], 1e-12
            )
            if relative < 1e-6:
                break
        codebooks = best_codebooks
        codes = best_codes
        final_loss = best_loss
        cache_hit = False
    else:
        codebooks = cached["codebooks"].to(
            device=points.device,
            dtype=points.dtype,
        )
        scales = cached["scales"].to(
            device=points.device,
            dtype=points.dtype,
        )
        points = (
            working / scales
        ).reshape(rows, cols // in_group_size, in_group_size).reshape(-1, in_group_size)
        codes = _assign_additive(
            points,
            codebooks,
            batch_size,
            assignment_sweeps,
        )
        reconstructed = _reconstruct_vectors(codebooks, codes)
        final_loss = initial_loss = float(
            (points - reconstructed).square().sum().item()
        )
        loss_history = [final_loss]
        accepted_iterations = 0
        cache_hit = True
        kmeans_iterations = []

    stats = {
        "method_name": METHOD14_NAME,
        "layer_name": layer_name,
        "cache_hit": bool(cache_hit),
        "initial_loss": float(initial_loss),
        "final_loss": float(final_loss),
        "relative_improvement": float(
            (initial_loss - final_loss) / max(initial_loss, 1e-12)
        ),
        "accepted_iterations": int(accepted_iterations),
        "loss_monotonic": bool(
            all(
                loss_history[index + 1]
                <= loss_history[index] + max(1e-12, loss_history[index] * 1e-8)
                for index in range(len(loss_history) - 1)
            )
        ),
        "kmeans_iterations": kmeans_iterations,
        "empty_clusters": int(empty_clusters),
        "usage": _usage_summary(codes, codebook_size),
        "elapsed_seconds": float(time.time() - started),
    }
    stats.update(
        _storage_stats(
            rows,
            cols,
            in_group_size,
            num_codebooks,
            codebook_size,
        )
    )

    state = {
        "codes": codes.detach().cpu().to(torch.uint8).reshape(
            rows,
            cols // in_group_size,
            num_codebooks,
        ),
        "codebooks": codebooks.detach().cpu().float(),
        "scales": scales.detach().cpu().float(),
        "stats": stats,
        "shape": (rows, cols),
        "in_group_size": int(in_group_size),
        "original_device": str(original_device),
        "original_dtype": str(original_dtype),
    }
    if cached is None and use_cache:
        cache_path = _save_cache(
            cache_dir,
            layer_name,
            metadata,
            state["codebooks"],
            state["scales"],
            stats,
        )
        stats["cache_path"] = str(cache_path) if cache_path else None
    elif cached is not None:
        stats["cache_path"] = str(_cache_file(cache_dir, layer_name, metadata))
    _record_stats(layer_name, stats)
    return state


def method14_aqlm_dequantize_tensor(state, dtype=torch.float32, device="cpu"):
    rows, cols = state["shape"]
    codes = state["codes"].long().reshape(-1, state["codes"].shape[-1]).to(device)
    codebooks = state["codebooks"].to(device=device, dtype=torch.float32)
    scales = state["scales"].to(device=device, dtype=torch.float32)
    vectors = _reconstruct_vectors(codebooks, codes)
    reconstructed = vectors.reshape(rows, cols) * scales
    return reconstructed.to(dtype=dtype)


def method14_aqlm_reconstruct_tensor(weight, **kwargs):
    state = method14_aqlm_quantize_tensor(weight, **kwargs)
    reconstructed = method14_aqlm_dequantize_tensor(
        state,
        dtype=weight.dtype,
        device=weight.device,
    )
    del state
    torch.cuda.empty_cache()
    gc.collect()
    return reconstructed

