import argparse
import json
import os
import subprocess
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "experiments" / "method24_shape_w2" / "runner.py"
VENV_PYTHON = ROOT / "venv" / "bin" / "python"


def gpu_rows():
    output = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    rows = []
    for line in output.splitlines():
        index, memory, utilization = [
            part.strip() for part in line.split(",")
        ]
        rows.append(
            {
                "index": index,
                "memory_used_mib": int(memory),
                "utilization_percent": int(utilization),
            }
        )
    return rows


def main():
    parser = argparse.ArgumentParser(
        description="Launch method24 shape-W2 AWQ-any4 on one empty GPU"
    )
    parser.add_argument("--max-gpus", type=int, default=1)
    parser.add_argument("--empty-threshold-mib", type=int, default=100)
    parser.add_argument(
        "--model-path",
        default="/data/model/alpindale-Llama-3.2-1B",
    )
    parser.add_argument("--search-tokens", type=int, default=256)
    parser.add_argument("--row-chunk", type=int, default=256)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--awq-calib-samples", type=int, default=128)
    parser.add_argument("--awq-calib-seqlen", type=int, default=512)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--ppl-seqlen", type=int, default=2048)
    parser.add_argument(
        "--cache-dir",
        default="/data/lsz/any4/experiments/method24_shape_w2/cache",
    )
    parser.add_argument("--run-dir")
    args = parser.parse_args()

    if args.max_gpus != 1:
        raise SystemExit("Method24 uses exactly one GPU; pass --max-gpus 1")

    rows = gpu_rows()
    empty = [
        row
        for row in rows
        if row["memory_used_mib"] <= args.empty_threshold_mib
        and row["utilization_percent"] == 0
    ]
    if not empty:
        print(
            json.dumps(
                {"status": "no_empty_gpu", "gpu_scan": rows},
                indent=2,
            )
        )
        return 3

    gpu = empty[0]["index"]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = (
        Path(args.run_dir)
        if args.run_dir
        else ROOT
        / "logs"
        / "llama3.2-1b"
        / f"wiki2_method24_shape_w2_{timestamp}_gpu{gpu}"
    )
    run_dir.mkdir(parents=True, exist_ok=True)

    command = [
        str(VENV_PYTHON),
        str(RUNNER),
        "--model-path",
        args.model_path,
        "--run-dir",
        str(run_dir),
        "--physical-gpu",
        gpu,
        "--empty-threshold-mib",
        str(args.empty_threshold_mib),
        "--search-tokens",
        str(args.search_tokens),
        "--row-chunk",
        str(args.row_chunk),
        "--parallel-jobs",
        str(args.parallel_jobs),
        "--awq-calib-samples",
        str(args.awq_calib_samples),
        "--awq-calib-seqlen",
        str(args.awq_calib_seqlen),
        "--loader-samples",
        str(args.loader_samples),
        "--ppl-seqlen",
        str(args.ppl_seqlen),
        "--cache-dir",
        args.cache_dir,
    ]
    command_text = " ".join(command)
    (run_dir / "command.txt").write_text(
        command_text + "\n",
        encoding="utf-8",
    )

    launch_state = {
        "method": "method24_shape_w2_awq_any4",
        "status": "starting",
        "selected_gpu": gpu,
        "gpu_scan": rows,
        "max_gpus": 1,
        "command": command,
    }
    launcher_path = run_dir / "launcher.json"
    launcher_path.write_text(
        json.dumps(launch_state, indent=2) + "\n",
        encoding="utf-8",
    )

    env = os.environ.copy()
    env.update(
        {
            "CUDA_VISIBLE_DEVICES": gpu,
            "TRANSFORMERS_OFFLINE": "1",
            "HF_DATASETS_OFFLINE": "1",
            "HF_DATASETS_CACHE": "/home/ubuntu/.cache/huggingface/datasets",
            "TOKENIZERS_PARALLELISM": "false",
            "OPENBLAS_NUM_THREADS": "1",
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
            "VECLIB_MAXIMUM_THREADS": "1",
        }
    )
    with (run_dir / "run.log").open("a", encoding="utf-8") as log:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
        )

    launch_state["status"] = (
        "complete" if completed.returncode == 0 else "failed"
    )
    launch_state["return_code"] = completed.returncode
    launcher_path.write_text(
        json.dumps(launch_state, indent=2) + "\n",
        encoding="utf-8",
    )
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())

