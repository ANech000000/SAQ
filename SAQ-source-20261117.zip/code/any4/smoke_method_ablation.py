import itertools
import json
import numpy as np
import tempfile
import torch

import kmeans
import quantize


def brute_force_1d(x, k):
    x = np.sort(np.asarray(x, dtype=np.float64))
    n = len(x)
    best = float('inf')
    for cuts in itertools.combinations(range(1, n), k - 1):
        starts = (0,) + cuts
        ends = cuts + (n,)
        sse = 0.0
        for a, b in zip(starts, ends):
            seg = x[a:b]
            sse += ((seg - seg.mean()) ** 2).sum()
        best = min(best, sse)
    return best


def check_dp():
    x = np.array([0.0, 0.1, 1.0, 1.1, 5.0, 5.2]).reshape(-1, 1)
    assign_val, centers, labels = kmeans.kmeans_1d_dp(x, n_clusters=3)
    dp_sse = float(((x.reshape(-1) - assign_val.reshape(-1)) ** 2).sum())
    brute = brute_force_1d(x.reshape(-1), 3)
    assert abs(dp_sse - brute) < 1e-8, (dp_sse, brute, centers, labels)


def check_dynamic_selector():
    w = torch.zeros(3, 128)
    w[0] = torch.linspace(-0.01, 0.01, 128)
    w[1] = torch.cat([torch.linspace(-1, 1, 64), torch.linspace(-0.2, 0.2, 64)])
    w[2] = torch.randn(128) * 0.1
    w[2, 0] = 9.0
    selected = quantize.choose_dynamic_group_sizes(w, dynamic_group_thresholds=(0.8, 1.2))
    assert selected.shape == (3, 1)
    assert set(selected.flatten().tolist()).issubset({32, 64, 128})


def check_quant_paths():
    torch.manual_seed(0)
    w = torch.randn(8, 128, dtype=torch.float16, device='cuda')
    for group_size, cluster_row in [('dynamic', quantize.cluster_row_scikit), (128, quantize.cluster_row_dp), ('dynamic', quantize.cluster_row_dp)]:
        assign, lut, scales_and_zeros = quantize.anyq_quantize_tensor(
            w,
            n_bit=4,
            q_group_size=group_size,
            cluster_row=cluster_row,
            parallelize=False,
        )
        wdeq = quantize.anyq_dequantize_tensor(assign, lut, scales_and_zeros, n_bit=4, q_group_size=group_size)
        assert wdeq.shape == w.shape
        assert torch.isfinite(wdeq).all()


def check_dp_cache():
    cache_dir = tempfile.mkdtemp(prefix='any4_dp_cache_smoke_')
    x = np.array([[0.0, 0.05, 0.1, 1.0, 1.1, 2.0, 2.1, 2.2]], dtype=np.float32)
    sw1 = np.ones(x.shape[1], dtype=np.float32)
    sw2 = np.linspace(1.0, 3.0, x.shape[1], dtype=np.float32)

    stats_fill = cache_dir + '/fill_stats.json'
    assign1, any41, vals1 = quantize.cluster_rows(
        x,
        cluster_row=quantize.cluster_row_dp,
        n_bit=2,
        sample_weight=sw1,
        dp_cache_dir=cache_dir,
        dp_cache_mode='readwrite',
        dp_cache_stats_path=stats_fill,
        layer_name='smoke.layer',
        dp_cache_q_group_size=128,
        dp_cache_scale_sample_weight=True,
    )
    fill = json.loads(open(stats_fill).read())
    assert fill['misses'] == 1 and fill['writes'] == 1 and fill['hits'] == 0, fill

    stats_hit = cache_dir + '/hit_stats.json'
    assign2, any42, vals2 = quantize.cluster_rows(
        x,
        cluster_row=quantize.cluster_row_dp,
        n_bit=2,
        sample_weight=sw1,
        dp_cache_dir=cache_dir,
        dp_cache_mode='readonly',
        dp_cache_verify=True,
        dp_cache_stats_path=stats_hit,
        layer_name='smoke.layer',
        dp_cache_q_group_size=128,
        dp_cache_scale_sample_weight=True,
    )
    hit = json.loads(open(stats_hit).read())
    assert hit['hits'] == 1 and hit['verify_ok'] == 1, hit
    assert torch.allclose(vals1.float(), vals2.float(), atol=1e-5, rtol=1e-5)

    stats_diff = cache_dir + '/diff_weight_stats.json'
    quantize.cluster_rows(
        x,
        cluster_row=quantize.cluster_row_dp,
        n_bit=2,
        sample_weight=sw2,
        dp_cache_dir=cache_dir,
        dp_cache_mode='readonly',
        dp_cache_stats_path=stats_diff,
        layer_name='smoke.layer',
        dp_cache_q_group_size=128,
        dp_cache_scale_sample_weight=True,
    )
    diff = json.loads(open(stats_diff).read())
    assert diff['hits'] == 0 and diff['misses'] == 1 and diff['readonly_misses'] == 1, diff


if __name__ == '__main__':
    check_dp()
    check_dynamic_selector()
    check_quant_paths()
    check_dp_cache()
    print('smoke ok')
