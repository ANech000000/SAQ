#!/usr/bin/env bash
set -euo pipefail

cd /data/lsz/any4

EXP="logs/llama3.2-1b/c4_ptb_ppl_original_method2_20260707_gpu3_gpu4"
mkdir -p "$EXP"
echo "$EXP" > /tmp/any4_c4_ptb_latest_exp.txt

{
  echo "start_$(date +%Y%m%d_%H%M%S)"
  echo "gpu_before"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits

  echo "wave1_c4_start"
  CUDA_VISIBLE_DEVICES=3 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset c4 \
    --method original_any4 \
    > "$EXP/c4_original_any4.run.log" 2>&1 &
  p1=$!
  CUDA_VISIBLE_DEVICES=4 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset c4 \
    --method method2_dp_kmeans \
    > "$EXP/c4_method2_dp_kmeans.run.log" 2>&1 &
  p2=$!
  wait "$p1"
  s1=$?
  wait "$p2"
  s2=$?
  echo "wave1_status $s1 $s2"
  if [ "$s1" -ne 0 ] || [ "$s2" -ne 0 ]; then
    exit 1
  fi

  echo "wave2_ptb_start"
  CUDA_VISIBLE_DEVICES=3 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset ptb \
    --method original_any4 \
    > "$EXP/ptb_original_any4.run.log" 2>&1 &
  p3=$!
  CUDA_VISIBLE_DEVICES=4 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset ptb \
    --method method2_dp_kmeans \
    > "$EXP/ptb_method2_dp_kmeans.run.log" 2>&1 &
  p4=$!
  wait "$p3"
  s3=$?
  wait "$p4"
  s4=$?
  echo "wave2_status $s3 $s4"
  if [ "$s3" -ne 0 ] || [ "$s4" -ne 0 ]; then
    exit 1
  fi

  ./venv/bin/python - <<'PY'
import json
from pathlib import Path

exp = Path("logs/llama3.2-1b/c4_ptb_ppl_original_method2_20260707_gpu3_gpu4")
summary = {"experiment_dir": str(exp), "datasets": {}}
for dataset in ["c4", "ptb"]:
    summary["datasets"][dataset] = {}
    for method in ["original_any4", "method2_dp_kmeans"]:
        p = exp / dataset / method / "results.json"
        summary["datasets"][dataset][method] = json.loads(p.read_text())
(exp / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(summary, indent=2, ensure_ascii=False))
PY

  echo "gpu_after"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
  echo "done_$(date +%Y%m%d_%H%M%S)"
} | tee "$EXP/run.log"
