import argparse
import gc
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from calibrate import calibrate
from data_gptq import get_loaders, llama_eval
from quantize import quant_methods, quantize_model

BASELINES = {
    "fp16_ppl": 9.750678062438965,
    "original_any4_4bit_ppl": 10.618475914001465,
}

METHODS = {
    "method1_dynamic_group": {
        "description": "??1: dynamic group size + custom Lloyd k-means (non-DP)",
        "quant_args": {"group_size": "dynamic", "cluster_row": "custom"},
    },
    "method2_dp_kmeans": {
        "description": "??2: fixed group size 128 + DP 1D k-means",
        "quant_args": {"group_size": 128, "cluster_row": "dp"},
    },
    "method3_dynamic_plus_dp": {
        "description": "??3: dynamic group size + DP 1D k-means",
        "quant_args": {"group_size": "dynamic", "cluster_row": "dp"},
    },
    "method7_two_lut_per_row": {
        "description": "方法7: original scikit any4, two 16-value LUTs per weight row",
        "quant_args": {"group_size": 128, "cluster_row": "scikit", "method7_two_lut_per_row": True},
    },
}


def run_cmd(cmd):
    try:
        return subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT).strip()
    except Exception as exc:
        return f"unavailable: {exc}"


def current_gpu_index():
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    return visible if visible else "all-visible"


def load_model_and_tokenizer(model_path: str, dtype: torch.dtype):
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=dtype,
        device_map=None,
    ).to("cuda")
    model.eval()
    return model, tokenizer


def eval_wiki2(model, tokenizer, loader_samples: int, seqlen: int):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=loader_samples,
    )
    return llama_eval(model, testloader, "cuda", seqlen=seqlen)


def run_method(method_name, args):
    method = METHODS[method_name]
    method_dir = Path(args.log_dir) / method_name
    method_dir.mkdir(parents=True, exist_ok=True)
    command = " ".join(sys.argv)
    (method_dir / "command.txt").write_text(command + "\n")
    dp_cache_stats_path = args.dp_cache_stats_path
    if args.dp_cache_mode != "off" and not dp_cache_stats_path:
        dp_cache_stats_path = str(method_dir / "dp_cache_stats.json")

    started = time.time()
    model, tokenizer = load_model_and_tokenizer(args.model_path, torch.float16)
    qargs = dict(method["quant_args"])
    qargs.update({
        "n_bit": 4,
        "skip_modules": "lm_head",
        "sample_weight": calibrate,
        "scale_sample_weight": True,
        "pseudo": True,
        "parallelize": True,
        "parallel_jobs": 32,
    })
    if args.dp_cache_mode != "off":
        qargs.update({
            "dp_cache_dir": args.dp_cache_dir,
            "dp_cache_mode": args.dp_cache_mode,
            "dp_cache_verify": args.dp_cache_verify,
            "dp_cache_stats_path": dp_cache_stats_path,
        })
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=quant_methods["anyq"],
        tokenizer=tokenizer,
        **qargs,
    )
    model.eval()
    ppl = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
    elapsed = time.time() - started
    dp_cache_stats = None
    if dp_cache_stats_path and Path(dp_cache_stats_path).exists():
        dp_cache_stats = json.loads(Path(dp_cache_stats_path).read_text())
    result = {
        "method": method_name,
        "description": method["description"],
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "quant_args": {k: str(v) for k, v in qargs.items() if k != "sample_weight"},
        "gpu": current_gpu_index(),
        "elapsed_sec": elapsed,
        "ppl": ppl,
        "dp_cache_stats": dp_cache_stats,
    }
    (method_dir / "results.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--log-dir", default="logs/llama3.2-1b/wiki2_method_ablation")
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--methods", nargs="+", default=list(METHODS.keys()), choices=list(METHODS.keys()))
    parser.add_argument("--dp-cache-dir", default=None)
    parser.add_argument("--dp-cache-mode", choices=["off", "readwrite", "readonly"], default="off")
    parser.add_argument("--dp-cache-verify", action="store_true")
    parser.add_argument("--dp-cache-stats-path", default=None)
    args = parser.parse_args()

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    summary_path = log_dir / "summary.json"
    summary = {
        "baselines": BASELINES,
        "gpu": current_gpu_index(),
        "nvidia_smi_before": run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"]),
        "methods": {},
    }
    print(json.dumps({"starting": args.methods, "gpu": summary["gpu"]}, ensure_ascii=False))
    for method_name in args.methods:
        result = run_method(method_name, args)
        summary["methods"][method_name] = result
        summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    summary["nvidia_smi_after"] = run_cmd(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"])
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
