import gc
import hashlib
import json
import math
import os
import time
from pathlib import Path

import torch

import method14_quant


METHOD15_NAME = "method15_guided_aqlm"
METHOD15_VERSION = "method15_guided_aqlm_v1"
_METHOD15_LAYER_STATS = {}


def reset_method15_stats():
    _METHOD15_LAYER_STATS.clear()


def get_method15_stats():
    return json.loads(json.dumps(_METHOD15_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD15_LAYER_STATS[layer_name or "<tensor>"] = stats


def _prepare_hessian(hessian, rows, cols, in_group_size, device):
    if not isinstance(hessian, dict):
        raise ValueError("method15 requires a Hessian dictionary.")
    diag = hessian.get("diag")
    factors = hessian.get("factors")
    if not isinstance(diag, torch.Tensor) or not isinstance(factors, torch.Tensor):
        raise ValueError("method15 Hessian must contain tensor diag and factors.")
    diag = torch.nan_to_num(
        diag.detach().to(device=device, dtype=torch.float32),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    ).clamp_min_(0.0)
    factors = torch.nan_to_num(
        factors.detach().to(device=device, dtype=torch.float32),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )
    if diag.ndim != 3 or factors.ndim != 4:
        raise ValueError("method15 Hessian has invalid rank.")
    if tuple(factors.shape[:3]) != tuple(diag.shape):
        raise ValueError("method15 Hessian diag and factors are incompatible.")
    output_groups, blocks, block_size = diag.shape
    if blocks * block_size != cols:
        raise ValueError("method15 Hessian does not cover all input columns.")
    if block_size % in_group_size != 0:
        raise ValueError("Hessian block size must be divisible by in_group_size.")
    if rows % output_groups != 0:
        raise ValueError("Output rows must be divisible by Hessian output groups.")
    empty = (
        diag.sum(dim=(1, 2))
        + factors.square().sum(dim=(1, 2, 3))
    ) <= 0
    if empty.any():
        diag[empty] = 1.0
        factors[empty] = 0.0
    return diag, factors


def _guided_loss_from_error(error, diag, factors):
    rows, cols = error.shape
    output_groups, blocks, block_size = diag.shape
    rows_per_group = rows // output_groups
    total = error.new_zeros(())
    for output_group in range(output_groups):
        start = output_group * rows_per_group
        stop = start + rows_per_group
        grouped = error[start:stop].reshape(rows_per_group, blocks, block_size)
        total = total + (
            grouped.square() * diag[output_group].unsqueeze(0)
        ).sum()
        projection = torch.einsum(
            "rbi,bik->rbk",
            grouped,
            factors[output_group],
        )
        total = total + projection.square().sum()
    return total


def _dense_hessian(diag, factors):
    return torch.diag_embed(diag) + torch.einsum(
        "gbir,gbjr->gbij",
        factors,
        factors,
    )


@torch.no_grad()
def _guided_assign_codes(
    weight,
    scales,
    codebooks,
    codes,
    diag,
    factors,
    in_group_size,
    sweeps,
    block_chunk,
):
    rows, cols = weight.shape
    output_groups, blocks, block_size = diag.shape
    vectors_per_block = block_size // in_group_size
    rows_per_group = rows // output_groups
    codes_view = codes.reshape(
        rows,
        blocks,
        vectors_per_block,
        codebooks.shape[0],
    ).clone()
    reconstructed_vectors = method14_quant._reconstruct_vectors(
        codebooks,
        codes.reshape(-1, codebooks.shape[0]),
    )
    reconstructed_blocks = reconstructed_vectors.reshape(
        rows,
        blocks,
        block_size,
    )
    weight_blocks = weight.reshape(rows, blocks, block_size)
    scale_blocks = scales.reshape(rows, 1, 1)
    error_blocks = weight_blocks - scale_blocks * reconstructed_blocks
    hessian = _dense_hessian(diag, factors)

    for _ in range(max(0, int(sweeps))):
        for output_group in range(output_groups):
            row_start = output_group * rows_per_group
            row_stop = row_start + rows_per_group
            group_scale = scale_blocks[row_start:row_stop]
            for block_start in range(0, blocks, block_chunk):
                block_stop = min(block_start + block_chunk, blocks)
                block_slice = slice(block_start, block_stop)
                group_weight = weight_blocks[
                    row_start:row_stop, block_slice
                ]
                group_error = error_blocks[
                    row_start:row_stop, block_slice
                ]
                group_reconstruction = reconstructed_blocks[
                    row_start:row_stop, block_slice
                ]
                group_codes = codes_view[
                    row_start:row_stop, block_slice
                ]
                chunk_hessian = hessian[
                    output_group, block_slice
                ]

                for local_vector in range(vectors_per_block):
                    segment_start = local_vector * in_group_size
                    segment_stop = segment_start + in_group_size
                    segment = slice(segment_start, segment_stop)
                    hss = chunk_hessian[:, segment, segment]
                    h_columns = chunk_hessian[:, :, segment]
                    for codebook_index in range(codebooks.shape[0]):
                        current_labels = group_codes[
                            :, :, local_vector, codebook_index
                        ]
                        current_component = codebooks[
                            codebook_index
                        ][current_labels]
                        current_reconstruction = group_reconstruction[
                            :, :, segment
                        ]
                        other = current_reconstruction - current_component
                        candidates = (
                            other.unsqueeze(2)
                            + codebooks[codebook_index].view(
                                1,
                                1,
                                codebooks.shape[1],
                                in_group_size,
                            )
                        )
                        candidate_error = (
                            group_weight[:, :, segment].unsqueeze(2)
                            - group_scale.unsqueeze(2) * candidates
                        )
                        current_error_segment = group_error[:, :, segment]
                        full_gradient = torch.einsum(
                            "rcj,cji->rci",
                            group_error,
                            h_columns,
                        )
                        self_gradient = torch.einsum(
                            "rci,cij->rcj",
                            current_error_segment,
                            hss,
                        )
                        cross = full_gradient - self_gradient
                        objective = torch.einsum(
                            "rcki,cij,rckj->rck",
                            candidate_error,
                            hss,
                            candidate_error,
                        )
                        objective = objective + 2.0 * (
                            candidate_error * cross.unsqueeze(2)
                        ).sum(dim=-1)
                        labels = objective.argmin(dim=-1)
                        new_component = codebooks[
                            codebook_index
                        ][labels]
                        delta = new_component - current_component
                        group_codes[
                            :, :, local_vector, codebook_index
                        ] = labels
                        group_reconstruction[:, :, segment] += delta
                        group_error[:, :, segment] -= group_scale * delta

    flat_codes = codes_view.reshape(
        rows,
        cols // in_group_size,
        codebooks.shape[0],
    )
    reconstruction = reconstructed_blocks.reshape(rows, cols) * scales
    error = weight - reconstruction
    loss = float(_guided_loss_from_error(error, diag, factors).item())
    return flat_codes, reconstruction, loss


def _reconstruct_weight(codebooks, codes, scales, rows, cols):
    vectors = method14_quant._reconstruct_vectors(
        codebooks,
        codes.reshape(-1, codebooks.shape[0]),
    )
    return vectors.reshape(rows, cols) * scales


def _optimize_codebooks(
    weight,
    scales,
    codebooks,
    codes,
    diag,
    factors,
    steps,
    learning_rate,
):
    if steps <= 0:
        reconstructed = _reconstruct_weight(
            codebooks,
            codes,
            scales,
            *weight.shape,
        )
        loss = float(
            _guided_loss_from_error(
                weight - reconstructed,
                diag,
                factors,
            ).item()
        )
        return codebooks, loss, 0

    parameter = torch.nn.Parameter(codebooks.clone())
    optimizer = torch.optim.Adam(
        [parameter],
        lr=float(learning_rate),
        betas=(0.0, 0.95),
        amsgrad=True,
    )
    best = codebooks.clone()
    with torch.no_grad():
        initial = _reconstruct_weight(
            parameter,
            codes,
            scales,
            *weight.shape,
        )
        best_loss = float(
            _guided_loss_from_error(
                weight - initial,
                diag,
                factors,
            ).item()
        )
    accepted = 0
    normalizer = max(float(weight.numel()), 1.0)

    for _ in range(int(steps)):
        optimizer.zero_grad(set_to_none=True)
        reconstructed = _reconstruct_weight(
            parameter,
            codes,
            scales,
            *weight.shape,
        )
        loss = _guided_loss_from_error(
            weight - reconstructed,
            diag,
            factors,
        )
        if not torch.isfinite(loss):
            break
        (loss / normalizer).backward()
        optimizer.step()
        with torch.no_grad():
            candidate = _reconstruct_weight(
                parameter,
                codes,
                scales,
                *weight.shape,
            )
            candidate_loss = float(
                _guided_loss_from_error(
                    weight - candidate,
                    diag,
                    factors,
                ).item()
            )
            if math.isfinite(candidate_loss) and candidate_loss < best_loss:
                best_loss = candidate_loss
                best = parameter.detach().clone()
                accepted += 1
    return best, best_loss, accepted


def _cache_metadata(
    weight,
    hessian,
    layer_name,
    model_path,
    in_group_size,
    guided_sweeps,
    codebook_steps,
    learning_rate,
    block_chunk,
    codebook_size,
    base_max_samples,
    base_kmeans_iter,
    base_outer_iter,
    base_assignment_sweeps,
    base_batch_size,
    seed,
):
    return {
        "algorithm": METHOD15_VERSION,
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(weight.shape),
        "weight_dtype": str(weight.dtype),
        "weight_hash": method14_quant._tensor_hash(weight),
        "hessian_diag_hash": method14_quant._tensor_hash(hessian["diag"]),
        "hessian_factors_hash": method14_quant._tensor_hash(hessian["factors"]),
        "in_group_size": int(in_group_size),
        "guided_sweeps": int(guided_sweeps),
        "codebook_steps": int(codebook_steps),
        "learning_rate": float(learning_rate),
        "block_chunk": int(block_chunk),
        "num_codebooks": 2,
        "codebook_size": int(codebook_size),
        "base_algorithm": method14_quant.METHOD14_VERSION,
        "base_max_samples": int(base_max_samples),
        "base_kmeans_iter": int(base_kmeans_iter),
        "base_outer_iter": int(base_outer_iter),
        "base_assignment_sweeps": int(base_assignment_sweeps),
        "base_batch_size": int(base_batch_size),
        "seed": int(seed),
    }


def _cache_file(cache_dir, layer_name, metadata):
    safe = (layer_name or "tensor").replace(".", "__").replace("/", "_")
    digest = hashlib.sha256(
        json.dumps(metadata, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]
    return Path(cache_dir) / f"{safe}.{digest}.pt"


def _load_cache(cache_dir, layer_name, metadata, overwrite):
    if not cache_dir or overwrite:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("metadata") != metadata:
        return None
    if not isinstance(payload.get("codebooks"), torch.Tensor):
        return None
    if not isinstance(payload.get("scales"), torch.Tensor):
        return None
    return payload


def _save_cache(cache_dir, layer_name, metadata, codebooks, scales, stats):
    if not cache_dir:
        return None
    path = _cache_file(cache_dir, layer_name, metadata)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "metadata": metadata,
        "codebooks": codebooks.detach().cpu().float(),
        "scales": scales.detach().cpu().float(),
        "stats": stats,
    }, temporary)
    os.replace(temporary, path)
    return path


def method15_guided_aqlm_quantize_tensor(
    weight,
    *,
    hessian,
    layer_name=None,
    model_path=None,
    base_cache_dir=None,
    cache_dir=None,
    use_cache=True,
    overwrite_cache=False,
    in_group_size=8,
    guided_sweeps=1,
    codebook_steps=0,
    learning_rate=1e-2,
    block_chunk=2,
    codebook_size=256,
    base_max_samples=32768,
    base_kmeans_iter=12,
    base_outer_iter=2,
    base_assignment_sweeps=1,
    base_batch_size=32768,
    seed=0,
):
    if weight.ndim != 2:
        raise ValueError("method15 expects a rank-2 weight tensor.")
    if in_group_size <= 0:
        raise ValueError("in_group_size must be positive.")
    if weight.shape[1] % in_group_size != 0:
        raise ValueError("Input features must be divisible by in_group_size.")
    if block_chunk <= 0:
        raise ValueError("block_chunk must be positive.")
    if guided_sweeps < 0:
        raise ValueError("guided_sweeps must be nonnegative.")
    if codebook_steps < 0:
        raise ValueError("codebook_steps must be nonnegative.")
    if codebook_steps > 0 and learning_rate <= 0:
        raise ValueError("learning_rate must be positive.")
    if codebook_size <= 1 or codebook_size > 256:
        raise ValueError("codebook_size must be in [2, 256].")
    if base_max_samples < codebook_size:
        raise ValueError("base_max_samples must be at least codebook_size.")
    started = time.time()
    rows, cols = weight.shape
    device = weight.device
    diag, factors = _prepare_hessian(
        hessian,
        rows,
        cols,
        in_group_size,
        device,
    )
    metadata = _cache_metadata(
        weight,
        hessian,
        layer_name,
        model_path,
        in_group_size,
        guided_sweeps,
        codebook_steps,
        learning_rate,
        block_chunk,
        codebook_size,
        base_max_samples,
        base_kmeans_iter,
        base_outer_iter,
        base_assignment_sweeps,
        base_batch_size,
        seed,
    )
    cached = _load_cache(
        cache_dir if use_cache else None,
        layer_name,
        metadata,
        overwrite_cache,
    )

    base = method14_quant.method14_aqlm_quantize_tensor(
        weight,
        in_group_size=in_group_size,
        num_codebooks=2,
        codebook_size=codebook_size,
        max_samples=base_max_samples,
        kmeans_iter=base_kmeans_iter,
        outer_iter=base_outer_iter,
        assignment_sweeps=base_assignment_sweeps,
        batch_size=base_batch_size,
        seed=seed,
        layer_name=layer_name,
        model_path=model_path,
        cache_dir=base_cache_dir,
        use_cache=True,
        overwrite_cache=False,
    )
    codebooks = base["codebooks"].to(device=device, dtype=torch.float32)
    scales = base["scales"].to(device=device, dtype=torch.float32)
    codes = base["codes"].to(device=device, dtype=torch.long)
    working = weight.detach().to(device=device, dtype=torch.float32)

    if cached is not None:
        codebooks = cached["codebooks"].to(device=device, dtype=torch.float32)
        scales = cached["scales"].to(device=device, dtype=torch.float32)
    initial_reconstruction = _reconstruct_weight(
        codebooks,
        codes,
        scales,
        rows,
        cols,
    )
    initial_loss = float(
        _guided_loss_from_error(
            working - initial_reconstruction,
            diag,
            factors,
        ).item()
    )

    codes, reconstruction, assignment_loss = _guided_assign_codes(
        working,
        scales,
        codebooks,
        codes,
        diag,
        factors,
        in_group_size,
        guided_sweeps,
        block_chunk,
    )
    codebook_loss = assignment_loss
    accepted_steps = 0
    assignment_passes = 1
    final_loss = assignment_loss
    if cached is None and codebook_steps > 0:
        optimized_codebooks, codebook_loss, accepted_steps = _optimize_codebooks(
            working,
            scales,
            codebooks,
            codes,
            diag,
            factors,
            codebook_steps,
            learning_rate,
        )
        if accepted_steps > 0 and codebook_loss <= assignment_loss:
            codebooks = optimized_codebooks
            codes, reconstruction, final_loss = _guided_assign_codes(
                working,
                scales,
                codebooks,
                codes,
                diag,
                factors,
                in_group_size,
                guided_sweeps,
                block_chunk,
            )
            assignment_passes += 1
    tolerance = max(1e-12, initial_loss * 1e-7)
    if not math.isfinite(final_loss) or final_loss > initial_loss + tolerance:
        raise RuntimeError(
            f"method15 guided loss increased from {initial_loss} to {final_loss}."
        )

    stats = {
        "method_name": METHOD15_NAME,
        "layer_name": layer_name,
        "cache_hit": bool(cached is not None),
        "base_cache_hit": bool(base["stats"]["cache_hit"]),
        "initial_loss": initial_loss,
        "assignment_loss": assignment_loss,
        "codebook_loss": float(codebook_loss),
        "final_loss": final_loss,
        "relative_improvement": float(
            (initial_loss - final_loss) / max(initial_loss, 1e-12)
        ),
        "guided_sweeps": int(guided_sweeps),
        "codebook_steps": int(codebook_steps),
        "accepted_codebook_steps": int(accepted_steps),
        "guided_assignment_passes": int(assignment_passes),
        "loss_monotonic": bool(final_loss <= initial_loss + tolerance),
        "elapsed_seconds": float(time.time() - started),
    }
    stats.update(
        method14_quant._storage_stats(
            rows,
            cols,
            in_group_size,
            2,
            codebook_size,
        )
    )
    state = {
        "codes": codes.detach().cpu().to(torch.uint8),
        "codebooks": codebooks.detach().cpu().float(),
        "scales": scales.detach().cpu().float(),
        "shape": (rows, cols),
        "in_group_size": int(in_group_size),
        "stats": stats,
    }
    if cached is None and use_cache:
        cache_path = _save_cache(
            cache_dir,
            layer_name,
            metadata,
            state["codebooks"],
            state["scales"],
            stats,
        )
        stats["cache_path"] = str(cache_path) if cache_path else None
    elif cached is not None:
        stats["cache_path"] = str(_cache_file(cache_dir, layer_name, metadata))
    _record_stats(layer_name, stats)
    return state


def method15_guided_aqlm_dequantize_tensor(
    state,
    dtype=torch.float32,
    device="cpu",
):
    return method14_quant.method14_aqlm_dequantize_tensor(
        state,
        dtype=dtype,
        device=device,
    )


def method15_guided_aqlm_reconstruct_tensor(weight, **kwargs):
    state = method15_guided_aqlm_quantize_tensor(weight, **kwargs)
    reconstructed = method15_guided_aqlm_dequantize_tensor(
        state,
        dtype=weight.dtype,
        device=weight.device,
    )
    del state
    torch.cuda.empty_cache()
    gc.collect()
    return reconstructed

