import gc
import json
import math
import time

import torch

import method12_quant
import method16_quant


METHOD18_NAME = "method18_layer_global_sparse_repair"
METHOD18_VERSION = "method18_layer_global_sparse_repair_v1"
_METHOD18_LAYER_STATS = {}


def reset_method18_stats():
    _METHOD18_LAYER_STATS.clear()


def get_method18_stats():
    return json.loads(json.dumps(_METHOD18_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD18_LAYER_STATS[layer_name or "<tensor>"] = stats


def _storage_stats(
    rows,
    cols,
    group_size,
    sparse_slots,
    requested_slots,
    residual_bits=8,
):
    if residual_bits not in {4, 8, 16}:
        raise ValueError("residual_bits must be one of 4, 8, or 16.")
    if sparse_slots < 0 or sparse_slots > rows * cols:
        raise ValueError("sparse_slots is outside the tensor size.")
    base = method12_quant._storage_stats(rows, cols, group_size)
    column_index_bits = max(1, math.ceil(math.log2(cols)))
    row_pointer_bits = max(
        1,
        math.ceil(math.log2(max(1, int(sparse_slots)) + 1)),
    )
    csr_row_pointer_bits = (rows + 1) * row_pointer_bits
    residual_scale_bits = rows * 16 if residual_bits < 16 else 0
    sparse_payload_bits = sparse_slots * (
        column_index_bits + residual_bits
    )
    sparse_bits = (
        sparse_payload_bits
        + csr_row_pointer_bits
        + residual_scale_bits
    )
    total_bits = base["logical_total_bytes"] * 8 + sparse_bits
    return {
        **base,
        "requested_sparse_slots": int(requested_slots),
        "sparse_slots": int(sparse_slots),
        "sparse_index_bits": int(column_index_bits),
        "sparse_value_bits": int(residual_bits),
        "csr_row_pointer_bits_per_entry": int(row_pointer_bits),
        "csr_row_pointer_bits": int(csr_row_pointer_bits),
        "sparse_payload_bits": int(sparse_payload_bits),
        "residual_scale_bits": int(residual_scale_bits),
        "sparse_residual_bits": int(sparse_bits),
        "logical_total_bits_with_sparse": int(total_bits),
        "effective_bits_per_weight": float(total_bits / (rows * cols)),
    }


@torch.no_grad()
def repair_reconstruction_global(
    weight,
    reconstruction,
    hessian,
    fraction,
    group_size=128,
    residual_bits=8,
):
    if weight.ndim != 2 or reconstruction.shape != weight.shape:
        raise ValueError("Method18 expects matching rank-2 weight tensors.")
    if not 0.0 < float(fraction) < 1.0:
        raise ValueError("Method18 fraction must be in (0, 1).")
    if residual_bits not in {4, 8, 16}:
        raise ValueError("residual_bits must be one of 4, 8, or 16.")

    rows, cols = weight.shape
    num_weights = rows * cols
    slot_budget = max(
        1,
        min(num_weights - 1, int(round(num_weights * float(fraction)))),
    )
    diag, factors = method16_quant._prepare_hessian(
        hessian,
        rows,
        cols,
        weight.device,
    )
    original = weight.detach().float()
    base = reconstruction.detach().to(weight.device).float()
    error = original - base
    before_rows = method16_quant._guided_row_losses(
        error,
        diag,
        factors,
    )
    gains = method16_quant._single_coordinate_gains(
        error,
        diag,
        factors,
    )
    selected_gain, flat_indices = torch.topk(
        gains.reshape(-1),
        k=slot_budget,
        sorted=False,
    )
    positive = torch.isfinite(selected_gain) & (selected_gain > 0)
    row_indices = torch.div(
        flat_indices,
        cols,
        rounding_mode="floor",
    )
    column_indices = flat_indices.remainder(cols)

    base_values = base.reshape(-1)[flat_indices]
    original_values = original.reshape(-1)[flat_indices]
    selected_residual = torch.where(
        positive,
        original_values - base_values,
        torch.zeros_like(base_values),
    )
    if residual_bits == 16:
        quantized_residual = selected_residual
        active_slot = positive & (selected_residual != 0)
    else:
        qmax = (1 << (residual_bits - 1)) - 1
        row_absmax = torch.zeros(
            rows,
            device=weight.device,
            dtype=torch.float32,
        )
        row_absmax.scatter_reduce_(
            0,
            row_indices,
            selected_residual.abs(),
            reduce="amax",
            include_self=True,
        )
        residual_scale = (row_absmax / float(qmax)).clamp_min(1e-12)
        residual_codes = torch.round(
            selected_residual / residual_scale[row_indices]
        ).clamp(-qmax, qmax)
        quantized_residual = (
            residual_codes * residual_scale[row_indices]
        )
        active_slot = positive & (residual_codes != 0)

    candidate = base.clone()
    candidate.reshape(-1).scatter_(
        0,
        flat_indices,
        base_values + quantized_residual,
    )


    after_rows = method16_quant._guided_row_losses(
        original - candidate,
        diag,
        factors,
    )
    tolerance = torch.maximum(
        before_rows.abs() * 1e-6,
        torch.full_like(before_rows, 1e-8),
    )
    accepted = torch.isfinite(after_rows) & (
        after_rows <= before_rows + tolerance
    )
    touched = torch.zeros(
        rows,
        device=weight.device,
        dtype=torch.bool,
    )
    if positive.any():
        touched[row_indices[positive]] = True
    repaired = torch.where(accepted.unsqueeze(1), candidate, base)
    final_rows = torch.where(accepted, after_rows, before_rows)
    encoded_slot = active_slot & accepted[row_indices]
    encoded_flat = flat_indices[encoded_slot]
    encoded_rows = row_indices[encoded_slot]
    row_slot_counts = torch.bincount(
        encoded_rows,
        minlength=rows,
    )
    sparse_slots = int(encoded_slot.sum().item())

    stats = {
        "requested_fraction": float(fraction),
        "residual_bits": int(residual_bits),
        "allocation": "layer_global",
        "storage_format": "csr_by_row",
        "actual_requested_fraction": float(slot_budget / num_weights),
        "actual_slot_fraction": float(sparse_slots / num_weights),
        "selected_positive_gains": int(positive.sum().item()),
        "selected_gain_sum": float(
            selected_gain[positive].sum().item()
            if positive.any()
            else 0.0
        ),
        "touched_rows": int(touched.sum().item()),
        "untouched_rows": int((~touched).sum().item()),
        "accepted_rows": int((accepted & touched).sum().item()),
        "rejected_rows": int(((~accepted) & touched).sum().item()),
        "active_repairs": int(sparse_slots),
        "nonempty_csr_rows": int((row_slot_counts > 0).sum().item()),
        "min_slots_per_nonempty_row": int(
            row_slot_counts[row_slot_counts > 0].min().item()
            if (row_slot_counts > 0).any()
            else 0
        ),
        "max_slots_per_row": int(row_slot_counts.max().item()),
        "initial_loss": float(before_rows.sum().item()),
        "final_loss": float(final_rows.sum().item()),
        "loss_monotonic": bool(
            torch.all(final_rows <= before_rows + tolerance).item()
        ),
    }
    stats.update(
        _storage_stats(
            rows,
            cols,
            group_size,
            sparse_slots,
            slot_budget,
            residual_bits,
        )
    )
    encoded_flat = torch.sort(encoded_flat).values.cpu()
    return repaired.to(dtype=weight.dtype), encoded_flat, stats


def method18_global_sparse_repair_tensor(
    weight,
    *,
    hessian,
    fraction,
    layer_name=None,
    model_path=None,
    init_importance=None,
    method11_init_cache_dir=None,
    method12_source_cache_dir=None,
    residual_bits=8,
    base_cache_dir=None,
    use_base_cache=True,
    overwrite_base_cache=False,
    group_size=128,
    parallel_jobs=16,
    base_reconstruction=None,
):
    if weight.ndim != 2 or weight.shape[1] % group_size != 0:
        raise ValueError(
            "Method18 expects rank-2 weights divisible by group_size."
        )
    started = time.time()
    if base_reconstruction is None:
        reconstruction, base_cache_hit, cache_path, source_stats = (
            method16_quant._load_or_build_base(
                weight,
                hessian=hessian,
                layer_name=layer_name,
                model_path=model_path,
                init_importance=init_importance,
                method11_init_cache_dir=method11_init_cache_dir,
                method12_source_cache_dir=method12_source_cache_dir,
                base_cache_dir=base_cache_dir if use_base_cache else None,
                overwrite_base_cache=overwrite_base_cache,
                group_size=group_size,
                parallel_jobs=parallel_jobs,
            )
        )
        base_source = "cache" if base_cache_hit else "method12"
    else:
        if base_reconstruction.shape != weight.shape:
            raise ValueError(
                "Injected base reconstruction has the wrong shape."
            )
        reconstruction = base_reconstruction.to(
            device=weight.device,
            dtype=weight.dtype,
        )
        base_cache_hit = False
        cache_path = None
        source_stats = None
        base_source = "injected"

    repaired, encoded_indices, stats = repair_reconstruction_global(
        weight,
        reconstruction,
        hessian,
        fraction,
        group_size=group_size,
        residual_bits=residual_bits,
    )
    stats.update({
        "method_name": METHOD18_NAME,
        "algorithm_version": METHOD18_VERSION,
        "layer_name": layer_name,
        "base_source": base_source,
        "base_cache_hit": bool(base_cache_hit),
        "base_cache_path": cache_path,
        "method12_source_cache_hit": (
            bool(source_stats.get("cache_hit"))
            if isinstance(source_stats, dict)
            else None
        ),
        "elapsed_seconds": float(time.time() - started),
    })
    _record_stats(layer_name, stats)
    del reconstruction, encoded_indices
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()
    return repaired
