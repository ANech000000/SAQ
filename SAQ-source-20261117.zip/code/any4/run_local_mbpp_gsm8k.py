import argparse
import gc
import json
import math
import multiprocessing as mp
import os
import re
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from calibrate import calibrate
from quantize import quant_methods, quantize_model


MBPP_EVALUATOR_VERSION = "mbpp_v2_prompt_aware_controlled_imports"

METHODS = {
    "original_any4": {
        "description": "original any4 4bit",
        "quant_args": {
            "n_bit": 4,
            "skip_modules": "lm_head",
            "sample_weight": calibrate,
            "scale_sample_weight": True,
        },
    },
    "method2_dp_kmeans": {
        "description": "method2: fixed group size 128 + DP 1D k-means",
        "quant_args": {
            "group_size": 128,
            "cluster_row": "dp",
            "n_bit": 4,
            "skip_modules": "lm_head",
            "sample_weight": calibrate,
            "scale_sample_weight": True,
            "pseudo": True,
            "parallelize": True,
            "parallel_jobs": 32,
        },
    },
}


def load_json(path):
    with open(path, "r") as f:
        return json.load(f)


def load_model_and_tokenizer(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
    ).to("cuda")
    model.eval()
    return model, tokenizer


def generate_texts(model, tokenizer, prompts, max_new_tokens, batch_size):
    outputs = []
    for start in range(0, len(prompts), batch_size):
        batch = prompts[start:start + batch_size]
        encoded = tokenizer(batch, return_tensors="pt", padding=True, truncation=True, max_length=1536).to("cuda")
        with torch.no_grad():
            gen = model.generate(
                **encoded,
                do_sample=False,
                temperature=None,
                top_p=None,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        for i in range(len(batch)):
            new_tokens = gen[i, encoded.input_ids.shape[1]:]
            outputs.append(tokenizer.decode(new_tokens, skip_special_tokens=True))
    return outputs


def extract_code(text):
    match = re.search(r"```(?:python)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    lines = text.strip().splitlines()
    code_lines = []
    started = False
    for line in lines:
        if line.lstrip().startswith(("def ", "import ", "from ", "class ")):
            started = True
        if started:
            if line.strip().lower().startswith(("explanation", "the function", "this function")):
                break
            code_lines.append(line)
    return "\n".join(code_lines).strip() if code_lines else text.strip()


_ALLOWED_IMPORT_ROOTS = {
    "bisect", "collections", "functools", "heapq", "itertools", "math",
    "operator", "random", "re", "statistics", "string",
}


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    root = name.split(".", 1)[0]
    if level != 0 or root not in _ALLOWED_IMPORT_ROOTS:
        raise ImportError(f"Import of {name!r} is not allowed by the MBPP evaluator.")
    return __import__(name, globals, locals, fromlist, level)


def _run_mbpp_code(code, tests, test_imports, queue):
    safe_builtins = {
        "abs": abs, "all": all, "any": any, "bool": bool, "dict": dict, "enumerate": enumerate,
        "filter": filter, "float": float, "int": int, "len": len, "list": list, "map": map,
        "max": max, "min": min, "pow": pow, "range": range, "reversed": reversed, "round": round,
        "set": set, "sorted": sorted, "str": str, "sum": sum, "tuple": tuple, "zip": zip,
        "isinstance": isinstance, "issubclass": issubclass, "type": type,
        "chr": chr, "ord": ord, "divmod": divmod, "hash": hash,
        "Exception": Exception, "ValueError": ValueError, "TypeError": TypeError,
        "IndexError": IndexError, "KeyError": KeyError, "ZeroDivisionError": ZeroDivisionError,
        "__import__": _safe_import,
    }
    env = {
        "__builtins__": safe_builtins,
        "math": math,
        "re": re,
    }
    try:
        for imp in test_imports or []:
            exec(imp, env, env)
        exec(code, env, env)
        for test in tests:
            exec(test, env, env)
        queue.put({"passed": True, "error": ""})
    except Exception as exc:
        queue.put({"passed": False, "error": repr(exc)})


def check_mbpp(code, tests, test_imports, timeout_sec):
    ctx = mp.get_context("fork")
    queue = ctx.Queue()
    proc = ctx.Process(target=_run_mbpp_code, args=(code, tests, test_imports, queue))
    proc.start()
    proc.join(timeout_sec)
    if proc.is_alive():
        proc.terminate()
        proc.join(1)
        return False, "timeout"
    if queue.empty():
        return False, "no_result"
    result = queue.get()
    return bool(result["passed"]), result["error"]


def build_mbpp_prompt(item, style):
    if style == "bigcode":
        description = item.get("text") or item.get("prompt")
        tests = item.get("test_list", [])
        example = tests[0] if tests else ""
        return f'"""\n{description}\n{example}\n"""\n'
    return (
        "You are an expert Python programmer. Write a Python function to solve the problem.\n"
        f"Problem: {item['prompt']}\n"
        "Return only the Python code.\n"
    )


def stop_mbpp_generation(text):
    stop_words = ["\nclass", "\nassert", '\n"""', "\nprint", "\nif", "\n<|/", "\n```"]
    end = len(text)
    for stop in stop_words:
        idx = text.find(stop)
        if idx != -1 and idx < end:
            end = idx
    return text[:end]


def eval_mbpp(model, tokenizer, data, batch_size, max_new_tokens, timeout_sec, prompt_style):
    prompts = [build_mbpp_prompt(item, prompt_style) for item in data]
    generations = generate_texts(model, tokenizer, prompts, max_new_tokens=max_new_tokens, batch_size=batch_size)
    records = []
    passed = 0
    for item, prompt, generation in zip(data, prompts, generations):
        if prompt_style == "bigcode":
            code = prompt + stop_mbpp_generation(generation)
        else:
            code = extract_code(generation)
        ok, error = check_mbpp(code, item.get("test_list", []), item.get("test_imports", []), timeout_sec)
        passed += int(ok)
        records.append({
            "task_id": item.get("task_id"),
            "prompt": item.get("prompt"),
            "passed": ok,
            "error": error,
            "prompt_style": prompt_style,
            "evaluator_version": MBPP_EVALUATOR_VERSION,
            "prompt_used": prompt,
            "generation": generation,
            "code": code,
        })
    return {"pass@1": passed / len(data), "passed": passed, "total": len(data), "records": records}


_NUMBER_RE = re.compile(r"[-+]?\d[\d,]*(?:\.\d+)?")


def extract_number(text):
    numbers = _NUMBER_RE.findall(text.replace(",", ""))
    if not numbers:
        return None
    try:
        return float(numbers[-1])
    except ValueError:
        return None


def eval_gsm8k(model, tokenizer, data, batch_size, max_new_tokens):
    prompts = [
        f"Question: {item.get('instruction') or item.get('question') or item.get('sQuestion')}\n"
        "Answer: Let's think step by step."
        for item in data
    ]
    generations = generate_texts(model, tokenizer, prompts, max_new_tokens=max_new_tokens, batch_size=batch_size)
    records = []
    correct = 0
    for item, generation in zip(data, generations):
        pred = extract_number(generation)
        gold = item.get("answer", item.get("pred", item.get("lSolutions")))
        try:
            gold_num = float(str(gold).replace(",", "").strip())
        except ValueError:
            gold_num = extract_number(str(gold))
        ok = pred is not None and gold_num is not None and abs(pred - gold_num) < 1e-6
        correct += int(ok)
        records.append({
            "question": item.get("instruction") or item.get("question") or item.get("sQuestion"),
            "gold": gold_num,
            "pred": pred,
            "correct": ok,
            "generation": generation,
        })
    return {"accuracy": correct / len(data), "correct": correct, "total": len(data), "records": records}


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def run_method(method_name, args, mbpp_data, gsm_data):
    method = METHODS[method_name]
    method_dir = Path(args.log_dir) / method_name
    method_dir.mkdir(parents=True, exist_ok=True)
    write_json(method_dir / "command.json", {"argv": os.sys.argv, "method": method_name})

    started = time.time()
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    qargs = dict(method["quant_args"])
    if method_name == "method2_dp_kmeans" and args.dp_cache_dir:
        qargs.update({
            "dp_cache_dir": args.dp_cache_dir,
            "dp_cache_mode": "readonly",
            "dp_cache_verify": False,
            "dp_cache_stats_path": str(method_dir / "dp_cache_stats.json"),
        })
    quant_started = time.time()
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=quant_methods["anyq"],
        tokenizer=tokenizer,
        **qargs,
    )
    quant_elapsed = time.time() - quant_started
    model.eval()

    results = {
        "method": method_name,
        "description": method["description"],
        "model_path": args.model_path,
        "gpu": os.environ.get("CUDA_VISIBLE_DEVICES", "all-visible"),
        "quant_args": {k: str(v) for k, v in qargs.items() if k != "sample_weight"},
        "quant_elapsed_sec": quant_elapsed,
    }

    mbpp = eval_mbpp(model, tokenizer, mbpp_data, args.batch_size, args.mbpp_max_new_tokens, args.mbpp_timeout_sec, args.mbpp_prompt_style)
    write_json(method_dir / "mbpp_generations.json", mbpp["records"])
    results["mbpp"] = {k: v for k, v in mbpp.items() if k != "records"}
    results["mbpp_evaluator"] = {
        "version": MBPP_EVALUATOR_VERSION,
        "prompt_style": args.mbpp_prompt_style,
        "controlled_imports": sorted(_ALLOWED_IMPORT_ROOTS),
    }
    write_json(method_dir / "results.json", results)

    gsm = eval_gsm8k(model, tokenizer, gsm_data, args.batch_size, args.gsm_max_new_tokens)
    write_json(method_dir / "gsm8k_generations.json", gsm["records"])
    results["gsm8k"] = {k: v for k, v in gsm.items() if k != "records"}
    results["elapsed_sec"] = time.time() - started
    if (method_dir / "dp_cache_stats.json").exists():
        results["dp_cache_stats"] = json.loads((method_dir / "dp_cache_stats.json").read_text())
    write_json(method_dir / "results.json", results)

    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--mbpp-path", default="/data/lsz/llm_dataset/code/MBPP/mbpp_test.json")
    parser.add_argument("--gsm8k-path", default="/data/lsz/llm_dataset/math/GSM8K/test.json")
    parser.add_argument("--log-dir", default="logs/llama3.2-1b/local_mbpp_gsm8k")
    parser.add_argument("--methods", nargs="+", default=["original_any4", "method2_dp_kmeans"], choices=list(METHODS))
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--mbpp-max-new-tokens", type=int, default=256)
    parser.add_argument("--mbpp-prompt-style", choices=["bigcode", "plain"], default="bigcode")
    parser.add_argument("--gsm-max-new-tokens", type=int, default=256)
    parser.add_argument("--mbpp-timeout-sec", type=int, default=3)
    parser.add_argument("--mbpp-limit", type=int, default=None)
    parser.add_argument("--gsm8k-limit", type=int, default=None)
    parser.add_argument("--dp-cache-dir", default=None)
    args = parser.parse_args()

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    mbpp_data = load_json(args.mbpp_path)
    gsm_data = load_json(args.gsm8k_path)
    if args.mbpp_limit is not None:
        mbpp_data = mbpp_data[:args.mbpp_limit]
    if args.gsm8k_limit is not None:
        gsm_data = gsm_data[:args.gsm8k_limit]

    summary = {
        "model_path": args.model_path,
        "mbpp_path": args.mbpp_path,
        "gsm8k_path": args.gsm8k_path,
        "gpu": os.environ.get("CUDA_VISIBLE_DEVICES", "all-visible"),
        "methods": {},
    }
    for method in args.methods:
        result = run_method(method, args, mbpp_data, gsm_data)
        summary["methods"][method] = {
            "mbpp": result.get("mbpp"),
            "gsm8k": result.get("gsm8k"),
            "elapsed_sec": result.get("elapsed_sec"),
            "quant_elapsed_sec": result.get("quant_elapsed_sec"),
        }
        write_json(log_dir / "summary.json", summary)
        print(json.dumps(summary["methods"][method], indent=2))
    write_json(log_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
