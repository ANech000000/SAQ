# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

from typing import Callable, Dict, List, Tuple, Type, Union
from tqdm import tqdm
import gc
import hashlib
import itertools
import json
import os
import random
import tempfile
import time
import torch
from joblib import Parallel, delayed
import numpy as np
import sklearn.cluster
from threadpoolctl import threadpool_limits

import bitsandbytes as bnb

import kmeans
from utils import get_lm_head_from_model, import_or_skip, string_split

METHOD3_NAME = "method3_outlier_reserved_lut"
DEFAULT_METHOD3_CACHE_DIR = "/data/lsz/any4/experiments/method3/cache"
METHOD11_NAME = "method11_any2_hlut"
METHOD11_ALGORITHM_VERSION = "method11_hlut_v1"
DEFAULT_METHOD11_CACHE_DIR = "/data/lsz/any4/experiments/method11/cache"
_METHOD11_LAYER_STATS = {}

def count_layer_type(model, layer_type=torch.nn.Linear, count=0):
    for _, module in model._modules.items():
        if isinstance(module, layer_type):
            count += 1

        if len(list(module.children())) > 0:
            # recurse
            count += count_layer_type(module, layer_type, 0)
    return count

def quantize_model(model: torch.nn.Module, layer_from: Type, layer_to: Callable, skip_modules=None, tokenizer=None, calibrate_args=None, memory_cleanup_interval=0, calibrate_once=False, **kwargs):
    # Handle Default Arguments
    if skip_modules is None:
        # By default, we follow most quantization papers by excluding language model head
        skip_modules = [get_lm_head_from_model(model)]
    if isinstance(skip_modules, str):
        skip_modules = string_split(skip_modules, ",")
    if isinstance(skip_modules, torch.nn.Module):
        skip_modules = [skip_modules]
    # TODO: add option to perform offline calibration before looping
    if calibrate_args is None:
        calibrate_args = {}
    calibrate_fn = None
    if "sample_weight" in kwargs:
        if isinstance(kwargs["sample_weight"], Callable):
            calibrate_fn = kwargs["sample_weight"]

    modules = [(name, module) for name, module in model.named_modules() if isinstance(module, layer_from) and name not in skip_modules and module not in skip_modules]
    calibration_weights = None
    if calibrate_fn is not None and calibrate_once:
        if calibrate_args.get("return_activations", False):
            raise ValueError("calibrate_once does not support return_activations because retaining every layer activation can exhaust host memory.")
        offline_args = dict(calibrate_args)
        offline_args.setdefault("seed", 0)
        calibration_weights = calibrate_fn(
            model=model,
            tokenizer=tokenizer,
            layers=[name for name, _ in modules],
            **offline_args,
        )
    pbar = tqdm(modules, unit="layer", desc="Quantizing")
    for index, (name, module) in enumerate(pbar):
        pbar.set_postfix_str(name)

        # Calibrate if necessary
        # TODO: move this to inside the quantization function?
        if calibration_weights is not None:
            kwargs["sample_weight"] = calibration_weights[name]
        elif calibrate_fn is not None:
            calibrate_args["seed"] = index
            if calibrate_args.get("return_activations", False):
                # TODO: rename "sample_weight" to "sample_mean_activations" ?
                kwargs["sample_weight"], kwargs["sample_activations"] = calibrate_fn(model=model, tokenizer=tokenizer, layers=[name], **calibrate_args)
                kwargs["sample_activations"] = kwargs["sample_activations"][name]
            else:
                kwargs["sample_weight"] = calibrate_fn(model=model, tokenizer=tokenizer, layers=[name], **calibrate_args)

        new_module = layer_to(module, name=name, **kwargs)

        # Get the parent module
        parent_name = '.'.join(name.split('.')[:-1])
        if parent_name:
            parent_module = model.get_submodule(parent_name)
        else:
            parent_module = model
        # Replace the old module with the new one
        setattr(parent_module, name.split('.')[-1], new_module)

        # Save memory
        if calibrate_fn is not None:
            if "sample_weight" in kwargs:
                del kwargs["sample_weight"]
            if "sample_activations" in kwargs:
                del kwargs["sample_activations"]
        cleanup_interval = int(memory_cleanup_interval or 0)
        if cleanup_interval > 0 and (index + 1) % cleanup_interval == 0:
            torch.cuda.empty_cache()
            gc.collect()

    torch.cuda.empty_cache()
    gc.collect()

    return model

def pack_scales_and_zeros(scales, zeros, w_shape):
    # Scales and zeros for the same q-group should be contiguous, so we can
    # load as a 32-bit word
    scales = scales.view(w_shape[0], -1)
    zeros = zeros.view(w_shape[0], -1)
    scales_and_zeros = (
        torch.cat(
            [
                scales.reshape(scales.size(0), scales.size(1), 1),
                zeros.reshape(zeros.size(0), zeros.size(1), 1),
            ],
            2,
        )
        .transpose(0, 1)
        .contiguous()
    )
    return scales_and_zeros

# TODO: add option to group_q to decide max and min of scaling: 0 to 15? -1 to 1? -7 to 8? -7.5 to 8.5?
def group_q(w_orig, n_bit, q_group_size=128, assymetric=True, unsigned=True, zero_point=True):
    w = w_orig.float()
    assert q_group_size > 1
    assert w.shape[-1] % q_group_size == 0
    assert w.dim() == 2

    to_quant = w.reshape(-1, q_group_size)
    assert torch.isnan(to_quant).sum() == 0

    if assymetric:
        max_val = to_quant.amax(dim=1, keepdim=True)
        min_val = to_quant.amin(dim=1, keepdim=True)
        if unsigned:
            min_int = 0
            max_int = 2**n_bit - 1
        else:
            min_int = -(2**(n_bit - 1))
            max_int = 2**(n_bit - 1) - 1
        scales = (max_val - min_val).clamp(min=1e-6) / (max_int - min_int)
        if zero_point:
            zeros = min_val + scales * (2 ** (n_bit - 1))
        else:
            zeros = min_val

        w_new = to_quant.sub(min_val).div(scales).reshape(w_orig.size())
        w_new_zeros = torch.zeros(to_quant.size(), dtype=to_quant.dtype, device=to_quant.device).sub(min_val).div(scales).reshape(w_orig.size())
    else:
        # TODO: this wastes one bit. Review with Jeff.
        # TODO: check how to handle "unsigned" argument
        absmax_val = to_quant.abs().amax(dim=1, keepdim=True)
        absmax_int = 2**(n_bit - 1) - 1
        scales = absmax_val.clamp(min=1e-6) / absmax_int
        zeros = torch.zeros_like(scales)

        w_new = to_quant.div(scales).reshape(w_orig.size())
        w_new_zeros = torch.zeros_like(w_new)


    assert torch.isnan(scales).sum() == 0
    assert torch.isnan(zeros).sum() == 0

    scales_and_zeros = pack_scales_and_zeros(scales, zeros, w.shape)

    return w_new, w_new_zeros, scales_and_zeros


def _parse_int_list(value, default):
    if value is None:
        return tuple(default)
    if isinstance(value, str):
        return tuple(int(v.strip()) for v in value.split(',') if v.strip())
    return tuple(int(v) for v in value)


def _parse_float_list(value, default):
    if value is None:
        return tuple(default)
    if isinstance(value, str):
        return tuple(float(v.strip()) for v in value.split(',') if v.strip())
    return tuple(float(v) for v in value)


def _normalize_metric(metric):
    denom = torch.quantile(metric.detach().flatten(), 0.75).clamp(min=1e-6)
    return (metric / denom).clamp(max=4.0)


def choose_dynamic_group_sizes(W, dynamic_group_sizes=(32, 64, 128), dynamic_group_thresholds=(0.8, 1.5), dynamic_group_metric_weights=(1.0, 1.0, 1.0)):
    group_sizes = sorted(_parse_int_list(dynamic_group_sizes, (32, 64, 128)))
    thresholds = _parse_float_list(dynamic_group_thresholds, (0.8, 1.5))
    weights = _parse_float_list(dynamic_group_metric_weights, (1.0, 1.0, 1.0))
    if len(group_sizes) != 3:
        raise ValueError('dynamic group size currently expects exactly three candidates, e.g. 32,64,128.')
    if len(thresholds) != 2:
        raise ValueError('dynamic_group_thresholds must contain two values.')
    if len(weights) != 3:
        raise ValueError('dynamic_group_metric_weights must contain three values.')
    max_group = max(group_sizes)
    if W.dim() != 2 or W.shape[-1] % max_group != 0:
        raise ValueError(f'weight shape {tuple(W.shape)} must be 2D and divisible by max dynamic group size {max_group}.')

    blocks = W.float().reshape(-1, max_group)
    block_range = blocks.amax(dim=1) - blocks.amin(dim=1)
    block_var = blocks.var(dim=1, unbiased=False)
    median = blocks.median(dim=1, keepdim=True).values
    mad = (blocks - median).abs().median(dim=1).values
    std = blocks.std(dim=1, unbiased=False)
    outlier_scale = torch.where(mad > 1e-8, 3.0 * mad, 3.0 * std.clamp(min=1e-8))
    outlier_ratio = ((blocks - median).abs() > outlier_scale.unsqueeze(1)).float().mean(dim=1)

    score = (
        weights[0] * _normalize_metric(block_range) +
        weights[1] * _normalize_metric(block_var) +
        weights[2] * _normalize_metric(outlier_ratio)
    ) / max(sum(weights), 1e-6)

    small, mid, large = group_sizes
    selected = torch.full_like(score, large, dtype=torch.int64)
    selected[score >= thresholds[0]] = mid
    selected[score >= thresholds[1]] = small
    return selected.reshape(W.shape[0], W.shape[1] // max_group)


def dynamic_group_q(W, n_bit=4, dynamic_group_sizes=(32, 64, 128), dynamic_group_thresholds=(0.8, 1.5), dynamic_group_metric_weights=(1.0, 1.0, 1.0), assymetric=True, zero_point=True):
    if not assymetric:
        raise ValueError('dynamic_group_q currently supports asymmetric scaling only.')
    group_sizes = sorted(_parse_int_list(dynamic_group_sizes, (32, 64, 128)))
    max_group = max(group_sizes)
    selected = choose_dynamic_group_sizes(W, group_sizes, dynamic_group_thresholds, dynamic_group_metric_weights)
    Wf = W.float()
    Wg = torch.empty_like(Wf)
    scales = torch.empty_like(Wf)
    zeros = torch.empty_like(Wf)
    max_int = 2**n_bit - 1
    min_int = 0

    for row in range(Wf.shape[0]):
        for block_idx in range(Wf.shape[1] // max_group):
            chosen = int(selected[row, block_idx].item())
            start = block_idx * max_group
            for sub_start in range(start, start + max_group, chosen):
                sub_end = sub_start + chosen
                chunk = Wf[row, sub_start:sub_end]
                max_val = chunk.max()
                min_val = chunk.min()
                scale = (max_val - min_val).clamp(min=1e-6) / (max_int - min_int)
                zero = min_val + scale * (2 ** (n_bit - 1)) if zero_point else min_val
                Wg[row, sub_start:sub_end] = (chunk - min_val) / scale
                scales[row, sub_start:sub_end] = scale
                zeros[row, sub_start:sub_end] = zero

    return Wg, {"dynamic": True, "scales": scales.to(W.dtype), "zeros": zeros.to(W.dtype), "selected_group_sizes": selected}


DYNAMIC_GROUP_STATS = {}


def reset_dynamic_group_stats():
    DYNAMIC_GROUP_STATS.clear()


def get_dynamic_group_stats():
    return DYNAMIC_GROUP_STATS


def _record_dynamic_group_stats(layer_name, selected_group_sizes, weight_shape):
    if selected_group_sizes is None:
        return
    layer = layer_name or f"layer_{len(DYNAMIC_GROUP_STATS)}"
    selected = selected_group_sizes.detach().cpu().reshape(-1)
    counts = {str(gs): int((selected == gs).sum().item()) for gs in (32, 64, 128)}
    elem_counts = {str(gs): int(counts[str(gs)] * gs) for gs in (32, 64, 128)}
    total_segments = int(selected.numel())
    total_elems = int(sum(elem_counts.values()))
    DYNAMIC_GROUP_STATS[layer] = {
        "weight_shape": list(weight_shape),
        "segment_counts": counts,
        "element_counts": elem_counts,
        "segment_ratio": {k: (v / total_segments if total_segments else 0.0) for k, v in counts.items()},
        "element_ratio": {k: (v / total_elems if total_elems else 0.0) for k, v in elem_counts.items()},
    }


def _outlier_ratio_1d(chunk):
    median = chunk.median()
    abs_dev = (chunk - median).abs()
    mad = abs_dev.median()
    std = chunk.std(unbiased=False)
    scale = 3.0 * mad if mad > 1e-8 else 3.0 * std.clamp(min=1e-8)
    return (abs_dev > scale).float().mean()


def _chunk_accepts(chunk, range_threshold, var_threshold, outlier_threshold):
    chunk_range = chunk.max() - chunk.min()
    chunk_var = chunk.var(unbiased=False)
    chunk_outlier_ratio = _outlier_ratio_1d(chunk)
    return chunk_range <= range_threshold and chunk_var <= var_threshold and chunk_outlier_ratio <= outlier_threshold


def greedy_dynamic_group_q(W, n_bit=4, dynamic_group_sizes=(128, 64, 32), range_alpha=1.25, var_alpha=1.25, outlier_threshold=0.05, assymetric=True, zero_point=True, layer_name=None):
    if not assymetric:
        raise ValueError('greedy_dynamic_group_q currently supports asymmetric scaling only.')
    candidates = tuple(_parse_int_list(dynamic_group_sizes, (128, 64, 32)))
    if candidates != (128, 64, 32):
        raise ValueError('greedy_dynamic_group_q expects candidates ordered as 128,64,32.')
    if W.dim() != 2 or W.shape[-1] % 128 != 0:
        raise ValueError(f'weight shape {tuple(W.shape)} must be 2D and divisible by 128.')

    Wf = torch.nan_to_num(W.float(), nan=0.0, posinf=0.0, neginf=0.0)
    rows, cols = Wf.shape
    blocks128 = Wf.reshape(-1, 128)
    range128 = blocks128.amax(dim=1) - blocks128.amin(dim=1)
    var128 = blocks128.var(dim=1, unbiased=False)
    range_threshold = range128.median() * float(range_alpha)
    var_threshold = var128.median() * float(var_alpha)
    accept128 = (range128 <= range_threshold) & (var128 <= var_threshold)

    Wg = torch.empty_like(Wf)
    scales = torch.empty_like(Wf)
    zeros = torch.empty_like(Wf)
    selected_counts = {32: 0, 64: 0, 128: 0}
    max_int = 2**n_bit - 1

    def fill_segments(view, selected_size):
        max_val = view.amax(dim=1, keepdim=True)
        min_val = view.amin(dim=1, keepdim=True)
        scale = (max_val - min_val).clamp(min=1e-6) / max_int
        zero = min_val + scale * (2 ** (n_bit - 1)) if zero_point else min_val
        q = (view - min_val) / scale
        return q, scale.expand_as(view), zero.expand_as(view), int(view.shape[0])

    Wg128 = Wg.reshape(-1, 128)
    scales128 = scales.reshape(-1, 128)
    zeros128 = zeros.reshape(-1, 128)

    if accept128.any():
        idx = accept128.nonzero(as_tuple=False).flatten()
        q, sc, ze, count = fill_segments(blocks128[idx], 128)
        Wg128[idx] = q
        scales128[idx] = sc
        zeros128[idx] = ze
        selected_counts[128] += count

    reject128 = (~accept128).nonzero(as_tuple=False).flatten()
    if reject128.numel() > 0:
        sub64 = blocks128[reject128].reshape(-1, 64)
        range64 = sub64.amax(dim=1) - sub64.amin(dim=1)
        var64 = sub64.var(dim=1, unbiased=False)
        accept64 = (range64 <= range_threshold) & (var64 <= var_threshold)
        q64 = Wg128[reject128].reshape(-1, 64)
        sc64 = scales128[reject128].reshape(-1, 64)
        ze64 = zeros128[reject128].reshape(-1, 64)
        if accept64.any():
            idx64 = accept64.nonzero(as_tuple=False).flatten()
            q, sc, ze, count = fill_segments(sub64[idx64], 64)
            q64[idx64] = q
            sc64[idx64] = sc
            ze64[idx64] = ze
            selected_counts[64] += count
        reject64 = (~accept64).nonzero(as_tuple=False).flatten()
        if reject64.numel() > 0:
            sub32 = sub64[reject64].reshape(-1, 32)
            q, sc, ze, count = fill_segments(sub32, 32)
            q64[reject64] = q.reshape(-1, 64)
            sc64[reject64] = sc.reshape(-1, 64)
            ze64[reject64] = ze.reshape(-1, 64)
            selected_counts[32] += count
        Wg128[reject128] = q64.reshape(-1, 128)
        scales128[reject128] = sc64.reshape(-1, 128)
        zeros128[reject128] = ze64.reshape(-1, 128)

    selected = torch.cat([
        torch.full((selected_counts[32],), 32, device=W.device, dtype=torch.int64),
        torch.full((selected_counts[64],), 64, device=W.device, dtype=torch.int64),
        torch.full((selected_counts[128],), 128, device=W.device, dtype=torch.int64),
    ])
    _record_dynamic_group_stats(layer_name, selected, W.shape)
    return Wg, {
        "dynamic": True,
        "policy": "greedy_dynamic",
        "scales": scales.to(W.dtype),
        "zeros": zeros.to(W.dtype),
        "selected_group_sizes": selected,
    }

def extract_scales_and_zeros(scales_and_zeros, w_shape, q_group_size):
    scales = scales_and_zeros.transpose(0, 1)[:, :, 0]
    zeros = scales_and_zeros.transpose(0, 1)[:, :, 1]

    scales = expand_q_groups(scales, w_shape, q_group_size)
    zeros = expand_q_groups(zeros, w_shape, q_group_size)

    return scales, zeros


def dynamic_degroup_q(w_c, scales_and_zeros, n_bit=4, scale_only=False):
    if not isinstance(scales_and_zeros, dict) or not scales_and_zeros.get('dynamic'):
        raise ValueError('dynamic_degroup_q expects dynamic scales_and_zeros dict.')
    scales = scales_and_zeros['scales'].to(w_c.device)
    zeros = scales_and_zeros['zeros'].to(w_c.device)
    if not scale_only:
        w_c = w_c - (2**(n_bit - 1))
    return w_c * scales + zeros

def degroup_q(w_c, scales_and_zeros=None, scales=None, zeros=None, n_bit=4, q_group_size=128, centering=True):
    if scales_and_zeros is not None:
        scales1, zeros1 = extract_scales_and_zeros(scales_and_zeros, w_c.shape, q_group_size)
        if scales is None:
            scales = scales1
        if zeros is None:
            zeros = zeros1

    if q_group_size:
        if centering:
            w_c = w_c - (2**(n_bit - 1))
        reconstructed = w_c * scales + zeros
    else:
        reconstructed = w_c
    return reconstructed

# takes the scale or offset per each quantization group and reshapes/duplicates it to map
# to the original matrix size
def expand_q_groups(x, orig_size, q_group_size):
    out = x.reshape(orig_size[0], orig_size[1] // q_group_size, 1)
    out = out.expand(orig_size[0], orig_size[1] // q_group_size, q_group_size)
    return out.contiguous().view(orig_size)

def intq_quantize_tensor(x, n_bit = 4, q_group_size=128, parallelize=True, scale_only=False, new_grouping=False, unsigned=False, zero_point=False, **kwargs):
    # FIXME: this is a hack to get tinygemm int4 kernel to work. Please instead call group_q or group_q1
    if new_grouping == "tinygemm":
        from tinygemm_lib.utils import group_quantize_tensor
        intq, scales_and_zeros = group_quantize_tensor(
            x, n_bit=n_bit, q_group_size=q_group_size
        )
        _, intq_zeros = extract_scales_and_zeros(scales_and_zeros, x.shape, q_group_size)
    elif new_grouping == True:
        # TODO: Please unify group_q, group_q1, and group_quantize_tensor
        intq, scales, zeros = group_q1(x, n_bit=n_bit, assymetric=not scale_only, q_group_size=q_group_size, inplace=False, get_scale_zp=True)
        scales_and_zeros = pack_scales_and_zeros(scales, zeros, x.shape)
        intq = intq.round()
        intq_zeros = zeros
    else:
        intq, intq_zeros, scales_and_zeros = group_q(x, n_bit, q_group_size=q_group_size, assymetric=not scale_only, unsigned=unsigned, zero_point=zero_point)
        intq = intq.round()
        assert intq.size(1) == q_group_size * scales_and_zeros.size(0)

    intq = intq.to(torch.int32)
    scales_and_zeros = scales_and_zeros.to(x.dtype)

    return intq, intq_zeros, scales_and_zeros

def intq_dequantize_tensor(intq, scales_and_zeros=None, scales=None, zeros=None, n_bit=4, q_group_size=128, new_grouping=False, dtype=torch.float16, unsigned=False):
    if new_grouping:
        reconstructed = degroup_q1(intq, scales_and_zeros=scales_and_zeros, scales=scales, zeros=zeros, q_group_size=q_group_size, inplace=False)
    else:
        reconstructed = degroup_q(intq, scales_and_zeros=scales_and_zeros, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=False)
    reconstructed = reconstructed.to(dtype=dtype)
    return reconstructed

# performs quantization and dequantization under N-bit grouped integer quantization
# (i.e., returns the effective result of the quantization algorithm)
def intq_reconstruct_tensor(x, n_bit = 4, q_group_size=128, parallelize=True, unsigned=False, new_grouping=False, zero_point=False,  scale_only=False, dtype=torch.float16, *args, **kwargs):
    intq, intq_zeros, scales_and_zeros = intq_quantize_tensor(x, n_bit=n_bit, q_group_size=q_group_size, new_grouping=new_grouping, scale_only=scale_only, unsigned=unsigned, zero_point=zero_point)
    reconstructed = intq_dequantize_tensor(intq, scales_and_zeros=scales_and_zeros, n_bit=n_bit, q_group_size=q_group_size, dtype=dtype, new_grouping=new_grouping, unsigned=unsigned)

    return reconstructed

def pseudo_quantize_tensor(
    w, n_bit=8, assymetric=True, q_group_size=-1, inplace=False, get_scale_zp=False
):
    org_w_shape = w.shape
    if q_group_size > 0:
        assert org_w_shape[-1] % q_group_size == 0
        w = w.reshape(-1, q_group_size)
    assert w.dim() == 2
    if assymetric:
        max_val = w.amax(dim=1, keepdim=True)
        min_val = w.amin(dim=1, keepdim=True)
        max_int = 2**n_bit - 1
        min_int = 0
        scales = (max_val - min_val).clamp(min=1e-5) / max_int
        zeros = (-torch.round(min_val / scales)).clamp_(min_int, max_int)
    else:  # we actually never used this
        max_val = w.abs().amax(dim=1, keepdim=True)
        max_val = max_val.clamp(min=1e-5)
        max_int = 2 ** (n_bit - 1) - 1
        min_int = -(2 ** (n_bit - 1))
        scales = max_val / max_int
        zeros = 0

    assert torch.isnan(scales).sum() == 0
    assert torch.isnan(w).sum() == 0

    if inplace:
        (
            (w.div_(scales).round_().add_(zeros)).clamp_(min_int, max_int).sub_(zeros)
        ).mul_(scales)
    else:
        w = (
            torch.clamp(torch.round(w / scales) + zeros, min_int, max_int) - zeros
        ) * scales
    assert torch.isnan(w).sum() == 0

    w = w.reshape(org_w_shape)

    if get_scale_zp:
        return w, scales.view(w.shape[0], -1), zeros.view(w.shape[0], -1)
    else:
        return w

# TODO: add min_int and max_int as optional args
def group_q1(
    w, n_bit=4, assymetric=True, q_group_size=-1, inplace=False, get_scale_zp=False, clamp=True, round_zeros=True
):
    org_w_shape = w.shape
    if q_group_size > 0:
        assert org_w_shape[-1] % q_group_size == 0
        w = w.reshape(-1, q_group_size)
    assert w.dim() == 2
    if assymetric:
        max_val = w.amax(dim=1, keepdim=True)
        min_val = w.amin(dim=1, keepdim=True)
        max_int = 2**n_bit - 1
        min_int = 0
        scales = (max_val - min_val).clamp(min=1e-5) / (max_int - min_int)
        if round_zeros:
            zeros = min_int -torch.round(min_val / scales)
        else:
            zeros = min_int -(min_val / scales)
        if clamp:
            zeros.clamp_(min_int, max_int)
    else:  # we actually never used this
        max_val = w.abs().amax(dim=1, keepdim=True)
        max_val = max_val.clamp(min=1e-5)
        max_int = 2 ** (n_bit - 1) - 1
        min_int = -(2 ** (n_bit - 1))
        scales = max_val / max_int
        zeros = 0

    assert torch.isnan(scales).sum() == 0
    assert torch.isnan(w).sum() == 0

    if inplace:
        w.div_(scales).add_(zeros)
        if clamp:
            w.clamp_(min_int, max_int)
    else:
        w = (w / scales) + zeros
        if clamp:
            w = torch.clamp(w, min_int, max_int)
    assert torch.isnan(w).sum() == 0

    w = w.reshape(org_w_shape)

    if get_scale_zp:
        return w, scales, zeros
    else:
        return w


def degroup_q1(
    w, scales_and_zeros=None, scales=None, zeros=None, q_group_size=-1, inplace=False
):
    if scales is None:
        scales, zeros = extract_scales_and_zeros(scales_and_zeros, w.shape, q_group_size)

    assert torch.isnan(scales).sum() == 0
    assert torch.isnan(w).sum() == 0

    if inplace:
        w.sub_(zeros).mul_(scales)
    else:
        w = (w - zeros) * scales
    assert torch.isnan(w).sum() == 0

    return w

def intq_layer(module: torch.nn.Linear, n_bit: int = 4, group_size: int = 128, transpose=False, pseudo=None, new_grouping=False, zero_point=False, **kwargs):
    w = module.weight

    if pseudo is None:
        if n_bit in [4, 8] and import_or_skip("tinygemm"):
            pseudo = False
        else:
            pseudo = True

    if transpose:
        w = w.t()

    if pseudo:
        w_deq = intq_reconstruct_tensor(w, n_bit=n_bit, q_group_size=group_size, **kwargs)
        # w_deq = pseudo_quantize_tensor(w, n_bit=n_bit, assymetric=not kwargs.get("scale_only", False), q_group_size=group_size)

        if transpose:
            w_deq = w_deq.t()

        module.weight.data = w_deq.to(device=module.weight.device, dtype=module.weight.dtype)
    else:
        # FIXME: find a better way than hacking the values of `new_grouping` and `zero_point`
        intq, _, scales_and_zeros = intq_quantize_tensor(w, n_bit=n_bit, q_group_size=group_size, new_grouping="tinygemm", zero_point=False, **kwargs)

        if transpose:
            intq = intq.t()
            scales, zeros = extract_scales_and_zeros(scales_and_zeros, w.shape, group_size)
            scales = scales.t()
            zeros = zeros.t()
            scales_and_zeros = pack_scales_and_zeros(scales, zeros, w.shape)
        if n_bit == 4:
            from modules import Int4Linear
            qmodule = Int4Linear(
                in_features=module.in_features,
                out_features=module.out_features,
                bias=module.bias is not None,
                device=module.weight.device,
                dtype=module.weight.dtype,
                group_size=group_size,
            )
        elif n_bit == 8:
            from modules import Int8Linear
            qmodule = Int8Linear(
                in_features=module.in_features,
                out_features=module.out_features,
                bias=module.bias is not None,
                device=module.weight.device,
                dtype=module.weight.dtype,
                group_size=group_size,
            )
        else:
            raise ValueError(f"No int quantized modules supported for n_bit={n_bit}. You may consider setting pseudo=True.")
        qmodule.weight.data = intq.to(device=module.weight.device)
        qmodule.scales_and_zeros.data = scales_and_zeros.to(device=module.weight.device)
        qmodule.bias = module.bias
        qmodule.reshape_weight()
        module = qmodule

    return module

def cluster_row_custom(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, **kwargs):
    init = kmeans.build_init(x=r, n_clusters=2 ** n_bit, init_type=init)
    if init is None:
        init = "k-means++"
    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)
    assign_val, any4, assign = kmeans.kmeans(r, n_clusters=2**n_bit, init=init, sample_weight=sample_weight, X_surrogate=r_surrogate, **kwargs)

    any4 = torch.from_numpy(any4).reshape(2**n_bit)
    assign = torch.from_numpy(assign).flatten()
    assign_val = torch.from_numpy(assign_val).flatten()

    return assign, any4, assign_val

def cluster_row_scikit(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, **kwargs):
    assert r_surrogate==None, "scikit clustering does not support surrogate_to_cluster"
    init = kmeans.build_init(x=r, n_clusters=2 ** n_bit, init_type=init)
    if init is None:
        init = "k-means++"
    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)

    clusters = sklearn.cluster.KMeans(n_clusters=2**n_bit, init=init, random_state=0, n_init="auto", **kwargs).fit(r, sample_weight=sample_weight)
    any4 = torch.from_numpy(clusters.cluster_centers_).reshape(2**n_bit)
    assign = torch.from_numpy(clusters.labels_)
    assign_val = torch.from_numpy(clusters.cluster_centers_[clusters.predict(r)]).flatten()

    return assign, any4, assign_val


def cluster_row_dp(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, **kwargs):
    if init not in (None, 'dp'):
        raise ValueError('cluster_row=dp does not use init; pass init=None.')
    if r_surrogate is not None:
        raise ValueError('cluster_row=dp does not support surrogate clustering.')
    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)
    assign_val, any4, assign = kmeans.kmeans_1d_dp(r, n_clusters=2**n_bit, sample_weight=sample_weight, **kwargs)
    any4 = torch.from_numpy(any4).reshape(2**n_bit)
    assign = torch.from_numpy(assign).flatten()
    assign_val = torch.from_numpy(assign_val).flatten()
    return assign, any4, assign_val



def cluster_row_identity(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, **kwargs):
    if r_surrogate is not None:
        raise ValueError('cluster_row=identity does not support surrogate clustering.')
    max_code = 2 ** n_bit - 1
    x = np.asarray(r, dtype=np.float64).reshape(-1)
    x = np.nan_to_num(x, nan=0.0, posinf=float(max_code), neginf=0.0)
    assign = np.clip(np.rint(x), 0, max_code).astype(np.int64)
    any4 = np.arange(0, max_code + 1, dtype=np.float64)
    assign_val = any4[assign]
    return torch.from_numpy(assign), torch.from_numpy(any4), torch.from_numpy(assign_val)

def cluster_row_lite(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, max_iter=8, **kwargs):
    if r_surrogate is not None:
        raise ValueError('cluster_row=lite does not support surrogate clustering.')
    x = np.asarray(r, dtype=np.float64).reshape(-1)
    k = 2 ** n_bit
    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)
    if sample_weight is None:
        w = np.ones_like(x)
    else:
        w = np.asarray(sample_weight, dtype=np.float64).reshape(-1)
        if w.sum() == 0:
            w = np.ones_like(x)
    if x.size <= k:
        order = np.argsort(x, kind='mergesort')
        centroids = np.empty(k, dtype=np.float64)
        centroids[:x.size] = x[order]
        centroids[x.size:] = x[order[-1]]
    else:
        quantiles = np.linspace(0.0, 1.0, k)
        centroids = np.quantile(x, quantiles)
    labels = np.zeros(x.shape[0], dtype=np.int64)
    for _ in range(max_iter):
        distances = np.abs(x[:, None] - centroids[None, :])
        new_labels = np.argmin(distances, axis=1)
        if np.array_equal(labels, new_labels):
            break
        labels = new_labels
        for j in range(k):
            mask = labels == j
            if mask.any():
                denom = w[mask].sum()
                centroids[j] = x[mask].mean() if denom == 0 else np.average(x[mask], weights=w[mask])
    assign_val = centroids[labels]
    return torch.from_numpy(labels), torch.from_numpy(centroids), torch.from_numpy(assign_val)

def cluster_row_agglomerative(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, **kwargs):
    assert r_surrogate==None, "scikit clustering does not support surrogate_to_cluster"
    assert init==None, "agglomerative clustering does not support init"
    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)

    clusters = sklearn.cluster.AgglomerativeClustering(n_clusters=2**n_bit, **kwargs).fit(r)
    assign = np.array(clusters.labels_)
    any4 = np.array([np.average(r[assign == label].flatten(), weights=sample_weight[assign == label] if sample_weight is not None else None) for label in np.unique(assign)])
    assign_val = any4[assign]

    return torch.from_numpy(assign), torch.from_numpy(any4), torch.from_numpy(assign_val)


def cluster_row_outlier_reserved(r, n_bit=4, init=None, sample_weight=None, r_surrogate=None, abs_sample_weight=True, reserved_outlier_codes=2, outlier_kmeans_backend="scikit", **kwargs):
    assert r_surrogate==None, "outlier_reserved clustering does not support surrogate_to_cluster"
    assert n_bit == 4, "outlier_reserved is currently implemented for 4-bit LUTs"
    if reserved_outlier_codes not in (1, 2):
        raise ValueError(f"reserved_outlier_codes must be 1 or 2, got {reserved_outlier_codes}")
    if outlier_kmeans_backend not in ("scikit", "dp"):
        raise ValueError(f"outlier_kmeans_backend must be scikit or dp, got {outlier_kmeans_backend}")

    total_codes = 2 ** n_bit
    kmeans_codes = total_codes - reserved_outlier_codes
    r_flat = np.asarray(r).reshape(-1)
    if r_flat.shape[0] <= reserved_outlier_codes:
        raise ValueError("row has too few values for reserved outlier clustering")

    sample_weight = kmeans.build_sample_weight(x=r, sample_weight_type=sample_weight, abs=abs_sample_weight)
    outlier_idx = np.argpartition(np.abs(r_flat), -reserved_outlier_codes)[-reserved_outlier_codes:]
    outlier_idx = outlier_idx[np.argsort(-np.abs(r_flat[outlier_idx]))]
    normal_mask = np.ones(r_flat.shape[0], dtype=bool)
    normal_mask[outlier_idx] = False
    normal_r = r[normal_mask]
    if normal_r.shape[0] < kmeans_codes:
        raise ValueError(f"need at least {kmeans_codes} normal values, got {normal_r.shape[0]}")

    normal_weight = sample_weight[normal_mask] if sample_weight is not None else None
    if outlier_kmeans_backend == "dp":
        _, normal_centroids, normal_labels = kmeans.kmeans_1d_dp(normal_r, n_clusters=kmeans_codes, sample_weight=normal_weight, **kwargs)
        normal_centroids = np.asarray(normal_centroids).reshape(kmeans_codes)
        normal_labels = np.asarray(normal_labels).reshape(-1)
    else:
        normal_init = kmeans.build_init(x=normal_r, n_clusters=kmeans_codes, init_type=init)
        if normal_init is None:
            normal_init = "k-means++"
        clusters = sklearn.cluster.KMeans(n_clusters=kmeans_codes, init=normal_init, random_state=0, n_init="auto", **kwargs).fit(normal_r, sample_weight=normal_weight)
        normal_centroids = clusters.cluster_centers_.reshape(kmeans_codes)
        normal_labels = clusters.labels_

    any4 = torch.zeros(total_codes, dtype=torch.float32)
    any4[:kmeans_codes] = torch.from_numpy(normal_centroids.copy()).float()
    any4[kmeans_codes:] = torch.from_numpy(r_flat[outlier_idx].copy()).float()

    assign = torch.empty(r_flat.shape[0], dtype=torch.int64)
    assign[torch.from_numpy(normal_mask)] = torch.from_numpy(normal_labels).long()
    for reserved_offset, idx in enumerate(outlier_idx):
        assign[int(idx)] = kmeans_codes + reserved_offset
    assign_val = any4[assign].float()

    return assign, any4, assign_val


def _method3_cache_safe_name(value):
    value = str(value or "unnamed_linear")
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value)


def _method3_cache_file(cache_dir, layer_name):
    return os.path.join(cache_dir, _method3_cache_safe_name(layer_name) + ".pt")


def _method3_cache_metadata(*, model_path, layer_name, weight_shape, dtype, n_bit, group_size, scale_only, zero_point, reserved_outlier_codes, cluster_row_name, outlier_kmeans_backend="scikit"):
    return {
        "method_name": METHOD3_NAME,
        "model_path": str(model_path) if model_path is not None else None,
        "layer_name": layer_name,
        "weight_shape": list(weight_shape),
        "dtype": str(dtype),
        "n_bit": int(n_bit),
        "group_size": str(group_size),
        "scale_only": bool(scale_only),
        "zero_point": bool(zero_point),
        "reserved_outlier_codes": int(reserved_outlier_codes),
        "cluster_row": cluster_row_name,
        "outlier_kmeans_backend": outlier_kmeans_backend,
    }


def _load_method3_centroids(cache_dir, layer_name, expected_metadata, overwrite=False):
    if cache_dir is None or overwrite:
        return None
    cache_file = _method3_cache_file(cache_dir, layer_name)
    if not os.path.exists(cache_file):
        return None
    try:
        payload = torch.load(cache_file, map_location="cpu")
    except Exception as exc:
        print(f"Failed to load centroids cache {cache_file}: {exc}. Recomputing.")
        return None
    if payload.get("metadata") != expected_metadata:
        print(f"Centroids cache metadata mismatch for {layer_name}. Recomputing.")
        return None
    centroids = payload.get("centroids")
    if not isinstance(centroids, torch.Tensor):
        print(f"Centroids cache missing tensor for {layer_name}. Recomputing.")
        return None
    return centroids.float()


def _save_method3_centroids(cache_dir, layer_name, metadata, centroids):
    if cache_dir is None:
        return
    cache_file = _method3_cache_file(cache_dir, layer_name)
    os.makedirs(os.path.dirname(cache_file), exist_ok=True)
    torch.save({"metadata": metadata, "centroids": centroids.detach().cpu().float()}, cache_file)


def _assign_from_method3_centroids(x, any4):
    any4 = any4.to(device=x.device, dtype=x.dtype)
    assign = torch.empty(x.shape, dtype=torch.int64, device=x.device)
    assign_val = torch.empty_like(x)
    for row in range(x.shape[0]):
        distances = (x[row].unsqueeze(1) - any4[row].unsqueeze(0)).abs()
        row_assign = torch.argmin(distances, dim=1)
        assign[row] = row_assign
        assign_val[row] = any4[row].gather(0, row_assign)
    return assign.cpu(), any4.cpu(), assign_val

# TODO: change arg name x_cluster to x_surrogate
def cluster_matrix(x, n_bit=4, bias_pow=1.0, keep_outliers=False, cluster_row: Callable = cluster_row_scikit, init=None, sample_weight=None, parallelize=True, x_cluster=None, layer_name=None, model_path=None, weight_shape=None, method3_q_group_size=None, method3_scale_only=False, method3_zero_point=True, centroids_cache_dir=None, use_centroids_cache=True, overwrite_centroids_cache=False, cluster_row_name=None, reserved_outlier_codes=2, outlier_kmeans_backend="scikit", **kwargs):
    if bias_pow != 1.0:
        # k-means should be roughly zero centered, since we should bias larger magnitude (negative or positive) values
        # for greater representation.
        # Values are in the range [0, 15] so subtract (15 - 0) / 2 = 7.5 to approximately zero center the data
        #
        # Note that there is no guarantee that each q-group is itself zero centered (there can be a "DC bias")
        # but note that across all q-groups, values closer to 0 and closer to 15 are extremal values
        x = x - ((2 ** n_bit) - 1) / 2.
        # give more weight to extremal values by considering the signed square
        x = (x.abs() ** bias_pow) * torch.sign(x)

    start = time.time()
    if cluster_row is cluster_row_outlier_reserved and use_centroids_cache and centroids_cache_dir is None:
        centroids_cache_dir = DEFAULT_METHOD3_CACHE_DIR
    use_method3_cache = (
        cluster_row is cluster_row_outlier_reserved
        and use_centroids_cache
        and centroids_cache_dir is not None
        and bias_pow == 1.0
        and not keep_outliers
    )
    cache_metadata = None
    if use_method3_cache:
        cache_metadata = _method3_cache_metadata(
            model_path=model_path,
            layer_name=layer_name,
            weight_shape=weight_shape or x.shape,
            dtype=x.dtype,
            n_bit=n_bit,
            group_size=method3_q_group_size,
            scale_only=method3_scale_only,
            zero_point=method3_zero_point,
            reserved_outlier_codes=reserved_outlier_codes,
            cluster_row_name=cluster_row_name or "outlier_reserved",
            outlier_kmeans_backend=outlier_kmeans_backend,
        )
        cached_any4 = _load_method3_centroids(centroids_cache_dir, layer_name, cache_metadata, overwrite=overwrite_centroids_cache)
        if cached_any4 is not None:
            assign, any4, assign_val = _assign_from_method3_centroids(x, cached_any4)
            return assign, any4, assign_val

    to_cluster = x.cpu().detach().float().numpy()
    surrogate_to_cluster = x_cluster.cpu().float().detach().numpy() if x_cluster is not None else None
    sample_weight = sample_weight.cpu().float().detach().numpy() if isinstance(sample_weight, torch.Tensor) else sample_weight
    cluster_kwargs = kwargs.copy()
    if cluster_row is cluster_row_outlier_reserved:
        cluster_kwargs["reserved_outlier_codes"] = reserved_outlier_codes
        cluster_kwargs["outlier_kmeans_backend"] = outlier_kmeans_backend
    if parallelize:
        assign, any4, assign_val = cluster_rows_parallel(to_cluster, cluster_row=cluster_row, n_bit=n_bit, init=init, sample_weight=sample_weight, x_surrogate=surrogate_to_cluster, **cluster_kwargs)
    else:
        assign, any4, assign_val = cluster_rows(to_cluster, cluster_row=cluster_row, init=init, n_bit=n_bit, sample_weight=sample_weight, x_surrogate=surrogate_to_cluster, **cluster_kwargs)
    assign_val = assign_val.to(x.device)

    if use_method3_cache and cache_metadata is not None:
        _save_method3_centroids(centroids_cache_dir, layer_name, cache_metadata, any4)

    if keep_outliers:
        max_outliers = torch.amax(x, dim=1, keepdim=True)
        min_outliers = torch.amin(x, dim=1, keepdim=True)

        any4.scatter_(dim=1, index=torch.argmax(any4, dim=1, keepdim=True), src=max_outliers.to(any4.device))
        any4.scatter_(dim=1, index=torch.argmin(any4, dim=1, keepdim=True), src=min_outliers.to(any4.device))

        assign_val.scatter_(dim=1, index=torch.argmax(assign_val, dim=1, keepdim=True), src=max_outliers.to(assign_val.device))
        assign_val.scatter_(dim=1, index=torch.argmin(assign_val, dim=1, keepdim=True), src=min_outliers.to(assign_val.device))

    if bias_pow != 1.0:
        # undo the pow

        any4 = (any4.abs() ** (1. / bias_pow)) * torch.sign(any4)
        assign_val = (assign_val.abs() ** (1. / bias_pow)) * torch.sign(assign_val)

        # map values back to [0, 15]
        any4 = any4 + ((2 ** n_bit) - 1) / 2.
        assign_val = assign_val + ((2 ** n_bit) - 1) / 2.

    # Clean up memory
    del to_cluster
    if surrogate_to_cluster is not None:
        del surrogate_to_cluster

    return assign, any4, assign_val

def get_sample_weight(sample_weight, index):
    if sample_weight is None:
        return None
    elif np.squeeze(sample_weight).ndim == 1:
        return sample_weight
    elif np.squeeze(sample_weight).ndim == 2:
        return sample_weight[index]

DP_CACHE_VERSION = 1


def _dp_cache_enabled(cluster_row, dp_cache_dir=None, dp_cache_mode="off"):
    return cluster_row is cluster_row_dp and dp_cache_dir is not None and dp_cache_mode != "off"


def _dp_cache_safe_name(value):
    value = str(value or "unknown_layer")
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value)


def _dp_cache_array_hash(value):
    if value is None:
        return "none"
    arr = np.ascontiguousarray(np.asarray(value, dtype=np.float32).reshape(-1))
    h = hashlib.sha256()
    h.update(str(arr.shape).encode("utf-8"))
    h.update(arr.tobytes())
    return h.hexdigest()


def _dp_cache_path(dp_cache_dir, layer_name, row_index, n_bit, q_group_size, scale_sample_weight, row_hash, sample_weight_hash):
    layer_dir = os.path.join(dp_cache_dir, _dp_cache_safe_name(layer_name))
    key = {
        "version": DP_CACHE_VERSION,
        "layer_name": str(layer_name),
        "row_index": int(row_index),
        "n_bit": int(n_bit),
        "q_group_size": str(q_group_size),
        "cluster_row": "dp",
        "scale_sample_weight": bool(scale_sample_weight),
        "row_hash": row_hash,
        "sample_weight_hash": sample_weight_hash,
    }
    key_json = json.dumps(key, sort_keys=True, separators=(",", ":"))
    name = hashlib.sha256(key_json.encode("utf-8")).hexdigest() + ".npz"
    return os.path.join(layer_dir, name), key, key_json


def _dp_assign_from_centroids(r, centroids):
    x = np.asarray(r, dtype=np.float64).reshape(-1)
    c = np.asarray(centroids, dtype=np.float64).reshape(-1)
    labels = np.argmin(np.abs(x[:, None] - c[None, :]), axis=1).astype(np.int64)
    assign_val = c[labels]
    return (
        torch.from_numpy(labels),
        torch.from_numpy(c.astype(np.float32)),
        torch.from_numpy(assign_val.astype(np.float32)),
    )


def _atomic_json_write(path, payload):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp.", suffix=".json", dir=parent or ".")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
            f.write("\n")
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _dp_cache_write(path, centroids, metadata):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp.", suffix=".npz", dir=parent)
    os.close(fd)
    try:
        np.savez(
            tmp,
            centroids=np.asarray(centroids, dtype=np.float32).reshape(-1),
            metadata=json.dumps(metadata, sort_keys=True),
        )
        if not tmp.endswith(".npz"):
            tmp_npz = tmp + ".npz"
        else:
            tmp_npz = tmp
        os.replace(tmp_npz, path)
        if tmp_npz != tmp and os.path.exists(tmp):
            os.unlink(tmp)
    except Exception:
        for candidate in (tmp, tmp + ".npz"):
            try:
                if os.path.exists(candidate):
                    os.unlink(candidate)
            except OSError:
                pass
        raise


def _dp_cache_stats_empty():
    return {
        "version": DP_CACHE_VERSION,
        "hits": 0,
        "misses": 0,
        "writes": 0,
        "readonly_misses": 0,
        "verify_ok": 0,
        "verify_fail": 0,
        "rows": 0,
        "layers": {},
    }


def _merge_dp_cache_stats(path, layer_name, stats):
    if not path:
        return
    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                total = json.load(f)
        except Exception:
            total = _dp_cache_stats_empty()
    else:
        total = _dp_cache_stats_empty()
    layer_key = str(layer_name or "unknown_layer")
    layer_stats = total["layers"].setdefault(layer_key, _dp_cache_stats_empty())
    for key in ("hits", "misses", "writes", "readonly_misses", "verify_ok", "verify_fail", "rows"):
        total[key] = int(total.get(key, 0)) + int(stats.get(key, 0))
        layer_stats[key] = int(layer_stats.get(key, 0)) + int(stats.get(key, 0))
    total["hit_ratio"] = total["hits"] / total["rows"] if total["rows"] else 0.0
    layer_stats["hit_ratio"] = layer_stats["hits"] / layer_stats["rows"] if layer_stats["rows"] else 0.0
    _atomic_json_write(path, total)


def _cluster_row_dp_cached(r, row_index, n_bit=4, sample_weight=None, r_surrogate=None, dp_cache_dir=None, dp_cache_mode="off", dp_cache_verify=False, layer_name=None, dp_cache_q_group_size=None, dp_cache_scale_sample_weight=False, **kwargs):
    stats = {"hits": 0, "misses": 0, "writes": 0, "readonly_misses": 0, "verify_ok": 0, "verify_fail": 0, "rows": 1}
    row_hash = _dp_cache_array_hash(r)
    sample_weight_hash = _dp_cache_array_hash(sample_weight)
    path, key, key_json = _dp_cache_path(dp_cache_dir, layer_name, row_index, n_bit, dp_cache_q_group_size, dp_cache_scale_sample_weight, row_hash, sample_weight_hash)

    if os.path.exists(path):
        with np.load(path, allow_pickle=False) as data:
            centroids = data["centroids"].astype(np.float32)
        assign, any4, assign_val = _dp_assign_from_centroids(r, centroids)
        stats["hits"] = 1
        if dp_cache_verify:
            ref_assign, ref_any4, ref_assign_val = cluster_row_dp(r, n_bit=n_bit, sample_weight=sample_weight, r_surrogate=r_surrogate, **kwargs)
            if torch.allclose(assign_val.float(), ref_assign_val.float(), atol=1e-5, rtol=1e-5):
                stats["verify_ok"] = 1
            else:
                stats["verify_fail"] = 1
                raise AssertionError(f"DP cache verification failed for {layer_name} row {row_index}")
        return assign, any4, assign_val, stats

    stats["misses"] = 1
    if dp_cache_mode == "readonly":
        stats["readonly_misses"] = 1
    assign, any4, assign_val = cluster_row_dp(r, n_bit=n_bit, sample_weight=sample_weight, r_surrogate=r_surrogate, **kwargs)
    if dp_cache_mode == "readwrite":
        metadata = dict(key)
        metadata.update({
            "key_json": key_json,
            "row_shape": list(np.asarray(r).shape),
            "created_at": time.time(),
        })
        _dp_cache_write(path, any4.numpy(), metadata)
        stats["writes"] = 1
    return assign, any4, assign_val, stats

def cluster_rows(x, cluster_row: Callable = cluster_row_scikit, n_bit=4, x_surrogate=None, sample_weight=None, **kwargs):
    assign = torch.zeros(x.shape, dtype=torch.int32)
    any4 = torch.zeros((x.shape[0], 2**n_bit))
    assign_val = torch.zeros(x.shape)
    dp_cache_dir = kwargs.pop("dp_cache_dir", None)
    dp_cache_mode = kwargs.pop("dp_cache_mode", "off")
    dp_cache_verify = kwargs.pop("dp_cache_verify", False)
    dp_cache_stats_path = kwargs.pop("dp_cache_stats_path", None)
    layer_name = kwargs.pop("layer_name", None)
    cache_enabled = _dp_cache_enabled(cluster_row, dp_cache_dir, dp_cache_mode)
    stats = _dp_cache_stats_empty()

    for row in range(x.shape[0]):
        r = x[row].reshape(x.shape[1], 1)
        row_sample_weight = get_sample_weight(sample_weight, row)
        if x_surrogate is not None:
            r_surrogate = x_surrogate[row].reshape(x_surrogate.shape[1], 1)
            if cache_enabled:
                assign[row], any4[row], assign_val[row], row_stats = _cluster_row_dp_cached(r, row, n_bit=n_bit, sample_weight=row_sample_weight, r_surrogate=r_surrogate, dp_cache_dir=dp_cache_dir, dp_cache_mode=dp_cache_mode, dp_cache_verify=dp_cache_verify, layer_name=layer_name, **kwargs)
            else:
                assign[row], any4[row], assign_val[row] = cluster_row(r, n_bit, sample_weight=row_sample_weight, r_surrogate=r_surrogate, **kwargs)
                row_stats = None
        else:
            if cache_enabled:
                assign[row], any4[row], assign_val[row], row_stats = _cluster_row_dp_cached(r, row, n_bit=n_bit, sample_weight=row_sample_weight, dp_cache_dir=dp_cache_dir, dp_cache_mode=dp_cache_mode, dp_cache_verify=dp_cache_verify, layer_name=layer_name, **kwargs)
            else:
                assign[row], any4[row], assign_val[row] = cluster_row(r, n_bit, sample_weight=row_sample_weight, **kwargs)
                row_stats = None
        if row_stats:
            for key in ("hits", "misses", "writes", "readonly_misses", "verify_ok", "verify_fail", "rows"):
                stats[key] += row_stats[key]

    if cache_enabled:
        _merge_dp_cache_stats(dp_cache_stats_path, layer_name, stats)

    return assign, any4, assign_val

def cluster_rows_parallel(x, cluster_row: Callable = cluster_row_scikit, x_surrogate=None, sample_weight=None, **kwargs):
    parallel_jobs = kwargs.pop("parallel_jobs", 8)
    parallel_backend = kwargs.pop("parallel_backend", "loky")
    parallel_batch_size = kwargs.pop("parallel_batch_size", "auto")
    parallel_pre_dispatch = kwargs.pop("parallel_pre_dispatch", "2*n_jobs")
    parallel_inner_threads = kwargs.pop("parallel_inner_threads", 1)
    dp_cache_dir = kwargs.pop("dp_cache_dir", None)
    dp_cache_mode = kwargs.pop("dp_cache_mode", "off")
    dp_cache_verify = kwargs.pop("dp_cache_verify", False)
    dp_cache_stats_path = kwargs.pop("dp_cache_stats_path", None)
    layer_name = kwargs.pop("layer_name", None)
    cache_enabled = _dp_cache_enabled(cluster_row, dp_cache_dir, dp_cache_mode)
    if parallel_backend not in ("threading", "loky"):
        raise ValueError(f"parallel_backend must be threading or loky, got {parallel_backend}")

    if cache_enabled:
        cache_kwargs = dict(kwargs)
        cache_n_bit = cache_kwargs.pop("n_bit", 4)
        if x_surrogate is None:
            tasks = (delayed(_cluster_row_dp_cached)(x[row].reshape(-1, 1), row, n_bit=cache_n_bit, sample_weight=get_sample_weight(sample_weight, row), dp_cache_dir=dp_cache_dir, dp_cache_mode=dp_cache_mode, dp_cache_verify=dp_cache_verify, layer_name=layer_name, **cache_kwargs) for row in range(x.shape[0]))
        else:
            tasks = (delayed(_cluster_row_dp_cached)(x[row].reshape(-1, 1), row, n_bit=cache_n_bit, sample_weight=get_sample_weight(sample_weight, row), r_surrogate=x_surrogate[row].reshape(-1, 1), dp_cache_dir=dp_cache_dir, dp_cache_mode=dp_cache_mode, dp_cache_verify=dp_cache_verify, layer_name=layer_name, **cache_kwargs) for row in range(x.shape[0]))
    else:
        if x_surrogate is None:
            tasks = (delayed(cluster_row)(x[row].reshape(-1, 1), sample_weight=get_sample_weight(sample_weight, row), **kwargs) for row in range(x.shape[0]))
        else:
            tasks = (delayed(cluster_row)(x[row].reshape(-1, 1), sample_weight=get_sample_weight(sample_weight, row), r_surrogate=x_surrogate[row].reshape(-1, 1), **kwargs) for row in range(x.shape[0]))
    parallel_options = dict(
        n_jobs=parallel_jobs,
        backend=parallel_backend,
        batch_size=parallel_batch_size,
        pre_dispatch=parallel_pre_dispatch,
    )
    if parallel_backend == "loky":
        parallel_options["inner_max_num_threads"] = max(
            1, int(parallel_inner_threads)
        )
    parallel_runner = Parallel(**parallel_options)
    if parallel_backend == "threading":
        with threadpool_limits(limits=max(1, int(parallel_inner_threads))):
            results: List = parallel_runner(tasks)
    else:
        results: List = parallel_runner(tasks)
    # Transpose the list of tuples to a tuple of lists
    results_transposed = tuple(zip(*results))
    # Convert each item in the tuple (which are tuples) to lists
    results_transposed = tuple(list(item) for item in results_transposed)

    # Unpack into different matrices
    assign = torch.stack(results_transposed[0], dim=0).contiguous()
    any4 = torch.stack(results_transposed[1], dim=0).contiguous()
    assign_val = torch.stack(results_transposed[2], dim=0).contiguous()
    if cache_enabled:
        stats = _dp_cache_stats_empty()
        for row_stats in results_transposed[3]:
            for key in ("hits", "misses", "writes", "readonly_misses", "verify_ok", "verify_fail", "rows"):
                stats[key] += row_stats[key]
        _merge_dp_cache_stats(dp_cache_stats_path, layer_name, stats)

    return assign, any4, assign_val



def build_fisher_sample_weight(sample_weight, Wg, W):
    if sample_weight is None:
        raise ValueError("fisher_sample_weight=True requires calibration sample_weight.")
    if not isinstance(sample_weight, torch.Tensor):
        sample_weight = torch.as_tensor(sample_weight)

    fisher = sample_weight.to(device=Wg.device, dtype=Wg.dtype)
    if fisher.dim() == 1:
        if fisher.numel() != Wg.shape[1]:
            raise ValueError(
                f"fisher sample_weight length {fisher.numel()} does not match weight columns {Wg.shape[1]}"
            )
        fisher = fisher.reshape(1, -1).expand_as(Wg)
    elif fisher.dim() == 2:
        if tuple(fisher.shape) != tuple(Wg.shape):
            raise ValueError(
                f"fisher sample_weight shape {tuple(fisher.shape)} does not match normalized weight shape {tuple(Wg.shape)}"
            )
    else:
        raise ValueError(f"fisher sample_weight must be 1D or 2D, got {fisher.dim()}D")

    weight_mask = (W.to(device=Wg.device) != 0).to(Wg.dtype)
    fisher = torch.nan_to_num(fisher, nan=0.0, posinf=0.0, neginf=0.0).clamp_min(0)
    fisher = fisher * weight_mask
    empty_rows = fisher.sum(dim=1, keepdim=True) == 0
    if empty_rows.any():
        fisher = torch.where(empty_rows.expand_as(fisher), torch.ones_like(fisher), fisher)
    return fisher



def build_guided_hessian_sample_weight(sample_weight, Wg, W):
    """Expand a compressed GuidedQuant Hessian diagonal to weight rows."""
    if sample_weight is None or not isinstance(sample_weight, dict):
        raise ValueError("guided_hessian_sample_weight requires a per-layer dict.")
    if "diag" not in sample_weight or "row_boundaries" not in sample_weight:
        raise ValueError("Guided Hessian entry must contain diag and row_boundaries.")

    diag = torch.as_tensor(sample_weight["diag"], device=Wg.device, dtype=Wg.dtype)
    boundaries = [int(v) for v in sample_weight["row_boundaries"]]
    if diag.dim() != 2 or diag.shape[1] != Wg.shape[1]:
        raise ValueError(
            f"Guided Hessian diag shape {tuple(diag.shape)} is incompatible "
            f"with weight shape {tuple(Wg.shape)}"
        )
    if len(boundaries) != diag.shape[0] + 1 or boundaries[0] != 0 or boundaries[-1] != Wg.shape[0]:
        raise ValueError(
            f"Guided Hessian row boundaries {boundaries} do not cover {Wg.shape[0]} rows."
        )

    guided = torch.empty_like(Wg)
    for group_idx, (start, end) in enumerate(zip(boundaries[:-1], boundaries[1:])):
        guided[start:end] = diag[group_idx].reshape(1, -1)

    guided = torch.nan_to_num(guided, nan=0.0, posinf=0.0, neginf=0.0).clamp_min(0)
    guided = guided * (W.to(device=Wg.device) != 0).to(Wg.dtype)
    empty_rows = guided.sum(dim=1, keepdim=True) == 0
    if empty_rows.any():
        guided = torch.where(empty_rows.expand_as(guided), torch.ones_like(guided), guided)
    return guided


def _method10_group_affine_from_scales_and_zeros(scales_and_zeros):
    grouped = scales_and_zeros.transpose(0, 1).contiguous().float()
    scales = grouped[:, :, 0]
    zeros = grouped[:, :, 1]
    offsets = zeros - 8.0 * scales
    return scales, offsets


def _method10_expand_group_values(values, group_size, cols):
    rows, groups = values.shape
    return values[:, :, None].expand(rows, groups, group_size).reshape(rows, cols)


def _method10_sort_lut(C, assign):
    order = torch.argsort(C, dim=1)
    C_sorted = torch.gather(C, dim=1, index=order)
    inv = torch.empty_like(order)
    labels = torch.arange(C.shape[1], device=C.device).view(1, -1).expand_as(order)
    inv.scatter_(1, order, labels)
    assign_sorted = torch.gather(inv, dim=1, index=assign.long())
    return C_sorted, assign_sorted


def _method10_assign_nearest(W, C, scales, offsets, group_size, chunk_rows=256):
    rows, cols = W.shape
    groups = cols // group_size
    W3 = W.view(rows, groups, group_size)
    assign = torch.empty((rows, cols), dtype=torch.long, device=W.device)
    for start in range(0, rows, chunk_rows):
        end = min(start + chunk_rows, rows)
        w_chunk = W3[start:end]
        recon = scales[start:end, :, None, None] * C[start:end, None, None, :] + offsets[start:end, :, None, None]
        dist = (w_chunk[..., None] - recon).pow(2)
        assign[start:end] = torch.argmin(dist, dim=-1).reshape(end - start, cols)
    return assign


def _method10_reconstruct(W, C, assign, scales, offsets, group_size):
    rows, cols = W.shape
    codes = torch.gather(C, dim=1, index=assign.long())
    scale_e = _method10_expand_group_values(scales, group_size, cols)
    offset_e = _method10_expand_group_values(offsets, group_size, cols)
    return scale_e * codes + offset_e


def _method10_loss(W, C, assign, scales, offsets, group_size):
    W_hat = _method10_reconstruct(W, C, assign, scales, offsets, group_size)
    return torch.mean((W - W_hat).pow(2)).item()


def _method10_update_codebook(W, C, assign, scales, offsets, group_size, eps=1e-12, scale_eps=1e-6):
    rows, cols = W.shape
    K = C.shape[1]
    scale_e = _method10_expand_group_values(scales, group_size, cols)
    offset_e = _method10_expand_group_values(offsets, group_size, cols)
    num_src = scale_e * (W - offset_e)
    den_src = scale_e.pow(2)
    num = torch.zeros((rows, K), dtype=W.dtype, device=W.device)
    den = torch.zeros((rows, K), dtype=W.dtype, device=W.device)
    num.scatter_add_(1, assign.long(), num_src)
    den.scatter_add_(1, assign.long(), den_src)
    non_empty = den > eps
    C_new = torch.where(non_empty, num / den.clamp_min(eps), C)

    empty = ~non_empty
    if empty.any():
        W_hat = scale_e * torch.gather(C, dim=1, index=assign.long()) + offset_e
        err = (W - W_hat).pow(2)
        code_values = (W - offset_e) / scale_e.clamp_min(scale_eps)
        for row in torch.nonzero(empty.any(dim=1), as_tuple=False).flatten().tolist():
            empty_codes = torch.nonzero(empty[row], as_tuple=False).flatten()
            top_idx = torch.topk(err[row], k=int(empty_codes.numel()), largest=True).indices
            C_new[row, empty_codes] = code_values[row, top_idx]
    return C_new


def _method10_update_affine(W, C, assign, group_size, ridge=1e-6, scale_eps=1e-6):
    rows, cols = W.shape
    groups = cols // group_size
    W3 = W.view(rows, groups, group_size)
    codes = torch.gather(C, dim=1, index=assign.long()).view(rows, groups, group_size)
    x_mean = codes.mean(dim=2)
    w_mean = W3.mean(dim=2)
    x_centered = codes - x_mean[:, :, None]
    w_centered = W3 - w_mean[:, :, None]
    denom = x_centered.pow(2).sum(dim=2)
    numer = (x_centered * w_centered).sum(dim=2)
    raw_scale = numer / (denom + ridge)
    valid = (denom > ridge) & torch.isfinite(raw_scale) & (raw_scale > scale_eps)
    scales = torch.where(valid, raw_scale.clamp_min(scale_eps), torch.full_like(raw_scale, scale_eps))
    offsets_reg = w_mean - scales * x_mean
    offsets = torch.where(valid, offsets_reg, w_mean)
    return scales, offsets


def method10_joint_affine_quantize_tensor(
    W,
    n_bit=4,
    q_group_size=128,
    per_row=True,
    zero_point=True,
    scale_only=False,
    init=None,
    parallelize=True,
    method10_n_iter=10,
    method10_tol=1e-6,
    method10_ridge=1e-6,
    method10_scale_eps=1e-6,
    method10_chunk_rows=256,
    method10_sort_lut=True,
    method10_return_debug=False,
    **kwargs,
):
    if n_bit != 4:
        raise ValueError("method10_joint_affine requires n_bit=4.")
    if not per_row:
        raise ValueError("method10_joint_affine requires per_row=True.")
    if not isinstance(q_group_size, int) or q_group_size <= 1:
        raise ValueError("method10_joint_affine requires a fixed integer q_group_size > 1.")
    if scale_only:
        raise ValueError("method10_joint_affine currently expects asymmetric affine grouping, not scale_only.")
    if W.dim() != 2 or W.shape[1] % q_group_size != 0:
        raise ValueError(f"method10_joint_affine expects 2D weight with columns divisible by group size, got {tuple(W.shape)} and {q_group_size}.")

    orig_device = W.device
    W_work = W.detach().float()
    Wg, _, init_scales_and_zeros = group_q(W_work, n_bit, q_group_size=q_group_size, assymetric=True, zero_point=True)
    scales, offsets = _method10_group_affine_from_scales_and_zeros(init_scales_and_zeros)
    scales = scales.to(device=W_work.device, dtype=W_work.dtype)
    offsets = offsets.to(device=W_work.device, dtype=W_work.dtype)

    assign, C, _ = cluster_matrix(
        Wg.contiguous(),
        n_bit=n_bit,
        bias_pow=1.0,
        keep_outliers=False,
        cluster_row=cluster_row_scikit,
        init=init,
        sample_weight=None,
        parallelize=parallelize,
        x_cluster=None,
        **{k: v for k, v in kwargs.items() if k in ("max_iter", "tol", "parallel_jobs")},
    )
    assign = assign.to(device=W_work.device, dtype=torch.long)
    C = C.to(device=W_work.device, dtype=W_work.dtype)
    if method10_sort_lut:
        C, assign = _method10_sort_lut(C, assign)

    loss = _method10_loss(W_work, C, assign, scales, offsets, q_group_size)
    init_loss = loss
    best_loss = loss
    best_state = (C.clone(), assign.clone(), scales.clone(), offsets.clone())
    prev_loss = loss

    for _ in range(int(method10_n_iter)):
        assign = _method10_assign_nearest(W_work, C, scales, offsets, q_group_size, chunk_rows=int(method10_chunk_rows))
        C = _method10_update_codebook(W_work, C, assign, scales, offsets, q_group_size, scale_eps=method10_scale_eps)
        if method10_sort_lut:
            C, assign = _method10_sort_lut(C, assign)
        scales, offsets = _method10_update_affine(W_work, C, assign, q_group_size, ridge=method10_ridge, scale_eps=method10_scale_eps)
        loss = _method10_loss(W_work, C, assign, scales, offsets, q_group_size)
        if loss <= best_loss:
            best_loss = loss
            best_state = (C.clone(), assign.clone(), scales.clone(), offsets.clone())
        if prev_loss - loss < method10_tol:
            break
        prev_loss = loss

    C, assign, scales, offsets = best_state
    final_assign = _method10_assign_nearest(W_work, C, scales, offsets, q_group_size, chunk_rows=int(method10_chunk_rows))
    final_loss = _method10_loss(W_work, C, final_assign, scales, offsets, q_group_size)
    if final_loss <= best_loss:
        assign = final_assign
        best_loss = final_loss
    zeros = offsets + 8.0 * scales
    scales_and_zeros = pack_scales_and_zeros(scales, zeros, W_work.shape)
    if method10_return_debug:
        print(f"method10_joint_affine init_loss={init_loss:.8e} best_loss={best_loss:.8e}")
    return assign.to(orig_device), C.to(orig_device, W.dtype), scales_and_zeros.to(orig_device, W.dtype)

def reset_method11_stats():
    _METHOD11_LAYER_STATS.clear()


def get_method11_stats():
    return json.loads(json.dumps(_METHOD11_LAYER_STATS))


def _method11_record_stats(layer_name, stats):
    _METHOD11_LAYER_STATS[layer_name or "<tensor>"] = stats


def _method11_array_hash(value):
    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        value = value.detach().cpu().contiguous().numpy()
    array = np.ascontiguousarray(value)
    digest = hashlib.sha256()
    digest.update(str(array.shape).encode("utf-8"))
    digest.update(str(array.dtype).encode("utf-8"))
    digest.update(memoryview(array).cast("B"))
    return digest.hexdigest()


def _method11_cache_file(cache_dir, layer_name):
    safe_name = (layer_name or "tensor").replace(".", "__").replace("/", "_")
    return os.path.join(cache_dir, safe_name + ".pt")


def _method11_cache_metadata(
    W,
    sample_weight,
    layer_name,
    model_path,
    group_size,
    num_tables,
    table_size,
    joint_affine,
    fisher_sample_weight,
    max_iter,
    tol,
    ridge,
    scale_eps,
    init,
):
    return {
        "algorithm": METHOD11_ALGORITHM_VERSION,
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(W.shape),
        "weight_dtype": str(W.dtype),
        "weight_hash": _method11_array_hash(W),
        "sample_weight_hash": _method11_array_hash(sample_weight),
        "n_bit": 2,
        "group_size": int(group_size),
        "num_tables": int(num_tables),
        "table_size": int(table_size),
        "joint_affine": bool(joint_affine),
        "fisher_sample_weight": bool(fisher_sample_weight),
        "max_iter": int(max_iter),
        "tol": float(tol),
        "ridge": float(ridge),
        "scale_eps": float(scale_eps),
        "init": str(init),
    }


def _method11_load_cache(cache_dir, layer_name, metadata, overwrite=False):
    if not cache_dir or overwrite:
        return None
    cache_file = _method11_cache_file(cache_dir, layer_name)
    if not os.path.exists(cache_file):
        return None
    try:
        payload = torch.load(cache_file, map_location="cpu")
    except Exception as exc:
        print(f"Failed to load method11 cache {cache_file}: {exc}. Recomputing.")
        return None
    if payload.get("metadata") != metadata:
        return None
    lut = payload.get("lut")
    scales_and_zeros = payload.get("scales_and_zeros")
    if not isinstance(lut, torch.Tensor) or not isinstance(scales_and_zeros, torch.Tensor):
        return None
    return payload


def _method11_save_cache(cache_dir, layer_name, metadata, state, stats):
    if not cache_dir:
        return
    os.makedirs(cache_dir, exist_ok=True)
    cache_file = _method11_cache_file(cache_dir, layer_name)
    payload = {
        "metadata": metadata,
        "lut": state["lut"].detach().cpu().float(),
        "scales_and_zeros": state["scales_and_zeros"].detach().cpu().float(),
        "stats": stats,
    }
    torch.save(payload, cache_file)


def _method11_prepare_importance(sample_weight, W, fisher_sample_weight):
    if sample_weight is None:
        if fisher_sample_weight:
            raise ValueError("method11 Fisher weighting requires sample_weight.")
        return None
    if not isinstance(sample_weight, torch.Tensor):
        sample_weight = torch.as_tensor(sample_weight)
    weight = sample_weight.detach().cpu().float().squeeze()
    if weight.dim() == 1:
        if weight.numel() != W.shape[1]:
            raise ValueError(
                f"method11 sample_weight length {weight.numel()} does not match columns {W.shape[1]}."
            )
    elif weight.dim() == 2:
        if tuple(weight.shape) != tuple(W.shape):
            raise ValueError(
                f"method11 2D sample_weight shape {tuple(weight.shape)} does not match {tuple(W.shape)}."
            )
    else:
        raise ValueError(f"method11 sample_weight must be 1D or 2D, got {weight.dim()}D.")
    return torch.nan_to_num(weight, nan=0.0, posinf=0.0, neginf=0.0).clamp_min(0).numpy()


def _method11_storage_stats(rows, cols, group_size, num_tables, table_size):
    groups = rows * (cols // group_size)
    code_bytes = (rows * cols * 2 + 7) // 8
    route_bits = 0 if num_tables == 1 else int(np.ceil(np.log2(num_tables)))
    route_bytes = (groups * route_bits + 7) // 8
    lut_bytes = rows * num_tables * table_size * 2
    affine_bytes = groups * 2 * 2
    total_bytes = code_bytes + route_bytes + lut_bytes + affine_bytes
    return {
        "logical_weight_count": int(rows * cols),
        "logical_code_bytes": int(code_bytes),
        "logical_route_bytes": int(route_bytes),
        "fp16_lut_bytes": int(lut_bytes),
        "fp16_scale_zero_bytes": int(affine_bytes),
        "logical_total_bytes": int(total_bytes),
        "effective_bits_per_weight": float(total_bytes * 8.0 / (rows * cols)),
    }


def _method11_dp_centroids(values, weights, table_size):
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    weights = np.asarray(weights, dtype=np.float64).reshape(-1)
    weights = np.nan_to_num(weights, nan=0.0, posinf=0.0, neginf=0.0)
    weights = np.maximum(weights, 0.0)
    if weights.sum() <= 0:
        weights = np.ones_like(values, dtype=np.float64)
    _, centroids, _ = kmeans.kmeans_1d_dp(
        values.reshape(-1, 1),
        n_clusters=table_size,
        sample_weight=weights,
    )
    centroids = np.sort(np.asarray(centroids, dtype=np.float64).reshape(-1))
    if centroids.size < table_size:
        centroids = np.pad(centroids, (0, table_size - centroids.size), mode="edge")
    if not np.isfinite(centroids).all():
        raise ValueError("method11 DP produced non-finite centroids.")
    return centroids[:table_size].astype(np.float32)


def _method11_c16_distilled_init(
    normalized_groups,
    dp_weight,
    num_tables,
    table_size,
):
    teacher_size = num_tables * table_size
    teacher = _method11_dp_centroids(
        normalized_groups,
        dp_weight,
        teacher_size,
    ).astype(np.float64)
    values = np.asarray(normalized_groups, dtype=np.float64)
    weights = np.asarray(dp_weight, dtype=np.float64)
    distances = (values[:, :, None] - teacher[None, None, :]) ** 2
    nearest = np.argmin(distances, axis=2)

    groups = values.shape[0]
    candidate_luts = np.empty(
        (groups, table_size),
        dtype=np.float32,
    )
    for group_index in range(groups):
        usage = np.bincount(
            nearest[group_index],
            weights=weights[group_index],
            minlength=teacher_size,
        )
        used = np.flatnonzero(usage > 0)
        used = used[
            np.argsort(-usage[used], kind="mergesort")
        ]
        selected = [int(index) for index in used[:table_size]]
        if len(selected) < table_size:
            single_loss = np.sum(
                weights[group_index, :, None]
                * distances[group_index],
                axis=0,
            )
            for index in np.argsort(single_loss, kind="mergesort"):
                index = int(index)
                if index not in selected:
                    selected.append(index)
                if len(selected) == table_size:
                    break
        candidate_luts[group_index] = np.sort(
            teacher[np.asarray(selected[:table_size], dtype=np.int64)]
        ).astype(np.float32)

    lut = np.empty((num_tables, table_size), dtype=np.float32)
    lut[0] = _method11_dp_centroids(
        normalized_groups,
        dp_weight,
        table_size,
    )
    selected_patterns = {tuple(float(value) for value in lut[0])}
    selected_groups = set()
    for table_index in range(1, num_tables):
        diff = (
            values[:, :, None, None]
            - lut[None, None, :table_index, :]
        )
        table_error = np.sum(
            np.min(diff * diff, axis=3)
            * weights[:, :, None],
            axis=1,
        )
        group_loss = np.min(table_error, axis=1)
        order = np.argsort(-group_loss, kind="mergesort")
        seed_group = None
        for candidate in order:
            candidate = int(candidate)
            pattern = tuple(
                float(value) for value in candidate_luts[candidate]
            )
            if (
                candidate not in selected_groups
                and pattern not in selected_patterns
            ):
                seed_group = candidate
                break
        if seed_group is None:
            seed_group = next(
                (
                    int(candidate)
                    for candidate in order
                    if int(candidate) not in selected_groups
                ),
                int(order[0]),
            )
        selected_groups.add(seed_group)
        lut[table_index] = candidate_luts[seed_group]
        selected_patterns.add(
            tuple(float(value) for value in lut[table_index])
        )
    return lut


def _method11_exact_c16_subset_medoid_init(
    normalized_groups,
    dp_weight,
    num_tables,
    table_size,
):
    if num_tables != 4 or table_size != 4:
        raise ValueError(
            "exact_c16_subset_medoid requires four tables with four entries."
        )
    teacher_size = num_tables * table_size
    teacher = _method11_dp_centroids(
        normalized_groups,
        dp_weight,
        teacher_size,
    ).astype(np.float64)
    values = np.asarray(normalized_groups, dtype=np.float64)
    weights = np.asarray(dp_weight, dtype=np.float64)
    subsets = np.asarray(
        list(itertools.combinations(range(teacher_size), table_size)),
        dtype=np.int64,
    )
    subset_centers = teacher[subsets]

    # Solve every group's restricted 4-of-16 problem exactly.
    optimal_subset_indices = np.empty(values.shape[0], dtype=np.int64)
    for group_index in range(values.shape[0]):
        squared = (
            values[group_index, :, None, None]
            - subset_centers[None, :, :]
        ) ** 2
        losses = np.sum(
            np.min(squared, axis=2)
            * weights[group_index, :, None],
            axis=0,
        )
        optimal_subset_indices[group_index] = int(np.argmin(losses))

    unique_subset_indices = []
    seen = set()
    for subset_index in optimal_subset_indices:
        key = tuple(int(value) for value in subsets[int(subset_index)])
        if key not in seen:
            seen.add(key)
            unique_subset_indices.append(int(subset_index))
    candidate_luts = subset_centers[
        np.asarray(unique_subset_indices, dtype=np.int64)
    ]

    # Cluster the optimal subsets using actual weighted reconstruction error.
    squared = (
        values[:, :, None, None]
        - candidate_luts[None, None, :, :]
    ) ** 2
    candidate_error = np.sum(
        np.min(squared, axis=3) * weights[:, :, None],
        axis=1,
    )
    candidate_count = candidate_luts.shape[0]
    selected = [int(np.argmin(np.sum(candidate_error, axis=0)))]
    current_group_error = candidate_error[:, selected[0]].copy()
    while len(selected) < min(num_tables, candidate_count):
        best_candidate = None
        best_loss = None
        for candidate in range(candidate_count):
            if candidate in selected:
                continue
            loss = float(
                np.minimum(
                    current_group_error,
                    candidate_error[:, candidate],
                ).sum()
            )
            if best_loss is None or loss < best_loss:
                best_loss = loss
                best_candidate = candidate
        selected.append(int(best_candidate))
        current_group_error = np.minimum(
            current_group_error,
            candidate_error[:, int(best_candidate)],
        )

    # Deterministic PAM-style swaps improve the four-table facility objective.
    if len(selected) == num_tables:
        for _ in range(8):
            current_loss = float(
                np.min(candidate_error[:, selected], axis=1).sum()
            )
            best_loss = current_loss
            best_swap = None
            selected_set = set(selected)
            for slot in range(num_tables):
                for candidate in range(candidate_count):
                    if candidate in selected_set:
                        continue
                    proposal = list(selected)
                    proposal[slot] = candidate
                    loss = float(
                        np.min(candidate_error[:, proposal], axis=1).sum()
                    )
                    if loss < best_loss - max(
                        1e-12,
                        abs(best_loss) * 1e-12,
                    ):
                        best_loss = loss
                        best_swap = (slot, candidate)
            if best_swap is None:
                break
            selected[best_swap[0]] = int(best_swap[1])

    lut = np.empty((num_tables, table_size), dtype=np.float32)
    for table_index, candidate in enumerate(selected):
        lut[table_index] = candidate_luts[candidate].astype(np.float32)
    if len(selected) < num_tables:
        fallback = _method11_dp_centroids(
            normalized_groups,
            dp_weight,
            table_size,
        )
        for table_index in range(len(selected), num_tables):
            lut[table_index] = fallback
    return lut


def _method11_row_importance(importance, row_index, w_row, fisher_sample_weight):
    if importance is None:
        row_weight = np.ones(w_row.shape[0], dtype=np.float64)
    elif importance.ndim == 1:
        row_weight = np.asarray(importance, dtype=np.float64).copy()
    else:
        row_weight = np.asarray(importance[row_index], dtype=np.float64).copy()
    row_weight = np.nan_to_num(row_weight, nan=0.0, posinf=0.0, neginf=0.0)
    row_weight = np.maximum(row_weight, 0.0)
    if fisher_sample_weight:
        row_weight *= (w_row != 0).astype(np.float64)
    if row_weight.sum() <= 0:
        row_weight = np.ones_like(row_weight)
    return row_weight


def _method11_assign_row(w_groups, importance_groups, scales, offsets, lut):
    levels = scales[:, None, None] * lut[None, :, :] + offsets[:, None, None]
    diff = w_groups[:, :, None, None] - levels[:, None, :, :]
    squared = diff * diff
    candidate_codes = np.argmin(squared, axis=3)
    candidate_error = np.min(squared, axis=3)
    table_errors = np.sum(candidate_error * importance_groups[:, :, None], axis=1)
    table_ids = np.argmin(table_errors, axis=1)
    group_index = np.arange(w_groups.shape[0])[:, None]
    column_index = np.arange(w_groups.shape[1])[None, :]
    codes = candidate_codes[group_index, column_index, table_ids[:, None]]
    group_loss = table_errors[np.arange(w_groups.shape[0]), table_ids]
    return (
        codes.astype(np.uint8),
        table_ids.astype(np.uint8),
        float(group_loss.sum()),
        group_loss.astype(np.float64),
    )


def _method11_canonicalize_table(lut, table_index, table_ids, scales, offsets, scale_eps):
    centroid = lut[table_index].astype(np.float64)
    lower = float(centroid[0])
    width = float(centroid[-1] - centroid[0])
    if not np.isfinite(width) or width <= scale_eps:
        return
    alpha = width / 3.0
    lut[table_index] = ((centroid - lower) / alpha).astype(np.float32)
    selected = table_ids == table_index
    if np.any(selected):
        old_scale = scales[selected].copy()
        scales[selected] = old_scale * alpha
        offsets[selected] = offsets[selected] + old_scale * lower


def _method11_update_affine(
    w_groups,
    importance_groups,
    lut,
    table_ids,
    codes,
    scales,
    offsets,
    ridge,
    scale_eps,
):
    accepted = 0
    for group_index in range(w_groups.shape[0]):
        weight = importance_groups[group_index]
        weight_sum = float(weight.sum())
        if weight_sum <= 0:
            continue
        centroid = lut[int(table_ids[group_index]), codes[group_index].astype(np.int64)].astype(np.float64)
        target = w_groups[group_index].astype(np.float64)
        centroid_mean = float(np.sum(weight * centroid) / weight_sum)
        target_mean = float(np.sum(weight * target) / weight_sum)
        centered_centroid = centroid - centroid_mean
        centered_target = target - target_mean
        denominator = float(np.sum(weight * centered_centroid * centered_centroid))
        numerator = float(np.sum(weight * centered_centroid * centered_target))
        candidate_scale = numerator / (denominator + ridge)
        if not np.isfinite(candidate_scale) or candidate_scale <= scale_eps:
            continue
        candidate_offset = target_mean - candidate_scale * centroid_mean
        old_reconstruction = scales[group_index] * centroid + offsets[group_index]
        new_reconstruction = candidate_scale * centroid + candidate_offset
        old_loss = float(np.sum(weight * (target - old_reconstruction) ** 2))
        new_loss = float(np.sum(weight * (target - new_reconstruction) ** 2))
        if np.isfinite(new_loss) and new_loss <= old_loss + max(1e-12, abs(old_loss) * 1e-10):
            scales[group_index] = candidate_scale
            offsets[group_index] = candidate_offset
            accepted += 1
    return accepted


def _method11_optimize_row(
    row_index,
    w_row,
    normalized_row,
    importance,
    initial_scales,
    initial_offsets,
    group_size,
    num_tables,
    table_size,
    joint_affine,
    max_iter,
    tol,
    ridge,
    scale_eps,
    init,
    fisher_sample_weight,
):
    cols = w_row.shape[0]
    groups = cols // group_size
    w_groups = np.asarray(w_row, dtype=np.float64).reshape(groups, group_size)
    normalized_groups = np.asarray(normalized_row, dtype=np.float64).reshape(groups, group_size)
    importance_row = _method11_row_importance(
        importance,
        row_index,
        np.asarray(w_row),
        fisher_sample_weight,
    )
    importance_groups = importance_row.reshape(groups, group_size)
    scales = np.asarray(initial_scales, dtype=np.float64).copy()
    offsets = np.asarray(initial_offsets, dtype=np.float64).copy()

    dp_weight = importance_groups * (scales[:, None] ** 2)
    if init == "exact_c16_subset_medoid":
        lut = _method11_exact_c16_subset_medoid_init(
            normalized_groups,
            dp_weight,
            num_tables,
            table_size,
        )
    elif init == "c16_distilled":
        lut = _method11_c16_distilled_init(
            normalized_groups,
            dp_weight,
            num_tables,
            table_size,
        )
    else:
        lut = np.empty((num_tables, table_size), dtype=np.float32)
        lut[0] = _method11_dp_centroids(
            normalized_groups,
            dp_weight,
            table_size,
        )
        selected_seed_groups = set()
        for table_index in range(1, num_tables):
            _, _, _, group_loss = _method11_assign_row(
                w_groups,
                importance_groups,
                scales,
                offsets,
                lut[:table_index],
            )
            candidates = np.argsort(-group_loss, kind="mergesort")
            seed_group = next(
                (
                    int(candidate)
                    for candidate in candidates
                    if int(candidate) not in selected_seed_groups
                ),
                int(candidates[0]),
            )
            selected_seed_groups.add(seed_group)
            lut[table_index] = _method11_dp_centroids(
                normalized_groups[seed_group],
                dp_weight[seed_group],
                table_size,
            )

    codes, table_ids, current_loss, group_loss = _method11_assign_row(
        w_groups,
        importance_groups,
        scales,
        offsets,
        lut,
    )
    initial_loss = current_loss
    best_loss = current_loss
    best_state = (codes.copy(), table_ids.copy(), lut.copy(), scales.copy(), offsets.copy())
    loss_history = [float(current_loss)]
    empty_reinitializations = 0
    affine_updates = 0

    for _ in range(max_iter):
        previous_state = (codes.copy(), table_ids.copy(), lut.copy(), scales.copy(), offsets.copy())
        previous_loss = current_loss
        previous_table_ids = table_ids.copy()

        for table_index in range(num_tables):
            selected = table_ids == table_index
            if not np.any(selected):
                seed_group = int(np.argmax(group_loss))
                normalized_current = (w_groups[seed_group] - offsets[seed_group]) / max(
                    scales[seed_group],
                    scale_eps,
                )
                lut[table_index] = _method11_dp_centroids(
                    normalized_current,
                    importance_groups[seed_group] * scales[seed_group] ** 2,
                    table_size,
                )
                empty_reinitializations += 1
                continue

            normalized_current = (
                w_groups[selected] - offsets[selected, None]
            ) / np.maximum(scales[selected, None], scale_eps)
            weighted_current = importance_groups[selected] * (scales[selected, None] ** 2)
            lut[table_index] = _method11_dp_centroids(
                normalized_current,
                weighted_current,
                table_size,
            )
            if joint_affine:
                _method11_canonicalize_table(
                    lut,
                    table_index,
                    table_ids,
                    scales,
                    offsets,
                    scale_eps,
                )

        codes, table_ids, current_loss, group_loss = _method11_assign_row(
            w_groups,
            importance_groups,
            scales,
            offsets,
            lut,
        )
        if joint_affine:
            affine_updates += _method11_update_affine(
                w_groups,
                importance_groups,
                lut,
                table_ids,
                codes,
                scales,
                offsets,
                ridge,
                scale_eps,
            )
            codes, table_ids, current_loss, group_loss = _method11_assign_row(
                w_groups,
                importance_groups,
                scales,
                offsets,
                lut,
            )

        numerical_tolerance = max(1e-12, abs(previous_loss) * 1e-9)
        if not np.isfinite(current_loss) or current_loss > previous_loss + numerical_tolerance:
            codes, table_ids, lut, scales, offsets = previous_state
            current_loss = previous_loss
            loss_history.append(float(current_loss))
            break

        loss_history.append(float(current_loss))
        if current_loss < best_loss:
            best_loss = current_loss
            best_state = (codes.copy(), table_ids.copy(), lut.copy(), scales.copy(), offsets.copy())

        relative_improvement = (previous_loss - current_loss) / max(abs(previous_loss), 1e-12)
        if np.array_equal(previous_table_ids, table_ids) or relative_improvement < tol:
            break

    codes, table_ids, lut, scales, offsets = best_state
    table_usage = np.bincount(table_ids.astype(np.int64), minlength=num_tables)
    row_stats = {
        "init": str(init),
        "initial_loss": float(initial_loss),
        "final_loss": float(best_loss),
        "iterations": int(max(len(loss_history) - 1, 0)),
        "empty_reinitializations": int(empty_reinitializations),
        "affine_updates": int(affine_updates),
        "table_usage": [int(value) for value in table_usage],
        "loss_monotonic": all(
            loss_history[index] <= loss_history[index - 1] + max(1e-12, abs(loss_history[index - 1]) * 1e-9)
            for index in range(1, len(loss_history))
        ),
    }
    return codes, table_ids, lut, scales, offsets, row_stats


def _method11_reassign_row(
    row_index,
    w_row,
    importance,
    scales,
    offsets,
    lut,
    group_size,
    fisher_sample_weight,
):
    groups = w_row.shape[0] // group_size
    w_groups = np.asarray(w_row, dtype=np.float64).reshape(groups, group_size)
    importance_row = _method11_row_importance(
        importance,
        row_index,
        np.asarray(w_row),
        fisher_sample_weight,
    )
    importance_groups = importance_row.reshape(groups, group_size)
    codes, table_ids, loss, group_loss = _method11_assign_row(
        w_groups,
        importance_groups,
        np.asarray(scales, dtype=np.float64),
        np.asarray(offsets, dtype=np.float64),
        np.asarray(lut, dtype=np.float32),
    )
    return codes, table_ids, loss, group_loss


def _method11_importance_for_row(importance, row_index):
    if importance is None or importance.ndim == 1:
        return importance
    return importance[row_index]


def method11_hlut_quantize_tensor(
    W,
    n_bit=2,
    q_group_size=128,
    per_row=True,
    scale_only=False,
    sample_weight=None,
    fisher_sample_weight=False,
    method11_num_tables=4,
    method11_table_size=4,
    method11_init="global_dp_farthest",
    method11_joint_affine=False,
    method11_max_iter=8,
    method11_tol=1e-6,
    method11_ridge=1e-6,
    method11_scale_eps=1e-6,
    method11_parallel_jobs=32,
    method11_cache_dir=None,
    method11_use_cache=True,
    method11_overwrite_cache=False,
    method11_return_stats=True,
    layer_name=None,
    model_path=None,
    parallelize=True,
    **kwargs,
):
    if n_bit != 2:
        raise ValueError("method11_hlut requires n_bit=2.")
    if not per_row:
        raise ValueError("method11_hlut requires per_row=True.")
    if scale_only:
        raise ValueError("method11_hlut requires asymmetric scale and zero.")
    if not isinstance(q_group_size, int) or q_group_size <= 1:
        raise ValueError("method11_hlut requires a fixed integer group_size > 1.")
    if W.dim() != 2 or W.shape[1] % q_group_size != 0:
        raise ValueError(
            f"method11_hlut expects 2D weights with columns divisible by group_size, got {tuple(W.shape)}."
        )
    if method11_num_tables not in (1, 4):
        raise ValueError("method11_num_tables must be 1 or 4 in method11 v1.")
    if method11_table_size != 4:
        raise ValueError("method11_table_size must be 4 in method11 v1.")
    if method11_init not in (
        "global_dp_farthest",
        "c16_distilled",
        "exact_c16_subset_medoid",
    ):
        raise ValueError(f"Unsupported method11_init={method11_init}.")
    if kwargs.get("new_grouping"):
        raise ValueError("method11_hlut does not support new_grouping.")
    if kwargs.get("surrogate_cluster") or kwargs.get("nnq"):
        raise ValueError("method11_hlut does not support surrogate_cluster or nnq.")

    started = time.time()
    original_device = W.device
    original_dtype = W.dtype
    W_cpu = W.detach().cpu().float().contiguous()
    importance = _method11_prepare_importance(sample_weight, W_cpu, fisher_sample_weight)
    Wg, _, initial_scales_and_zeros = group_q(
        W_cpu,
        n_bit=2,
        q_group_size=q_group_size,
        assymetric=True,
        zero_point=True,
    )
    affine_grouped = initial_scales_and_zeros.transpose(0, 1).contiguous().float()
    initial_scales = affine_grouped[:, :, 0].numpy()
    initial_zeros = affine_grouped[:, :, 1].numpy()
    initial_offsets = initial_zeros - 2.0 * initial_scales

    if method11_use_cache and method11_cache_dir is None and layer_name is not None:
        method11_cache_dir = DEFAULT_METHOD11_CACHE_DIR
    metadata = _method11_cache_metadata(
        W_cpu,
        importance,
        layer_name,
        model_path,
        q_group_size,
        method11_num_tables,
        method11_table_size,
        method11_joint_affine,
        fisher_sample_weight,
        method11_max_iter,
        method11_tol,
        method11_ridge,
        method11_scale_eps,
        method11_init,
    )
    cached = _method11_load_cache(
        method11_cache_dir if method11_use_cache else None,
        layer_name,
        metadata,
        overwrite=method11_overwrite_cache,
    )

    rows, cols = W_cpu.shape
    groups = cols // q_group_size
    jobs = min(max(1, int(method11_parallel_jobs if parallelize else 1)), rows)
    W_numpy = W_cpu.numpy()
    normalized_numpy = Wg.detach().cpu().float().numpy()

    if cached is not None:
        lut_numpy = cached["lut"].float().numpy()
        cached_affine = cached["scales_and_zeros"].float().transpose(0, 1).contiguous().numpy()
        scales_numpy = cached_affine[:, :, 0]
        zeros_numpy = cached_affine[:, :, 1]
        offsets_numpy = zeros_numpy - 2.0 * scales_numpy

        if jobs <= 1:
            reassigned = [
                _method11_reassign_row(
                    0,
                    W_numpy[row_index],
                    _method11_importance_for_row(importance, row_index),
                    scales_numpy[row_index],
                    offsets_numpy[row_index],
                    lut_numpy[row_index],
                    q_group_size,
                    fisher_sample_weight,
                )
                for row_index in range(rows)
            ]
        else:
            reassigned = Parallel(
                n_jobs=jobs,
                pre_dispatch=jobs,
                batch_size=8,
            )(
                delayed(_method11_reassign_row)(
                    0,
                    W_numpy[row_index],
                    _method11_importance_for_row(importance, row_index),
                    scales_numpy[row_index],
                    offsets_numpy[row_index],
                    lut_numpy[row_index],
                    q_group_size,
                    fisher_sample_weight,
                )
                for row_index in range(rows)
            )
        codes_numpy = np.stack([result[0] for result in reassigned], axis=0).reshape(rows, cols)
        table_ids_numpy = np.stack([result[1] for result in reassigned], axis=0)
        final_loss = float(sum(result[2] for result in reassigned))
        table_usage = np.bincount(
            table_ids_numpy.astype(np.int64).reshape(-1),
            minlength=method11_num_tables,
        )
        scales_and_zeros = cached["scales_and_zeros"].float().contiguous()
        stats = dict(cached.get("stats") or {})
        stats.update({
            "cache_hit": True,
            "final_loss": final_loss,
            "table_usage": [int(value) for value in table_usage],
            "elapsed_seconds": float(time.time() - started),
        })
    else:
        if jobs <= 1:
            optimized = [
                _method11_optimize_row(
                    0,
                    W_numpy[row_index],
                    normalized_numpy[row_index],
                    _method11_importance_for_row(importance, row_index),
                    initial_scales[row_index],
                    initial_offsets[row_index],
                    q_group_size,
                    method11_num_tables,
                    method11_table_size,
                    method11_joint_affine,
                    int(method11_max_iter),
                    float(method11_tol),
                    float(method11_ridge),
                    float(method11_scale_eps),
                    method11_init,
                    fisher_sample_weight,
                )
                for row_index in range(rows)
            ]
        else:
            optimized = Parallel(
                n_jobs=jobs,
                pre_dispatch=jobs,
                batch_size=8,
            )(
                delayed(_method11_optimize_row)(
                    0,
                    W_numpy[row_index],
                    normalized_numpy[row_index],
                    _method11_importance_for_row(importance, row_index),
                    initial_scales[row_index],
                    initial_offsets[row_index],
                    q_group_size,
                    method11_num_tables,
                    method11_table_size,
                    method11_joint_affine,
                    int(method11_max_iter),
                    float(method11_tol),
                    float(method11_ridge),
                    float(method11_scale_eps),
                    method11_init,
                    fisher_sample_weight,
                )
                for row_index in range(rows)
            )
        codes_numpy = np.stack([result[0] for result in optimized], axis=0).reshape(rows, cols)
        table_ids_numpy = np.stack([result[1] for result in optimized], axis=0)
        lut_numpy = np.stack([result[2] for result in optimized], axis=0)
        scales_numpy = np.stack([result[3] for result in optimized], axis=0)
        offsets_numpy = np.stack([result[4] for result in optimized], axis=0)
        zeros_numpy = offsets_numpy + 2.0 * scales_numpy
        scales_and_zeros = pack_scales_and_zeros(
            torch.from_numpy(scales_numpy.astype(np.float32)),
            torch.from_numpy(zeros_numpy.astype(np.float32)),
            W_cpu.shape,
        )
        row_stats = [result[5] for result in optimized]
        table_usage = np.sum(
            np.asarray([entry["table_usage"] for entry in row_stats], dtype=np.int64),
            axis=0,
        )
        initial_loss = float(sum(entry["initial_loss"] for entry in row_stats))
        final_loss = float(sum(entry["final_loss"] for entry in row_stats))
        stats = {
            "method_name": METHOD11_NAME,
            "layer_name": layer_name,
            "cache_hit": False,
            "init": str(method11_init),
            "joint_affine": bool(method11_joint_affine),
            "fisher_sample_weight": bool(fisher_sample_weight),
            "num_tables": int(method11_num_tables),
            "table_size": int(method11_table_size),
            "group_size": int(q_group_size),
            "initial_loss": initial_loss,
            "final_loss": final_loss,
            "relative_loss_reduction": float(
                (initial_loss - final_loss) / max(abs(initial_loss), 1e-12)
            ),
            "mean_iterations": float(np.mean([entry["iterations"] for entry in row_stats])),
            "max_iterations": int(max(entry["iterations"] for entry in row_stats)),
            "empty_reinitializations": int(
                sum(entry["empty_reinitializations"] for entry in row_stats)
            ),
            "affine_updates": int(sum(entry["affine_updates"] for entry in row_stats)),
            "table_usage": [int(value) for value in table_usage],
            "loss_monotonic": bool(all(entry["loss_monotonic"] for entry in row_stats)),
            "elapsed_seconds": float(time.time() - started),
        }

    state = {
        "codes": torch.from_numpy(codes_numpy.astype(np.uint8)),
        "table_ids": torch.from_numpy(table_ids_numpy.astype(np.uint8)),
        "lut": torch.from_numpy(lut_numpy.astype(np.float32)),
        "scales_and_zeros": scales_and_zeros.float(),
        "stats": stats,
    }
    stats.update(_method11_storage_stats(
        rows,
        cols,
        q_group_size,
        method11_num_tables,
        method11_table_size,
    ))
    if cached is None and method11_use_cache:
        _method11_save_cache(method11_cache_dir, layer_name, metadata, state, stats)
    if method11_return_stats:
        _method11_record_stats(layer_name, stats)

    state["original_device"] = str(original_device)
    state["original_dtype"] = str(original_dtype)
    return state


def method11_hlut_dequantize_tensor(state, dtype=torch.float32, device="cpu"):
    codes = state["codes"].long().cpu()
    table_ids = state["table_ids"].long().cpu()
    lut = state["lut"].float().cpu()
    scales_and_zeros = state["scales_and_zeros"].float().cpu()
    rows, cols = codes.shape
    groups = table_ids.shape[1]
    group_size = cols // groups
    row_index = torch.arange(rows).view(rows, 1)
    selected_lut = lut[row_index, table_ids]
    centroid = torch.gather(
        selected_lut,
        dim=2,
        index=codes.reshape(rows, groups, group_size),
    )
    affine = scales_and_zeros.transpose(0, 1).contiguous()
    scales = affine[:, :, 0].unsqueeze(-1)
    zeros = affine[:, :, 1].unsqueeze(-1)
    reconstructed = (centroid - 2.0) * scales + zeros
    return reconstructed.reshape(rows, cols).to(device=device, dtype=dtype)


def method11_hlut_reconstruct_tensor(W, **kwargs):
    state = method11_hlut_quantize_tensor(W, **kwargs)
    reconstructed = method11_hlut_dequantize_tensor(
        state,
        dtype=W.dtype,
        device=W.device,
    )
    del state
    torch.cuda.empty_cache()
    gc.collect()
    return reconstructed


def anyq_quantize_tensor(W, n_bit=4, q_group_size=128, new_grouping=False, per_row=True, zero_point=True, scale_only=False, bias_pow=1.0, keep_outliers=False, cluster_row: Callable = cluster_row_scikit, init=None, sample_weight=None, sample_weight_preprocess=None, sample_activations=None, scale_sample_weight=False, abs_weight_sample_weight=False, parallelize=True, surrogate_cluster=False, nnq=False, nnq_args={}, device=None, **kwargs):
    if kwargs.pop("method10_joint_affine", False):
        return method10_joint_affine_quantize_tensor(W, n_bit=n_bit, q_group_size=q_group_size, per_row=per_row, zero_point=zero_point, scale_only=scale_only, init=init, parallelize=parallelize, **kwargs)
    orig_device = W.device
    if device is not None:
        W = W.to(device)

    if not per_row:
        orig_shape = W.shape
        W = W.reshape(1, -1)

    if sample_weight_preprocess:
        assert sample_weight is not None and isinstance(sample_weight, torch.Tensor)
        # We won't apply absolute here and it can be applied in another call to build_sample_weight before clustering
        sample_weight = kmeans.build_sample_weight(sample_weight.unsqueeze(dim=1).detach().cpu().numpy(), sample_weight_preprocess, abs=False)
        sample_weight = torch.Tensor(sample_weight)

    if q_group_size:
        # TODO: create separate function that fuses scales and zeros into scales_and_zeros, and only use that when actually quantizing rather than reconstructing
        if q_group_size == "greedy_dynamic":
            Wg, scales_and_zeros = greedy_dynamic_group_q(W, n_bit=n_bit, dynamic_group_sizes=kwargs.pop("dynamic_group_sizes", (128, 64, 32)), range_alpha=kwargs.pop("range_alpha", 1.25), var_alpha=kwargs.pop("var_alpha", 1.25), outlier_threshold=kwargs.pop("outlier_threshold", 0.05), assymetric=not scale_only, zero_point=zero_point, layer_name=kwargs.pop("layer_name", None))
            scales = scales_and_zeros["scales"]
            zeros = scales_and_zeros["zeros"]
        elif q_group_size == "dynamic":
            Wg, scales_and_zeros = dynamic_group_q(W, n_bit=n_bit, dynamic_group_sizes=kwargs.pop("dynamic_group_sizes", (32, 64, 128)), dynamic_group_thresholds=kwargs.pop("dynamic_group_thresholds", (0.8, 1.5)), dynamic_group_metric_weights=kwargs.pop("dynamic_group_metric_weights", (1.0, 1.0, 1.0)), assymetric=not scale_only, zero_point=zero_point)
            scales = scales_and_zeros["scales"]
            zeros = scales_and_zeros["zeros"]
        elif new_grouping:
            W = W.detach()
            Wg, scales, zeros = group_q1(W, n_bit, q_group_size=q_group_size, assymetric=not scale_only, get_scale_zp=True, inplace=True, round_zeros=False, clamp=False)
            scales_and_zeros = pack_scales_and_zeros(scales, zeros, W.shape)
        else:
            Wg, _, scales_and_zeros = group_q(W, n_bit, q_group_size=q_group_size, assymetric=not scale_only, zero_point=zero_point)
            scales, zeros = extract_scales_and_zeros(scales_and_zeros, Wg.shape, q_group_size)

        if scale_sample_weight:
            if sample_weight is None:
               sample_weight = torch.ones_like(W[0])
            sample_weight = sample_weight.to(scales.device) * scales
    else:
        Wg = W.float()
        scales, zeros = torch.ones(W.shape[0]), torch.zeros(W.shape[0])
        scales_and_zeros = pack_scales_and_zeros(scales, zeros, W.shape)

    if abs_weight_sample_weight:
        if sample_weight is None:
            sample_weight = torch.ones_like(W[0])
        sample_weight = sample_weight.to(W.device) * W.abs()

    if kwargs.pop("fisher_sample_weight", False):
        sample_weight = build_fisher_sample_weight(sample_weight, Wg, W)

    if kwargs.pop("guided_hessian_sample_weight", False):
        sample_weight = build_guided_hessian_sample_weight(sample_weight, Wg, W)

    Wg = Wg.contiguous()
    if sample_weight is not None and isinstance(sample_weight, torch.Tensor):
        sample_weight = sample_weight.contiguous()

    if surrogate_cluster:
        surrogate_to_cluster = W
    else:
        surrogate_to_cluster = None

    if cluster_row is not None:
        if cluster_row is cluster_row_dp:
            kwargs.setdefault("dp_cache_q_group_size", q_group_size)
            kwargs.setdefault("dp_cache_scale_sample_weight", scale_sample_weight)
        if cluster_row is cluster_row_outlier_reserved:
            kwargs.setdefault("method3_q_group_size", q_group_size)
            kwargs.setdefault("method3_scale_only", scale_only)
            kwargs.setdefault("method3_zero_point", zero_point)
            kwargs.setdefault("weight_shape", W.shape)
            kwargs.setdefault("cluster_row_name", "outlier_reserved")
        assign, any4, Wc = cluster_matrix(Wg, n_bit=n_bit, bias_pow=bias_pow, keep_outliers=keep_outliers, cluster_row=cluster_row, init=init, sample_weight=sample_weight, parallelize=parallelize, x_cluster=surrogate_to_cluster, **kwargs)
    else:
        assert nnq, "We should either enabling clustering (cluster_row should be not None) or enable neural network learning (nnq should be True) but we have cluster_row: {cluster_row}, nnq: {nnq}"
        assign, any4, Wc = None, None, Wg

    if nnq:
        try:
            assign, any4, Wc = learn_anyq(
                Wc=Wc,
                scales=scales,
                zeros=zeros,
                W=W,
                n_bit=n_bit,
                q_group_size=q_group_size,
                scale_only=scale_only,
                init_values=any4,
                X_train=sample_activations,
                X_val=sample_weight,
                device=device,
                **nnq_args,
            )
        except RuntimeError as e:
            if 'out of memory' in str(e):
                torch.cuda.empty_cache()
                print(f"Hit OOM so will not update this layer")
            else:
                raise
        except Exception as e:
            raise
        # Ensure tensors are back on same device as weight
        Wc = Wc.to(W.device)

    if not per_row:
        W = W.reshape(orig_shape)
        assign = assign.reshape(orig_shape)
        scales_and_zeros = scales_and_zeros.reshape(-1, orig_shape[0], 2)
        any4 = any4.squeeze()

    if isinstance(scales_and_zeros, dict):
        scales_and_zeros = {k: (v.to(orig_device, W.dtype) if torch.is_tensor(v) and k != "selected_group_sizes" else v.to(orig_device) if torch.is_tensor(v) else v) for k, v in scales_and_zeros.items()}
    else:
        scales_and_zeros = scales_and_zeros.to(orig_device, W.dtype)

    return assign.to(orig_device), any4.to(orig_device, W.dtype), scales_and_zeros

def anyq_dequantize_tensor(assign, any4, scales_and_zeros, n_bit=4, q_group_size=128, per_row=True, new_grouping=False, scale_only=False):
    if not per_row:
        orig_shape = assign.shape
        assign = assign.reshape(1, -1)
        scales_and_zeros = scales_and_zeros.reshape(-1, 1, 2)
        Wc = any4[assign]
    else:
        Wc = torch.gather(input=any4, dim=1, index=assign.long())
    # TODO: create separate de_group function
    if q_group_size in ("dynamic", "greedy_dynamic"):
        Wdeq = dynamic_degroup_q(Wc, scales_and_zeros, n_bit=n_bit, scale_only=scale_only)
    else:
        scales, zeros = extract_scales_and_zeros(scales_and_zeros, assign.shape, q_group_size)
        if q_group_size:
            if new_grouping:
                Wdeq = degroup_q1(Wc, scales=scales, zeros=zeros, q_group_size=q_group_size)
            else:
                # Commenting this inplace operation because this applies a side effect on an input argument that won't be noticed when calling the function
                # if not scale_only:
                #     any4.sub_(2**(n_bit - 1))
                Wdeq = degroup_q(Wc, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=not scale_only)
            del scales, zeros
        else:
            Wdeq = Wc

    if not per_row:
        Wdeq = Wdeq.reshape(orig_shape)

    return Wdeq


def anyq_reconstruct_tensor_two_lut_per_row(W, n_bit=4, q_group_size=128, new_grouping=False, per_row=True, scale_only=False, bias_pow=1.0, keep_outliers=False, cluster_row: Callable = cluster_row_scikit, init=None, sample_weight=None, sample_weight_preprocess=None, sample_activations=None, scale_sample_weight=False, abs_weight_sample_weight=False, parallelize=True, surrogate_cluster=False, nnq=False, nnq_args={}, device=None, **kwargs):
    if not per_row:
        raise ValueError("method7_two_lut_per_row requires per_row=True.")
    if nnq:
        raise ValueError("method7_two_lut_per_row does not support nnq.")
    if surrogate_cluster:
        raise ValueError("method7_two_lut_per_row does not support surrogate_cluster.")
    if q_group_size in ("dynamic", "greedy_dynamic"):
        raise ValueError("method7_two_lut_per_row expects a fixed q_group_size.")
    if W.dim() != 2:
        raise ValueError("method7_two_lut_per_row expects a 2D weight tensor.")
    if W.shape[1] % 2 != 0:
        raise ValueError(f"method7_two_lut_per_row needs even input dimension, got {W.shape[1]}.")

    orig_device = W.device
    if device is not None:
        W = W.to(device)

    if sample_weight_preprocess:
        assert sample_weight is not None and isinstance(sample_weight, torch.Tensor)
        sample_weight = kmeans.build_sample_weight(sample_weight.unsqueeze(dim=1).detach().cpu().numpy(), sample_weight_preprocess, abs=False)
        sample_weight = torch.Tensor(sample_weight)

    if q_group_size:
        if new_grouping:
            W = W.detach()
            Wg, scales, zeros = group_q1(W, n_bit, q_group_size=q_group_size, assymetric=not scale_only, get_scale_zp=True, inplace=True, round_zeros=False, clamp=False)
            scales_and_zeros = pack_scales_and_zeros(scales, zeros, W.shape)
        else:
            Wg, _, scales_and_zeros = group_q(W, n_bit, q_group_size=q_group_size, assymetric=not scale_only)
            scales, zeros = extract_scales_and_zeros(scales_and_zeros, Wg.shape, q_group_size)
        if scale_sample_weight:
            if sample_weight is None:
                sample_weight = torch.ones_like(W[0])
            sample_weight = sample_weight.to(scales.device) * scales
    else:
        Wg = W.float()
        scales = torch.ones(W.shape, device=W.device, dtype=W.float().dtype)
        zeros = torch.zeros(W.shape, device=W.device, dtype=W.float().dtype)
        scales_and_zeros = pack_scales_and_zeros(scales, zeros, W.shape)

    if abs_weight_sample_weight:
        if sample_weight is None:
            sample_weight = torch.ones_like(W[0])
        sample_weight = sample_weight.to(W.device) * W.abs()

    rows, cols = Wg.shape
    split_cols = cols // 2
    Wg_split = Wg.contiguous().reshape(rows, 2, split_cols).reshape(rows * 2, split_cols)

    split_sample_weight = sample_weight
    if isinstance(sample_weight, torch.Tensor):
        sample_weight = sample_weight.contiguous()
        if sample_weight.dim() == 1:
            if sample_weight.numel() != cols:
                raise ValueError(f"1D sample_weight length {sample_weight.numel()} does not match columns {cols}.")
            split_sample_weight = sample_weight.reshape(2, split_cols).repeat(rows, 1)
        elif sample_weight.dim() == 2:
            if tuple(sample_weight.shape) != tuple(Wg.shape):
                raise ValueError(f"2D sample_weight shape {tuple(sample_weight.shape)} does not match weight shape {tuple(Wg.shape)}.")
            split_sample_weight = sample_weight.reshape(rows, 2, split_cols).reshape(rows * 2, split_cols)
        else:
            raise ValueError(f"Unsupported sample_weight dim {sample_weight.dim()} for method7_two_lut_per_row.")

    assign, any4, Wc_split = cluster_matrix(
        Wg_split,
        n_bit=n_bit,
        bias_pow=bias_pow,
        keep_outliers=keep_outliers,
        cluster_row=cluster_row,
        init=init,
        sample_weight=split_sample_weight,
        parallelize=parallelize,
        x_cluster=None,
        **kwargs,
    )
    Wc = Wc_split.reshape(rows, 2, split_cols).reshape(rows, cols).to(W.device)
    if q_group_size:
        if new_grouping:
            Wdeq = degroup_q1(Wc, scales=scales, zeros=zeros, q_group_size=q_group_size)
        else:
            Wdeq = degroup_q(Wc, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=not scale_only)
    else:
        Wdeq = Wc

    del assign, any4, Wc_split
    if isinstance(scales_and_zeros, torch.Tensor):
        del scales_and_zeros
    torch.cuda.empty_cache()
    gc.collect()
    return Wdeq.to(orig_device)

class STEMin(torch.autograd.Function):
  @staticmethod
  def forward(ctx, input):
    return input.min(dim=-1)

  @staticmethod
  def backward(ctx, grad_output):
    return torch.nn.functional.hardtanh(grad_output)

class AnyQNN(torch.nn.Module):
    def __init__(self, n_values=16, n_rows=1):
        super(AnyQNN, self).__init__()
        # Initialize trainable values
        self.values = torch.nn.Parameter(torch.randn(n_rows, n_values))
        # Initialize trainable mappings
        self.n_values = n_values
        self.n_rows = n_rows

    def forward(self, x):
        # Expand input tensor and trainable values for vectorized distance computation
        x_expanded = x.unsqueeze(dim=-1)
        values_expanded = self.values.unsqueeze(dim=1).expand(-1, x.shape[-1], -1)

        # Calculate distances between input values and trainable values
        distances = (x_expanded - values_expanded)**2

        # Find the index of the minimum distance for each element
        # _, min_indices = distances.min(dim=-1)
        _, min_indices = STEMin.apply(distances)
        min_indices.reshape(x.shape)

        # Select the values with minimum distance
        # Create a tensor for the row indices
        row_indices = torch.arange(min_indices.size(0)).unsqueeze(1).expand_as(min_indices)
        # Use advanced indexing to select the elements
        selected_values = self.values[row_indices, min_indices]

        return selected_values

def nlc_loss(output, label):
    # Calculate the cosine similarity between output and label
    cosine_sim = torch.nn.functional.cosine_similarity(output, label).mean().abs()
    # Calculate the negative log-likelihood loss
    nlc = -torch.log(cosine_sim)
    return nlc

# TODO: try lr schedule.
# TODO: in each iteration feed different activations
def learn_anyq(Wc, scales, zeros, W, n_bit=4, q_group_size=128, scale_only=False, init_values=None, objective="Y_mse", X_val=None, X_train=None, lr=0.001, transpose=False, overfit=True, dtype=None, device=None, epochs=500):
    n_rows, dim = Wc.shape
    n_values = 2**n_bit
    if device == "cpu":
        if dtype is None:
            # CPU does not support torch.half
            dtype = torch.float32
    if dtype is None:
        dtype = W.dtype
    W = W.to(dtype=dtype, device=device)
    Wc = Wc.to(dtype=dtype, device=device)
    if scales is not None:
        scales = scales.to(device=device)
    if zeros is not None:
        zeros = zeros.to(device=device)

    # Create network
    net = AnyQNN(n_values=n_values, n_rows=n_rows)
    if init_values is not None:
        net.values.data = init_values.to(dtype=dtype, device=W.device)
    net.to(dtype=dtype, device=W.device)
    net.train()

    # Create learning objective
    if objective.endswith("mse"):
        criterion = torch.nn.MSELoss()
    elif objective.endswith("cossim"):
        criterion = nlc_loss
    else:
        raise ValueError(f"Unsupoorted objective {objective}")
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)

    Wcqn = net(Wc)
    Wqn = degroup_q(Wcqn, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=not scale_only).to(dtype)
    # TODO: we will probably need to refactor the codeo to handle transpose and decide when we should transpose and de-transpose
    if transpose:
        Wqn = Wqn.T

    if X_train is not None:
        X_train = [X_i.to(device=W.device, dtype=dtype) for X_i in X_train]

    if X_val is None:
        # TODO: add bs and slen as arguments to this function?
        bs, slen = 32, 1024
        X_val =  torch.randn(bs, slen, dim, device=W.device, requires_grad=False, dtype=dtype)
    else:
        X_val = X_val.to(device=W.device, dtype=dtype)

    # Check final outputs
    Y_val = torch.matmul(X_val, W.T)
    Yqn_val = torch.matmul(X_val, Wqn.T)

    W_mse = torch.nn.functional.mse_loss(W.squeeze(), Wqn.squeeze())
    Y_val_mse = torch.nn.functional.mse_loss(Y_val, Yqn_val)
    W_cossim = torch.nn.functional.cosine_similarity(W.flatten(), Wqn.flatten(), dim=0)

    print("W_mse:", W_mse.item(), "W_cossim:", W_cossim.item())
    print("Y_val_mse:", Y_val_mse.item())

    # Training loop
    for epoch in range(epochs):
        optimizer.zero_grad()
        Wcqn = net(Wc)
        Wqn = degroup_q(Wcqn, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=not scale_only).to(dtype)

        if transpose:
            Wqn = Wqn.T

        if objective == "W_mse":
            output = Wqn
            label = W
        elif objective == "Y_mse":
            if X_train is not None:
                Xi = X_train[random.randint(0, len(X_train)-1)]
                Yi = torch.matmul(Xi, W.T)
            elif overfit:
                Xi = X_val
                Yi = Y_val.squeeze()
            else:
                Xi = torch.randn_like(X_val)
                Yi = torch.matmul(Xi, W.T)
            output = torch.matmul(Xi, Wqn.T).squeeze()
            label = Yi.squeeze()

        loss = criterion(output, label)
        loss.backward(retain_graph=True)
        optimizer.step()

        if epoch % 10 == 0:
            print(f'Epoch {epoch}, Loss: {loss.item()}')

    net.hard_max = True
    Wcqn = net(Wc)
    Wqn = degroup_q(Wcqn, scales=scales, zeros=zeros, n_bit=n_bit, q_group_size=q_group_size, centering=not scale_only).to(dtype)
    if transpose:
        Wqn = Wqn.T

    # Check final outputs
    Y_val = torch.matmul(X_val, W.T)
    Yqn_val = torch.matmul(X_val, Wqn.T)

    W_mse = torch.nn.functional.mse_loss(W.squeeze(), Wqn.squeeze())
    Y_val_mse = torch.nn.functional.mse_loss(Y_val.squeeze(), Yqn_val.squeeze())
    W_cossim = torch.nn.functional.cosine_similarity(W.view(-1), Wqn.view(-1), dim=0)

    # print("Y_val:", Y_val, "Yqn_val:", Yqn_val)

    print("W_mse:", W_mse.item(), "W_cossim:", W_cossim.item())
    print("Y_val_mse:", Y_val_mse.item())

    assign_vals = Wcqn
    any4 = net.values.data
    # FIXME: fill assign rather than setting it to None
    assign = None

    del net, X_train, X_val, Wc, Yqn_val
    torch.cuda.empty_cache()
    gc.collect()

    return assign, any4, assign_vals

# performs quantization and dequantization under any4 scalar k-means grouped integer quantization
# (i.e., returns the effective result of the quantization algorithm)
def anyq_reconstruct_tensor(W, n_bit=4, q_group_size=128, new_grouping=False, per_row=True, scale_only=False, bias_pow=1.0, keep_outliers=False, cluster_row: Callable = cluster_row_scikit, init=None, sample_weight=None, sample_weight_preprocess=None, sample_activations=None, scale_sample_weight=False, abs_weight_sample_weight=False, parallelize=True, surrogate_cluster=False, nnq=False, nnq_args={}, device=None, **kwargs):
    if kwargs.pop("method11_hlut", False):
        if sample_weight_preprocess is not None:
            raise ValueError("method11_hlut does not support sample_weight_preprocess.")
        if scale_sample_weight or abs_weight_sample_weight:
            raise ValueError("method11_hlut uses its own original-domain weighting.")
        return method11_hlut_reconstruct_tensor(
            W,
            n_bit=n_bit,
            q_group_size=q_group_size,
            per_row=per_row,
            scale_only=scale_only,
            sample_weight=sample_weight,
            fisher_sample_weight=kwargs.pop("fisher_sample_weight", False),
            parallelize=parallelize,
            new_grouping=new_grouping,
            surrogate_cluster=surrogate_cluster,
            nnq=nnq,
            device=device,
            **kwargs,
        )
    if kwargs.pop("method7_two_lut_per_row", False):
        return anyq_reconstruct_tensor_two_lut_per_row(
            W,
            n_bit=n_bit,
            q_group_size=q_group_size,
            new_grouping=new_grouping,
            per_row=per_row,
            scale_only=scale_only,
            bias_pow=bias_pow,
            keep_outliers=keep_outliers,
            cluster_row=cluster_row,
            init=init,
            sample_weight=sample_weight,
            sample_weight_preprocess=sample_weight_preprocess,
            sample_activations=sample_activations,
            scale_sample_weight=scale_sample_weight,
            abs_weight_sample_weight=abs_weight_sample_weight,
            parallelize=parallelize,
            surrogate_cluster=surrogate_cluster,
            nnq=nnq,
            nnq_args=nnq_args,
            device=device,
            **kwargs,
        )
    assign, any4, scales_and_zeros = anyq_quantize_tensor(W, n_bit=n_bit, q_group_size=q_group_size, per_row=per_row, new_grouping=new_grouping, scale_only=scale_only, bias_pow=bias_pow, keep_outliers=keep_outliers, cluster_row=cluster_row, init=init, sample_weight=sample_weight, sample_weight_preprocess=sample_weight_preprocess, sample_activations=sample_activations, scale_sample_weight=scale_sample_weight, abs_weight_sample_weight=abs_weight_sample_weight, parallelize=parallelize, surrogate_cluster=surrogate_cluster, nnq=nnq, nnq_args=nnq_args, device=device, **kwargs)
    Wdeq = anyq_dequantize_tensor(assign, any4, scales_and_zeros, n_bit=n_bit, q_group_size=q_group_size, per_row=per_row, new_grouping=new_grouping, scale_only=scale_only)

    del assign, any4
    torch.cuda.empty_cache()
    gc.collect()

    return Wdeq

cluster_row_fn_dict = {
    "scikit": cluster_row_scikit,
    "custom": cluster_row_custom,
    "agglomerative": cluster_row_agglomerative,
    "dp": cluster_row_dp,
    "lite": cluster_row_lite,
    "identity": cluster_row_identity,
    "outlier_reserved": cluster_row_outlier_reserved,
}

# TODO: create anyq, nf4, fp4, intq functions that take weight tensor as input and return weight tensor as output?
def anyq_layer(module: torch.nn.Module, name="", n_bit: int = 4, group_size: int = 128, any_group_size: int = None, per_row = True, scale_only=False, parallelize=True, bias_pow=1.0, keep_outliers=False, transpose=False, cluster_row: str = "scikit", init=None, sample_weight=None, surrogate_cluster=False, pseudo=None, kernel: str = "linear_y_f16RM_x_f16RM_W_any4TC",  w_inner_k: int = 4, other_impl=False, **kwargs):
    if pseudo is None:
        if group_size in ("dynamic", "greedy_dynamic"):
            pseudo = True
        elif n_bit in [4] and import_or_skip("tinygemm"):
            pseudo = False
        else:
            pseudo = True

    w = module.weight
    if isinstance(sample_weight, Dict):
        sample_weight = sample_weight[name]
    if kwargs.get("method11_hlut", False) and not pseudo:
        raise ValueError("method11_hlut v1 supports pseudo=True only.")

    if pseudo:
        kwargs.setdefault("layer_name", name)
        if transpose:
            w = w.t()
        if any_group_size:
            w = w.view(-1, any_group_size)

        # TODO: implement this try-except with a decorator to the function?
        try:
            if other_impl:
                from pre_process.awq.quantizer import pseudo_any_quantize_tensor
                w_deq = pseudo_any_quantize_tensor(w.detach().half(), n_bit=n_bit, zero_point=True, q_group_size=group_size, get_scale_zp=False)
            else:
                w_deq = anyq_reconstruct_tensor(w, n_bit=n_bit, q_group_size=group_size, per_row=per_row, scale_only=scale_only, parallelize=parallelize, bias_pow=bias_pow, keep_outliers=keep_outliers, cluster_row=cluster_row_fn_dict[cluster_row], init=init, sample_weight=sample_weight, surrogate_cluster=surrogate_cluster, **kwargs)
        except RuntimeError as e:
            if 'out of memory' in str(e):
                torch.cuda.empty_cache()
                gc.collect()
                print(f"Hit OOM so will move weights to CPU and re-run")
                orig_device = w.device
                w_cpu = w.to("cpu")
                w_deq = anyq_reconstruct_tensor(w_cpu, n_bit=n_bit, q_group_size=group_size, per_row=per_row, scale_only=scale_only, parallelize=parallelize, bias_pow=bias_pow, keep_outliers=keep_outliers, cluster_row=cluster_row_fn_dict[cluster_row], init=init, sample_weight=sample_weight, surrogate_cluster=surrogate_cluster, **kwargs)
                w_deq = w_deq.to(orig_device)
            else:
                raise
        except Exception as e:
            raise

        if any_group_size:
            w_deq = w_deq.view(module.weight.shape)
        if transpose:
            w_deq = w_deq.t()

        module.weight.data = w_deq.to(device=module.weight.device, dtype=module.weight.dtype)
    else:
        assert transpose is False, "anyq quantized modules don't yet support transpose."
        assert any_group_size is None, "anyq quantized modules don't yet support transpose."
        intq, lut, scales_and_zeros = anyq_quantize_tensor(w, n_bit=n_bit, q_group_size=group_size, per_row=per_row, scale_only=scale_only, parallelize=parallelize, bias_pow=bias_pow, keep_outliers=keep_outliers, cluster_row=cluster_row_fn_dict[cluster_row], init=init, sample_weight=sample_weight, surrogate_cluster=surrogate_cluster, **kwargs)

        if n_bit == 4:
            from modules import Any4Linear
            qmodule = Any4Linear(
                in_features=module.in_features,
                out_features=module.out_features,
                bias=module.bias is not None,
                device=module.weight.device,
                dtype=module.weight.dtype,
                group_size=group_size if group_size != 0 else w.shape[1],
                per_row=per_row,
                kernel=kernel,
                w_inner_k=w_inner_k,
            )
        else:
            raise ValueError(f"No int quantized modules supported for n_bit={n_bit}. You may consider setting pseudo=True.")
        qmodule.weight.data = intq.to(device=module.weight.device)
        qmodule.scales_and_zeros.data = scales_and_zeros.to(device=module.weight.device)
        qmodule.lut.data = lut.to(device=module.weight.device) - (2**(n_bit - 1))
        qmodule.bias = module.bias
        qmodule.reshape_weight()
        module = qmodule

    # Save memory
    if isinstance(sample_weight, Dict) and name in sample_weight:
        del sample_weight[name]
        sample_weight[name]= None
        torch.cuda.empty_cache()
        gc.collect()

    return module

def fp4_layer(module: torch.nn.Module, name="", n_bit: int = 4, group_size: int = 128, transpose=False, **kwargs):
    assert n_bit==4, "fp4 only supports 4-bit"

    w = module.weight.clone()
    if transpose:
        w = w.t()

    wq, wq_state = bnb.functional.quantize_fp4(w, blocksize=group_size)
    w_deq = bnb.functional.dequantize_fp4(wq, wq_state, blocksize=group_size)

    if transpose:
        w_deq = w_deq.t()

    module.weight.data = w_deq.to(device=module.weight.device, dtype=module.weight.dtype)
    return module

def nf4_layer(module: torch.nn.Module, name="", n_bit: int = 4, group_size: int = 128, transpose=False, **kwargs):
    assert n_bit==4, "nf4 only supports 4-bit"

    w = module.weight.clone()
    if transpose:
        w = w.t()

    wq, wq_state = bnb.functional.quantize_nf4(w, blocksize=group_size)
    w_deq = bnb.functional.dequantize_nf4(wq, wq_state, blocksize=group_size)

    if transpose:
        w_deq = w_deq.t()

    module.weight.data = w_deq.to(device=module.weight.device, dtype=module.weight.dtype)
    return module

def intq_model(model: torch.nn.Module, layer_from: torch.nn.Module = torch.nn.Linear, *args, **kwargs):
    return quantize_model(model=model, layer_from=layer_from, layer_to=intq_layer, *args, **kwargs)

def fp4_model(model: torch.nn.Module, layer_from: torch.nn.Module = torch.nn.Linear, *args, **kwargs):
    return quantize_model(model=model, layer_from=layer_from, layer_to=fp4_layer, *args, **kwargs)

def nf4_model(model: torch.nn.Module, layer_from: torch.nn.Module = torch.nn.Linear, *args, **kwargs):
    return quantize_model(model=model, layer_from=layer_from, layer_to=nf4_layer, *args, **kwargs)

def anyq_model(model: torch.nn.Module, layer_from: torch.nn.Module = torch.nn.Linear, *args, **kwargs):
    return quantize_model(model=model, layer_from=layer_from, layer_to=anyq_layer, *args, **kwargs)

def intq(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    if isinstance(input_arg, torch.Tensor):
        raise NotImplementedError("We have not yet created an API to quantize tensor although we have the functions for that.")
    elif isinstance(input_arg, torch.nn.Module):
        if hasattr(input_arg, "weight") and isinstance(input_arg.weight, torch.nn.Parameter):
            # Assume linear layer
            return intq_layer(input_arg, *args, **kwargs)
        else:
            # Assume model
            return intq_model(input_arg, *args, **kwargs)
    else:
        return ValueError(f"Unsupported input type {type(input_arg)}.")

def int4(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    assert kwargs.pop("n_bit", None) in [4, None]
    return intq(input_arg=input_arg, n_bit=4, *args, **kwargs)

def int8(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    assert kwargs.pop("n_bit", None) in [8, None]
    return intq(input_arg=input_arg, n_bit=8, *args, **kwargs)

def fp4(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    if isinstance(input_arg, torch.Tensor):
        raise NotImplementedError("We have not yet created an API to quantize tensor although we have the functions for that.")
    elif isinstance(input_arg, torch.nn.Module):
        if hasattr(input_arg, "weight") and isinstance(input_arg.weight, torch.nn.Parameter):
            # Assume linear layer
            return fp4_layer(input_arg, *args, **kwargs)
        else:
            # Assume model
            return fp4_model(input_arg, *args, **kwargs)
    else:
        return ValueError(f"Unsupported input type {type(input_arg)}.")

def nf4(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    if isinstance(input_arg, torch.Tensor):
        raise NotImplementedError("We have not yet created an API to quantize tensor although we have the functions for that.")
    elif isinstance(input_arg, torch.nn.Module):
        if hasattr(input_arg, "weight") and isinstance(input_arg.weight, torch.nn.Parameter):
            # Assume linear layer
            return nf4_layer(input_arg, *args, **kwargs)
        else:
            # Assume model
            return nf4_model(input_arg, *args, **kwargs)
    else:
        return ValueError(f"Unsupported input type {type(input_arg)}.")

def anyq(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    if isinstance(input_arg, torch.Tensor):
        raise NotImplementedError("We have not yet created an API to quantize tensor although we have the functions for that.")
    elif isinstance(input_arg, torch.nn.Module):
        if hasattr(input_arg, "weight") and isinstance(input_arg.weight, torch.nn.Parameter):
            # Assume linear layer
            return anyq_layer(input_arg, *args, **kwargs)
        else:
            # Assume model
            return anyq_model(input_arg, *args, **kwargs)
    else:
        return ValueError(f"Unsupported input type {type(input_arg)}.")

def any4(input_arg: Union[torch.nn.Module, torch.Tensor], *args, **kwargs):
    assert kwargs.pop("n_bit", None) in [4, None]
    return anyq(input_arg=input_arg, n_bit=4, *args, **kwargs)

quant_methods = {
    "intq": intq,
    "anyq": anyq,
    "int4": int4,
    "int8": int8,
    "any4": any4,
    "nf4": nf4,
    "fp4": fp4,
}
