import argparse
import json
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from calibrate import calibrate
from data_gptq import get_loaders, llama_eval
from quantize import quant_methods, quantize_model


def load_model_and_tokenizer(model_path: str, dtype: torch.dtype):
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=dtype,
        device_map=None,
    ).to("cuda")
    model.eval()
    return model, tokenizer


def eval_wiki2(model, tokenizer, nsamples: int, seqlen: int):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=nsamples,
    )
    return llama_eval(model, testloader, "cuda", seqlen=seqlen)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--log-dir", default="logs/llama3.2-1b/wiki2_ppl")
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--skip-fp16", action="store_true")
    parser.add_argument("--skip-any4", action="store_true")
    args = parser.parse_args()

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    results = {
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
    }

    if not args.skip_fp16:
        model, tokenizer = load_model_and_tokenizer(args.model_path, torch.float16)
        results["fp16_ppl"] = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
        del model
        torch.cuda.empty_cache()

    if not args.skip_any4:
        model, tokenizer = load_model_and_tokenizer(args.model_path, torch.float16)
        model = quantize_model(
            model,
            layer_from=torch.nn.Linear,
            layer_to=quant_methods["anyq"],
            tokenizer=tokenizer,
            n_bit=4,
            skip_modules="lm_head",
            sample_weight=calibrate,
            scale_sample_weight=True,
        )
        model.eval()
        results["any4_4bit_ppl"] = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)

    with (log_dir / "results.json").open("w") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
