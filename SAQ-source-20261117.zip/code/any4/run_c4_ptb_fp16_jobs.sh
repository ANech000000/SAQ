#!/usr/bin/env bash
set -euo pipefail

cd /data/lsz/any4

EXP="logs/llama3.2-1b/c4_ptb_fp16_ppl_20260707_gpu3_gpu4"
mkdir -p "$EXP"

{
  echo "start_$(date +%Y%m%d_%H%M%S)"
  echo "gpu_before"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits

  CUDA_VISIBLE_DEVICES=3 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset c4 \
    --method fp16 \
    > "$EXP/c4_fp16.run.log" 2>&1 &
  p1=$!

  CUDA_VISIBLE_DEVICES=4 ./venv/bin/python run_local_c4_ptb_ppl.py \
    --log-dir "$EXP" \
    --dataset ptb \
    --method fp16 \
    > "$EXP/ptb_fp16.run.log" 2>&1 &
  p2=$!

  wait "$p1"
  s1=$?
  wait "$p2"
  s2=$?
  echo "status $s1 $s2"
  if [ "$s1" -ne 0 ] || [ "$s2" -ne 0 ]; then
    exit 1
  fi

  ./venv/bin/python - <<'PY'
import json
from pathlib import Path

exp = Path("logs/llama3.2-1b/c4_ptb_fp16_ppl_20260707_gpu3_gpu4")
summary = {"experiment_dir": str(exp), "datasets": {}}
for dataset in ["c4", "ptb"]:
    p = exp / dataset / "fp16" / "results.json"
    summary["datasets"][dataset] = {"fp16": json.loads(p.read_text())}
(exp / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(summary, indent=2, ensure_ascii=False))
PY

  echo "gpu_after"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
  echo "done_$(date +%Y%m%d_%H%M%S)"
} | tee "$EXP/run.log"
