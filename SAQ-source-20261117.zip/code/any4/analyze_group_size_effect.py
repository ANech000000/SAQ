#!/usr/bin/env python3
"""Measure why smaller any4 groups reduce weight reconstruction error."""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import time
from collections import defaultdict
from pathlib import Path

import torch
from safetensors import safe_open


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--group-sizes", type=int, nargs="+", default=[128, 64, 32])
    parser.add_argument("--rows-per-tensor", type=int, default=32)
    parser.add_argument("--max-tensors", type=int, default=0)
    parser.add_argument("--kmeans-iters", type=int, default=20)
    parser.add_argument("--quantile-points", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260713)
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def row_kmeans_1d(x: torch.Tensor, clusters: int = 16, iterations: int = 20):
    """Deterministic batched Lloyd k-means for one shared LUT per row."""
    q = torch.linspace(0, 1, clusters, dtype=x.dtype, device=x.device)
    centers = torch.quantile(x, q, dim=1).transpose(0, 1).contiguous()
    labels = torch.zeros_like(x, dtype=torch.long)
    for _ in range(iterations):
        labels = (x.unsqueeze(-1) - centers.unsqueeze(1)).abs().argmin(dim=-1)
        updated = centers.clone()
        for k in range(clusters):
            mask = labels == k
            count = mask.sum(dim=1)
            sums = (x * mask).sum(dim=1)
            valid = count > 0
            updated[valid, k] = sums[valid] / count[valid]
        if torch.equal(updated, centers):
            break
        centers = updated
    labels = (x.unsqueeze(-1) - centers.unsqueeze(1)).abs().argmin(dim=-1)
    reconstructed = centers.gather(1, labels)
    return reconstructed, centers


def analyze_rows(rows: torch.Tensor, group_size: int, iterations: int, quantile_points: int):
    rows = rows.float()
    batch, width = rows.shape
    grouped = rows.reshape(batch, -1, group_size)
    group_min = grouped.amin(dim=2, keepdim=True)
    group_max = grouped.amax(dim=2, keepdim=True)
    ranges = group_max - group_min
    scales = ranges.clamp_min(1e-6) / 15.0
    normalized = (grouped - group_min) / scales

    normalized_rows = normalized.reshape(batch, width)
    reconstructed_norm, _ = row_kmeans_1d(normalized_rows, iterations=iterations)
    norm_sq = (normalized_rows - reconstructed_norm).square()
    expanded_scales = scales.expand_as(normalized).reshape(batch, width)
    raw_sq = norm_sq * expanded_scales.square()

    q_shape = torch.linspace(0, 1, quantile_points, dtype=rows.dtype)
    curves = torch.quantile(normalized, q_shape, dim=2).permute(1, 2, 0)
    template = curves.mean(dim=1, keepdim=True)
    shape_sq = (curves - template).square().mean(dim=2)

    q05 = torch.quantile(grouped, 0.05, dim=2)
    q95 = torch.quantile(grouped, 0.95, dim=2)
    robust_range = (q95 - q05).clamp_min(1e-12)
    inflation = ranges.squeeze(2) / robust_range

    return {
        "weight_count": int(rows.numel()),
        "group_count": int(grouped.numel() // group_size),
        "raw_weight_sq_sum": float(rows.square().sum()),
        "range_sum": float(ranges.sum()),
        "range_sq_sum": float(ranges.square().sum()),
        "scale_sq_sum": float(scales.square().sum()),
        "normalized_sse": float(norm_sq.sum()),
        "raw_sse": float(raw_sq.sum()),
        "shape_sq_sum": float(shape_sq.sum()),
        "outlier_inflation_sum": float(inflation.sum()),
        "outlier_inflation_max": float(inflation.max()),
    }


def merge_stats(dst: dict, src: dict) -> None:
    for key, value in src.items():
        if key == "outlier_inflation_max":
            dst[key] = max(dst.get(key, 0.0), value)
        else:
            dst[key] = dst.get(key, 0) + value


def finalize(stats: dict) -> dict:
    weights = stats["weight_count"]
    groups = stats["group_count"]
    return {
        **stats,
        "mean_range": stats["range_sum"] / groups,
        "rms_range": math.sqrt(stats["range_sq_sum"] / groups),
        "mean_scale_sq": stats["scale_sq_sum"] / groups,
        "normalized_mse": stats["normalized_sse"] / weights,
        "normalized_rmse": math.sqrt(stats["normalized_sse"] / weights),
        "raw_mse": stats["raw_sse"] / weights,
        "raw_rmse": math.sqrt(stats["raw_sse"] / weights),
        "relative_weight_l2": math.sqrt(stats["raw_sse"] / stats["raw_weight_sq_sum"]),
        "shape_rmse_to_row_template": math.sqrt(stats["shape_sq_sum"] / groups),
        "mean_outlier_range_inflation": stats["outlier_inflation_sum"] / groups,
    }


def tensor_names(model: Path):
    files = sorted(model.glob("*.safetensors"))
    for file in files:
        with safe_open(file, framework="pt", device="cpu") as handle:
            for name in handle.keys():
                if not name.endswith(".weight"):
                    continue
                if "embed_tokens" in name or name.startswith("lm_head"):
                    continue
                tensor = handle.get_tensor(name)
                if tensor.ndim == 2:
                    yield file, name, tensor


def run_self_test() -> None:
    torch.manual_seed(7)
    template = torch.linspace(-1, 1, 128)
    rows = torch.cat([template * 2 + 3, template * 0.5 - 1]).reshape(1, -1)
    stats = analyze_rows(rows, 128, iterations=20, quantile_points=32)
    if stats["shape_sq_sum"] > 1e-8:
        raise AssertionError("Affine-equivalent groups should have zero shape distance")
    if not math.isfinite(stats["raw_sse"]):
        raise AssertionError("Reconstruction SSE must be finite")


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        print("self-test passed")
        return

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    started = time.time()
    totals = {size: {} for size in args.group_sizes}
    layers = []
    processed = 0

    for _, name, tensor in tensor_names(args.model):
        if args.max_tensors and processed >= args.max_tensors:
            break
        valid_sizes = [size for size in args.group_sizes if tensor.shape[1] % size == 0]
        if not valid_sizes:
            continue
        count = min(args.rows_per_tensor, tensor.shape[0])
        generator = torch.Generator().manual_seed(args.seed + processed)
        indices = torch.randperm(tensor.shape[0], generator=generator)[:count]
        rows = tensor.index_select(0, indices).float()
        record = {"tensor": name, "shape": list(tensor.shape), "sampled_rows": count, "metrics": {}}
        for size in valid_sizes:
            raw = analyze_rows(rows, size, args.kmeans_iters, args.quantile_points)
            merge_stats(totals[size], raw)
            record["metrics"][str(size)] = finalize(raw)
        layers.append(record)
        processed += 1
        print(f"[{processed}] {name} {tuple(tensor.shape)}", flush=True)

    summary = {str(size): finalize(stats) for size, stats in totals.items() if stats}
    baseline = summary.get("128")
    if baseline:
        for size, stats in summary.items():
            stats["raw_mse_vs_g128"] = stats["raw_mse"] / baseline["raw_mse"]
            stats["shape_rmse_vs_g128"] = (
                stats["shape_rmse_to_row_template"] / baseline["shape_rmse_to_row_template"]
            )

    result = {
        "model": str(args.model),
        "seed": args.seed,
        "rows_per_tensor": args.rows_per_tensor,
        "tensors_processed": processed,
        "kmeans": "deterministic batched Lloyd, 16 centroids shared per sampled row",
        "elapsed_seconds": time.time() - started,
        "summary": summary,
        "layers": layers,
    }
    (args.output_dir / "results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    with (args.output_dir / "summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["group_size", *next(iter(summary.values())).keys()])
        writer.writeheader()
        for size, stats in summary.items():
            writer.writerow({"group_size": size, **stats})
    command = " ".join(["python", *(__import__("sys").argv)])
    (args.output_dir / "command.txt").write_text(command + "\n", encoding="utf-8")
    print(json.dumps({"elapsed_seconds": result["elapsed_seconds"], "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
