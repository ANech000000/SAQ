import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path


METHOD_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
VENV_PYTHON = ROOT / "venv" / "bin" / "python"
DEFAULT_REFERENCE = METHOD_DIR / "runs" / "wiki2_ppl" / "results.json"
DEFAULT_RUN_ROOT = METHOD_DIR / "runs" / "performance"
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, METHOD24_DIR, METHOD25_DIR, METHOD_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from performance_topology import (
    MAX_GPUS,
    affinity_command,
    allocate_cpu_sets,
    apply_cpu_affinity,
    assert_gpu_empty,
    parse_cpu_list,
    select_empty_gpus,
)


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(temporary, path)


def safe_layer_name(name):
    return "".join(
        character if character.isalnum() or character in "._-" else "_"
        for character in name
    )


def tensor_sha256(tensor):
    value = tensor.detach().cpu().contiguous().numpy()
    return hashlib.sha256(value.tobytes()).hexdigest()


def build_balanced_manifest(reference_path, shard_count):
    payload = json.loads(Path(reference_path).read_text())
    if payload.get("status") != "complete":
        raise ValueError(f"Reference Method30 result is not complete: {reference_path}")
    layers = payload.get("layers", {})
    if len(layers) != 112:
        raise ValueError(f"Expected 112 reference layers, got {len(layers)}.")
    order = {name: index for index, name in enumerate(layers)}
    entries = []
    for name, entry in layers.items():
        diagnostics = entry.get("diagnostics", {})
        cost = float(
            diagnostics.get("initialization_seconds", entry.get("layer_seconds", 1.0))
        )
        entries.append({
            "name": name,
            "order": order[name],
            "shape": entry.get("weight_shape"),
            "estimated_seconds": max(cost, 1e-6),
        })

    shards = [
        {"index": index, "estimated_seconds": 0.0, "layers": []}
        for index in range(shard_count)
    ]
    for entry in sorted(entries, key=lambda item: item["estimated_seconds"], reverse=True):
        target = min(shards, key=lambda shard: shard["estimated_seconds"])
        target["layers"].append(entry)
        target["estimated_seconds"] += entry["estimated_seconds"]
    for shard in shards:
        shard["layers"].sort(key=lambda item: item["order"])
    return {
        "version": 1,
        "method": "method30_linear_sharded_candidate",
        "reference_result": str(reference_path),
        "reference_ppl": payload.get("wiki2_ppl"),
        "shard_count": shard_count,
        "layer_count": len(entries),
        "shards": shards,
    }


def _base_environment(physical_gpu):
    environment = os.environ.copy()
    environment.update({
        "CUDA_VISIBLE_DEVICES": str(physical_gpu),
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "TOKENIZERS_PARALLELISM": "false",
    })
    return environment


def _profile_arguments(args):
    return [
        "--importance-mode", args.importance_mode,
        "--initializer", args.initializer,
        "--max-iter", str(args.max_iter),
        "--importance-chunk-rows", str(args.importance_chunk_rows),
        "--lloyd-max-iter", str(args.lloyd_max_iter),
        "--lloyd-tol", str(args.lloyd_tol),
        "--lloyd-chunk-rows", str(args.lloyd_chunk_rows),
        "--lloyd-initialization", args.lloyd_initialization,
        "--cleanup-policy", args.cleanup_policy,
        "--cleanup-threshold-mib", str(args.cleanup_threshold_mib),
        "--empty-threshold-mib", str(args.empty_threshold_mib),
        "--empty-utilization-percent", str(args.empty_utilization_percent),
    ]


def _worker_command(args, manifest_path, shard, allocation, run_dir):
    result_path = run_dir / "shards" / f"shard_{shard['index']}" / "result.json"
    command = [
        str(VENV_PYTHON),
        str(Path(__file__).resolve()),
        "worker",
        "--manifest", str(manifest_path),
        "--shard-index", str(shard["index"]),
        "--physical-gpu", allocation["gpu"]["index"],
        "--cpu-list", allocation["cpu_list"],
        "--parallel-jobs", str(allocation["parallel_jobs"]),
        "--output", str(result_path),
        *_profile_arguments(args),
    ]
    return affinity_command(command, allocation["cpus"]), result_path


def _merge_command(args, manifest_path, physical_gpu, run_dir):
    output = run_dir / "results.json"
    command = [
        str(VENV_PYTHON),
        str(Path(__file__).resolve()),
        "merge",
        "--manifest", str(manifest_path),
        "--physical-gpu", str(physical_gpu),
        "--output", str(output),
        "--empty-threshold-mib", str(args.empty_threshold_mib),
        "--empty-utilization-percent", str(args.empty_utilization_percent),
    ]
    return command, output


def _start_process(command, environment, log_path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    handle = log_path.open("a", encoding="utf-8")
    process = subprocess.Popen(
        command,
        cwd=str(ROOT),
        env=environment,
        stdout=handle,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return process, handle


def run_parent(args):
    parent_started = time.perf_counter()
    if not 1 <= args.max_gpus <= MAX_GPUS:
        raise ValueError(f"--max-gpus must be between 1 and {MAX_GPUS}.")
    requested = None
    if args.physical_gpus:
        requested = [item.strip() for item in args.physical_gpus.split(",") if item.strip()]
        if len(requested) > args.max_gpus:
            raise ValueError("Requested GPU count exceeds --max-gpus.")
    selected, inspected = select_empty_gpus(
        args.max_gpus if requested is None else len(requested),
        args.empty_threshold_mib,
        args.empty_utilization_percent,
        requested=requested,
    )
    if len(selected) < args.min_gpus:
        summary = {
            "status": "not_started_insufficient_empty_gpus",
            "required": args.min_gpus,
            "available": len(selected),
            "gpu_scan": inspected,
        }
        print(json.dumps(summary, indent=2))
        return 3

    run_dir = Path(args.run_dir) if args.run_dir else (
        DEFAULT_RUN_ROOT / time.strftime("sharded_%Y%m%d_%H%M%S")
    )
    run_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = run_dir / "manifest.json"
    manifest = build_balanced_manifest(args.reference_result, len(selected))
    allocations = allocate_cpu_sets(selected, max_workers=args.max_workers_per_gpu)
    for shard, gpu in zip(manifest["shards"], selected):
        allocation = allocations[gpu["index"]]
        shard["physical_gpu"] = gpu["index"]
        shard["numa_node"] = gpu["numa_node"]
        shard["cpu_list"] = allocation["cpu_list"]
        shard["parallel_jobs"] = allocation["parallel_jobs"]
    manifest.update({
        "status": "prepared_not_started",
        "gpu_scan": inspected,
        "profile": {
            "importance_mode": args.importance_mode,
            "importance_chunk_rows": args.importance_chunk_rows,
            "initializer": args.initializer,
            "max_iter": args.max_iter,
            "cleanup_policy": args.cleanup_policy,
            "max_workers_per_gpu": args.max_workers_per_gpu,
        },
        "safety": {
            "max_gpus": MAX_GPUS,
            "empty_memory_threshold_mib": args.empty_threshold_mib,
            "empty_utilization_threshold_percent": args.empty_utilization_percent,
            "kill_existing_processes": False,
        },
    })
    commands = []
    for shard, gpu in zip(manifest["shards"], selected):
        command, result_path = _worker_command(
            args,
            manifest_path,
            shard,
            allocations[gpu["index"]],
            run_dir,
        )
        shard["result_path"] = str(result_path)
        commands.append(command)
    manifest["worker_commands"] = commands
    atomic_write_json(manifest_path, manifest)

    if not args.execute:
        print(json.dumps({
            "status": manifest["status"],
            "manifest": str(manifest_path),
            "workers": len(commands),
        }, indent=2))
        return 0

    manifest["status"] = "workers_running"
    manifest["started_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(manifest_path, manifest)
    worker_phase_started = time.perf_counter()
    jobs = []
    for shard, command in zip(manifest["shards"], commands):
        physical_gpu = shard["physical_gpu"]
        assert_gpu_empty(
            physical_gpu,
            args.empty_threshold_mib,
            args.empty_utilization_percent,
        )
        log_path = run_dir / "logs" / f"shard_{shard['index']}.log"
        process, handle = _start_process(
            command,
            _base_environment(physical_gpu),
            log_path,
        )
        jobs.append((shard, process, handle, log_path))

    worker_results = []
    worker_failed = False
    for shard, process, handle, log_path in jobs:
        return_code = process.wait()
        handle.close()
        result_path = Path(shard["result_path"])
        result = None
        if result_path.exists():
            result = json.loads(result_path.read_text())
        worker_results.append({
            "shard": shard["index"],
            "return_code": return_code,
            "status": result.get("status") if result else "missing_result",
            "result_path": str(result_path),
            "log_path": str(log_path),
        })
        worker_failed = worker_failed or return_code != 0 or result is None or result.get("status") != "complete"
    manifest["worker_results"] = worker_results
    manifest["worker_phase_seconds"] = time.perf_counter() - worker_phase_started
    if worker_failed:
        manifest["status"] = "worker_failed_no_merge"
        manifest["total_seconds"] = time.perf_counter() - parent_started
        atomic_write_json(manifest_path, manifest)
        return 2

    merge_gpu = selected[0]["index"]
    assert_gpu_empty(
        merge_gpu,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
    )
    merge_command, result_path = _merge_command(
        args,
        manifest_path,
        merge_gpu,
        run_dir,
    )
    merge_log = run_dir / "logs" / "merge_eval.log"
    merge_phase_started = time.perf_counter()
    process, handle = _start_process(
        merge_command,
        _base_environment(merge_gpu),
        merge_log,
    )
    return_code = process.wait()
    handle.close()
    manifest["merge"] = {
        "physical_gpu": merge_gpu,
        "command": merge_command,
        "return_code": return_code,
        "result_path": str(result_path),
        "log_path": str(merge_log),
    }
    manifest["status"] = "complete" if return_code == 0 else "merge_failed"
    manifest["merge_phase_seconds"] = time.perf_counter() - merge_phase_started
    manifest["total_seconds"] = time.perf_counter() - parent_started
    manifest["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(manifest_path, manifest)
    return 0 if return_code == 0 else 2


def _load_runtime_modules():
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    os.environ["NUMEXPR_NUM_THREADS"] = "1"
    import gc
    import torch
    from layer_timing import load_activations
    from method30_quant import method30_reconstruct_tensor
    from experiments.method30.runner import (
        CONFIG,
        build_channel_scale,
        evaluate_wiki2,
        load_alpha_selection,
        load_fisher,
        load_model_and_tokenizer,
        maybe_cleanup_cuda,
        new_cleanup_stats,
        validate_sources,
    )
    return {
        "gc": gc,
        "torch": torch,
        "load_activations": load_activations,
        "method30_reconstruct_tensor": method30_reconstruct_tensor,
        "CONFIG": CONFIG,
        "build_channel_scale": build_channel_scale,
        "evaluate_wiki2": evaluate_wiki2,
        "load_alpha_selection": load_alpha_selection,
        "load_fisher": load_fisher,
        "load_model_and_tokenizer": load_model_and_tokenizer,
        "maybe_cleanup_cuda": maybe_cleanup_cuda,
        "new_cleanup_stats": new_cleanup_stats,
        "validate_sources": validate_sources,
    }


def run_worker(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Worker expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    gpu = assert_gpu_empty(
        args.physical_gpu,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
    )
    affinity = apply_cpu_affinity(parse_cpu_list(args.cpu_list))
    if args.parallel_jobs > len(affinity):
        raise RuntimeError("parallel_jobs exceeds the worker CPU affinity.")
    runtime = _load_runtime_modules()
    torch = runtime["torch"]
    gc = runtime["gc"]
    config = runtime["CONFIG"]
    manifest = json.loads(Path(args.manifest).read_text())
    shard = manifest["shards"][args.shard_index]
    if shard["index"] != args.shard_index:
        raise ValueError("Shard manifest index mismatch.")
    layer_names = [entry["name"] for entry in shard["layers"]]
    output = Path(args.output)
    weight_dir = output.parent / "weights"

    result = {
        "status": "loading_model",
        "shard_index": args.shard_index,
        "physical_gpu": str(args.physical_gpu),
        "gpu_before": gpu,
        "cpu_affinity": affinity,
        "parallel_jobs": args.parallel_jobs,
        "layers": {},
    }
    atomic_write_json(output, result)
    alphas, _ = runtime["load_alpha_selection"](
        config["alpha_selection_path"],
        config["alpha_key"],
    )
    fisher, _ = runtime["load_fisher"](config["fisher_path"])
    model, tokenizer = runtime["load_model_and_tokenizer"](config["model_path"])
    linears, _, _ = runtime["validate_sources"](
        model, alphas, fisher, config["group_size"]
    )
    linear_map = dict(linears)
    if not set(layer_names).issubset(linear_map):
        raise ValueError("Shard contains unknown Linear names.")

    cleanup = runtime["new_cleanup_stats"](
        args.cleanup_policy,
        args.cleanup_threshold_mib,
    )
    result["status"] = "quantizing"
    atomic_write_json(output, result)
    started = time.perf_counter()
    active_layer_index = None
    activations = None
    for position, full_name in enumerate(layer_names):
        module = linear_map[full_name]
        layer_index = int(full_name.split(".")[2])
        if layer_index != active_layer_index:
            del activations
            activations = runtime["load_activations"](
                config["activation_cache"], layer_index
            )
            active_layer_index = layer_index
        channel_scale, alpha = runtime["build_channel_scale"](
            full_name, module, alphas, activations
        )
        source_weight = module.weight.detach().to("cuda:0", torch.float32)
        torch.cuda.synchronize()
        layer_started = time.perf_counter()
        reconstructed, diagnostics = runtime["method30_reconstruct_tensor"](
            source_weight,
            channel_scale,
            fisher[full_name],
            group_size=config["group_size"],
            max_iter=args.max_iter,
            relative_tol=config["joint_affine"]["relative_tol"],
            ridge=config["joint_affine"]["ridge"],
            scale_eps=config["joint_affine"]["scale_eps"],
            chunk_rows=config["joint_affine"]["chunk_rows"],
            loss_increase_rtol=config["joint_affine"]["loss_increase_rtol"],
            parallelize=args.initializer == "sklearn",
            parallel_jobs=args.parallel_jobs,
            importance_mode=args.importance_mode,
            importance_chunk_rows=args.importance_chunk_rows,
            initializer=args.initializer,
            lloyd_max_iter=args.lloyd_max_iter,
            lloyd_tol=args.lloyd_tol,
            lloyd_chunk_rows=args.lloyd_chunk_rows,
            lloyd_initialization=args.lloyd_initialization,
        )
        torch.cuda.synchronize()
        weight_path = weight_dir / f"{safe_layer_name(full_name)}.pt"
        weight_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = weight_path.with_suffix(f".pt.tmp.{os.getpid()}")
        cpu_weight = reconstructed.detach().cpu().to(module.weight.dtype).contiguous()
        torch.save(cpu_weight, temporary)
        os.replace(temporary, weight_path)
        result["layers"][full_name] = {
            "weight_path": str(weight_path),
            "weight_sha256": tensor_sha256(cpu_weight),
            "shape": list(cpu_weight.shape),
            "dtype": str(cpu_weight.dtype),
            "alpha": float(alpha),
            "seconds": float(time.perf_counter() - layer_started),
            "diagnostics": diagnostics,
        }
        result["completed_layers"] = position + 1
        atomic_write_json(output, result)

        next_layer_index = None
        if position + 1 < len(layer_names):
            next_layer_index = int(layer_names[position + 1].split(".")[2])
        block_boundary = next_layer_index != layer_index
        del channel_scale, source_weight, reconstructed, cpu_weight, diagnostics
        runtime["maybe_cleanup_cuda"](
            args.cleanup_policy,
            args.cleanup_threshold_mib,
            block_boundary,
            full_name,
            cleanup,
        )

    del activations, model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    result["cleanup"] = cleanup
    result["quantization_seconds"] = float(time.perf_counter() - started)
    result["status"] = "complete"
    atomic_write_json(output, result)
    return 0


def run_merge(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Merge expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    gpu = assert_gpu_empty(
        args.physical_gpu,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
    )
    runtime = _load_runtime_modules()
    torch = runtime["torch"]
    gc = runtime["gc"]
    config = runtime["CONFIG"]
    manifest = json.loads(Path(args.manifest).read_text())
    output = Path(args.output)
    result = {
        "status": "loading_model",
        "method": "method30_linear_sharded_candidate",
        "manifest": str(args.manifest),
        "physical_gpu": str(args.physical_gpu),
        "gpu_before": gpu,
        "baseline_method30_ppl": manifest.get("reference_ppl"),
    }
    atomic_write_json(output, result)
    model, tokenizer = runtime["load_model_and_tokenizer"](config["model_path"])
    expected = {
        name: module for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    }
    layer_records = {}
    for shard in manifest["shards"]:
        shard_result = json.loads(Path(shard["result_path"]).read_text())
        if shard_result.get("status") != "complete":
            raise RuntimeError(f"Shard {shard['index']} is not complete.")
        overlap = set(layer_records) & set(shard_result["layers"])
        if overlap:
            raise RuntimeError(f"Duplicate sharded layers: {sorted(overlap)}")
        layer_records.update(shard_result["layers"])
    if set(layer_records) != set(expected):
        raise RuntimeError(
            f"Sharded layer coverage mismatch: missing={sorted(set(expected) - set(layer_records))}, "
            f"extra={sorted(set(layer_records) - set(expected))}."
        )

    merge_started = time.perf_counter()
    for name, module in expected.items():
        record = layer_records[name]
        weight = torch.load(record["weight_path"], map_location="cpu")
        if list(weight.shape) != list(module.weight.shape):
            raise ValueError(f"Weight shape mismatch for {name}.")
        if tensor_sha256(weight) != record["weight_sha256"]:
            raise ValueError(f"Weight checksum mismatch for {name}.")
        module.weight.data.copy_(weight.to(module.weight.dtype))
        del weight
    result["merge_seconds"] = float(time.perf_counter() - merge_started)
    result["status"] = "evaluating"
    atomic_write_json(output, result)

    model.to("cuda:0")
    model.eval()
    evaluation_started = time.perf_counter()
    ppl = runtime["evaluate_wiki2"](
        model,
        tokenizer,
        config["loader_samples"],
        config["seqlen"],
    )
    result["evaluation_seconds"] = float(time.perf_counter() - evaluation_started)
    result["wiki2_ppl"] = float(ppl)
    result["delta_vs_single_method30"] = float(
        ppl - float(manifest.get("reference_ppl"))
    )
    result["status"] = "complete"
    atomic_write_json(output, result)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return 0


def add_profile_arguments(parser):
    parser.add_argument("--importance-mode", choices=("dense", "broadcast"), default="broadcast")
    parser.add_argument("--initializer", choices=("sklearn", "gpu_lloyd"), default="sklearn")
    parser.add_argument("--max-iter", type=int, default=10)
    parser.add_argument("--importance-chunk-rows", type=int, default=512)
    parser.add_argument("--lloyd-max-iter", type=int, default=50)
    parser.add_argument("--lloyd-tol", type=float, default=1e-4)
    parser.add_argument("--lloyd-chunk-rows", type=int, default=64)
    parser.add_argument("--lloyd-initialization", choices=("weighted_quantile", "linear"), default="weighted_quantile")
    parser.add_argument("--cleanup-policy", choices=("per_linear", "block", "threshold", "block_or_threshold", "never"), default="block_or_threshold")
    parser.add_argument("--cleanup-threshold-mib", type=float, default=4096)
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)


def build_parser():
    parser = argparse.ArgumentParser(description="Method30 NUMA-aware Linear sharding")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    parent = subparsers.add_parser("parent")
    parent.add_argument("--execute", action="store_true")
    parent.add_argument("--max-gpus", type=int, default=3)
    parent.add_argument("--min-gpus", type=int, default=2)
    parent.add_argument("--physical-gpus", default="")
    parent.add_argument("--max-workers-per-gpu", type=int, default=16)
    parent.add_argument("--reference-result", default=str(DEFAULT_REFERENCE))
    parent.add_argument("--run-dir")
    add_profile_arguments(parent)

    worker = subparsers.add_parser("worker")
    worker.add_argument("--manifest", required=True)
    worker.add_argument("--shard-index", type=int, required=True)
    worker.add_argument("--physical-gpu", required=True)
    worker.add_argument("--cpu-list", required=True)
    worker.add_argument("--parallel-jobs", type=int, required=True)
    worker.add_argument("--output", required=True)
    add_profile_arguments(worker)

    merge = subparsers.add_parser("merge")
    merge.add_argument("--manifest", required=True)
    merge.add_argument("--physical-gpu", required=True)
    merge.add_argument("--output", required=True)
    merge.add_argument("--empty-threshold-mib", type=int, default=256)
    merge.add_argument("--empty-utilization-percent", type=int, default=5)
    return parser


def main():
    args = build_parser().parse_args()
    if args.mode == "parent":
        return run_parent(args)
    if args.mode == "worker":
        return run_worker(args)
    return run_merge(args)


if __name__ == "__main__":
    raise SystemExit(main())
