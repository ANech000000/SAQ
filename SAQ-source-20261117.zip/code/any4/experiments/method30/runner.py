import argparse
import gc
import hashlib
import json
import os
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["NUMEXPR_MAX_THREADS"] = "64"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD_DIR = Path(__file__).resolve().parent
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, METHOD_DIR, METHOD24_DIR, METHOD25_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from data_gptq import get_loaders, llama_eval
from layer_timing import LINEAR_TO_ACTIVATION, load_activations
from method24_shape import build_awq_scale
from method30_quant import (
    IMPORTANCE_MODES,
    INITIALIZERS,
    METHOD_NAME,
    method30_reconstruct_tensor,
)


CONFIG = json.loads((METHOD_DIR / "config.json").read_text())
EXPECTED_ALPHA_COUNT = 96
EXPECTED_LINEAR_COUNT = 112
EXPECTED_FALLBACK_COUNT = 16
CLEANUP_POLICIES = (
    "per_linear",
    "block",
    "threshold",
    "block_or_threshold",
    "never",
)


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(temporary, path)


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def gpu_memory_mib(physical_gpu):
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={physical_gpu}",
            "--query-gpu=memory.used",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    return int(output.strip().splitlines()[0])


def check_single_empty_gpu(physical_gpu, max_used_mib):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    visible_ids = [
        value.strip() for value in visible.split(",") if value.strip()
    ]
    if visible_ids != [str(physical_gpu)]:
        raise RuntimeError(
            "Method30 requires exactly one visible physical GPU: "
            f"expected CUDA_VISIBLE_DEVICES={physical_gpu}, got {visible!r}."
        )
    used = gpu_memory_mib(physical_gpu)
    if used > max_used_mib:
        raise RuntimeError(
            f"GPU {physical_gpu} is not empty: {used} MiB used "
            f"> {max_used_mib} MiB."
        )
    return used


def cuda_memory_stats_mib():
    mib = 1024 * 1024
    return {
        "allocated_mib": float(torch.cuda.memory_allocated() / mib),
        "reserved_mib": float(torch.cuda.memory_reserved() / mib),
        "max_allocated_mib": float(torch.cuda.max_memory_allocated() / mib),
        "max_reserved_mib": float(torch.cuda.max_memory_reserved() / mib),
    }


def new_cleanup_stats(policy, threshold_mib):
    return {
        "policy": policy,
        "threshold_mib": float(threshold_mib),
        "checks": 0,
        "events": 0,
        "linear_events": 0,
        "block_events": 0,
        "threshold_events": 0,
        "max_reserved_before_cleanup_mib": 0.0,
        "event_log": [],
    }


def maybe_cleanup_cuda(
    policy,
    threshold_mib,
    block_boundary,
    linear_name,
    stats,
):
    memory = cuda_memory_stats_mib()
    reserved = memory["reserved_mib"]
    stats["checks"] += 1
    stats["max_reserved_before_cleanup_mib"] = max(
        stats["max_reserved_before_cleanup_mib"],
        reserved,
    )
    threshold_hit = threshold_mib > 0 and reserved >= threshold_mib
    reasons = []
    if policy == "per_linear":
        reasons.append("linear")
    if policy in ("block", "block_or_threshold") and block_boundary:
        reasons.append("block")
    if policy in ("threshold", "block_or_threshold") and threshold_hit:
        reasons.append("threshold")
    if not reasons or policy == "never":
        return False

    torch.cuda.empty_cache()
    gc.collect()
    stats["events"] += 1
    for reason in reasons:
        stats[f"{reason}_events"] += 1
    stats["event_log"].append({
        "linear": linear_name,
        "reasons": reasons,
        "reserved_before_mib": reserved,
        "reserved_after_mib": cuda_memory_stats_mib()["reserved_mib"],
    })
    return True


def load_alpha_selection(path, alpha_key):
    payload = json.loads(Path(path).read_text())
    if payload.get("status") != "complete":
        raise ValueError(f"Alpha selection is not complete: {path}")
    selected = payload.get("selected_alphas", {}).get(alpha_key)
    if not isinstance(selected, dict):
        raise ValueError(f"Missing alpha key {alpha_key!r} in {path}.")
    alphas = {str(name): float(value) for name, value in selected.items()}
    if len(alphas) != EXPECTED_ALPHA_COUNT:
        raise ValueError(
            f"Expected {EXPECTED_ALPHA_COUNT} selected alphas, got {len(alphas)}."
        )
    return alphas, payload


def load_fisher(path):
    payload = torch.load(path, map_location="cpu")
    fisher = payload.get("fisher") if isinstance(payload, dict) else payload
    if not isinstance(fisher, dict):
        raise ValueError(f"Expected a layer-to-Fisher dictionary in {path}.")
    fisher = {
        str(name): torch.as_tensor(value).detach().float().contiguous()
        for name, value in fisher.items()
    }
    return fisher, payload.get("metadata", {}) if isinstance(payload, dict) else {}


def load_model_and_tokenizer(model_path):
    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    return model, tokenizer


def layer_and_local_name(full_name):
    parts = full_name.split(".")
    if len(parts) < 4 or parts[0] != "model" or parts[1] != "layers":
        raise ValueError(f"Unexpected Linear name {full_name!r}.")
    return int(parts[2]), ".".join(parts[3:])


def validate_sources(model, alphas, fisher, group_size):
    linears = [
        (name, module)
        for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    ]
    linear_names = {name for name, _ in linears}
    searchable_names = set()
    fallback_names = set()
    for name, module in linears:
        _, local_name = layer_and_local_name(name)
        if local_name in LINEAR_TO_ACTIVATION:
            searchable_names.add(name)
        elif local_name == "self_attn.o_proj":
            fallback_names.add(name)
        else:
            raise ValueError(
                f"Method30 has no alpha policy for Linear {name!r}."
            )
        if module.weight.dim() != 2:
            raise ValueError(f"{name} is not a matrix.")
        if module.weight.shape[1] % group_size:
            raise ValueError(
                f"{name} columns {module.weight.shape[1]} are not divisible "
                f"by group_size={group_size}."
            )

    if len(linears) != EXPECTED_LINEAR_COUNT:
        raise ValueError(
            f"Expected {EXPECTED_LINEAR_COUNT} quantized Linears, "
            f"got {len(linears)}."
        )
    if len(fallback_names) != EXPECTED_FALLBACK_COUNT:
        raise ValueError(
            f"Expected {EXPECTED_FALLBACK_COUNT} o_proj fallbacks, "
            f"got {len(fallback_names)}."
        )
    if set(alphas) != searchable_names:
        missing = sorted(searchable_names - set(alphas))
        extra = sorted(set(alphas) - searchable_names)
        raise ValueError(
            f"Alpha coverage mismatch; missing={missing}, extra={extra}."
        )
    if set(fisher) != linear_names:
        missing = sorted(linear_names - set(fisher))
        extra = sorted(set(fisher) - linear_names)
        raise ValueError(
            f"Fisher coverage mismatch; missing={missing}, extra={extra}."
        )
    for name, module in linears:
        if fisher[name].numel() != module.weight.shape[1]:
            raise ValueError(
                f"{name} Fisher length {fisher[name].numel()} does not "
                f"match input dimension {module.weight.shape[1]}."
            )
        if not torch.isfinite(fisher[name]).all():
            raise ValueError(f"{name} Fisher contains non-finite values.")
    return linears, searchable_names, fallback_names


def build_channel_scale(
    full_name,
    module,
    alphas,
    layer_activations,
):
    _, local_name = layer_and_local_name(full_name)
    if full_name not in alphas:
        if local_name != "self_attn.o_proj":
            raise ValueError(f"Missing alpha for {full_name}.")
        return torch.ones(module.weight.shape[1], dtype=torch.float32), 0.0

    activation_key = LINEAR_TO_ACTIVATION[local_name]
    activation = layer_activations[activation_key]
    if activation.shape[1] != module.weight.shape[1]:
        raise ValueError(
            f"{full_name} activation width {activation.shape[1]} does not "
            f"match weight width {module.weight.shape[1]}."
        )
    alpha = float(alphas[full_name])
    scale = build_awq_scale(
        activation.abs().mean(dim=0),
        alpha,
    ).detach().cpu().float()
    if not torch.isfinite(scale).all() or (scale <= 0).any():
        raise ValueError(f"{full_name} produced invalid AWQ scales.")
    return scale, alpha


def evaluate_wiki2(model, tokenizer, loader_samples, seqlen):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=loader_samples,
    )
    return float(llama_eval(model, testloader, "cuda", seqlen=seqlen))


def aggregate_diagnostics(layer_results):
    diagnostics = [entry["diagnostics"] for entry in layer_results.values()]
    relative_improvements = [
        entry["relative_loss_improvement"] for entry in diagnostics
    ]
    return {
        "layers": len(diagnostics),
        "all_losses_monotonic": bool(
            all(entry["loss_monotonic"] for entry in diagnostics)
        ),
        "rollback_layers": int(
            sum(bool(entry["rollback"]) for entry in diagnostics)
        ),
        "total_iterations": int(
            sum(entry["iterations"] for entry in diagnostics)
        ),
        "accepted_affine_updates": int(
            sum(entry["accepted_affine_updates"] for entry in diagnostics)
        ),
        "mean_relative_loss_improvement": float(
            sum(relative_improvements) / max(len(relative_improvements), 1)
        ),
        "min_relative_loss_improvement": float(
            min(relative_improvements, default=0.0)
        ),
        "initialization_seconds_sum": float(
            sum(entry["initialization_seconds"] for entry in diagnostics)
        ),
        "optimization_seconds_sum": float(
            sum(entry["optimization_seconds"] for entry in diagnostics)
        ),
    }


def execute(args):
    if not torch.cuda.is_available():
        raise RuntimeError("Method30 requires CUDA for the full PPL run.")
    if not 1 <= args.parallel_jobs <= 32:
        raise ValueError("parallel_jobs must be between 1 and 32.")
    if args.cleanup_policy not in CLEANUP_POLICIES:
        raise ValueError(
            f"cleanup_policy must be one of {CLEANUP_POLICIES}."
        )
    if args.cleanup_threshold_mib < 0:
        raise ValueError("cleanup_threshold_mib cannot be negative.")
    initial_gpu_memory = check_single_empty_gpu(
        args.physical_gpu,
        args.empty_threshold_mib,
    )
    os.environ["HF_DATASETS_CACHE"] = args.dataset_cache
    torch.backends.cuda.matmul.allow_tf32 = False
    device = torch.device("cuda:0")
    output = Path(args.output)

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    total_started = time.perf_counter()
    alphas, alpha_payload = load_alpha_selection(
        args.alpha_selection_path,
        args.alpha_key,
    )
    fisher, fisher_metadata = load_fisher(args.fisher_path)

    result = {
        "method_name": METHOD_NAME,
        "status": "loading_model",
        "sequence": [
            "method27_lambda_0p3_awq_scale",
            "method9_fisher_weighted_any4_initialization",
            "weighted_4bit_joint_lut_affine_optimization",
        ],
        "model_path": args.model_path,
        "dataset": CONFIG["dataset"],
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "n_bit": 4,
        "group_size": args.group_size,
        "physical_gpu": str(args.physical_gpu),
        "initial_gpu_memory_mib": int(initial_gpu_memory),
        "started_at": started_at,
        "sources": {
            "alpha_selection_path": args.alpha_selection_path,
            "alpha_key": args.alpha_key,
            "alpha_selection_sha256": file_sha256(
                args.alpha_selection_path
            ),
            "alpha_source_search": alpha_payload.get("source_search"),
            "fisher_path": args.fisher_path,
            "fisher_sha256": file_sha256(args.fisher_path),
            "fisher_metadata": fisher_metadata,
            "activation_cache": args.activation_cache,
        },
        "parameters": {
            "parallel_jobs": args.parallel_jobs,
            "max_iter": args.max_iter,
            "relative_tol": args.relative_tol,
            "ridge": args.ridge,
            "scale_eps": args.scale_eps,
            "chunk_rows": args.chunk_rows,
            "loss_increase_rtol": args.loss_increase_rtol,
            "importance_mode": args.importance_mode,
            "importance_chunk_rows": args.importance_chunk_rows,
            "initializer": args.initializer,
            "lloyd_max_iter": args.lloyd_max_iter,
            "lloyd_tol": args.lloyd_tol,
            "lloyd_chunk_rows": args.lloyd_chunk_rows,
            "lloyd_initialization": args.lloyd_initialization,
            "cleanup_policy": args.cleanup_policy,
            "cleanup_threshold_mib": args.cleanup_threshold_mib,
        },
        "baselines": CONFIG["baselines"],
        "layers": {},
        "completed_linears": 0,
    }
    atomic_write_json(output, result)

    model_load_started = time.perf_counter()
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    result["model_load_seconds"] = (
        time.perf_counter() - model_load_started
    )
    linears, searchable_names, fallback_names = validate_sources(
        model,
        alphas,
        fisher,
        args.group_size,
    )
    result["coverage"] = {
        "quantized_linears": len(linears),
        "method27_scaled_linears": len(searchable_names),
        "alpha_zero_fallback_linears": len(fallback_names),
        "fisher_layers": len(fisher),
    }
    result["alpha_histogram"] = dict(
        sorted(Counter(str(value) for value in alphas.values()).items())
    )
    result["status"] = "quantizing"
    atomic_write_json(output, result)

    quantization_started = time.perf_counter()
    active_layer_index = None
    layer_activations = None
    cleanup_stats = new_cleanup_stats(
        args.cleanup_policy,
        args.cleanup_threshold_mib,
    )
    for index, (full_name, module) in enumerate(linears, 1):
        layer_index, _ = layer_and_local_name(full_name)
        if layer_index != active_layer_index:
            del layer_activations
            layer_activations = load_activations(
                args.activation_cache,
                layer_index,
            )
            active_layer_index = layer_index

        channel_scale, alpha = build_channel_scale(
            full_name,
            module,
            alphas,
            layer_activations,
        )
        source_weight = module.weight.detach().to(
            device=device,
            dtype=torch.float32,
        )
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        layer_started = time.perf_counter()
        reconstructed, diagnostics = method30_reconstruct_tensor(
            source_weight,
            channel_scale,
            fisher[full_name],
            group_size=args.group_size,
            max_iter=args.max_iter,
            relative_tol=args.relative_tol,
            ridge=args.ridge,
            scale_eps=args.scale_eps,
            chunk_rows=args.chunk_rows,
            loss_increase_rtol=args.loss_increase_rtol,
            parallelize=not args.no_parallelize,
            parallel_jobs=args.parallel_jobs,
            importance_mode=args.importance_mode,
            importance_chunk_rows=args.importance_chunk_rows,
            initializer=args.initializer,
            lloyd_max_iter=args.lloyd_max_iter,
            lloyd_tol=args.lloyd_tol,
            lloyd_chunk_rows=args.lloyd_chunk_rows,
            lloyd_initialization=args.lloyd_initialization,
        )
        torch.cuda.synchronize()
        diagnostics["cuda_memory"] = cuda_memory_stats_mib()
        layer_seconds = time.perf_counter() - layer_started
        module.weight.data.copy_(
            reconstructed.detach().cpu().to(module.weight.dtype)
        )

        result["layers"][full_name] = {
            "alpha": float(alpha),
            "alpha_source": (
                args.alpha_key
                if full_name in alphas
                else "o_proj_alpha0_fallback"
            ),
            "weight_shape": list(module.weight.shape),
            "layer_seconds": float(layer_seconds),
            "diagnostics": diagnostics,
        }
        result["completed_linears"] = index
        result["active_linear"] = full_name
        result["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        atomic_write_json(output, result)
        print(
            f"[{index}/{len(linears)}] {full_name}: "
            f"alpha={alpha:g}, loss={diagnostics['initial_weighted_loss']:.8e}"
            f"->{diagnostics['final_weighted_loss']:.8e}, "
            f"iters={diagnostics['iterations']}",
            flush=True,
        )

        next_layer_index = None
        if index < len(linears):
            next_layer_index, _ = layer_and_local_name(linears[index][0])
        block_boundary = next_layer_index != layer_index
        del source_weight, reconstructed, channel_scale, diagnostics
        maybe_cleanup_cuda(
            args.cleanup_policy,
            args.cleanup_threshold_mib,
            block_boundary,
            full_name,
            cleanup_stats,
        )

    del layer_activations
    torch.cuda.empty_cache()
    gc.collect()
    result["cleanup"] = cleanup_stats
    result["quantization_seconds"] = (
        time.perf_counter() - quantization_started
    )
    result["diagnostics_summary"] = aggregate_diagnostics(result["layers"])
    if not result["diagnostics_summary"]["all_losses_monotonic"]:
        raise AssertionError("At least one Method30 layer was non-monotonic.")

    result["status"] = "evaluating_wiki2"
    result["active_linear"] = None
    atomic_write_json(output, result)
    model.to(device)
    model.eval()
    evaluation_started = time.perf_counter()
    ppl = evaluate_wiki2(
        model,
        tokenizer,
        args.loader_samples,
        args.seqlen,
    )
    result["evaluation_seconds"] = (
        time.perf_counter() - evaluation_started
    )
    result["wiki2_ppl"] = float(ppl)
    result["delta_vs_method9"] = float(
        ppl - CONFIG["baselines"]["method9_fisher_any4_ppl"]
    )
    result["delta_vs_method27"] = float(
        ppl - CONFIG["baselines"]["method27_lambda_0p3_ppl"]
    )
    result["delta_vs_original_any4"] = float(
        ppl - CONFIG["baselines"]["original_any4_4bit_ppl"]
    )
    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    result["total_seconds"] = time.perf_counter() - total_started
    atomic_write_json(output, result)
    print(json.dumps(result, indent=2), flush=True)

    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return result


def mark_failed(output, error):
    path = Path(output)
    if path.exists():
        try:
            payload = json.loads(path.read_text())
        except Exception:
            payload = {}
    else:
        payload = {}
    payload["status"] = "failed"
    payload["error"] = f"{type(error).__name__}: {error}"
    payload["failed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(path, payload)


def build_parser():
    defaults = CONFIG["joint_affine"]
    performance = CONFIG.get("performance_candidates", {})
    baseline = performance.get("baseline_defaults", {})
    parser = argparse.ArgumentParser(description=METHOD_NAME)
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument(
        "--alpha-selection-path",
        default=CONFIG["alpha_selection_path"],
    )
    parser.add_argument("--alpha-key", default=CONFIG["alpha_key"])
    parser.add_argument(
        "--activation-cache",
        default=CONFIG["activation_cache"],
    )
    parser.add_argument("--fisher-path", default=CONFIG["fisher_path"])
    parser.add_argument(
        "--dataset-cache",
        default=CONFIG["dataset_cache"],
    )
    parser.add_argument("--output", default=CONFIG["output"])
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument(
        "--empty-threshold-mib",
        type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    parser.add_argument(
        "--parallel-jobs",
        type=int,
        default=CONFIG["parallel_jobs"],
    )
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument("--seqlen", type=int, default=CONFIG["seqlen"])
    parser.add_argument(
        "--loader-samples",
        type=int,
        default=CONFIG["loader_samples"],
    )
    parser.add_argument("--max-iter", type=int, default=defaults["max_iter"])
    parser.add_argument(
        "--relative-tol",
        type=float,
        default=defaults["relative_tol"],
    )
    parser.add_argument("--ridge", type=float, default=defaults["ridge"])
    parser.add_argument(
        "--scale-eps",
        type=float,
        default=defaults["scale_eps"],
    )
    parser.add_argument(
        "--chunk-rows",
        type=int,
        default=defaults["chunk_rows"],
    )
    parser.add_argument(
        "--loss-increase-rtol",
        type=float,
        default=defaults["loss_increase_rtol"],
    )
    parser.add_argument(
        "--importance-mode",
        choices=IMPORTANCE_MODES,
        default=baseline.get("importance_mode", "dense"),
    )
    parser.add_argument(
        "--importance-chunk-rows",
        type=int,
        default=baseline.get("importance_chunk_rows", defaults["chunk_rows"]),
    )
    parser.add_argument(
        "--initializer",
        choices=INITIALIZERS,
        default=baseline.get("initializer", "sklearn"),
    )
    parser.add_argument(
        "--lloyd-max-iter",
        type=int,
        default=baseline.get("lloyd_max_iter", 50),
    )
    parser.add_argument(
        "--lloyd-tol",
        type=float,
        default=baseline.get("lloyd_tol", 1e-4),
    )
    parser.add_argument(
        "--lloyd-chunk-rows",
        type=int,
        default=baseline.get("lloyd_chunk_rows", 64),
    )
    parser.add_argument(
        "--lloyd-initialization",
        choices=("weighted_quantile", "linear"),
        default=baseline.get("lloyd_initialization", "weighted_quantile"),
    )
    parser.add_argument(
        "--cleanup-policy",
        choices=CLEANUP_POLICIES,
        default=baseline.get("cleanup_policy", "per_linear"),
    )
    parser.add_argument(
        "--cleanup-threshold-mib",
        type=float,
        default=baseline.get("cleanup_threshold_mib", 4096),
    )
    parser.add_argument("--no-parallelize", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    try:
        execute(args)
    except Exception as error:
        mark_failed(args.output, error)
        raise


if __name__ == "__main__":
    main()
