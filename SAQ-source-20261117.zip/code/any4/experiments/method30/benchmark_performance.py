import argparse
import gc
import hashlib
import json
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


METHOD_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, METHOD24_DIR, METHOD25_DIR, METHOD_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from layer_timing import load_activations
from method30_quant import method30_reconstruct_tensor
from performance_topology import apply_cpu_affinity, assert_gpu_empty
from experiments.method30.runner import (
    CONFIG,
    atomic_write_json,
    build_channel_scale,
    cuda_memory_stats_mib,
    load_alpha_selection,
    load_fisher,
    load_model_and_tokenizer,
    validate_sources,
)


VARIANTS = {
    "baseline_dense_sklearn16": {
        "importance_mode": "dense",
        "initializer": "sklearn",
        "parallel_jobs": 16,
    },
    "broadcast_sklearn16": {
        "importance_mode": "broadcast",
        "initializer": "sklearn",
        "parallel_jobs": 16,
    },
    "broadcast_sklearn32": {
        "importance_mode": "broadcast",
        "initializer": "sklearn",
        "parallel_jobs": 32,
    },
    "broadcast_gpu_lloyd": {
        "importance_mode": "broadcast",
        "initializer": "gpu_lloyd",
        "parallel_jobs": 1,
    },
}
DEFAULT_LAYERS = (
    "model.layers.0.self_attn.q_proj",
    "model.layers.0.mlp.gate_proj",
)


def tensor_sha256(tensor):
    value = tensor.detach().cpu().contiguous().numpy()
    return hashlib.sha256(value.tobytes()).hexdigest()


def parse_layers(value):
    layers = tuple(item.strip() for item in value.split(",") if item.strip())
    if not layers:
        raise ValueError("At least one benchmark layer is required.")
    return layers


def execute(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    gpu = assert_gpu_empty(
        args.physical_gpu,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
    )
    affinity = apply_cpu_affinity(
        [int(value) for value in args.cpu_list.split(",") if value.strip()]
        if "-" not in args.cpu_list
        else _expand_cpu_list(args.cpu_list)
    )
    profile = VARIANTS[args.variant]
    parallel_jobs = int(profile["parallel_jobs"])
    if parallel_jobs > len(affinity):
        raise RuntimeError(
            f"Variant needs {parallel_jobs} workers but affinity has "
            f"{len(affinity)} physical CPUs."
        )

    output = Path(args.output)
    result = {
        "status": "loading_model",
        "variant": args.variant,
        "profile": profile,
        "physical_gpu": str(args.physical_gpu),
        "gpu_before": gpu,
        "cpu_affinity": affinity,
        "layers": {},
        "max_iter": args.max_iter,
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write_json(output, result)

    alphas, _ = load_alpha_selection(
        CONFIG["alpha_selection_path"],
        CONFIG["alpha_key"],
    )
    fisher, _ = load_fisher(CONFIG["fisher_path"])
    model, tokenizer = load_model_and_tokenizer(CONFIG["model_path"])
    linears, _, _ = validate_sources(
        model,
        alphas,
        fisher,
        CONFIG["group_size"],
    )
    linear_map = dict(linears)
    targets = parse_layers(args.layers)
    missing = sorted(set(targets) - set(linear_map))
    if missing:
        raise ValueError(f"Unknown benchmark layers: {missing}")

    result["status"] = "benchmarking"
    atomic_write_json(output, result)
    total_started = time.perf_counter()
    for full_name in targets:
        module = linear_map[full_name]
        layer_index = int(full_name.split(".")[2])
        activations = load_activations(CONFIG["activation_cache"], layer_index)
        channel_scale, alpha = build_channel_scale(
            full_name,
            module,
            alphas,
            activations,
        )
        source_weight = module.weight.detach().to(
            device="cuda:0",
            dtype=torch.float32,
        )
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        started = time.perf_counter()
        reconstructed, diagnostics = method30_reconstruct_tensor(
            source_weight,
            channel_scale,
            fisher[full_name],
            group_size=CONFIG["group_size"],
            max_iter=args.max_iter,
            relative_tol=CONFIG["joint_affine"]["relative_tol"],
            ridge=CONFIG["joint_affine"]["ridge"],
            scale_eps=CONFIG["joint_affine"]["scale_eps"],
            chunk_rows=CONFIG["joint_affine"]["chunk_rows"],
            loss_increase_rtol=CONFIG["joint_affine"]["loss_increase_rtol"],
            parallelize=profile["initializer"] == "sklearn",
            parallel_jobs=parallel_jobs,
            importance_mode=profile["importance_mode"],
            importance_chunk_rows=args.importance_chunk_rows,
            initializer=profile["initializer"],
            lloyd_max_iter=args.lloyd_max_iter,
            lloyd_tol=args.lloyd_tol,
            lloyd_chunk_rows=args.lloyd_chunk_rows,
            lloyd_initialization=args.lloyd_initialization,
        )
        torch.cuda.synchronize()
        layer_seconds = time.perf_counter() - started
        result["layers"][full_name] = {
            "shape": list(source_weight.shape),
            "alpha": float(alpha),
            "seconds": float(layer_seconds),
            "reconstruction_sha256": tensor_sha256(reconstructed),
            "unweighted_mse": float(
                (source_weight - reconstructed.float()).square().mean().item()
            ),
            "cuda_memory": cuda_memory_stats_mib(),
            "diagnostics": diagnostics,
        }
        atomic_write_json(output, result)
        del activations, channel_scale, source_weight, reconstructed, diagnostics
        torch.cuda.empty_cache()
        gc.collect()

    result["status"] = "complete"
    result["total_seconds"] = float(time.perf_counter() - total_started)
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(output, result)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return result


def _expand_cpu_list(value):
    cpus = []
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, stop = (int(item) for item in part.split("-", 1))
            cpus.extend(range(start, stop + 1))
        else:
            cpus.append(int(part))
    return sorted(set(cpus))


def build_parser():
    parser = argparse.ArgumentParser(description="Method30 performance microbenchmark")
    parser.add_argument("--variant", choices=tuple(VARIANTS), required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--layers", default=",".join(DEFAULT_LAYERS))
    parser.add_argument("--max-iter", type=int, default=2)
    parser.add_argument("--importance-chunk-rows", type=int, default=128)
    parser.add_argument("--lloyd-max-iter", type=int, default=50)
    parser.add_argument("--lloyd-tol", type=float, default=1e-4)
    parser.add_argument("--lloyd-chunk-rows", type=int, default=64)
    parser.add_argument(
        "--lloyd-initialization",
        choices=("weighted_quantile", "linear"),
        default="weighted_quantile",
    )
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)
    return parser


def main():
    args = build_parser().parse_args()
    result = execute(args)
    print(json.dumps({
        "status": result["status"],
        "variant": result["variant"],
        "total_seconds": result["total_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
