import math
import time

import torch

from quantize import anyq_quantize_tensor, cluster_row_scikit, group_q


METHOD_NAME = "method30_m27_m9_weighted_joint_affine"
IMPORTANCE_MODES = ("dense", "broadcast")
INITIALIZERS = ("sklearn", "gpu_lloyd")


def transform_fisher(fisher, channel_scale, normalize=True, eps=1e-12):
    fisher = torch.as_tensor(
        fisher,
        device=channel_scale.device,
        dtype=torch.float32,
    ).reshape(-1)
    scale = torch.as_tensor(
        channel_scale,
        device=channel_scale.device,
        dtype=torch.float32,
    ).reshape(-1)
    if fisher.numel() != scale.numel():
        raise ValueError(
            f"Fisher length {fisher.numel()} does not match scale length "
            f"{scale.numel()}."
        )
    transformed = fisher / scale.clamp_min(eps).square()
    transformed = torch.nan_to_num(
        transformed,
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    ).clamp_min(0.0)
    if not normalize:
        return transformed
    mean = transformed.mean()
    if not torch.isfinite(mean) or mean <= eps:
        return torch.ones_like(transformed)
    return transformed / mean


def _importance_matrix(base_fisher, weight):
    importance = base_fisher.reshape(1, -1).expand_as(weight).clone()
    importance.mul_((weight != 0).to(importance.dtype))
    empty_rows = importance.sum(dim=1, keepdim=True) <= 0
    if empty_rows.any():
        importance = torch.where(
            empty_rows.expand_as(importance),
            torch.ones_like(importance),
            importance,
        )
    return importance


def _importance_rows(
    importance,
    weight,
    start,
    stop,
    mask_zero_weights,
):
    """Return row importance without retaining a dense layer-sized clone."""
    if importance.dim() == 2:
        return importance[start:stop]
    if importance.dim() != 1 or importance.numel() != weight.shape[1]:
        raise ValueError(
            f"Importance shape {tuple(importance.shape)} is incompatible with "
            f"weight shape {tuple(weight.shape)}."
        )
    expanded = importance.reshape(1, -1).expand(stop - start, -1)
    if not mask_zero_weights:
        return expanded
    masked = expanded * (weight[start:stop] != 0).to(expanded.dtype)
    empty_rows = masked.sum(dim=1, keepdim=True) <= 0
    return torch.where(empty_rows, torch.ones_like(masked), masked)


def _importance_storage_elements(importance):
    return int(importance.numel())


def _unpack_group_affine(scales_and_zeros):
    grouped = scales_and_zeros.transpose(0, 1).contiguous().float()
    scales = grouped[:, :, 0]
    zeros = grouped[:, :, 1]
    offsets = zeros - 8.0 * scales
    return scales, offsets


def _expand_group_values(values, group_size, cols):
    rows, groups = values.shape
    return (
        values[:, :, None]
        .expand(rows, groups, group_size)
        .reshape(rows, cols)
    )


def _sort_lut(lut, assignment):
    order = torch.argsort(lut, dim=1)
    sorted_lut = torch.gather(lut, dim=1, index=order)
    inverse = torch.empty_like(order)
    labels = (
        torch.arange(lut.shape[1], device=lut.device)
        .reshape(1, -1)
        .expand_as(order)
    )
    inverse.scatter_(1, order, labels)
    sorted_assignment = torch.gather(
        inverse,
        dim=1,
        index=assignment.long(),
    )
    return sorted_lut, sorted_assignment


def _assign_nearest(
    weight,
    lut,
    scales,
    offsets,
    group_size,
    chunk_rows,
):
    rows, cols = weight.shape
    groups = cols // group_size
    weight_groups = weight.reshape(rows, groups, group_size)
    assignment = torch.empty(
        (rows, cols),
        dtype=torch.long,
        device=weight.device,
    )
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        reconstructed_codes = (
            scales[start:stop, :, None, None]
            * lut[start:stop, None, None, :]
            + offsets[start:stop, :, None, None]
        )
        distance = (
            weight_groups[start:stop, :, :, None] - reconstructed_codes
        ).abs()
        assignment[start:stop] = torch.argmin(
            distance,
            dim=-1,
        ).reshape(stop - start, cols)
    return assignment


def _reconstruct(weight_shape, lut, assignment, scales, offsets, group_size):
    rows, cols = weight_shape
    codes = torch.gather(lut, dim=1, index=assignment.long())
    scale_values = _expand_group_values(scales, group_size, cols)
    offset_values = _expand_group_values(offsets, group_size, cols)
    return scale_values * codes + offset_values


def weighted_loss(
    weight,
    importance,
    lut,
    assignment,
    scales,
    offsets,
    group_size,
    chunk_rows=None,
    mask_zero_weights=False,
):
    if importance.dim() == 2:
        reconstructed = _reconstruct(
            weight.shape,
            lut,
            assignment,
            scales,
            offsets,
            group_size,
        )
        denominator = importance.sum().clamp_min(1e-12)
        return (
            importance * (weight - reconstructed).square()
        ).sum().div(denominator).item()

    rows, cols = weight.shape
    chunk_rows = max(1, int(chunk_rows or rows))
    numerator = torch.zeros((), device=weight.device, dtype=weight.dtype)
    denominator = torch.zeros_like(numerator)
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        row_importance = _importance_rows(
            importance,
            weight,
            start,
            stop,
            mask_zero_weights,
        )
        reconstructed = _reconstruct(
            (stop - start, cols),
            lut[start:stop],
            assignment[start:stop],
            scales[start:stop],
            offsets[start:stop],
            group_size,
        )
        numerator.add_(
            (row_importance * (weight[start:stop] - reconstructed).square()).sum()
        )
        denominator.add_(row_importance.sum())
    return numerator.div(denominator.clamp_min(1e-12)).item()


def _update_lut(
    weight,
    importance,
    lut,
    assignment,
    scales,
    offsets,
    group_size,
    chunk_rows=None,
    mask_zero_weights=False,
    eps=1e-12,
):
    rows, cols = weight.shape
    code_count = lut.shape[1]
    numerator = torch.zeros(
        (rows, code_count),
        dtype=weight.dtype,
        device=weight.device,
    )
    denominator = torch.zeros_like(numerator)

    if importance.dim() == 2:
        scale_values = _expand_group_values(scales, group_size, cols)
        offset_values = _expand_group_values(offsets, group_size, cols)
        numerator_source = (
            importance * scale_values * (weight - offset_values)
        )
        denominator_source = importance * scale_values.square()
        numerator.scatter_add_(1, assignment.long(), numerator_source)
        denominator.scatter_add_(1, assignment.long(), denominator_source)
    else:
        groups = cols // group_size
        chunk_rows = max(1, int(chunk_rows or rows))
        for start in range(0, rows, chunk_rows):
            stop = min(start + chunk_rows, rows)
            row_importance = _importance_rows(
                importance,
                weight,
                start,
                stop,
                mask_zero_weights,
            ).reshape(stop - start, groups, group_size)
            weight_groups = weight[start:stop].reshape(
                stop - start,
                groups,
                group_size,
            )
            scale_groups = scales[start:stop, :, None]
            offset_groups = offsets[start:stop, :, None]
            numerator_source = (
                row_importance
                * scale_groups
                * (weight_groups - offset_groups)
            ).reshape(stop - start, cols)
            denominator_source = (
                row_importance * scale_groups.square()
            ).reshape(stop - start, cols)
            numerator[start:stop].scatter_add_(
                1,
                assignment[start:stop].long(),
                numerator_source,
            )
            denominator[start:stop].scatter_add_(
                1,
                assignment[start:stop].long(),
                denominator_source,
            )

    populated = denominator > eps
    return torch.where(
        populated,
        numerator / denominator.clamp_min(eps),
        lut,
    )


def _update_affine_dense(
    weight,
    importance,
    lut,
    assignment,
    scales,
    offsets,
    group_size,
    ridge,
    scale_eps,
):
    rows, cols = weight.shape
    groups = cols // group_size
    weight_groups = weight.reshape(rows, groups, group_size)
    importance_groups = importance.reshape(rows, groups, group_size)
    codes = torch.gather(
        lut,
        dim=1,
        index=assignment.long(),
    ).reshape(rows, groups, group_size)

    weight_sum = importance_groups.sum(dim=2)
    safe_weight_sum = weight_sum.clamp_min(1e-12)
    code_mean = (
        importance_groups * codes
    ).sum(dim=2) / safe_weight_sum
    value_mean = (
        importance_groups * weight_groups
    ).sum(dim=2) / safe_weight_sum

    centered_codes = codes - code_mean[:, :, None]
    centered_values = weight_groups - value_mean[:, :, None]
    denominator = (
        importance_groups * centered_codes.square()
    ).sum(dim=2)
    numerator = (
        importance_groups * centered_codes * centered_values
    ).sum(dim=2)
    proposed_scale = numerator / (denominator + ridge)
    proposed_offset = value_mean - proposed_scale * code_mean

    valid = (
        (weight_sum > 1e-12)
        & (denominator > ridge)
        & torch.isfinite(proposed_scale)
        & torch.isfinite(proposed_offset)
        & (proposed_scale > scale_eps)
    )
    old_reconstruction = (
        scales[:, :, None] * codes + offsets[:, :, None]
    )
    new_reconstruction = (
        proposed_scale[:, :, None] * codes
        + proposed_offset[:, :, None]
    )
    old_loss = (
        importance_groups * (weight_groups - old_reconstruction).square()
    ).sum(dim=2)
    new_loss = (
        importance_groups * (weight_groups - new_reconstruction).square()
    ).sum(dim=2)
    accepted = valid & (new_loss <= old_loss + 1e-12)

    updated_scales = torch.where(accepted, proposed_scale, scales)
    updated_offsets = torch.where(accepted, proposed_offset, offsets)
    return updated_scales, updated_offsets, int(accepted.sum().item())


def _update_affine(
    weight,
    importance,
    lut,
    assignment,
    scales,
    offsets,
    group_size,
    ridge,
    scale_eps,
    chunk_rows=None,
    mask_zero_weights=False,
):
    if importance.dim() == 2:
        return _update_affine_dense(
            weight,
            importance,
            lut,
            assignment,
            scales,
            offsets,
            group_size,
            ridge,
            scale_eps,
        )

    rows = weight.shape[0]
    chunk_rows = max(1, int(chunk_rows or rows))
    updated_scales = scales.clone()
    updated_offsets = offsets.clone()
    accepted_total = 0
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        row_importance = _importance_rows(
            importance,
            weight,
            start,
            stop,
            mask_zero_weights,
        )
        chunk_scales, chunk_offsets, accepted = _update_affine_dense(
            weight[start:stop],
            row_importance,
            lut[start:stop],
            assignment[start:stop],
            scales[start:stop],
            offsets[start:stop],
            group_size,
            ridge,
            scale_eps,
        )
        updated_scales[start:stop] = chunk_scales
        updated_offsets[start:stop] = chunk_offsets
        accepted_total += accepted
    return updated_scales, updated_offsets, accepted_total


def _initialize_weighted_centroids(
    values,
    importance,
    code_count,
    strategy,
):
    if strategy == "linear":
        fractions = torch.linspace(
            0.0,
            1.0,
            code_count,
            device=values.device,
            dtype=values.dtype,
        ).reshape(1, -1)
        minimum = values.amin(dim=1, keepdim=True)
        maximum = values.amax(dim=1, keepdim=True)
        return minimum + (maximum - minimum) * fractions
    if strategy != "weighted_quantile":
        raise ValueError(
            f"Unsupported GPU Lloyd initialization strategy {strategy!r}."
        )

    sorted_values, order = torch.sort(values, dim=1)
    sorted_importance = torch.gather(importance, 1, order)
    cumulative = sorted_importance.cumsum(dim=1).contiguous()
    totals = cumulative[:, -1:].clamp_min(1e-12)
    fractions = (
        torch.arange(
            code_count,
            device=values.device,
            dtype=values.dtype,
        )
        .add_(0.5)
        .div_(code_count)
        .reshape(1, -1)
    )
    targets = (totals * fractions).contiguous()
    indices = torch.searchsorted(cumulative, targets, right=False)
    indices = indices.clamp_max(values.shape[1] - 1)
    return torch.gather(sorted_values, 1, indices)


def _lloyd_assignment(values, centroids):
    return torch.argmin(
        (values[:, :, None] - centroids[:, None, :]).abs(),
        dim=2,
    )


def _lloyd_loss(values, importance, assignment, centroids):
    reconstructed = torch.gather(centroids, 1, assignment.long())
    return (importance * (values - reconstructed).square()).sum()


def gpu_weighted_lloyd(
    normalized_weight,
    importance,
    mask_weight,
    code_count=16,
    max_iter=50,
    tol=1e-4,
    chunk_rows=64,
    initialization="weighted_quantile",
    mask_zero_weights=False,
    loss_increase_rtol=1e-6,
):
    """Run independent weighted one-dimensional Lloyd updates in row batches."""
    if normalized_weight.dim() != 2:
        raise ValueError("GPU Lloyd expects a 2D normalized weight tensor.")
    if code_count < 2:
        raise ValueError("GPU Lloyd requires at least two centroids.")
    if max_iter < 1 or chunk_rows < 1:
        raise ValueError("GPU Lloyd max_iter and chunk_rows must be positive.")

    rows, cols = normalized_weight.shape
    assignment = torch.empty(
        (rows, cols),
        device=normalized_weight.device,
        dtype=torch.long,
    )
    lut = torch.empty(
        (rows, code_count),
        device=normalized_weight.device,
        dtype=normalized_weight.dtype,
    )
    initial_numerator = torch.zeros(
        (), device=normalized_weight.device, dtype=normalized_weight.dtype
    )
    final_numerator = torch.zeros_like(initial_numerator)
    total_importance = torch.zeros_like(initial_numerator)
    chunk_iterations = []
    monotonic = True

    for start in range(0, rows, int(chunk_rows)):
        stop = min(start + int(chunk_rows), rows)
        values = normalized_weight[start:stop]
        row_importance = _importance_rows(
            importance,
            mask_weight,
            start,
            stop,
            mask_zero_weights,
        )
        centroids = _initialize_weighted_centroids(
            values,
            row_importance,
            code_count,
            initialization,
        )
        labels = _lloyd_assignment(values, centroids)
        previous_loss = _lloyd_loss(
            values,
            row_importance,
            labels,
            centroids,
        )
        initial_numerator.add_(previous_loss)
        total_importance.add_(row_importance.sum())
        iterations = 0

        for iteration in range(int(max_iter)):
            numerator = torch.zeros_like(centroids)
            denominator = torch.zeros_like(centroids)
            numerator.scatter_add_(
                1,
                labels,
                row_importance * values,
            )
            denominator.scatter_add_(1, labels, row_importance)
            candidate = torch.where(
                denominator > 1e-12,
                numerator / denominator.clamp_min(1e-12),
                centroids,
            )
            candidate = torch.sort(candidate, dim=1).values
            candidate_labels = _lloyd_assignment(values, candidate)
            candidate_loss = _lloyd_loss(
                values,
                row_importance,
                candidate_labels,
                candidate,
            )
            previous_value = float(previous_loss.item())
            candidate_value = float(candidate_loss.item())
            allowed = max(1e-12, abs(previous_value) * loss_increase_rtol)
            if candidate_value > previous_value + allowed:
                monotonic = False
                break

            relative_improvement = (
                previous_value - candidate_value
            ) / max(abs(previous_value), 1e-12)
            centroids = candidate
            labels = candidate_labels
            previous_loss = candidate_loss
            iterations = iteration + 1
            if relative_improvement <= float(tol):
                break

        lut[start:stop] = centroids
        assignment[start:stop] = labels
        final_numerator.add_(previous_loss)
        chunk_iterations.append(iterations)

    denominator = total_importance.clamp_min(1e-12)
    diagnostics = {
        "code_count": int(code_count),
        "chunk_rows": int(chunk_rows),
        "chunks": int(len(chunk_iterations)),
        "iterations_min": int(min(chunk_iterations, default=0)),
        "iterations_max": int(max(chunk_iterations, default=0)),
        "iterations_mean": float(
            sum(chunk_iterations) / max(len(chunk_iterations), 1)
        ),
        "initial_normalized_loss": float(
            initial_numerator.div(denominator).item()
        ),
        "final_normalized_loss": float(
            final_numerator.div(denominator).item()
        ),
        "loss_monotonic": bool(monotonic),
        "initialization": initialization,
    }
    return assignment, lut, diagnostics


def _initialize_method30(
    scaled_weight,
    scaled_fisher,
    importance,
    group_size,
    initializer,
    importance_mode,
    mask_zero_weights,
    parallelize,
    parallel_jobs,
    lloyd_max_iter,
    lloyd_tol,
    lloyd_chunk_rows,
    lloyd_initialization,
):
    if initializer == "sklearn":
        initialization_options = {}
        if parallelize:
            initialization_options.update({
                "parallel_jobs": parallel_jobs,
                "parallel_backend": "loky",
                "parallel_inner_threads": 1,
                "parallel_pre_dispatch": "2*n_jobs",
            })
        sample_weight = scaled_fisher
        fisher_sample_weight = importance_mode == "dense"
        sample_weight_storage = importance_mode
        if importance_mode == "broadcast" and mask_zero_weights:
            sample_weight = _importance_matrix(scaled_fisher, scaled_weight)
            sample_weight_storage = "dense_zero_mask_fallback"
        assignment, lut, scales_and_zeros = anyq_quantize_tensor(
            scaled_weight,
            n_bit=4,
            q_group_size=group_size,
            per_row=True,
            zero_point=True,
            scale_only=False,
            cluster_row=cluster_row_scikit,
            sample_weight=sample_weight,
            fisher_sample_weight=fisher_sample_weight,
            scale_sample_weight=False,
            parallelize=parallelize,
            **initialization_options,
        )
        scales, offsets = _unpack_group_affine(scales_and_zeros)
        return assignment, lut, scales, offsets, {
            "backend": "sklearn",
            "sample_weight_storage": sample_weight_storage,
            "parallel_jobs": int(parallel_jobs if parallelize else 1),
        }

    if initializer != "gpu_lloyd":
        raise ValueError(f"Unsupported Method30 initializer {initializer!r}.")
    normalized, _, scales_and_zeros = group_q(
        scaled_weight,
        n_bit=4,
        q_group_size=group_size,
        assymetric=True,
        zero_point=True,
    )
    scales, offsets = _unpack_group_affine(scales_and_zeros)
    assignment, lut, lloyd_diagnostics = gpu_weighted_lloyd(
        normalized,
        importance,
        scaled_weight,
        code_count=16,
        max_iter=lloyd_max_iter,
        tol=lloyd_tol,
        chunk_rows=lloyd_chunk_rows,
        initialization=lloyd_initialization,
        mask_zero_weights=mask_zero_weights,
    )
    return assignment, lut, scales, offsets, {
        "backend": "gpu_lloyd",
        "sample_weight_storage": importance_mode,
        "lloyd": lloyd_diagnostics,
    }


@torch.no_grad()
def method30_reconstruct_tensor(
    weight,
    channel_scale,
    fisher,
    group_size=128,
    max_iter=10,
    relative_tol=1e-6,
    ridge=1e-6,
    scale_eps=1e-6,
    chunk_rows=128,
    loss_increase_rtol=1e-7,
    parallelize=True,
    parallel_jobs=16,
    return_state=False,
    importance_mode="broadcast",
    importance_chunk_rows=512,
    initializer="sklearn",
    lloyd_max_iter=50,
    lloyd_tol=1e-4,
    lloyd_chunk_rows=64,
    lloyd_initialization="weighted_quantile",
):
    if weight.dim() != 2:
        raise ValueError(f"Expected a 2D weight, got {tuple(weight.shape)}.")
    rows, cols = weight.shape
    if cols % group_size:
        raise ValueError(
            f"Weight columns {cols} are not divisible by group_size={group_size}."
        )
    if max_iter < 0:
        raise ValueError("max_iter must be non-negative.")
    if chunk_rows < 1:
        raise ValueError("chunk_rows must be positive.")
    if importance_mode not in IMPORTANCE_MODES:
        raise ValueError(
            f"importance_mode must be one of {IMPORTANCE_MODES}, "
            f"got {importance_mode!r}."
        )
    if initializer not in INITIALIZERS:
        raise ValueError(
            f"initializer must be one of {INITIALIZERS}, got {initializer!r}."
        )
    if parallel_jobs < 1:
        raise ValueError("parallel_jobs must be positive.")
    importance_chunk_rows = int(importance_chunk_rows or chunk_rows)
    if importance_chunk_rows < 1:
        raise ValueError("importance_chunk_rows must be positive.")

    original_dtype = weight.dtype
    work = weight.detach().float()
    scale = torch.as_tensor(
        channel_scale,
        device=work.device,
        dtype=torch.float32,
    ).reshape(-1)
    if scale.numel() != cols:
        raise ValueError(
            f"Channel scale length {scale.numel()} does not match columns {cols}."
        )
    if not torch.isfinite(scale).all() or (scale <= 0).any():
        raise ValueError("Channel scales must be finite and strictly positive.")
    if not torch.isfinite(work).all():
        raise ValueError("Weight contains non-finite values.")

    total_started = time.perf_counter()
    scaled_weight = work * scale.reshape(1, -1)
    scaled_fisher = transform_fisher(fisher, scale, normalize=True)
    mask_zero_weights = bool((scaled_weight == 0).any().item())
    importance = (
        _importance_matrix(scaled_fisher, scaled_weight)
        if importance_mode == "dense"
        else scaled_fisher
    )

    initialization_started = time.perf_counter()
    assignment, lut, scales, offsets, initialization_diagnostics = (
        _initialize_method30(
            scaled_weight,
            scaled_fisher,
            importance,
            group_size,
            initializer,
            importance_mode,
            mask_zero_weights,
            parallelize,
            parallel_jobs,
            lloyd_max_iter,
            lloyd_tol,
            lloyd_chunk_rows,
            lloyd_initialization,
        )
    )
    initialization_seconds = time.perf_counter() - initialization_started

    assignment = assignment.to(device=work.device, dtype=torch.long)
    lut = lut.to(device=work.device, dtype=torch.float32)
    scales = scales.to(device=work.device, dtype=torch.float32)
    offsets = offsets.to(device=work.device, dtype=torch.float32)
    lut, assignment = _sort_lut(lut, assignment)

    initial_loss = weighted_loss(
        scaled_weight,
        importance,
        lut,
        assignment,
        scales,
        offsets,
        group_size,
        chunk_rows=importance_chunk_rows,
        mask_zero_weights=mask_zero_weights,
    )
    current_loss = initial_loss
    losses = [float(initial_loss)]
    affine_updates = 0
    rollback = False
    rollback_reason = None
    iterations = 0

    optimization_started = time.perf_counter()
    for iteration in range(int(max_iter)):
        candidate_assignment = _assign_nearest(
            scaled_weight,
            lut,
            scales,
            offsets,
            group_size,
            int(chunk_rows),
        )
        candidate_lut = _update_lut(
            scaled_weight,
            importance,
            lut,
            candidate_assignment,
            scales,
            offsets,
            group_size,
            chunk_rows=importance_chunk_rows,
            mask_zero_weights=mask_zero_weights,
        )
        candidate_lut, candidate_assignment = _sort_lut(
            candidate_lut,
            candidate_assignment,
        )
        (
            candidate_scales,
            candidate_offsets,
            accepted_affine,
        ) = _update_affine(
            scaled_weight,
            importance,
            candidate_lut,
            candidate_assignment,
            scales,
            offsets,
            group_size,
            float(ridge),
            float(scale_eps),
            chunk_rows=importance_chunk_rows,
            mask_zero_weights=mask_zero_weights,
        )
        candidate_assignment = _assign_nearest(
            scaled_weight,
            candidate_lut,
            candidate_scales,
            candidate_offsets,
            group_size,
            int(chunk_rows),
        )
        candidate_loss = weighted_loss(
            scaled_weight,
            importance,
            candidate_lut,
            candidate_assignment,
            candidate_scales,
            candidate_offsets,
            group_size,
            chunk_rows=importance_chunk_rows,
            mask_zero_weights=mask_zero_weights,
        )
        if not math.isfinite(candidate_loss):
            rollback = True
            rollback_reason = "non_finite_loss"
            break
        if candidate_loss > current_loss:
            allowed = max(
                1e-12,
                abs(current_loss) * float(loss_increase_rtol),
            )
            rollback = True
            rollback_reason = (
                "loss_increase"
                if candidate_loss - current_loss > allowed
                else "numerical_loss_increase"
            )
            break

        improvement = current_loss - candidate_loss
        relative_improvement = improvement / max(abs(current_loss), 1e-12)
        lut = candidate_lut
        assignment = candidate_assignment
        scales = candidate_scales
        offsets = candidate_offsets
        current_loss = candidate_loss
        affine_updates += accepted_affine
        iterations = iteration + 1
        losses.append(float(current_loss))
        if relative_improvement < float(relative_tol):
            break

    optimization_seconds = time.perf_counter() - optimization_started
    reconstructed_scaled = _reconstruct(
        scaled_weight.shape,
        lut,
        assignment,
        scales,
        offsets,
        group_size,
    )
    reconstructed = reconstructed_scaled / scale.reshape(1, -1)
    if not torch.isfinite(reconstructed).all():
        raise ValueError("Method30 produced non-finite reconstructed weights.")
    if (scales <= 0).any() or not torch.isfinite(scales).all():
        raise ValueError("Method30 produced invalid affine scales.")

    dense_importance_elements = int(rows * cols)
    stored_importance_elements = _importance_storage_elements(importance)
    diagnostics = {
        "rows": int(rows),
        "cols": int(cols),
        "groups_per_row": int(cols // group_size),
        "lut_entries": int(lut.shape[1]),
        "initializer": initializer,
        "initializer_diagnostics": initialization_diagnostics,
        "importance_mode": importance_mode,
        "importance_chunk_rows": int(importance_chunk_rows),
        "importance_storage_elements": stored_importance_elements,
        "dense_importance_elements": dense_importance_elements,
        "importance_storage_reduction": float(
            1.0 - stored_importance_elements / max(dense_importance_elements, 1)
        ),
        "zero_weight_mask_required": mask_zero_weights,
        "initial_weighted_loss": float(initial_loss),
        "final_weighted_loss": float(current_loss),
        "relative_loss_improvement": float(
            (initial_loss - current_loss) / max(abs(initial_loss), 1e-12)
        ),
        "iterations": int(iterations),
        "losses": losses,
        "loss_monotonic": bool(
            all(
                losses[index + 1] <= losses[index]
                for index in range(len(losses) - 1)
            )
        ),
        "rollback": bool(rollback),
        "rollback_reason": rollback_reason,
        "accepted_affine_updates": int(affine_updates),
        "affine_scale_min": float(scales.min().item()),
        "affine_scale_max": float(scales.max().item()),
        "transformed_fisher_min": float(scaled_fisher.min().item()),
        "transformed_fisher_max": float(scaled_fisher.max().item()),
        "transformed_fisher_mean": float(scaled_fisher.mean().item()),
        "initialization_seconds": float(initialization_seconds),
        "optimization_seconds": float(optimization_seconds),
        "total_seconds": float(time.perf_counter() - total_started),
    }
    if not diagnostics["loss_monotonic"]:
        raise AssertionError("Method30 weighted objective was not monotonic.")

    reconstructed = reconstructed.to(dtype=original_dtype)
    if not return_state:
        return reconstructed, diagnostics
    state = {
        "assignment": assignment,
        "lut": lut,
        "scales": scales,
        "offsets": offsets,
        "scaled_fisher": scaled_fisher,
    }
    return reconstructed, diagnostics, state
