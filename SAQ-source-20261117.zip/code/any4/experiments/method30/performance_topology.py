import os
import subprocess
from collections import defaultdict
from pathlib import Path


MAX_GPUS = 3


def parse_cpu_list(value):
    cpus = []
    for part in str(value).split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, stop = (int(item) for item in part.split("-", 1))
            cpus.extend(range(start, stop + 1))
        else:
            cpus.append(int(part))
    return sorted(set(cpus))


def format_cpu_list(cpus):
    values = sorted(set(int(cpu) for cpu in cpus))
    if not values:
        return ""
    ranges = []
    start = previous = values[0]
    for value in values[1:]:
        if value == previous + 1:
            previous = value
            continue
        ranges.append(str(start) if start == previous else f"{start}-{previous}")
        start = previous = value
    ranges.append(str(start) if start == previous else f"{start}-{previous}")
    return ",".join(ranges)


def _pci_sysfs_name(bus_id):
    fields = bus_id.strip().lower().split(":")
    if len(fields) == 3:
        domain = int(fields[0], 16) & 0xFFFF
        return f"{domain:04x}:{fields[1]}:{fields[2]}"
    raise ValueError(f"Unexpected PCI bus id {bus_id!r}.")


def gpu_rows():
    output = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,pci.bus_id,memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    rows = []
    for line in output.splitlines():
        if not line.strip():
            continue
        index, bus_id, memory_used, utilization = (
            item.strip() for item in line.split(",", 3)
        )
        sysfs_name = _pci_sysfs_name(bus_id)
        numa_path = Path("/sys/bus/pci/devices") / sysfs_name / "numa_node"
        numa_node = int(numa_path.read_text().strip())
        rows.append({
            "index": index,
            "pci_bus_id": bus_id,
            "numa_node": numa_node,
            "memory_used_mib": int(memory_used),
            "utilization_percent": int(utilization),
        })
    return rows


def physical_cores_by_numa():
    output = subprocess.check_output(
        ["lscpu", "-p=CPU,CORE,SOCKET,NODE"],
        text=True,
    )
    first_threads = {}
    for line in output.splitlines():
        if not line or line.startswith("#"):
            continue
        cpu, core, socket, node = (int(item) for item in line.split(","))
        key = (socket, core)
        first_threads[key] = min(cpu, first_threads.get(key, cpu))
    by_node = defaultdict(list)
    for (socket, core), cpu in sorted(first_threads.items()):
        node_path = Path(f"/sys/devices/system/cpu/cpu{cpu}/node0")
        node = None
        for candidate in Path(f"/sys/devices/system/cpu/cpu{cpu}").glob("node[0-9]*"):
            node = int(candidate.name[4:])
            break
        if node is None:
            node = socket
        by_node[node].append(cpu)
    return {int(node): sorted(cpus) for node, cpus in by_node.items()}


def select_empty_gpus(
    limit,
    memory_threshold_mib=256,
    utilization_threshold=5,
    requested=None,
):
    limit = int(limit)
    if not 1 <= limit <= MAX_GPUS:
        raise ValueError(f"GPU limit must be between 1 and {MAX_GPUS}.")
    requested_set = None
    if requested:
        requested_set = {str(value).strip() for value in requested if str(value).strip()}
    inspected = gpu_rows()
    empty = [
        row for row in inspected
        if row["memory_used_mib"] <= memory_threshold_mib
        and row["utilization_percent"] <= utilization_threshold
        and (requested_set is None or row["index"] in requested_set)
    ]
    if requested_set is not None and len(empty) != len(requested_set):
        states = {row["index"]: row for row in inspected}
        unavailable = {
            gpu: states.get(gpu, {"status": "not_reported"})
            for gpu in sorted(requested_set - {row["index"] for row in empty})
        }
        raise RuntimeError(f"Requested GPUs are not empty: {unavailable}")

    by_node = defaultdict(list)
    for row in sorted(empty, key=lambda item: int(item["index"])):
        by_node[row["numa_node"]].append(row)
    selected = []
    while len(selected) < limit and any(by_node.values()):
        for node in sorted(by_node):
            if by_node[node] and len(selected) < limit:
                selected.append(by_node[node].pop(0))
    return selected, inspected


def assert_gpu_empty(
    physical_gpu,
    memory_threshold_mib=256,
    utilization_threshold=5,
):
    target = str(physical_gpu)
    rows = {row["index"]: row for row in gpu_rows()}
    if target not in rows:
        raise RuntimeError(f"GPU {target} was not reported by nvidia-smi.")
    row = rows[target]
    if (
        row["memory_used_mib"] > memory_threshold_mib
        or row["utilization_percent"] > utilization_threshold
    ):
        raise RuntimeError(f"GPU {target} is not empty: {row}")
    return row


def allocate_cpu_sets(gpus, max_workers=32):
    if not gpus:
        raise ValueError("At least one GPU is required for CPU allocation.")
    if len(gpus) > MAX_GPUS:
        raise ValueError(f"At most {MAX_GPUS} GPUs may be allocated.")
    cores = physical_cores_by_numa()
    by_node = defaultdict(list)
    for gpu in gpus:
        by_node[int(gpu["numa_node"])].append(gpu)

    allocations = {}
    for node, node_gpus in sorted(by_node.items()):
        available = list(cores.get(node, []))
        if len(available) < len(node_gpus):
            raise RuntimeError(
                f"NUMA node {node} has {len(available)} physical cores for "
                f"{len(node_gpus)} GPU workers."
            )
        base, remainder = divmod(len(available), len(node_gpus))
        offset = 0
        for position, gpu in enumerate(sorted(node_gpus, key=lambda item: int(item["index"]))):
            share = base + (1 if position < remainder else 0)
            assigned = available[offset:offset + share]
            offset += share
            assigned = assigned[:min(int(max_workers), len(assigned))]
            allocations[gpu["index"]] = {
                "gpu": gpu,
                "cpus": assigned,
                "cpu_list": format_cpu_list(assigned),
                "parallel_jobs": len(assigned),
                "binding": "physical_cores_local_to_gpu_numa_first_touch",
            }
    return allocations


def apply_cpu_affinity(cpus):
    values = {int(cpu) for cpu in cpus}
    if not values:
        raise ValueError("CPU affinity cannot be empty.")
    os.sched_setaffinity(0, values)
    return sorted(os.sched_getaffinity(0))


def affinity_command(command, cpus):
    cpu_list = format_cpu_list(cpus)
    if not cpu_list:
        raise ValueError("CPU affinity cannot be empty.")
    return ["taskset", "-c", cpu_list, *command]
