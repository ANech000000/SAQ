import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


METHOD_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
PYTHON = ROOT / "venv" / "bin" / "python"
RUN_ROOT = METHOD_DIR / "runs" / "performance"
for path in (ROOT, METHOD_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from performance_topology import (
    affinity_command,
    allocate_cpu_sets,
    assert_gpu_empty,
    select_empty_gpus,
)


MICRO_VARIANTS = (
    "baseline_dense_sklearn16",
    "broadcast_sklearn16",
    "broadcast_sklearn32",
    "broadcast_gpu_lloyd",
)
FULL_PROFILES = {
    "baseline": {
        "importance_mode": "dense",
        "initializer": "sklearn",
        "parallel_jobs": 16,
        "cleanup_policy": "per_linear",
    },
    "broadcast_sklearn16_block": {
        "importance_mode": "broadcast",
        "initializer": "sklearn",
        "parallel_jobs": 16,
        "cleanup_policy": "block_or_threshold",
    },
    "broadcast_sklearn32_block": {
        "importance_mode": "broadcast",
        "initializer": "sklearn",
        "parallel_jobs": 32,
        "cleanup_policy": "block_or_threshold",
    },
    "broadcast_gpu_lloyd_block": {
        "importance_mode": "broadcast",
        "initializer": "gpu_lloyd",
        "parallel_jobs": 1,
        "cleanup_policy": "block_or_threshold",
    },
}


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(temporary, path)


def base_environment(physical_gpu):
    environment = os.environ.copy()
    environment.update({
        "CUDA_VISIBLE_DEVICES": str(physical_gpu),
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "TOKENIZERS_PARALLELISM": "false",
    })
    return environment


def select_one_gpu(args):
    requested = [args.physical_gpu] if args.physical_gpu else None
    selected, inspected = select_empty_gpus(
        1,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
        requested=requested,
    )
    if not selected:
        raise RuntimeError(f"No empty GPU is available: {inspected}")
    gpu = selected[0]
    allocation = allocate_cpu_sets([gpu], max_workers=32)[gpu["index"]]
    return gpu, allocation, inspected


def start_and_wait(command, physical_gpu, log_path):
    assert_gpu_empty(physical_gpu)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as handle:
        process = subprocess.Popen(
            command,
            cwd=str(ROOT),
            env=base_environment(physical_gpu),
            stdout=handle,
            stderr=subprocess.STDOUT,
            text=True,
        )
        return process.wait()


def _micro_cpu_count(variant):
    if variant == "broadcast_sklearn32":
        return 32
    return 16


def micro_summary(results):
    payloads = {
        name: json.loads(Path(path).read_text())
        for name, path in results.items()
        if Path(path).exists()
    }
    summary = {"variants": {}, "comparisons": {}}
    for name, payload in payloads.items():
        layers = payload.get("layers", {})
        summary["variants"][name] = {
            "status": payload.get("status"),
            "total_seconds": payload.get("total_seconds"),
            "initialization_seconds": sum(
                item["diagnostics"]["initialization_seconds"]
                for item in layers.values()
            ),
            "peak_reserved_mib": max(
                (item["cuda_memory"]["max_reserved_mib"] for item in layers.values()),
                default=0.0,
            ),
            "hashes": {
                layer: item["reconstruction_sha256"]
                for layer, item in layers.items()
            },
            "final_losses": {
                layer: item["diagnostics"]["final_weighted_loss"]
                for layer, item in layers.items()
            },
        }

    baseline = summary["variants"].get("baseline_dense_sklearn16")
    broadcast16 = summary["variants"].get("broadcast_sklearn16")
    broadcast32 = summary["variants"].get("broadcast_sklearn32")
    gpu_lloyd = summary["variants"].get("broadcast_gpu_lloyd")
    if baseline and broadcast16:
        summary["comparisons"]["broadcast_vs_dense"] = {
            "hashes_equal": baseline["hashes"] == broadcast16["hashes"],
            "initialization_speedup": baseline["initialization_seconds"]
            / max(broadcast16["initialization_seconds"], 1e-12),
            "peak_reserved_reduction_mib": baseline["peak_reserved_mib"]
            - broadcast16["peak_reserved_mib"],
        }
    if broadcast16 and broadcast32:
        summary["comparisons"]["workers_32_vs_16"] = {
            "hashes_equal": broadcast16["hashes"] == broadcast32["hashes"],
            "initialization_speedup": broadcast16["initialization_seconds"]
            / max(broadcast32["initialization_seconds"], 1e-12),
        }
    if broadcast16 and gpu_lloyd:
        summary["comparisons"]["gpu_lloyd_vs_sklearn16"] = {
            "hashes_equal": broadcast16["hashes"] == gpu_lloyd["hashes"],
            "initialization_speedup": broadcast16["initialization_seconds"]
            / max(gpu_lloyd["initialization_seconds"], 1e-12),
            "final_loss_ratio": {
                layer: gpu_lloyd["final_losses"][layer]
                / max(broadcast16["final_losses"][layer], 1e-12)
                for layer in set(broadcast16["final_losses"])
                & set(gpu_lloyd["final_losses"])
            },
        }
    summary["promotion"] = "disabled_pending_full_ppl_validation"
    return summary


def run_micro(args):
    gpu, allocation, inspected = select_one_gpu(args)
    run_dir = Path(args.run_dir) if args.run_dir else (
        RUN_ROOT / time.strftime("micro_%Y%m%d_%H%M%S")
    )
    plan_path = run_dir / "plan.json"
    plan = {
        "task": "microbench",
        "status": "prepared_not_started",
        "physical_gpu": gpu,
        "gpu_scan": inspected,
        "variants": [],
        "safety": {
            "parallel_gpu_processes": 1,
            "kill_existing_processes": False,
            "automatic_promotion": False,
        },
    }
    for variant in MICRO_VARIANTS:
        cpu_count = _micro_cpu_count(variant)
        cpus = allocation["cpus"][:cpu_count]
        output = run_dir / f"{variant}.json"
        log = run_dir / f"{variant}.log"
        command = affinity_command([
            str(PYTHON),
            str(METHOD_DIR / "benchmark_performance.py"),
            "--variant", variant,
            "--physical-gpu", gpu["index"],
            "--cpu-list", ",".join(str(cpu) for cpu in cpus),
            "--output", str(output),
            "--max-iter", str(args.micro_max_iter),
            "--lloyd-max-iter", str(args.lloyd_max_iter),
            "--lloyd-chunk-rows", str(args.lloyd_chunk_rows),
            "--empty-threshold-mib", str(args.empty_threshold_mib),
            "--empty-utilization-percent", str(args.empty_utilization_percent),
        ], cpus)
        plan["variants"].append({
            "name": variant,
            "cpu_list": cpus,
            "command": command,
            "output": str(output),
            "log": str(log),
        })
    atomic_write_json(plan_path, plan)
    if not args.execute:
        print(json.dumps({"status": plan["status"], "plan": str(plan_path)}, indent=2))
        return 0

    plan["status"] = "running"
    atomic_write_json(plan_path, plan)
    outputs = {}
    for item in plan["variants"]:
        assert_gpu_empty(
            gpu["index"],
            args.empty_threshold_mib,
            args.empty_utilization_percent,
        )
        return_code = start_and_wait(
            item["command"],
            gpu["index"],
            Path(item["log"]),
        )
        item["return_code"] = return_code
        item["status"] = "complete" if return_code == 0 else "failed"
        atomic_write_json(plan_path, plan)
        if return_code != 0:
            plan["status"] = "failed"
            atomic_write_json(plan_path, plan)
            return 2
        outputs[item["name"]] = item["output"]

    summary = micro_summary(outputs)
    summary_path = run_dir / "summary.json"
    atomic_write_json(summary_path, summary)
    plan["status"] = "complete"
    plan["summary"] = str(summary_path)
    atomic_write_json(plan_path, plan)
    print(json.dumps(summary, indent=2))
    return 0


def run_full_single(args):
    profile = FULL_PROFILES[args.profile]
    gpu, allocation, inspected = select_one_gpu(args)
    required_cpus = profile["parallel_jobs"] if profile["initializer"] == "sklearn" else 16
    cpus = allocation["cpus"][:required_cpus]
    if profile["parallel_jobs"] > len(cpus):
        raise RuntimeError("Selected CPU affinity cannot satisfy the profile.")
    run_dir = Path(args.run_dir) if args.run_dir else (
        RUN_ROOT / time.strftime(f"full_{args.profile}_%Y%m%d_%H%M%S")
    )
    output = run_dir / "results.json"
    log = run_dir / "run.log"
    command = affinity_command([
        str(PYTHON),
        str(METHOD_DIR / "runner.py"),
        "--physical-gpu", gpu["index"],
        "--parallel-jobs", str(profile["parallel_jobs"]),
        "--importance-mode", profile["importance_mode"],
        "--importance-chunk-rows", str(args.importance_chunk_rows),
        "--initializer", profile["initializer"],
        "--cleanup-policy", profile["cleanup_policy"],
        "--cleanup-threshold-mib", str(args.cleanup_threshold_mib),
        "--lloyd-max-iter", str(args.lloyd_max_iter),
        "--lloyd-chunk-rows", str(args.lloyd_chunk_rows),
        "--output", str(output),
        "--empty-threshold-mib", str(args.empty_threshold_mib),
    ], cpus)
    plan = {
        "task": "full_single",
        "profile": args.profile,
        "status": "prepared_not_started",
        "physical_gpu": gpu,
        "gpu_scan": inspected,
        "cpu_list": cpus,
        "command": command,
        "output": str(output),
        "log": str(log),
        "automatic_promotion": False,
    }
    plan_path = run_dir / "plan.json"
    atomic_write_json(plan_path, plan)
    if not args.execute:
        print(json.dumps({"status": plan["status"], "plan": str(plan_path)}, indent=2))
        return 0
    plan["status"] = "running"
    atomic_write_json(plan_path, plan)
    return_code = start_and_wait(command, gpu["index"], log)
    plan["return_code"] = return_code
    plan["status"] = "complete" if return_code == 0 else "failed"
    atomic_write_json(plan_path, plan)
    return return_code


def run_sharded(args):
    command = [
        str(PYTHON),
        str(METHOD_DIR / "sharded_runner.py"),
        "parent",
        "--max-gpus", str(args.max_gpus),
        "--min-gpus", str(args.min_gpus),
        "--max-workers-per-gpu", str(args.max_workers_per_gpu),
        "--importance-mode", args.sharded_importance_mode,
        "--initializer", args.sharded_initializer,
        "--cleanup-policy", "block_or_threshold",
    ]
    if args.physical_gpus:
        command.extend(["--physical-gpus", args.physical_gpus])
    if args.run_dir:
        command.extend(["--run-dir", args.run_dir])
    if args.execute:
        command.append("--execute")
    return subprocess.call(command, cwd=str(ROOT))


def add_gpu_arguments(parser):
    parser.add_argument("--physical-gpu", default="")
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)
    parser.add_argument("--run-dir")
    parser.add_argument("--execute", action="store_true")


def build_parser():
    parser = argparse.ArgumentParser(description="Method30 staged performance tasks")
    subparsers = parser.add_subparsers(dest="task", required=True)

    micro = subparsers.add_parser("microbench")
    add_gpu_arguments(micro)
    micro.add_argument("--micro-max-iter", type=int, default=2)
    micro.add_argument("--lloyd-max-iter", type=int, default=50)
    micro.add_argument("--lloyd-chunk-rows", type=int, default=64)

    full = subparsers.add_parser("full-single")
    add_gpu_arguments(full)
    full.add_argument("--profile", choices=tuple(FULL_PROFILES), required=True)
    full.add_argument("--importance-chunk-rows", type=int, default=512)
    full.add_argument("--cleanup-threshold-mib", type=float, default=4096)
    full.add_argument("--lloyd-max-iter", type=int, default=50)
    full.add_argument("--lloyd-chunk-rows", type=int, default=64)

    sharded = subparsers.add_parser("sharded")
    sharded.add_argument("--max-gpus", type=int, default=3)
    sharded.add_argument("--min-gpus", type=int, default=2)
    sharded.add_argument("--max-workers-per-gpu", type=int, default=16)
    sharded.add_argument("--physical-gpus", default="")
    sharded.add_argument("--run-dir")
    sharded.add_argument("--execute", action="store_true")
    sharded.add_argument("--sharded-importance-mode", choices=("dense", "broadcast"), default="broadcast")
    sharded.add_argument("--sharded-initializer", choices=("sklearn", "gpu_lloyd"), default="sklearn")
    return parser


def main():
    args = build_parser().parse_args()
    if args.task == "microbench":
        return run_micro(args)
    if args.task == "full-single":
        return run_full_single(args)
    return run_sharded(args)


if __name__ == "__main__":
    raise SystemExit(main())
