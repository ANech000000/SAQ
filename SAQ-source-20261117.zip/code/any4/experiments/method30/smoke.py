import argparse
import gc
import json
import os
import sys
from pathlib import Path

import torch


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD_DIR = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(METHOD_DIR) not in sys.path:
    sys.path.insert(0, str(METHOD_DIR))

from method30_quant import method30_reconstruct_tensor, transform_fisher
from runner import (
    CONFIG,
    build_channel_scale,
    check_single_empty_gpu,
    load_alpha_selection,
    load_fisher,
    load_model_and_tokenizer,
    validate_sources,
)
from layer_timing import load_activations


def assert_fisher_scale_equivalence():
    torch.manual_seed(30)
    weight = torch.randn(5, 32)
    reconstructed = torch.randn(5, 32)
    scale = torch.rand(32) + 0.2
    fisher = torch.rand(32) + 0.1

    scaled_weight = weight * scale.reshape(1, -1)
    scaled_reconstructed = reconstructed * scale.reshape(1, -1)
    scaled_fisher = transform_fisher(
        fisher,
        scale,
        normalize=False,
    )
    original_objective = (
        fisher.reshape(1, -1) * (weight - reconstructed).square()
    ).sum()
    scaled_objective = (
        scaled_fisher.reshape(1, -1)
        * (scaled_weight - scaled_reconstructed).square()
    ).sum()
    assert torch.allclose(
        original_objective,
        scaled_objective,
        rtol=1e-5,
        atol=1e-6,
    )


def run_synthetic_case(device):
    torch.manual_seed(31)
    weight = torch.randn(8, 256, device=device) * 0.25
    weight[:, 7] += torch.linspace(
        -0.8,
        0.8,
        weight.shape[0],
        device=device,
    )
    channel_scale = torch.rand(256) * 1.8 + 0.2
    fisher = torch.rand(256).square() + 0.01
    original = weight.clone()

    reconstructed, diagnostics, state = method30_reconstruct_tensor(
        weight,
        channel_scale,
        fisher,
        group_size=128,
        max_iter=3,
        relative_tol=1e-8,
        chunk_rows=4,
        parallelize=False,
        parallel_jobs=1,
        return_state=True,
    )
    assert torch.equal(weight, original)
    assert reconstructed.shape == weight.shape
    assert torch.isfinite(reconstructed).all()
    assert state["lut"].shape == (weight.shape[0], 16)
    assert torch.isfinite(state["lut"]).all()
    assert (state["scales"] > 0).all()
    assert diagnostics["loss_monotonic"]
    assert (
        diagnostics["final_weighted_loss"]
        <= diagnostics["initial_weighted_loss"] + 1e-12
    )
    return diagnostics


def assert_constant_fisher_scale_invariance(device):
    torch.manual_seed(32)
    weight = torch.randn(4, 256, device=device) * 0.2
    channel_scale = torch.ones(256)
    output_one, _ = method30_reconstruct_tensor(
        weight,
        channel_scale,
        torch.ones(256),
        group_size=128,
        max_iter=2,
        chunk_rows=4,
        parallelize=False,
        parallel_jobs=1,
    )
    output_seven, _ = method30_reconstruct_tensor(
        weight,
        channel_scale,
        torch.full((256,), 7.0),
        group_size=128,
        max_iter=2,
        chunk_rows=4,
        parallelize=False,
        parallel_jobs=1,
    )
    assert torch.allclose(output_one, output_seven, rtol=1e-6, atol=1e-7)


def run_real_linear(args):
    check_single_empty_gpu(
        args.physical_gpu,
        CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    alphas, _ = load_alpha_selection(
        CONFIG["alpha_selection_path"],
        CONFIG["alpha_key"],
    )
    fisher, _ = load_fisher(CONFIG["fisher_path"])
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    linears, searchable, fallback = validate_sources(
        model,
        alphas,
        fisher,
        CONFIG["group_size"],
    )
    assert len(linears) == 112
    assert len(searchable) == 96
    assert len(fallback) == 16

    target_name = "model.layers.0.self_attn.k_proj"
    target = dict(linears)[target_name]
    activations = load_activations(CONFIG["activation_cache"], 0)
    channel_scale, alpha = build_channel_scale(
        target_name,
        target,
        alphas,
        activations,
    )
    weight = target.weight.detach().clone()
    original = weight.clone()
    del model, tokenizer, activations
    gc.collect()

    device = torch.device("cuda:0")
    reconstructed, diagnostics, state = method30_reconstruct_tensor(
        weight.to(device=device, dtype=torch.float32),
        channel_scale,
        fisher[target_name],
        group_size=CONFIG["group_size"],
        max_iter=2,
        relative_tol=1e-8,
        ridge=CONFIG["joint_affine"]["ridge"],
        scale_eps=CONFIG["joint_affine"]["scale_eps"],
        chunk_rows=CONFIG["joint_affine"]["chunk_rows"],
        parallelize=True,
        parallel_jobs=args.parallel_jobs,
        return_state=True,
    )
    assert torch.equal(weight, original)
    assert reconstructed.shape == weight.shape
    assert state["lut"].shape == (weight.shape[0], 16)
    assert torch.isfinite(reconstructed).all()
    assert (state["scales"] > 0).all()
    assert diagnostics["loss_monotonic"]
    torch.cuda.empty_cache()
    return {
        "linear": target_name,
        "weight_shape": list(weight.shape),
        "alpha": float(alpha),
        "initial_weighted_loss": diagnostics["initial_weighted_loss"],
        "final_weighted_loss": diagnostics["final_weighted_loss"],
        "iterations": diagnostics["iterations"],
    }


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument(
        "--parallel-jobs",
        type=int,
        default=CONFIG["parallel_jobs"],
    )
    parser.add_argument("--synthetic-only", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    assert_fisher_scale_equivalence()
    synthetic_device = torch.device("cpu")
    synthetic = run_synthetic_case(synthetic_device)
    assert_constant_fisher_scale_invariance(synthetic_device)

    result = {
        "method_name": CONFIG["method_name"],
        "synthetic": {
            "status": "passed",
            "initial_weighted_loss": synthetic["initial_weighted_loss"],
            "final_weighted_loss": synthetic["final_weighted_loss"],
            "iterations": synthetic["iterations"],
        },
    }
    if not args.synthetic_only:
        visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
        if visible != str(args.physical_gpu):
            raise RuntimeError(
                f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, "
                f"got {visible!r}."
            )
        result["real_linear"] = run_real_linear(args)
        result["real_linear"]["status"] = "passed"
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
