import json
import sys
from pathlib import Path

import torch


METHOD_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
for path in (ROOT, METHOD_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method30_quant import method30_reconstruct_tensor
from performance_topology import allocate_cpu_sets, physical_cores_by_numa


def synthetic_inputs(rows=8, cols=256):
    torch.manual_seed(300)
    weight = torch.randn(rows, cols) * 0.2
    scale = torch.rand(cols) + 0.25
    fisher = torch.rand(cols).square() + 0.01
    return weight, scale, fisher


def assert_broadcast_matches_dense():
    weight, scale, fisher = synthetic_inputs()
    original = weight.clone()
    dense, dense_diagnostics = method30_reconstruct_tensor(
        weight,
        scale,
        fisher,
        max_iter=2,
        parallelize=False,
        parallel_jobs=1,
        importance_mode="dense",
        initializer="sklearn",
    )
    broadcast, broadcast_diagnostics = method30_reconstruct_tensor(
        weight,
        scale,
        fisher,
        max_iter=2,
        parallelize=False,
        parallel_jobs=1,
        importance_mode="broadcast",
        importance_chunk_rows=3,
        initializer="sklearn",
    )
    assert torch.equal(weight, original)
    assert torch.allclose(dense, broadcast, rtol=2e-5, atol=2e-6)
    assert dense_diagnostics["importance_storage_elements"] == weight.numel()
    assert broadcast_diagnostics["importance_storage_elements"] == weight.shape[1]
    assert broadcast_diagnostics["importance_storage_reduction"] > 0.8
    return {
        "max_abs_difference": float((dense - broadcast).abs().max().item()),
        "dense_storage_elements": dense_diagnostics["importance_storage_elements"],
        "broadcast_storage_elements": broadcast_diagnostics["importance_storage_elements"],
    }


def assert_zero_mask_chunking():
    weight, scale, fisher = synthetic_inputs(rows=6)
    weight[0].zero_()
    weight[1, ::17] = 0
    reconstructed, diagnostics = method30_reconstruct_tensor(
        weight,
        scale,
        fisher,
        max_iter=1,
        parallelize=False,
        parallel_jobs=1,
        importance_mode="broadcast",
        importance_chunk_rows=2,
        initializer="sklearn",
    )
    assert diagnostics["zero_weight_mask_required"]
    assert diagnostics["initializer_diagnostics"]["sample_weight_storage"] == "dense_zero_mask_fallback"
    assert torch.isfinite(reconstructed).all()
    return {
        "initializer_sample_weight_storage": diagnostics["initializer_diagnostics"]["sample_weight_storage"],
        "final_loss": diagnostics["final_weighted_loss"],
    }


def assert_gpu_lloyd_candidate():
    weight, scale, fisher = synthetic_inputs(rows=10)
    reconstructed, diagnostics, state = method30_reconstruct_tensor(
        weight,
        scale,
        fisher,
        max_iter=2,
        parallelize=False,
        parallel_jobs=1,
        importance_mode="broadcast",
        importance_chunk_rows=4,
        initializer="gpu_lloyd",
        lloyd_max_iter=20,
        lloyd_tol=1e-5,
        lloyd_chunk_rows=4,
        return_state=True,
    )
    lloyd = diagnostics["initializer_diagnostics"]["lloyd"]
    assert lloyd["loss_monotonic"]
    assert lloyd["final_normalized_loss"] <= lloyd["initial_normalized_loss"] + 1e-7
    assert diagnostics["loss_monotonic"]
    assert state["lut"].shape == (weight.shape[0], 16)
    assert torch.isfinite(reconstructed).all()
    return {
        "lloyd_initial_loss": lloyd["initial_normalized_loss"],
        "lloyd_final_loss": lloyd["final_normalized_loss"],
        "lloyd_iterations_max": lloyd["iterations_max"],
        "joint_final_loss": diagnostics["final_weighted_loss"],
    }


def assert_numa_allocations():
    cores = physical_cores_by_numa()
    fake_gpus = [
        {"index": "0", "numa_node": 0},
        {"index": "1", "numa_node": 0},
        {"index": "4", "numa_node": 1},
    ]
    allocations = allocate_cpu_sets(fake_gpus, max_workers=32)
    all_sets = [set(entry["cpus"]) for entry in allocations.values()]
    for left in range(len(all_sets)):
        for right in range(left + 1, len(all_sets)):
            assert not (all_sets[left] & all_sets[right])
    assert all(len(entry["cpus"]) <= 32 for entry in allocations.values())
    assert all(
        all(cpu in cores[entry["gpu"]["numa_node"]] for cpu in entry["cpus"])
        for entry in allocations.values()
    )
    return {
        gpu: {
            "numa_node": entry["gpu"]["numa_node"],
            "cpu_count": len(entry["cpus"]),
            "cpu_list": entry["cpu_list"],
        }
        for gpu, entry in allocations.items()
    }


def main():
    result = {
        "broadcast": assert_broadcast_matches_dense(),
        "zero_mask": assert_zero_mask_chunking(),
        "gpu_lloyd_cpu": assert_gpu_lloyd_candidate(),
        "numa": assert_numa_allocations(),
        "status": "passed",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
