import argparse
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from joblib import Parallel, delayed
from safetensors import safe_open
from threadpoolctl import threadpool_limits


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method22_quant import GROUP_SIZE, N_CLUSTERS, _fit_kmeans_1d, _nearest_values


CANDIDATES = [(lower, upper) for lower in range(5) for upper in range(5 - lower)]


def check_empty_gpu(physical_gpu: str, threshold_mib: int):
    output = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
        text=True,
    )
    rows = {}
    for line in output.splitlines():
        index, used = [part.strip() for part in line.split(",", 1)]
        rows[index] = int(used)
    if physical_gpu not in rows:
        raise RuntimeError(f"GPU {physical_gpu} was not reported by nvidia-smi")
    if rows[physical_gpu] > threshold_mib:
        raise RuntimeError(
            f"GPU {physical_gpu} is not empty: {rows[physical_gpu]} MiB > {threshold_mib} MiB"
        )
    return rows[physical_gpu]


def fit_row(values: np.ndarray, weights: np.ndarray):
    with threadpool_limits(limits=1):
        centers, labels, _ = _fit_kmeans_1d(values, weights)
    return centers, labels


def fit_rows(values, weights, jobs):
    results = Parallel(
        n_jobs=jobs,
        backend="loky",
        batch_size="auto",
        pre_dispatch="n_jobs//2",
    )(
        delayed(fit_row)(values[row], weights[row])
        for row in range(len(values))
    )
    centers = np.stack([item[0] for item in results]).astype(np.float32)
    labels = [np.asarray(item[1], dtype=np.int64) for item in results]
    return centers, labels


def prefix_range(prefix: torch.Tensor, starts: torch.Tensor, ends: torch.Tensor):
    return prefix[:, ends] - prefix[:, starts]


def score_candidates(sorted_x, sorted_q, sorted_weight, device, chunk_groups):
    lower = torch.tensor([item[0] for item in CANDIDATES], device=device, dtype=torch.long)
    upper = torch.tensor([item[1] for item in CANDIDATES], device=device, dtype=torch.long)
    ends = GROUP_SIZE - upper
    all_errors = []
    started = time.time()
    for start in range(0, sorted_x.shape[0], chunk_groups):
        end = min(start + chunk_groups, sorted_x.shape[0])
        x = sorted_x[start:end].to(device, non_blocking=True)
        q = sorted_q[start:end].to(device, non_blocking=True)
        weight = sorted_weight[start:end].to(device, non_blocking=True)
        a = 1.0 - q
        b = q

        terms = (
            weight * x.square(),
            weight * x * a,
            weight * x * b,
            weight * a.square(),
            weight * a * b,
            weight * b.square(),
        )
        prefixes = [
            torch.cat(
                [torch.zeros(term.shape[0], 1, device=device, dtype=term.dtype), term.cumsum(dim=1)],
                dim=1,
            )
            for term in terms
        ]
        sums = [prefix_range(prefix, lower, ends) for prefix in prefixes]
        l_bound = x[:, lower]
        u_bound = x[:, GROUP_SIZE - 1 - upper]
        error = (
            sums[0]
            - 2.0 * l_bound * sums[1]
            - 2.0 * u_bound * sums[2]
            + l_bound.square() * sums[3]
            + 2.0 * l_bound * u_bound * sums[4]
            + u_bound.square() * sums[5]
        ).clamp_min_(0.0)
        all_errors.append(error.cpu())
    torch.cuda.synchronize(device)
    return torch.cat(all_errors, dim=0), time.time() - started


def select_with_budget(errors: torch.Tensor):
    counts = torch.tensor([sum(item) for item in CANDIDATES], dtype=errors.dtype)
    budget = errors.shape[0]

    def choose(penalty):
        labels = torch.argmin(errors + penalty * counts.view(1, -1), dim=1)
        used = int(counts[labels].sum().item())
        return labels, used

    labels, used = choose(0.0)
    if used <= budget:
        return labels, used, 0.0

    low = 0.0
    high = max(float(errors.abs().amax().item()), 1e-12)
    labels, used = choose(high)
    while used > budget:
        high *= 2.0
        labels, used = choose(high)
    for _ in range(32):
        middle = (low + high) / 2.0
        candidate_labels, candidate_used = choose(middle)
        if candidate_used > budget:
            low = middle
        else:
            high = middle
            labels, used = candidate_labels, candidate_used
    return labels, used, high


def benchmark_weight(weight: torch.Tensor, layer_name: str, jobs: int, device, chunk_groups: int):
    total_started = time.time()
    raw = weight.detach().cpu().float().contiguous()
    rows, cols = raw.shape
    groups_per_row = cols // GROUP_SIZE
    grouped = raw.reshape(rows, groups_per_row, GROUP_SIZE)
    activation = torch.ones(cols, dtype=torch.float32)

    positions = grouped.abs().argmax(dim=2, keepdim=True)
    outlier_mask = torch.zeros_like(grouped, dtype=torch.bool)
    outlier_mask.scatter_(2, positions, True)
    normal_mask = ~outlier_mask
    normal = grouped[normal_mask].reshape(rows, groups_per_row, GROUP_SIZE - 1)
    normal_min = normal.amin(dim=2, keepdim=True)
    normal_max = normal.amax(dim=2, keepdim=True)
    scales = ((normal_max - normal_min).clamp_min(1e-6) / 15.0).contiguous()
    normalized = ((normal - normal_min) / scales).reshape(rows, -1).contiguous()
    activation_grouped = activation.reshape(1, groups_per_row, GROUP_SIZE).expand(rows, -1, -1)
    normal_weight = (
        activation_grouped[normal_mask].reshape(rows, groups_per_row, GROUP_SIZE - 1) * scales
    ).reshape(rows, -1).contiguous()

    initial_fit_started = time.time()
    initial_centers, _ = fit_rows(normalized.numpy(), normal_weight.numpy(), jobs)
    initial_fit_sec = time.time() - initial_fit_started

    assignment_started = time.time()
    normalized_all = ((grouped - normal_min) / scales).reshape(rows, cols).numpy()
    all_q = np.empty((rows, cols), dtype=np.float32)
    for row in range(rows):
        labels, _ = _nearest_values(normalized_all[row], initial_centers[row])
        all_q[row] = initial_centers[row][labels] / 15.0
    assignment_sec = time.time() - assignment_started

    flat_x = grouped.reshape(-1, GROUP_SIZE)
    flat_q = torch.from_numpy(all_q).reshape(-1, GROUP_SIZE)
    sorted_x, order = flat_x.sort(dim=1)
    sorted_q = flat_q.gather(1, order)
    flat_weight = activation_grouped.reshape(-1, GROUP_SIZE)
    sorted_weight = flat_weight.gather(1, order)

    errors, boundary_score_sec = score_candidates(
        sorted_x, sorted_q, sorted_weight, device, chunk_groups
    )
    selection_started = time.time()
    selected, outlier_count, penalty = select_with_budget(errors)
    candidate_lower = torch.tensor([item[0] for item in CANDIDATES], dtype=torch.long)
    candidate_upper = torch.tensor([item[1] for item in CANDIDATES], dtype=torch.long)
    selected_lower = candidate_lower[selected]
    selected_upper = candidate_upper[selected]
    group_index = torch.arange(flat_x.shape[0])
    learned_l = sorted_x[group_index, selected_lower]
    learned_u = sorted_x[group_index, GROUP_SIZE - 1 - selected_upper]
    selection_sec = time.time() - selection_started

    learned_l = learned_l.reshape(rows, groups_per_row, 1)
    learned_u = learned_u.reshape(rows, groups_per_row, 1)
    learned_scale = ((learned_u - learned_l).clamp_min(1e-6) / 15.0).contiguous()
    learned_outlier_mask = (grouped < learned_l) | (grouped > learned_u)

    final_values = []
    final_weights = []
    for row in range(rows):
        row_mask = ~learned_outlier_mask[row]
        row_normalized = ((grouped[row] - learned_l[row]) / learned_scale[row])[row_mask]
        row_scale = learned_scale[row].expand(-1, GROUP_SIZE)[row_mask]
        final_values.append(row_normalized.numpy())
        final_weights.append(row_scale.numpy())

    final_fit_started = time.time()
    fit_rows(final_values, final_weights, jobs)
    final_fit_sec = time.time() - final_fit_started

    outlier_fit_started = time.time()
    learned_outliers = grouped[learned_outlier_mask].numpy()
    if learned_outliers.size >= N_CLUSTERS:
        with threadpool_limits(limits=1):
            _fit_kmeans_1d(learned_outliers, np.ones_like(learned_outliers))
    outlier_fit_sec = time.time() - outlier_fit_started

    original_min = grouped.amin(dim=2)
    original_max = grouped.amax(dim=2)
    original_range = (original_max - original_min).clamp_min(1e-6)
    alpha = ((learned_l.squeeze(2) - original_min) / original_range).clamp(0, 1)
    beta = ((original_max - learned_u.squeeze(2)) / original_range).clamp(0, 1)

    return {
        "layer": layer_name,
        "shape": [rows, cols],
        "group_count": rows * groups_per_row,
        "candidate_count": len(CANDIDATES),
        "outlier_budget": rows * groups_per_row,
        "selected_outliers": int(learned_outlier_mask.sum().item()),
        "lagrange_selected_count": outlier_count,
        "lagrange_penalty": penalty,
        "alpha_mean": float(alpha.mean().item()),
        "beta_mean": float(beta.mean().item()),
        "timing_sec": {
            "initial_kmeans": initial_fit_sec,
            "initial_assignment": assignment_sec,
            "boundary_prefix_score": boundary_score_sec,
            "budget_selection": selection_sec,
            "final_kmeans": final_fit_sec,
            "outlier_kmeans_22b": outlier_fit_sec,
            "total": time.time() - total_started,
        },
    }


def main():
    parser = argparse.ArgumentParser(description="Benchmark one learned-boundary method22 search round")
    parser.add_argument(
        "--model-file",
        default="/data/model/alpindale-Llama-3.2-1B/model.safetensors",
    )
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--empty-threshold-mib", type=int, default=100)
    parser.add_argument("--parallel-jobs", type=int, default=8)
    parser.add_argument("--chunk-groups", type=int, default=4096)
    parser.add_argument(
        "--output",
        default="/data/lsz/any4/experiments/method22/runs/learned_boundary_benchmark.json",
    )
    args = parser.parse_args()

    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}"
        )
    initial_memory = check_empty_gpu(args.physical_gpu, args.empty_threshold_mib)
    device = torch.device("cuda:0")
    layer_keys = [
        "model.layers.0.self_attn.q_proj.weight",
        "model.layers.0.mlp.gate_proj.weight",
    ]
    results = []
    with safe_open(args.model_file, framework="pt", device="cpu") as model_file:
        available = set(model_file.keys())
        missing = [key for key in layer_keys if key not in available]
        if missing:
            raise KeyError(f"Missing model tensors: {missing}")
        for key in layer_keys:
            result = benchmark_weight(
                model_file.get_tensor(key),
                key,
                args.parallel_jobs,
                device,
                args.chunk_groups,
            )
            results.append(result)
            print(json.dumps(result, indent=2))

    q_weight = next(item["shape"][0] * item["shape"][1] for item in results if "q_proj" in item["layer"])
    gate_weight = next(item["shape"][0] * item["shape"][1] for item in results if "gate_proj" in item["layer"])
    q_time = next(item["timing_sec"]["total"] for item in results if "q_proj" in item["layer"])
    gate_time = next(item["timing_sec"]["total"] for item in results if "gate_proj" in item["layer"])
    total_quantized_weights = 973078528
    projection_sec = (q_time + gate_time) * total_quantized_weights / (q_weight + gate_weight)
    payload = {
        "status": "complete",
        "gpu": {
            "physical_index": args.physical_gpu,
            "memory_used_before_start_mib": initial_memory,
        },
        "parallel_jobs": args.parallel_jobs,
        "search_rounds": 1,
        "results": results,
        "rough_full_model_projection_sec": projection_sec,
        "rough_full_model_projection_min": projection_sec / 60.0,
        "projection_note": "Weight-count extrapolation only; full-model calibration and per-layer overhead are excluded.",
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
