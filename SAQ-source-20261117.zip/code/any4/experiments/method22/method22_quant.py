import copy
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from joblib import Parallel, delayed
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits


METHOD_NAME = "method22_group_outlier"
METHOD_VERSION = 2
GROUP_SIZE = 128
N_BIT = 4
N_CLUSTERS = 16

_LAYER_STATS: Dict[str, dict] = {}
_CACHE_STATS = {"hits": 0, "misses": 0, "writes": 0, "invalid": 0}


def clear_method22_stats():
    _LAYER_STATS.clear()
    for key in _CACHE_STATS:
        _CACHE_STATS[key] = 0


def get_method22_stats():
    layers = copy.deepcopy(_LAYER_STATS)
    totals = {
        "weight_count": sum(item["storage"]["weight_count"] for item in layers.values()),
        "theoretical_bits": sum(item["storage"]["theoretical_bits"] for item in layers.values()),
        "reconstructed_fp16_bytes": sum(
            item["storage"]["reconstructed_fp16_bytes"] for item in layers.values()
        ),
    }
    totals["theoretical_bpw"] = (
        totals["theoretical_bits"] / totals["weight_count"] if totals["weight_count"] else 0.0
    )
    return {"layers": layers, "totals": totals, "cache": dict(_CACHE_STATS)}


def _tensor_hash(tensor: torch.Tensor) -> str:
    array = tensor.detach().cpu().contiguous().numpy()
    digest = hashlib.sha256()
    digest.update(str(array.shape).encode("utf-8"))
    digest.update(str(array.dtype).encode("utf-8"))
    digest.update(array.tobytes())
    return digest.hexdigest()


def _safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(value or "unnamed"))


def _cache_path(cache_dir: str, kind: str, layer_name: str, metadata: dict) -> Path:
    encoded = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode("utf-8")
    key = hashlib.sha256(encoded).hexdigest()
    return Path(cache_dir) / kind / f"{_safe_name(layer_name)}-{key}.pt"


def _load_centroids(cache_dir: Optional[str], kind: str, layer_name: str, metadata: dict):
    if not cache_dir:
        return None
    path = _cache_path(cache_dir, kind, layer_name, metadata)
    if not path.exists():
        _CACHE_STATS["misses"] += 1
        return None
    try:
        payload = torch.load(path, map_location="cpu")
    except Exception as exc:
        _CACHE_STATS["invalid"] += 1
        print(f"Ignoring unreadable method22 cache {path}: {exc}")
        return None
    if payload.get("metadata") != metadata or not isinstance(payload.get("centroids"), torch.Tensor):
        _CACHE_STATS["invalid"] += 1
        print(f"Ignoring incompatible method22 cache {path}")
        return None
    _CACHE_STATS["hits"] += 1
    return payload["centroids"].float().contiguous()


def _save_centroids(
    cache_dir: Optional[str], kind: str, layer_name: str, metadata: dict, centroids: torch.Tensor
):
    if not cache_dir:
        return
    path = _cache_path(cache_dir, kind, layer_name, metadata)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("xb") as handle:
            torch.save(
                {"metadata": metadata, "centroids": centroids.detach().cpu().float().contiguous()},
                handle,
            )
        _CACHE_STATS["writes"] += 1
    except FileExistsError:
        # Hash-addressed entries are immutable. Another worker may have populated it.
        pass


def _nearest_values(values: np.ndarray, centroids: np.ndarray, chunk_size: int = 65536):
    flat_values = np.asarray(values, dtype=np.float32).reshape(-1)
    flat_centroids = np.asarray(centroids, dtype=np.float32).reshape(-1)
    labels = np.empty(flat_values.size, dtype=np.int64)
    reconstructed = np.empty(flat_values.size, dtype=np.float32)
    for start in range(0, flat_values.size, chunk_size):
        end = min(start + chunk_size, flat_values.size)
        distances = np.abs(flat_values[start:end, None] - flat_centroids[None, :])
        labels[start:end] = np.argmin(distances, axis=1)
        reconstructed[start:end] = flat_centroids[labels[start:end]]
    return labels, reconstructed


def _fit_kmeans_1d(values: np.ndarray, weights: np.ndarray, n_clusters: int = N_CLUSTERS):
    values = np.asarray(values, dtype=np.float32).reshape(-1)
    weights = np.asarray(weights, dtype=np.float64).reshape(-1)
    if values.size == 0:
        raise ValueError("Cannot cluster an empty method22 value array.")
    if values.shape != weights.shape:
        raise ValueError(f"values shape {values.shape} does not match weights shape {weights.shape}")
    weights = np.abs(weights)
    if not np.isfinite(weights).all() or weights.sum() <= 0:
        weights = np.ones_like(weights)

    unique = np.unique(values)
    if unique.size <= n_clusters:
        centroids = np.empty(n_clusters, dtype=np.float32)
        centroids[: unique.size] = unique
        centroids[unique.size :] = unique[-1]
        labels, reconstructed = _nearest_values(values, centroids)
        return centroids, labels, reconstructed

    estimator = KMeans(
        n_clusters=n_clusters,
        init="k-means++",
        n_init="auto",
        max_iter=300,
        tol=1e-4,
        random_state=0,
    )
    estimator.fit(values.reshape(-1, 1), sample_weight=weights)
    centroids = estimator.cluster_centers_.reshape(n_clusters)
    labels = estimator.labels_.reshape(-1)
    reconstructed = centroids[labels]
    return (
        np.asarray(centroids, dtype=np.float32).reshape(n_clusters),
        np.asarray(labels, dtype=np.int64).reshape(-1),
        np.asarray(reconstructed, dtype=np.float32).reshape(-1),
    )


def _fit_normal_row(values: np.ndarray, weights: np.ndarray):
    with threadpool_limits(limits=1):
        return _fit_kmeans_1d(values, weights)


def _select_outlier_positions(grouped: torch.Tensor):
    if grouped.dim() != 3 or grouped.shape[-1] != GROUP_SIZE:
        raise ValueError(
            f"Expected grouped weights shaped [rows, groups, {GROUP_SIZE}], got {tuple(grouped.shape)}"
        )
    return grouped.abs().argmax(dim=2, keepdim=True)


def _assign_normal_rows(normalized: torch.Tensor, centroids: torch.Tensor):
    rows = normalized.shape[0]
    reconstructed = torch.empty_like(normalized)
    assignments = torch.empty(normalized.shape, dtype=torch.int64)
    normalized_np = normalized.numpy()
    centroids_np = centroids.numpy()
    for row in range(rows):
        labels, row_values = _nearest_values(normalized_np[row], centroids_np[row])
        assignments[row] = torch.from_numpy(labels)
        reconstructed[row] = torch.from_numpy(row_values)
    return assignments, reconstructed


def _storage_stats(rows: int, cols: int, variant: str):
    groups_per_row = cols // GROUP_SIZE
    group_count = rows * groups_per_row
    position_bits = math.ceil(math.log2(GROUP_SIZE))
    components = {
        "normal_assignments": group_count * (GROUP_SIZE - 1) * N_BIT,
        "outlier_positions": group_count * position_bits,
        "scales_and_zeros": group_count * 2 * 16,
        "normal_lut": rows * N_CLUSTERS * 16,
    }
    if variant == "exact":
        components["outlier_payload"] = group_count * 16
        components["outlier_lut"] = 0
    else:
        components["outlier_payload"] = group_count * N_BIT
        components["outlier_lut"] = N_CLUSTERS * 16
    theoretical_bits = sum(components.values())
    weight_count = rows * cols
    return {
        "weight_count": weight_count,
        "group_count": group_count,
        "position_bits_per_group": position_bits,
        "components_bits": components,
        "theoretical_bits": theoretical_bits,
        "theoretical_bytes": theoretical_bits / 8.0,
        "theoretical_bpw": theoretical_bits / weight_count,
        "reconstructed_fp16_bytes": weight_count * 2,
    }


def _prepare_activation_weight(sample_weight, layer_name: str, cols: int):
    if isinstance(sample_weight, dict):
        if layer_name not in sample_weight:
            raise KeyError(f"Missing calibration weights for method22 layer {layer_name}")
        sample_weight = sample_weight[layer_name]
    if sample_weight is None:
        return torch.ones(cols, dtype=torch.float32)
    if not isinstance(sample_weight, torch.Tensor):
        sample_weight = torch.as_tensor(sample_weight)
    sample_weight = sample_weight.detach().cpu().float().abs().reshape(-1)
    if sample_weight.numel() != cols:
        raise ValueError(
            f"Calibration weight length {sample_weight.numel()} does not match input columns {cols} "
            f"for layer {layer_name}"
        )
    if not torch.isfinite(sample_weight).all() or sample_weight.sum() <= 0:
        return torch.ones(cols, dtype=torch.float32)
    return sample_weight.contiguous()


def reconstruct_method22_weight(
    weight: torch.Tensor,
    sample_weight=None,
    variant: str = "exact",
    layer_name: str = "",
    model_path: Optional[str] = None,
    group_size: int = GROUP_SIZE,
    cache_dir: Optional[str] = None,
    use_cache: bool = True,
    parallel_jobs: Optional[int] = None,
) -> Tuple[torch.Tensor, dict]:
    if variant not in ("exact", "clustered"):
        raise ValueError(f"Unsupported method22 variant {variant}")
    if group_size != GROUP_SIZE:
        raise ValueError(f"method22 currently requires group_size={GROUP_SIZE}, got {group_size}")
    if weight.dim() != 2:
        raise ValueError(f"method22 expects a 2D Linear weight, got shape {tuple(weight.shape)}")

    rows, cols = weight.shape
    if cols % group_size:
        raise ValueError(f"Input columns {cols} must be divisible by group_size={group_size}")
    groups_per_row = cols // group_size
    original_device = weight.device
    original_dtype = weight.dtype
    raw = weight.detach().cpu().float().contiguous()
    grouped = raw.reshape(rows, groups_per_row, group_size)
    activation = _prepare_activation_weight(sample_weight, layer_name, cols)

    outlier_positions = _select_outlier_positions(grouped)
    outlier_mask = torch.zeros_like(grouped, dtype=torch.bool)
    outlier_mask.scatter_(2, outlier_positions, True)
    normal_mask = ~outlier_mask
    outlier_values = grouped.gather(2, outlier_positions).squeeze(2).contiguous()

    normal_raw = grouped[normal_mask].reshape(rows, groups_per_row, group_size - 1)
    normal_min = normal_raw.amin(dim=2, keepdim=True)
    normal_max = normal_raw.amax(dim=2, keepdim=True)
    scales = ((normal_max - normal_min).clamp(min=1e-6) / ((2**N_BIT) - 1)).contiguous()
    normalized = ((normal_raw - normal_min) / scales).reshape(rows, -1).contiguous()

    activation_grouped = activation.reshape(1, groups_per_row, group_size).expand(rows, -1, -1)
    normal_activation = activation_grouped[normal_mask].reshape(rows, groups_per_row, group_size - 1)
    normal_cluster_weight = (normal_activation * scales).reshape(rows, -1).contiguous()

    common_metadata = {
        "method": METHOD_NAME,
        "version": METHOD_VERSION,
        "kind": "normal",
        "model_path": str(model_path) if model_path is not None else None,
        "layer_name": layer_name,
        "weight_shape": [rows, cols],
        "weight_hash": _tensor_hash(raw),
        "activation_hash": _tensor_hash(activation),
        "group_size": group_size,
        "n_bit": N_BIT,
        "n_clusters": N_CLUSTERS,
        "outlier_rule": "max_abs_first_tie",
        "backend": "scikit_kmeans",
        "scale_sample_weight": True,
        "random_state": 0,
        "n_init": "auto",
        "max_iter": 300,
        "tol": 1e-4,
    }
    active_cache_dir = cache_dir if use_cache else None
    normal_centroids = _load_centroids(active_cache_dir, "normal", layer_name, common_metadata)
    normal_cache_hit = normal_centroids is not None
    if normal_centroids is not None:
        if tuple(normal_centroids.shape) != (rows, N_CLUSTERS):
            raise ValueError(
                f"Cached normal centroids have shape {tuple(normal_centroids.shape)}, "
                f"expected {(rows, N_CLUSTERS)}"
            )
        normal_assignments, normal_reconstructed = _assign_normal_rows(normalized, normal_centroids)
    else:
        jobs = parallel_jobs or min(8, os.cpu_count() or 1)
        jobs = max(1, int(jobs))
        results = Parallel(
            n_jobs=jobs,
            backend="loky",
            batch_size="auto",
            pre_dispatch="n_jobs//2",
        )(
            delayed(_fit_normal_row)(normalized[row].numpy(), normal_cluster_weight[row].numpy())
            for row in range(rows)
        )
        normal_centroids = torch.from_numpy(np.stack([item[0] for item in results])).float()
        normal_assignments = torch.from_numpy(np.stack([item[1] for item in results])).long()
        normal_reconstructed = torch.from_numpy(np.stack([item[2] for item in results])).float()
        _save_centroids(active_cache_dir, "normal", layer_name, common_metadata, normal_centroids)

    normal_reconstructed = normal_reconstructed.reshape(rows, groups_per_row, group_size - 1)
    normal_dequantized = normal_reconstructed * scales + normal_min
    reconstructed_grouped = torch.empty_like(grouped)
    reconstructed_grouped[normal_mask] = normal_dequantized.reshape(-1)

    outlier_centroids = None
    outlier_assignments = None
    outlier_cache_hit = False
    if variant == "exact":
        reconstructed_outliers = outlier_values
    else:
        outlier_columns = (
            torch.arange(groups_per_row, dtype=torch.int64).view(1, -1) * group_size
            + outlier_positions.squeeze(2)
        )
        outlier_cluster_weight = activation[outlier_columns].reshape(-1).contiguous()
        outlier_metadata = dict(common_metadata)
        outlier_metadata.update(
            {
                "kind": "outlier",
                "domain": "raw_fp16_weight",
                "activation_hash": _tensor_hash(outlier_cluster_weight),
                "scale_sample_weight": False,
            }
        )
        outlier_centroids = _load_centroids(active_cache_dir, "outlier", layer_name, outlier_metadata)
        outlier_cache_hit = outlier_centroids is not None
        if outlier_centroids is None:
            with threadpool_limits(limits=1):
                centers, labels, values = _fit_kmeans_1d(
                    outlier_values.numpy().reshape(-1), outlier_cluster_weight.numpy()
                )
            outlier_centroids = torch.from_numpy(centers).float()
            outlier_assignments = torch.from_numpy(labels).long().reshape(rows, groups_per_row)
            reconstructed_outliers = torch.from_numpy(values).float().reshape(rows, groups_per_row)
            _save_centroids(active_cache_dir, "outlier", layer_name, outlier_metadata, outlier_centroids)
        else:
            if tuple(outlier_centroids.shape) != (N_CLUSTERS,):
                raise ValueError(
                    f"Cached outlier centroids have shape {tuple(outlier_centroids.shape)}, "
                    f"expected {(N_CLUSTERS,)}"
                )
            labels, values = _nearest_values(outlier_values.numpy(), outlier_centroids.numpy())
            outlier_assignments = torch.from_numpy(labels).long().reshape(rows, groups_per_row)
            reconstructed_outliers = torch.from_numpy(values).float().reshape(rows, groups_per_row)

    reconstructed_grouped.scatter_(2, outlier_positions, reconstructed_outliers.unsqueeze(2))
    reconstructed = reconstructed_grouped.reshape(rows, cols).to(original_device, original_dtype)

    stats = {
        "variant": variant,
        "layer_name": layer_name,
        "weight_shape": [rows, cols],
        "group_size": group_size,
        "outlier_count": rows * groups_per_row,
        "normal_centroids_shape": list(normal_centroids.shape),
        "outlier_centroids_shape": list(outlier_centroids.shape) if outlier_centroids is not None else None,
        "normal_assignment_min": int(normal_assignments.min().item()),
        "normal_assignment_max": int(normal_assignments.max().item()),
        "outlier_assignment_min": int(outlier_assignments.min().item()) if outlier_assignments is not None else None,
        "outlier_assignment_max": int(outlier_assignments.max().item()) if outlier_assignments is not None else None,
        "normal_cache_hit": normal_cache_hit,
        "outlier_cache_hit": outlier_cache_hit,
        "storage": _storage_stats(rows, cols, variant),
    }
    return reconstructed, stats


def method22_layer(
    module: torch.nn.Module,
    name: str = "",
    variant: str = "exact",
    group_size: int = GROUP_SIZE,
    sample_weight=None,
    model_path: Optional[str] = None,
    cache_dir: Optional[str] = None,
    use_cache: bool = True,
    parallel_jobs: Optional[int] = None,
    pseudo: bool = True,
    **kwargs,
):
    if not isinstance(module, torch.nn.Linear):
        raise TypeError(f"method22_layer expects torch.nn.Linear, got {type(module)}")
    if not pseudo:
        raise ValueError("method22 currently supports pseudo quantization only")
    reconstructed, stats = reconstruct_method22_weight(
        module.weight,
        sample_weight=sample_weight,
        variant=variant,
        layer_name=name,
        model_path=model_path,
        group_size=group_size,
        cache_dir=cache_dir,
        use_cache=use_cache,
        parallel_jobs=parallel_jobs,
    )
    module.weight.data = reconstructed.to(module.weight.device, module.weight.dtype)
    _LAYER_STATS[name] = stats
    return module
