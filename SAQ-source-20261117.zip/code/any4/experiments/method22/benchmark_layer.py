import argparse
import json
import sys
import time
from pathlib import Path

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method22_quant import reconstruct_method22_weight


def main():
    parser = argparse.ArgumentParser(description="Benchmark one synthetic method22 Linear weight")
    parser.add_argument("--rows", type=int, default=2048)
    parser.add_argument("--cols", type=int, default=2048)
    parser.add_argument("--parallel-jobs", type=int, default=8)
    args = parser.parse_args()

    if args.cols % 128:
        raise SystemExit("--cols must be divisible by 128")
    torch.manual_seed(0)
    weight = torch.randn(args.rows, args.cols, dtype=torch.float16)
    activation = torch.ones(args.cols, dtype=torch.float32)
    started = time.time()
    _, stats = reconstruct_method22_weight(
        weight,
        sample_weight=activation,
        variant="exact",
        layer_name="benchmark.q_proj",
        use_cache=False,
        parallel_jobs=args.parallel_jobs,
    )
    print(
        json.dumps(
            {
                "shape": [args.rows, args.cols],
                "parallel_jobs": args.parallel_jobs,
                "elapsed_sec": time.time() - started,
                "normal_centroids_shape": stats["normal_centroids_shape"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
