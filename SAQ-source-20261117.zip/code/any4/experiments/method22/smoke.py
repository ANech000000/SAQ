import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch


ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
EXP_DIR = Path(__file__).resolve().parent
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import method22_quant as method22


def make_weight():
    weight = torch.linspace(-1.0, 1.0, steps=2 * 256, dtype=torch.float32).reshape(2, 256)
    weight[0, 3] = 20.0
    weight[0, 140] = -18.0
    weight[1, 9] = -17.0
    weight[1, 200] = 19.0
    return weight


def expected_outlier_mask(weight):
    grouped = weight.reshape(weight.shape[0], -1, method22.GROUP_SIZE)
    positions = method22._select_outlier_positions(grouped)
    mask = torch.zeros_like(grouped, dtype=torch.bool)
    mask.scatter_(2, positions, True)
    return positions, mask.reshape_as(weight)


def assert_selection_and_tie_rule():
    grouped = torch.zeros(1, 1, method22.GROUP_SIZE)
    grouped[0, 0, 3] = 9.0
    grouped[0, 0, 7] = -9.0
    positions = method22._select_outlier_positions(grouped)
    assert positions.item() == 3


def assert_exact_and_outlier_isolation():
    weight = make_weight()
    activation = torch.linspace(0.5, 2.0, steps=weight.shape[1])
    reconstructed1, stats1 = method22.reconstruct_method22_weight(
        weight,
        sample_weight=activation,
        variant="exact",
        layer_name="test.exact",
        use_cache=False,
        parallel_jobs=1,
    )
    _, outlier_mask = expected_outlier_mask(weight)
    assert torch.equal(reconstructed1[outlier_mask], weight[outlier_mask])
    assert stats1["outlier_centroids_shape"] is None
    assert stats1["normal_assignment_min"] >= 0
    assert stats1["normal_assignment_max"] <= 15

    changed = weight.clone()
    changed[outlier_mask] *= 10
    reconstructed2, _ = method22.reconstruct_method22_weight(
        changed,
        sample_weight=activation,
        variant="exact",
        layer_name="test.exact.changed",
        use_cache=False,
        parallel_jobs=1,
    )
    assert torch.equal(reconstructed2[outlier_mask], changed[outlier_mask])
    assert torch.allclose(reconstructed1[~outlier_mask], reconstructed2[~outlier_mask], atol=0, rtol=0)


def assert_clustered_outlier_weight_mapping():
    weight = make_weight()
    activation = torch.arange(1, weight.shape[1] + 1, dtype=torch.float32)
    calls = []
    original = method22._fit_kmeans_1d

    def recording_fit(values, weights, n_clusters=method22.N_CLUSTERS):
        calls.append((np.asarray(values).reshape(-1).copy(), np.asarray(weights).reshape(-1).copy()))
        return original(values, weights, n_clusters=n_clusters)

    method22._fit_kmeans_1d = recording_fit
    try:
        _, stats = method22.reconstruct_method22_weight(
            weight,
            sample_weight=activation,
            variant="clustered",
            layer_name="test.clustered.weights",
            use_cache=False,
            parallel_jobs=1,
        )
    finally:
        method22._fit_kmeans_1d = original

    outlier_calls = [call for call in calls if call[0].size == 4]
    assert len(outlier_calls) == 1
    positions, _ = expected_outlier_mask(weight)
    group_offsets = torch.arange(2).view(1, -1) * method22.GROUP_SIZE
    expected_columns = (group_offsets + positions.squeeze(2)).reshape(-1)
    expected_weights = activation[expected_columns].numpy()
    assert np.array_equal(outlier_calls[0][1], expected_weights)
    assert stats["outlier_centroids_shape"] == [16]
    assert 0 <= stats["outlier_assignment_min"] <= stats["outlier_assignment_max"] <= 15


def assert_constant_groups_and_nearest_assignment():
    weight = torch.full((2, 256), 3.0, dtype=torch.float16)
    reconstructed, stats = method22.reconstruct_method22_weight(
        weight,
        sample_weight=torch.ones(256),
        variant="clustered",
        layer_name="test.constant",
        use_cache=False,
        parallel_jobs=1,
    )
    assert reconstructed.dtype == weight.dtype
    assert torch.equal(reconstructed, weight)
    assert not torch.isnan(reconstructed).any()
    assert stats["normal_centroids_shape"] == [2, 16]

    labels, values = method22._nearest_values(
        np.array([-1.0, 0.2, 4.0], dtype=np.float32),
        np.array([-2.0, 0.0, 5.0], dtype=np.float32),
    )
    assert np.array_equal(labels, np.array([0, 1, 2]))
    assert np.array_equal(values, np.array([-2.0, 0.0, 5.0], dtype=np.float32))


def assert_cache_roundtrip():
    weight = make_weight()
    activation = torch.linspace(1.0, 2.0, steps=weight.shape[1])
    with tempfile.TemporaryDirectory() as tmpdir:
        method22.clear_method22_stats()
        first, first_stats = method22.reconstruct_method22_weight(
            weight,
            sample_weight=activation,
            variant="clustered",
            layer_name="test.cache",
            model_path="/tmp/model",
            cache_dir=tmpdir,
            use_cache=True,
            parallel_jobs=1,
        )
        assert first_stats["normal_cache_hit"] is False
        assert first_stats["outlier_cache_hit"] is False
        assert len(list(Path(tmpdir).rglob("*.pt"))) == 2

        original = method22._fit_kmeans_1d

        def fail_fit(*args, **kwargs):
            raise AssertionError("KMeans was called despite a complete centroid cache hit")

        method22._fit_kmeans_1d = fail_fit
        try:
            second, second_stats = method22.reconstruct_method22_weight(
                weight,
                sample_weight=activation,
                variant="clustered",
                layer_name="test.cache",
                model_path="/tmp/model",
                cache_dir=tmpdir,
                use_cache=True,
                parallel_jobs=1,
            )
        finally:
            method22._fit_kmeans_1d = original
        assert second_stats["normal_cache_hit"] is True
        assert second_stats["outlier_cache_hit"] is True
        assert torch.equal(first, second)
        cache_stats = method22.get_method22_stats()["cache"]
        assert cache_stats["hits"] == 2
        assert cache_stats["writes"] == 2


def assert_storage_accounting():
    exact = method22._storage_stats(2, 256, "exact")
    clustered = method22._storage_stats(2, 256, "clustered")
    assert exact["group_count"] == 4
    assert exact["position_bits_per_group"] == 7
    expected_exact_bits = 4 * 127 * 4 + 4 * 7 + 4 * 32 + 2 * 16 * 16 + 4 * 16
    expected_clustered_bits = 4 * 127 * 4 + 4 * 7 + 4 * 32 + 2 * 16 * 16 + 4 * 4 + 16 * 16
    assert exact["theoretical_bits"] == expected_exact_bits
    assert clustered["theoretical_bits"] == expected_clustered_bits


def assert_linear_forward():
    torch.manual_seed(0)
    linear = torch.nn.Linear(256, 4, bias=True, dtype=torch.float32)
    activation = torch.linspace(0.5, 1.5, steps=256)
    quantized = method22.method22_layer(
        linear,
        name="test.linear",
        variant="exact",
        group_size=128,
        sample_weight={"test.linear": activation},
        use_cache=False,
        parallel_jobs=1,
        pseudo=True,
    )
    output = quantized(torch.randn(3, 256))
    assert output.shape == (3, 4)
    assert torch.isfinite(output).all()


def main():
    assert_selection_and_tie_rule()
    assert_exact_and_outlier_isolation()
    assert_clustered_outlier_weight_mapping()
    assert_constant_groups_and_nearest_assignment()
    assert_cache_roundtrip()
    assert_storage_accounting()
    assert_linear_forward()
    print(json.dumps({"method": method22.METHOD_NAME, "smoke": "passed"}, indent=2))


if __name__ == "__main__":
    main()
