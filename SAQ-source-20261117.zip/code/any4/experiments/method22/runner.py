import argparse
import gc
import json
import os
import subprocess
import sys
import time
from pathlib import Path


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
DEFAULT_CACHE_DIR = "/data/lsz/any4/experiments/method22/cache"
DEFAULT_MODEL_PATH = "/data/model/alpindale-Llama-3.2-1B"
DEFAULT_OUTPUT = EXP_DIR / "runs" / "wiki2_ppl" / "results.json"
BASELINES = {
    "fp16_ppl": 9.750678062438965,
    "original_any4_4bit_ppl": 10.618475914001465,
}
VARIANT_NAMES = {
    "exact": "method22a_exact_outlier",
    "clustered": "method22b_clustered_outlier",
}


def _gpu_memory_rows():
    try:
        output = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=index,memory.used",
                "--format=csv,noheader,nounits",
            ],
            text=True,
            stderr=subprocess.STDOUT,
        )
    except Exception as exc:
        raise RuntimeError(f"Unable to inspect GPUs with nvidia-smi: {exc}") from exc
    rows = []
    for line in output.splitlines():
        if not line.strip():
            continue
        index, used = [part.strip() for part in line.split(",", 1)]
        rows.append({"index": index, "memory_used_mib": int(used)})
    return rows


def _visible_gpu_filter():
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if not visible:
        return None
    values = [value.strip() for value in visible.split(",") if value.strip()]
    return set(values) if all(value.isdigit() for value in values) else None


def find_empty_gpus(threshold_mib: int, limit: int):
    allowed = _visible_gpu_filter()
    rows = _gpu_memory_rows()
    empty = [
        row for row in rows
        if row["memory_used_mib"] <= threshold_mib
        and (allowed is None or row["index"] in allowed)
    ]
    return empty[:limit], rows


def assert_gpu_empty(physical_gpu: str, threshold_mib: int):
    rows = {row["index"]: row["memory_used_mib"] for row in _gpu_memory_rows()}
    if physical_gpu not in rows:
        raise RuntimeError(f"GPU {physical_gpu} was not reported by nvidia-smi")
    used = rows[physical_gpu]
    if used > threshold_mib:
        raise RuntimeError(
            f"GPU {physical_gpu} is no longer empty: {used} MiB used exceeds {threshold_mib} MiB"
        )
    return used


def _write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def run_worker(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Worker must see exactly physical GPU {args.physical_gpu}; CUDA_VISIBLE_DEVICES={visible!r}"
        )
    initial_memory = assert_gpu_empty(str(args.physical_gpu), args.empty_threshold_mib)

    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    if str(EXP_DIR) not in sys.path:
        sys.path.insert(0, str(EXP_DIR))

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    from calibrate import calibrate
    from data_gptq import get_loaders, llama_eval
    from method22_quant import clear_method22_stats, get_method22_stats, method22_layer
    from quantize import quantize_model

    started = time.time()
    clear_method22_stats()
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
    ).to("cuda")
    model.eval()

    quant_started = time.time()
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=method22_layer,
        skip_modules="lm_head",
        tokenizer=tokenizer,
        sample_weight=calibrate,
        variant=args.worker_variant,
        group_size=128,
        model_path=args.model_path,
        cache_dir=args.cache_dir,
        use_cache=not args.no_cache,
        parallel_jobs=args.parallel_jobs,
        pseudo=True,
    )
    quantization_sec = time.time() - quant_started
    model.eval()

    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=args.seqlen,
        nsamples=args.loader_samples,
    )
    eval_started = time.time()
    ppl = float(llama_eval(model, testloader, "cuda", seqlen=args.seqlen))
    evaluation_sec = time.time() - eval_started
    method_stats = get_method22_stats()

    result = {
        "method": VARIANT_NAMES[args.worker_variant],
        "variant": args.worker_variant,
        "status": "complete",
        "ppl": ppl,
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "gpu": {
            "physical_index": str(args.physical_gpu),
            "cuda_visible_devices": visible,
            "memory_used_before_load_mib": initial_memory,
            "empty_threshold_mib": args.empty_threshold_mib,
        },
        "quantization": {
            "n_bit": 4,
            "group_size": 128,
            "normal_clusters": 16,
            "outlier_rule": "max_abs_first_tie",
            "normal_backend": "scikit_kmeans",
            "outlier_clusters": 16 if args.worker_variant == "clustered" else None,
            "outlier_weighting": "absolute_mean_activation" if args.worker_variant == "clustered" else None,
            "pseudo": True,
            "skip_modules": "lm_head",
        },
        "timing_sec": {
            "quantization": quantization_sec,
            "evaluation": evaluation_sec,
            "total": time.time() - started,
        },
        "method22_stats": method_stats,
        "baselines": BASELINES,
    }
    _write_json(Path(args.worker_output), result)
    print(json.dumps({"method": result["method"], "ppl": ppl}, indent=2))

    del model, tokenizer, testloader
    torch.cuda.empty_cache()
    gc.collect()
    return 0


def _worker_command(args, variant: str, physical_gpu: str, worker_output: Path):
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--worker",
        "--worker-variant",
        variant,
        "--physical-gpu",
        str(physical_gpu),
        "--worker-output",
        str(worker_output),
        "--model-path",
        args.model_path,
        "--cache-dir",
        args.cache_dir,
        "--seqlen",
        str(args.seqlen),
        "--loader-samples",
        str(args.loader_samples),
        "--parallel-jobs",
        str(args.parallel_jobs),
        "--empty-threshold-mib",
        str(args.empty_threshold_mib),
    ]
    if args.no_cache:
        command.append("--no-cache")
    return command


def _start_worker(args, variant: str, gpu: dict, run_dir: Path):
    worker_output = run_dir / f"{VARIANT_NAMES[variant]}.json"
    log_path = run_dir / f"{VARIANT_NAMES[variant]}.log"
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu["index"])
    env["OMP_NUM_THREADS"] = "1"
    env["MKL_NUM_THREADS"] = "1"
    env["OPENBLAS_NUM_THREADS"] = "1"
    env["NUMEXPR_NUM_THREADS"] = "1"
    log_handle = log_path.open("a", encoding="utf-8")
    command = _worker_command(args, variant, gpu["index"], worker_output)
    process = subprocess.Popen(
        command,
        cwd=str(ROOT),
        env=env,
        stdout=log_handle,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return {
        "variant": variant,
        "gpu": gpu,
        "process": process,
        "log_handle": log_handle,
        "log_path": log_path,
        "worker_output": worker_output,
        "command": command,
    }


def _wait_worker(job):
    return_code = job["process"].wait()
    job["log_handle"].close()
    result = None
    if job["worker_output"].exists():
        try:
            result = json.loads(job["worker_output"].read_text(encoding="utf-8"))
        except Exception as exc:
            result = {"status": "invalid_result", "error": str(exc)}
    if result is None:
        result = {
            "method": VARIANT_NAMES[job["variant"]],
            "variant": job["variant"],
            "status": "failed",
            "return_code": return_code,
            "gpu": job["gpu"],
            "log_path": str(job["log_path"]),
        }
    result["return_code"] = return_code
    result["log_path"] = str(job["log_path"])
    return result


def run_parent(args):
    if not 1 <= args.max_gpus <= 2:
        raise SystemExit("--max-gpus must be 1 or 2; method22 never uses more than two GPUs")
    variants = ["exact", "clustered"] if args.variant == "all" else [args.variant]
    output = Path(args.output)
    run_dir = output.parent
    run_dir.mkdir(parents=True, exist_ok=True)
    empty, inspected = find_empty_gpus(args.empty_threshold_mib, min(args.max_gpus, len(variants)))

    summary = {
        "method_family": "method22_group_outlier",
        "status": "starting",
        "requested_variants": variants,
        "max_gpus": args.max_gpus,
        "empty_threshold_mib": args.empty_threshold_mib,
        "gpu_scan": inspected,
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "baselines": BASELINES,
        "experiments": [],
    }
    if not empty:
        summary["status"] = "no_empty_gpu"
        _write_json(output, summary)
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 3

    if len(empty) >= 2 and len(variants) >= 2 and args.max_gpus >= 2:
        jobs = [_start_worker(args, variant, empty[index], run_dir) for index, variant in enumerate(variants)]
        for job in jobs:
            summary["experiments"].append(_wait_worker(job))
            _write_json(output, summary)
    else:
        for variant in variants:
            currently_empty, inspected_now = find_empty_gpus(args.empty_threshold_mib, 1)
            summary["gpu_scan"] = inspected_now
            if not currently_empty:
                summary["experiments"].append(
                    {
                        "method": VARIANT_NAMES[variant],
                        "variant": variant,
                        "status": "not_started_no_empty_gpu",
                    }
                )
                _write_json(output, summary)
                continue
            job = _start_worker(args, variant, currently_empty[0], run_dir)
            summary["experiments"].append(_wait_worker(job))
            _write_json(output, summary)

    summary["status"] = (
        "complete"
        if summary["experiments"] and all(item.get("status") == "complete" for item in summary["experiments"])
        else "partial_or_failed"
    )
    _write_json(output, summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if summary["status"] == "complete" else 2


def build_parser():
    parser = argparse.ArgumentParser(description="Run method22 WikiText-2 PPL experiments")
    parser.add_argument("--variant", choices=["exact", "clustered", "all"], default="all")
    parser.add_argument("--model-path", default=DEFAULT_MODEL_PATH)
    parser.add_argument("--cache-dir", default=DEFAULT_CACHE_DIR)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--max-gpus", type=int, default=2)
    parser.add_argument("--empty-threshold-mib", type=int, default=100)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=min(8, os.cpu_count() or 1))
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--worker-variant", choices=["exact", "clustered"], help=argparse.SUPPRESS)
    parser.add_argument("--physical-gpu", help=argparse.SUPPRESS)
    parser.add_argument("--worker-output", help=argparse.SUPPRESS)
    return parser


def main():
    args = build_parser().parse_args()
    if args.worker:
        if args.worker_variant is None or args.physical_gpu is None or args.worker_output is None:
            raise SystemExit("Worker mode requires --worker-variant, --physical-gpu, and --worker-output")
        raise SystemExit(run_worker(args))
    raise SystemExit(run_parent(args))


if __name__ == "__main__":
    main()
