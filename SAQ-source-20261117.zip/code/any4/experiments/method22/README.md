# Method22: group outlier separation

Method22 removes the maximum-absolute-value weight from every 128-value group before
computing the group's min/max normalization and the row-wise 16-centroid Any4 LUT.
The normal LUT and the optional outlier LUT both use the project's original Scikit
KMeans backend; row clustering uses the same `loky` process model as Any4.

- `method22a_exact_outlier` restores each removed FP16 value exactly.
- `method22b_clustered_outlier` uses one activation-weighted 16-centroid outlier LUT per
  Linear weight matrix and restores the corresponding centroid.

Both variants are pseudo-quantization experiments. The runner reports a theoretical
packed storage estimate; the reconstructed model still stores FP16 weights and does not
use a modified CUDA kernel.

Run the CPU smoke checks:

```bash
python experiments/method22/smoke.py
```

Run both WikiText-2 experiments on at most two empty GPUs:

```bash
python experiments/method22/runner.py --variant all --max-gpus 2
```

The launcher only selects GPUs using at most 100 MiB before startup. With two empty GPUs
the variants run concurrently, and with one empty GPU they run sequentially. It never
terminates or preempts another process. Results are written under
`experiments/method22/runs/wiki2_ppl/`.

## WikiText-2 result (2026-07-13)

Model: `/data/model/alpindale-Llama-3.2-1B`; sequence length: 2048; loader samples:
128; `lm_head` skipped.

| Method | PPL | Quantization | Theoretical BPW |
| --- | ---: | ---: | ---: |
| FP16 baseline | 9.750678 | - | 16.0000 |
| Original Any4 4bit | 10.618476 | - | - |
| method22a exact outlier | 10.463196 | 1272.54 s | 4.4976 |
| method22b clustered outlier | 10.574442 | 1292.53 s | 4.4039 |

The complete per-layer statistics and cache metadata are in
`runs/wiki2_ppl/results.json`. These BPW values describe the proposed packed format;
the evaluated pseudo-quantized model still stores reconstructed FP16 weights.
