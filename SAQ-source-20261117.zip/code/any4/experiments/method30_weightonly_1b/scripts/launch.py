import json
import os
import shutil
import subprocess
import time
from pathlib import Path


ROOT = Path("/data/lsz/any4/experiments/method30_weightonly_1b")
RUNNER = ROOT / "scripts" / "runner.py"
SOURCE_ROOT = ROOT / "runs" / "comparison_20260816_v2"
RUN_ROOT = ROOT / "runs" / "comparison_20260816_v3"
PYTHON = "/data/lsz/any4/venv/bin/python"
JOBS = (
    ("fp16", 0, "0-7"),
    ("rtn", 1, "8-15"),
    ("gptq", 2, "16-27"),
    ("awq", 3, "28-39"),
    ("any4", 4, "40-47"),
    ("csd_lut", 5, "48-63"),
)


def main():
    RUN_ROOT.mkdir(parents=True, exist_ok=True)
    launched = []
    for variant, gpu, cpus in JOBS:
        output_dir = RUN_ROOT / variant
        output_dir.mkdir(parents=True, exist_ok=True)
        command = [
            "taskset", "-c", cpus,
            PYTHON, str(RUNNER),
            "--variant", variant,
            "--physical-gpu", str(gpu),
            "--cpu-list", cpus,
            "--output-dir", str(output_dir),
        ]
        result_path = output_dir / "results.json"
        if not result_path.exists():
            shutil.copy2(SOURCE_ROOT / variant / "results.json", result_path)
            payload = json.loads(result_path.read_text(encoding="utf-8"))
            for task in ("arc_challenge", "hellaswag", "piqa", "boolq"):
                payload["metrics"].pop(task, None)
            if variant == "gptq":
                for dataset in ("wikitext2", "c4", "ptb"):
                    payload["metrics"].pop(dataset, None)
            payload["status"] = "prepared_for_corrected_evaluation"
            payload.pop("finished_at", None)
            result_path.write_text(
                json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
        if result_path.exists():
            command.append("--resume")
        env = os.environ.copy()
        env.update(
            {
                "CUDA_VISIBLE_DEVICES": str(gpu),
                "TRANSFORMERS_OFFLINE": "1",
                "HF_DATASETS_OFFLINE": "1",
                "HF_DATASETS_CACHE": "/home/ubuntu/.cache/huggingface/datasets",
                "PYTHONUNBUFFERED": "1",
                "PYTHONPATH": "/data/lsz/any4/venv/lib/python3.10/site-packages",
                "OPENBLAS_NUM_THREADS": "1",
                "OMP_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
            }
        )
        log = (output_dir / "run.log").open("a", buffering=1)
        process = subprocess.Popen(
            command,
            cwd="/data/lsz/any4",
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        launched.append(
            {"variant": variant, "gpu": gpu, "cpus": cpus, "pid": process.pid, "command": command}
        )
    (RUN_ROOT / "launcher.json").write_text(
        json.dumps({"launched_at": time.strftime("%Y-%m-%d %H:%M:%S"), "jobs": launched}, indent=2) + "\n"
    )
    print(json.dumps(launched, indent=2))


if __name__ == "__main__":
    main()
