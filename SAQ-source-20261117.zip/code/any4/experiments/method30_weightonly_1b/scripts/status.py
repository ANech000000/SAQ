import json
from pathlib import Path


root = Path("/data/lsz/any4/experiments/method30_weightonly_1b/runs/comparison_20260816_v3")
for variant in ("fp16", "rtn", "gptq", "awq", "any4", "csd_lut"):
    result_path = root / variant / "results.json"
    if result_path.exists():
        result = json.loads(result_path.read_text())
        print(variant, result.get("status"), sorted(result.get("metrics", {})))
    else:
        print(variant, "no-result")
