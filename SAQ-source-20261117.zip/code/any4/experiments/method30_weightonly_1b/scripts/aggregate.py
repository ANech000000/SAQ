import csv
import hashlib
import json
import math
from pathlib import Path


RUNS = Path("/data/lsz/any4/experiments/method30_weightonly_1b/runs")
SOURCE_ROOT = RUNS / "comparison_20260816_v3"
OUTPUT_ROOT = RUNS / "comparison_20260816_final"
GPTQ_PATH = RUNS / "official_gptq_v4" / "results.json"
VARIANTS = ("fp16", "rtn", "gptq", "awq", "any4", "csd_lut")
TASKS = ("arc_challenge", "hellaswag", "piqa", "boolq")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    records = []
    task_hashes = {}
    sources = {}
    for variant in VARIANTS:
        path = GPTQ_PATH if variant == "gptq" else SOURCE_ROOT / variant / "results.json"
        payload = json.loads(path.read_text())
        if payload.get("status") != "complete":
            raise RuntimeError(f"Incomplete: {path} status={payload.get('status')}")
        metrics = payload["metrics"]
        record = {
            "variant": variant,
            "method": payload["method"],
            "wikitext2_ppl": metrics["wikitext2"]["ppl"],
            "c4_ppl": metrics["c4"]["ppl"],
            "ptb_ppl": metrics["ptb"]["ppl"],
        }
        for task in TASKS:
            record[task + "_accuracy"] = metrics[task]["accuracy"]
            current_hash = metrics[task]["dataset_sha256"]
            if task in task_hashes and task_hashes[task] != current_hash:
                raise RuntimeError(f"Dataset hash mismatch for {task}")
            task_hashes[task] = current_hash
            record[task + "_samples"] = metrics[task]["total"]
        for key, value in record.items():
            if isinstance(value, float) and not math.isfinite(value):
                raise RuntimeError(f"Non-finite value {variant}.{key}")
        records.append(record)
        sources[variant] = {"path": str(path), "sha256": sha256(path)}
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    fields = list(records[0])
    with (OUTPUT_ROOT / "comparison.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (OUTPUT_ROOT / "comparison.json").write_text(json.dumps(records, indent=2) + "\n")
    manifest = {
        "model": "Llama 3.2 1B",
        "model_path": "/data/model/alpindale-Llama-3.2-1B",
        "weight_format": "W4A16",
        "group_size": 128,
        "task_protocol": "zero-shot option-text length-normalized conditional log-likelihood",
        "task_dataset_sha256": task_hashes,
        "source_results": sources,
    }
    (OUTPUT_ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
