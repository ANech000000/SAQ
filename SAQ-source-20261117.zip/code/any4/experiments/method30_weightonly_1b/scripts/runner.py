import argparse
import gc
import hashlib
import json
import math
import os
import random
import re
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_CACHE", "/home/ubuntu/.cache/huggingface/datasets")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTHONUNBUFFERED", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer


ROOT = Path("/data/lsz/any4")
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
SPINQUANT_DIR = Path("/data/lsz/SpinQuant")
for path in (ROOT, REFINE_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from calibrate import calibrate  # noqa: E402
from data_gptq import get_loaders, llama_eval  # noqa: E402
from pre_process.awq.pre_quant import run_awq  # noqa: E402
from pre_process.awq.quantizer import pseudo_quantize_tensor  # noqa: E402
from quantize import quant_methods, quantize_model  # noqa: E402
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test  # noqa: E402
from run_wiki2_ppl import eval_wiki2  # noqa: E402


METHODS = {
    "fp16": "FP16",
    "rtn": "RTN",
    "gptq": "GPTQ",
    "awq": "AWQ",
    "any4": "Any4",
    "csd_lut": "CSD-LUT",
}
LOCAL_TASK_ROOT = Path("/data/lsz/project-resq/tri_stage_resq/eval_data/local_tasks")
DEFAULT_TASKS = ("arc_challenge", "hellaswag", "piqa", "boolq")


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def gpu_snapshot(physical_gpu):
    import subprocess

    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={physical_gpu}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    ).strip()
    memory, utilization = [int(item.strip()) for item in output.split(",")]
    return {"memory_used_mib": memory, "utilization_percent": utilization}


def load_base_model(model_path):
    tokenizer = AutoTokenizer.from_pretrained(
        model_path, local_files_only=True, trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    return model, tokenizer


@torch.no_grad()
def quantize_rtn(model, group_size):
    for name, module in model.named_modules():
        if not isinstance(module, nn.Linear) or name == "lm_head":
            continue
        module.weight.data = pseudo_quantize_tensor(
            module.weight.data,
            n_bit=4,
            zero_point=True,
            q_group_size=group_size,
        ).to(module.weight.dtype)


class GroupQuantizer:
    def __init__(self, bits=4, symmetric=True):
        self.bits = int(bits)
        self.symmetric = bool(symmetric)
        self.maxq = 2 ** (self.bits - 1) - 1 if self.symmetric else 2**self.bits - 1
        self.minq = -(self.maxq + 1) if self.symmetric else 0
        self.scale = None
        self.zero = None

    def find_params(self, weight):
        maximum = weight.amax(dim=1, keepdim=True)
        minimum = weight.amin(dim=1, keepdim=True)
        if self.symmetric:
            absolute = torch.maximum(maximum.abs(), minimum.abs()).clamp_min(1e-5)
            self.scale = absolute / self.maxq
            self.zero = torch.zeros_like(self.scale)
        else:
            zeros = torch.zeros_like(maximum)
            maximum = torch.maximum(maximum, zeros)
            minimum = torch.minimum(minimum, zeros)
            self.scale = (maximum - minimum).clamp_min(1e-5) / self.maxq
            self.zero = torch.round(-minimum / self.scale).clamp_(0, self.maxq)

    def quantize(self, weight):
        integer = torch.clamp(
            torch.round(weight / self.scale) + self.zero, self.minq, self.maxq
        )
        return self.scale * (integer - self.zero)


class GPTQLayer:
    def __init__(self, layer):
        self.layer = layer
        self.columns = layer.weight.shape[1]
        self.hessian = torch.zeros(
            (self.columns, self.columns), device=layer.weight.device, dtype=torch.float32
        )
        self.samples = 0

    def add_batch(self, inputs):
        if inputs.dim() == 2:
            inputs = inputs.unsqueeze(0)
        batch = inputs.shape[0]
        flattened = inputs.reshape(-1, inputs.shape[-1]).t().float()
        self.hessian *= self.samples / (self.samples + batch)
        self.samples += batch
        flattened *= math.sqrt(2.0 / self.samples)
        self.hessian.addmm_(flattened, flattened.t())

    @torch.no_grad()
    def quantize(self, group_size=128, block_size=128, damp_percent=0.01):
        weight = self.layer.weight.detach().float().clone()
        hessian = self.hessian
        self.hessian = None
        dead = torch.diag(hessian) == 0
        hessian[dead, dead] = 1
        weight[:, dead] = 0
        diagonal = torch.arange(self.columns, device=weight.device)
        hessian[diagonal, diagonal] += damp_percent * torch.mean(torch.diag(hessian))
        inverse = torch.linalg.cholesky(hessian)
        inverse = torch.cholesky_inverse(inverse)
        inverse = torch.linalg.cholesky(inverse, upper=True)
        output = torch.zeros_like(weight)
        quantizer = GroupQuantizer(bits=4, symmetric=True)
        for start in range(0, self.columns, block_size):
            stop = min(start + block_size, self.columns)
            current = weight[:, start:stop].clone()
            errors = torch.zeros_like(current)
            local_inverse = inverse[start:stop, start:stop]
            for offset in range(stop - start):
                column = start + offset
                if column % group_size == 0:
                    quantizer.find_params(weight[:, column : min(column + group_size, self.columns)])
                vector = current[:, offset]
                quantized = quantizer.quantize(vector.unsqueeze(1)).flatten()
                output[:, column] = quantized
                error = (vector - quantized) / local_inverse[offset, offset]
                current[:, offset:] -= error.unsqueeze(1).matmul(
                    local_inverse[offset, offset:].unsqueeze(0)
                )
                errors[:, offset] = error
            weight[:, stop:] -= errors.matmul(inverse[start:stop, stop:])
        if not torch.isfinite(output).all():
            raise RuntimeError("GPTQ produced non-finite weights")
        self.layer.weight.data.copy_(output.to(self.layer.weight.dtype))


class CaptureStop(Exception):
    pass


def _move_llama_front(model, device):
    model.model.embed_tokens = model.model.embed_tokens.to(device)
    if hasattr(model.model, "norm"):
        model.model.norm = model.model.norm.to(device)
    if hasattr(model.model, "rotary_emb"):
        model.model.rotary_emb = model.model.rotary_emb.to(device)


@torch.no_grad()
def quantize_gptq(
    model, tokenizer, group_size, samples, sequence_length, damp_percent
):
    loader, _ = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        nsamples=samples,
        seed=0,
        seqlen=sequence_length,
    )
    layers = model.model.layers
    device = torch.device("cuda:0")
    hidden = model.config.hidden_size
    dtype = next(model.parameters()).dtype
    inputs = torch.zeros((samples, sequence_length, hidden), dtype=dtype, device=device)
    outputs = torch.zeros_like(inputs)
    captured = {"index": 0, "kwargs": {}}

    class Catcher(nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module

        def forward(self, hidden_states, **kwargs):
            index = captured["index"]
            inputs[index].copy_(hidden_states.squeeze(0))
            captured["index"] += 1
            captured["kwargs"] = kwargs
            raise CaptureStop

    _move_llama_front(model, device)
    layers[0] = Catcher(layers[0].to(device))
    for batch, _ in loader:
        try:
            model(batch.to(device))
        except CaptureStop:
            pass
    layers[0] = layers[0].module
    if captured["index"] != samples:
        raise RuntimeError(f"Captured {captured['index']} GPTQ samples, expected {samples}")
    layers[0] = layers[0].cpu()
    _move_llama_front(model, "cpu")
    torch.cuda.empty_cache()

    layer_kwargs = captured["kwargs"]
    groups = (
        ("self_attn.k_proj", "self_attn.v_proj", "self_attn.q_proj"),
        ("self_attn.o_proj",),
        ("mlp.up_proj", "mlp.gate_proj"),
        ("mlp.down_proj",),
    )
    for layer_index, layer in enumerate(layers):
        print(f"GPTQ layer {layer_index + 1}/{len(layers)}", flush=True)
        layer = layer.to(device)
        modules = dict(layer.named_modules())
        for names in groups:
            active = {name: GPTQLayer(modules[name]) for name in names}
            handles = []
            for name, quantizer in active.items():
                def hook(_module, hook_inputs, _output, quantizer=quantizer):
                    quantizer.add_batch(hook_inputs[0].detach())

                handles.append(modules[name].register_forward_hook(hook))
            for sample_index in range(samples):
                layer(inputs[sample_index].unsqueeze(0), **layer_kwargs)
            for handle in handles:
                handle.remove()
            for name in names:
                active[name].quantize(
                    group_size=group_size,
                    block_size=128,
                    damp_percent=damp_percent,
                )
        for sample_index in range(samples):
            outputs[sample_index] = layer(
                inputs[sample_index].unsqueeze(0), **layer_kwargs
            )[0]
        layers[layer_index] = layer.cpu()
        inputs, outputs = outputs, inputs
        torch.cuda.empty_cache()
        gc.collect()
    model.config.use_cache = True


@torch.no_grad()
def quantize_awq(model, tokenizer, group_size):
    run_awq(
        model=model,
        enc=tokenizer,
        w_bit=4,
        q_config={"q_group_size": group_size, "zero_point": True},
        n_samples=128,
        seqlen=512,
        auto_scale=True,
        mse_range=True,
        calib_data="wikitext2",
    )
    quantize_rtn(model, group_size)


def load_csd_model(args):
    import runner_any4_table as table

    loader_args = table.build_parser().parse_args(
        [
            "--suite", "harness",
            "--physical-gpu", str(args.physical_gpu),
            "--cpu-list", args.cpu_list,
            "--output-dir", str(Path(args.output_dir) / "csd_loader"),
            "--model-path", args.model_path,
        ]
    )
    return table._load_cached_model(loader_args)


def option_text_example(row):
    answer = str(row["answer"]).strip().lower()
    if answer in {"true", "false"}:
        prompt = str(row["instruction"]).rsplit("\n\nAnswer format:", 1)[0].rstrip()
        return prompt, ("true", "false"), 0 if answer == "true" else 1
    match = re.fullmatch(r"([a-z_]+)(\d+)", answer)
    if not match:
        raise ValueError(f"Unsupported answer label {answer!r}")
    prefix = match.group(1)
    instruction = str(row["instruction"])
    option_matches = list(
        re.finditer(rf"(?i)\b{re.escape(prefix)}(\d+):\s*", instruction)
    )
    if not option_matches:
        raise ValueError(f"No option texts found for {answer!r}")
    prompt = instruction[: option_matches[0].start()].rstrip()
    answer_format = instruction.lower().find("\n\nanswer format:", option_matches[-1].end())
    option_end = len(instruction) if answer_format < 0 else answer_format
    options = []
    indices = []
    for index, option_match in enumerate(option_matches):
        stop = option_matches[index + 1].start() if index + 1 < len(option_matches) else option_end
        options.append(" ".join(instruction[option_match.end() : stop].split()))
        indices.append(int(option_match.group(1)))
    target_number = int(match.group(2))
    if target_number not in indices:
        raise ValueError(f"Correct option {answer!r} is missing")
    return prompt, tuple(options), indices.index(target_number)


@torch.no_grad()
def score_pairs(model, tokenizer, pairs, batch_size, max_length=1024):
    pad = tokenizer.pad_token_id
    scores = []
    for batch_start in range(0, len(pairs), batch_size):
        batch = pairs[batch_start : batch_start + batch_size]
        encoded = []
        for prompt, candidate in batch:
            prompt_ids = tokenizer(prompt, add_special_tokens=True).input_ids
            continuation = tokenizer(" " + candidate, add_special_tokens=False).input_ids
            if len(continuation) >= max_length:
                raise ValueError("Continuation exceeds max length")
            prompt_ids = prompt_ids[-(max_length - len(continuation)) :]
            encoded.append((prompt_ids + continuation, len(prompt_ids), continuation))
        width = max(len(item[0]) for item in encoded)
        input_ids = torch.full((len(encoded), width), pad, dtype=torch.long, device="cuda:0")
        attention = torch.zeros_like(input_ids)
        spans = []
        for row_index, (tokens, prompt_length, continuation) in enumerate(encoded):
            left = width - len(tokens)
            input_ids[row_index, left:] = torch.tensor(tokens, device="cuda:0")
            attention[row_index, left:] = 1
            spans.append((left + prompt_length, continuation))
        logits = model(input_ids=input_ids, attention_mask=attention, use_cache=False).logits
        selected_logits = []
        targets = []
        owners = []
        for row_index, (start, continuation) in enumerate(spans):
            for offset, token in enumerate(continuation):
                selected_logits.append(logits[row_index, start + offset - 1])
                targets.append(token)
                owners.append(row_index)
        selected = torch.stack(selected_logits).float()
        target_tensor = torch.tensor(targets, device=selected.device)
        token_scores = torch.log_softmax(selected, dim=-1).gather(
            1, target_tensor.unsqueeze(1)
        ).squeeze(1)
        batch_scores = torch.zeros(len(encoded), device=selected.device)
        token_counts = torch.zeros(len(encoded), device=selected.device)
        for token_score, owner in zip(token_scores, owners):
            batch_scores[owner] += token_score
            token_counts[owner] += 1
        normalized_scores = batch_scores / token_counts.clamp_min(1)
        scores.extend(float(value) for value in normalized_scores.cpu())
        del logits, selected, token_scores, input_ids, attention
    return scores


@torch.no_grad()
def evaluate_local_task(model, tokenizer, task, batch_size, limit=None):
    path = LOCAL_TASK_ROOT / task / "test.json"
    rows = json.loads(path.read_text(encoding="utf-8"))
    if limit is not None:
        rows = rows[:limit]
    pairs = []
    slices = []
    for row in rows:
        prompt, candidates, target_index = option_text_example(row)
        start = len(pairs)
        pairs.extend((prompt, candidate) for candidate in candidates)
        slices.append((start, len(pairs), target_index))
    pair_scores = score_pairs(model, tokenizer, pairs, batch_size=batch_size)
    correct = 0
    for start, stop, target_index in slices:
        selected_index = max(
            range(stop - start), key=lambda offset: pair_scores[start + offset]
        )
        correct += int(selected_index == target_index)
    return {
        "accuracy": correct / len(rows),
        "correct": correct,
        "total": len(rows),
        "dataset_path": str(path),
        "dataset_sha256": sha256(path),
        "protocol": "zero-shot option-text length-normalized conditional log-likelihood",
    }


def result_template(args):
    return {
        "method": METHODS[args.variant],
        "variant": args.variant,
        "status": "starting",
        "model_path": args.model_path,
        "physical_gpu": str(args.physical_gpu),
        "quantization": {
            "weight_bits": 4 if args.variant != "fp16" else 16,
            "activation_bits": 16,
            "group_size": 128 if args.variant != "fp16" else None,
            "lm_head_quantized": False,
            "gptq": {"calibration": "WikiText-2", "samples": 128, "seqlen": 2048, "damp": args.gptq_damp, "act_order": False, "symmetric": True} if args.variant == "gptq" else None,
            "awq": {"calibration": "WikiText-2", "samples": 128, "seqlen": 512, "auto_scale": True, "mse_clip": True} if args.variant == "awq" else None,
        },
        "evaluation": {
            "ppl_seqlen": 2048,
            "wikitext_loader_samples": 128,
            "c4_eval_samples": 256,
            "tasks": list(args.tasks),
            "task_batch_size": args.task_batch_size,
            "task_limit": args.limit,
            "skip_ppl": args.skip_ppl,
        },
        "metrics": {},
        "timings": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", required=True, choices=tuple(METHODS))
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--tasks", nargs="+", default=DEFAULT_TASKS)
    parser.add_argument("--task-batch-size", type=int, default=32)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--skip-ppl", action="store_true")
    parser.add_argument("--skip-tasks", action="store_true")
    parser.add_argument("--gptq-damp", type=float, default=0.1)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    if os.environ.get("CUDA_VISIBLE_DEVICES") != str(args.physical_gpu):
        raise RuntimeError("CUDA_VISIBLE_DEVICES does not match --physical-gpu")
    initial_gpu = gpu_snapshot(args.physical_gpu)
    if initial_gpu["memory_used_mib"] > 256 or initial_gpu["utilization_percent"] > 5:
        raise RuntimeError(f"GPU {args.physical_gpu} is not empty: {initial_gpu}")
    random.seed(0)
    torch.manual_seed(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "results.json"
    if result_path.exists():
        if not args.resume:
            raise FileExistsError(result_path)
        result = json.loads(result_path.read_text(encoding="utf-8"))
    else:
        result = result_template(args)
    result["initial_gpu"] = initial_gpu
    atomic_json(result_path, result)

    started = time.perf_counter()
    if args.variant == "csd_lut":
        model, tokenizer, metadata = load_csd_model(args)
        result["load_metadata"] = metadata
        result["timings"]["load_and_quantize_seconds"] = time.perf_counter() - started
    else:
        model, tokenizer = load_base_model(args.model_path)
        if args.variant in {"fp16", "rtn", "any4"}:
            model.to("cuda:0")
        quant_started = time.perf_counter()
        if args.variant == "rtn":
            quantize_rtn(model, 128)
        elif args.variant == "gptq":
            old_cache = model.config.use_cache
            model.config.use_cache = False
            quantize_gptq(model, tokenizer, 128, 128, 2048, args.gptq_damp)
            model.config.use_cache = old_cache
            model.to("cuda:0")
        elif args.variant == "awq":
            quantize_awq(model, tokenizer, 128)
            model.to("cuda:0")
        elif args.variant == "any4":
            model = quantize_model(
                model,
                layer_from=nn.Linear,
                layer_to=quant_methods["anyq"],
                tokenizer=tokenizer,
                skip_modules="lm_head",
                n_bit=4,
                group_size=128,
                sample_weight=calibrate,
                scale_sample_weight=True,
                pseudo=True,
            )
        result["timings"]["load_and_quantize_seconds"] = time.perf_counter() - started
        result["timings"]["quantization_seconds"] = time.perf_counter() - quant_started
    model.eval()
    atomic_json(result_path, result)

    if not args.skip_ppl and "wikitext2" not in result["metrics"]:
        result["status"] = "evaluating_wikitext2"
        atomic_json(result_path, result)
        metric_started = time.perf_counter()
        value = eval_wiki2(model, tokenizer, 128, 2048)
        result["metrics"]["wikitext2"] = {"ppl": float(value), "seconds": time.perf_counter() - metric_started}
        atomic_json(result_path, result)
        print(f"WikiText-2 PPL={value:.10f}", flush=True)

    if not args.skip_ppl and "c4" not in result["metrics"]:
        result["status"] = "evaluating_c4"
        atomic_json(result_path, result)
        metric_started = time.perf_counter()
        encoded = load_c4_eval("/data/lsz/llm_dataset/pretraining/C4", tokenizer, 2048, 256, 0)
        value = llama_eval(model, encoded, "cuda", seqlen=2048)
        result["metrics"]["c4"] = {"ppl": float(value), "seconds": time.perf_counter() - metric_started}
        del encoded
        atomic_json(result_path, result)
        print(f"C4 PPL={value:.10f}", flush=True)

    if not args.skip_ppl and "ptb" not in result["metrics"]:
        result["status"] = "evaluating_ptb"
        atomic_json(result_path, result)
        metric_started = time.perf_counter()
        encoded = load_ptb_test("/data/lsz/llm_dataset/language_modeling/PTB", tokenizer, 2048)
        value = llama_eval(model, encoded, "cuda", seqlen=2048)
        result["metrics"]["ptb"] = {"ppl": float(value), "seconds": time.perf_counter() - metric_started}
        del encoded
        atomic_json(result_path, result)
        print(f"PTB PPL={value:.10f}", flush=True)

    for task in (() if args.skip_tasks else args.tasks):
        if task in result["metrics"]:
            continue
        result["status"] = f"evaluating_{task}"
        atomic_json(result_path, result)
        metric_started = time.perf_counter()
        metric = evaluate_local_task(
            model, tokenizer, task, batch_size=args.task_batch_size, limit=args.limit
        )
        metric["seconds"] = time.perf_counter() - metric_started
        result["metrics"][task] = metric
        atomic_json(result_path, result)
        print(f"{task} accuracy={metric['accuracy']:.10f}", flush=True)

    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    result["timings"]["total_seconds"] = time.perf_counter() - started
    result["final_gpu"] = gpu_snapshot(args.physical_gpu)
    atomic_json(result_path, result)
    print(json.dumps(result["metrics"], indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
