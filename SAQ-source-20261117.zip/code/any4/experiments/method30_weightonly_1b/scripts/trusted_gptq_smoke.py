import argparse
import gc
import os
import sys
import types
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_CACHE", "/home/ubuntu/.cache/huggingface/datasets")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


SPINQUANT = Path("/data/lsz/SpinQuant")
ANY4 = Path("/data/lsz/any4")
fast_hadamard_stub = types.ModuleType("fast_hadamard_transform")
fast_hadamard_stub.hadamard_transform = lambda *args, **kwargs: (_ for _ in ()).throw(
    RuntimeError("Hadamard transform is not used by the GPTQ-only baseline")
)
sys.modules.setdefault("fast_hadamard_transform", fast_hadamard_stub)
sys.path.insert(0, str(SPINQUANT))
from eval_utils import gptq_utils  # noqa: E402
from utils import quant_utils  # noqa: E402

sys.path.insert(0, str(ANY4))
from data_gptq import get_loaders, llama_eval  # noqa: E402


class CaptureStop(Exception):
    pass


def move_front(model, device):
    model.model.embed_tokens = model.model.embed_tokens.to(device)
    model.model.norm = model.model.norm.to(device)
    if hasattr(model.model, "rotary_emb"):
        model.model.rotary_emb = model.model.rotary_emb.to(device)


@torch.no_grad()
def quantize_trusted_gptq(model, loader, samples, sequence_length):
    device = torch.device("cuda:0")
    layers = model.model.layers
    dtype = next(model.parameters()).dtype
    inputs = torch.zeros(
        (samples, sequence_length, model.config.hidden_size), dtype=dtype, device=device
    )
    outputs = torch.zeros_like(inputs)
    captured = {"index": 0, "kwargs": {}}

    class Catcher(torch.nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module

        def forward(self, hidden_states, **kwargs):
            inputs[captured["index"]].copy_(hidden_states.squeeze(0))
            captured["index"] += 1
            captured["kwargs"] = kwargs
            raise CaptureStop

    move_front(model, device)
    layers[0] = Catcher(layers[0].to(device))
    for batch, _ in loader:
        try:
            model(batch.to(device))
        except CaptureStop:
            pass
    layers[0] = layers[0].module
    if captured["index"] != samples:
        raise RuntimeError(f"Captured {captured['index']} samples, expected {samples}")
    layers[0] = layers[0].cpu()
    move_front(model, "cpu")
    torch.cuda.empty_cache()

    groups = (
        ("self_attn.k_proj", "self_attn.v_proj", "self_attn.q_proj"),
        ("self_attn.o_proj",),
        ("mlp.up_proj", "mlp.gate_proj"),
        ("mlp.down_proj",),
    )
    layer_kwargs = captured["kwargs"]
    for layer_index, layer in enumerate(layers):
        print(f"Trusted GPTQ layer {layer_index + 1}/{len(layers)}", flush=True)
        layer = layer.to(device)
        modules = dict(layer.named_modules())
        for names in groups:
            active = {}
            handles = []
            for name in names:
                quantizer = gptq_utils.GPTQ(modules[name])
                quantizer.quantizer = quant_utils.WeightQuantizer()
                quantizer.quantizer.configure(
                    4, perchannel=True, sym=True, mse=False
                )
                active[name] = quantizer

                def hook(_module, hook_inputs, hook_output, quantizer=quantizer):
                    quantizer.add_batch(hook_inputs[0].detach(), hook_output.detach())

                handles.append(modules[name].register_forward_hook(hook))
            for sample_index in range(samples):
                outputs[sample_index] = layer(
                    inputs[sample_index].unsqueeze(0), **layer_kwargs
                )[0]
            for handle in handles:
                handle.remove()
            for name in names:
                active[name].fasterquant(
                    percdamp=0.01,
                    groupsize=128,
                    actorder=False,
                    static_groups=False,
                    export_to_et=False,
                )
                active[name].free()
            del active
            torch.cuda.empty_cache()
            gc.collect()
        for sample_index in range(samples):
            outputs[sample_index] = layer(
                inputs[sample_index].unsqueeze(0), **layer_kwargs
            )[0]
        layers[layer_index] = layer.cpu()
        inputs, outputs = outputs, inputs
        torch.cuda.empty_cache()
        gc.collect()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--samples", type=int, default=128)
    parser.add_argument("--seqlen", type=int, default=512)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    loader, test_loader = get_loaders(
        "wikitext-2",
        nsamples=args.samples,
        seed=0,
        seqlen=args.seqlen,
        tokenizer=tokenizer,
    )
    quantize_trusted_gptq(model, loader, args.samples, args.seqlen)
    model.to("cuda:0")
    model.eval()
    ppl = llama_eval(model, test_loader, "cuda", seqlen=2048)
    print(f"TRUSTED_GPTQ_WIKITEXT2_PPL={ppl:.10f}", flush=True)


if __name__ == "__main__":
    main()
