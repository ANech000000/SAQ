import argparse
import gzip
import hashlib
import json
import os
import random
import re
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_CACHE", "/home/ubuntu/.cache/huggingface/datasets")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoTokenizer


THIRD_PARTY = "/data/lsz/any4/experiments/method30_weightonly_1b/third_party/auto_gptq"
ANY4 = "/data/lsz/any4"
sys.path.insert(0, THIRD_PARTY)
sys.path.insert(1, ANY4)
from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig  # noqa: E402
from data_gptq import get_loaders, llama_eval  # noqa: E402


LOCAL_TASK_ROOT = Path("/data/lsz/project-resq/tri_stage_resq/eval_data/local_tasks")
TASKS = ("arc_challenge", "hellaswag", "piqa", "boolq")


class TokenizerWrapper:
    def __init__(self, input_ids):
        self.input_ids = input_ids


def load_ptb_test(tokenizer, seqlen):
    path = Path("/data/lsz/llm_dataset/language_modeling/PTB/test.jsonl")
    sentences = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            sentence = json.loads(line).get("sentence", "")
            if sentence:
                sentences.append(sentence)
    tokens = tokenizer(" ".join(sentences), return_tensors="pt").input_ids
    usable = (tokens.numel() // seqlen) * seqlen
    return TokenizerWrapper(tokens[:, :usable])


def load_c4_eval(tokenizer, seqlen, samples, seed):
    files = sorted(
        Path("/data/lsz/llm_dataset/pretraining/C4/en").glob(
            "c4-validation.*.json.gz"
        )
    )
    rng = random.Random(seed)
    chunks = []
    for path in files:
        with gzip.open(path, "rt") as handle:
            for line in handle:
                text = json.loads(line).get("text", "")
                if not text:
                    continue
                tokens = tokenizer(text, return_tensors="pt").input_ids
                if tokens.shape[1] < seqlen:
                    continue
                start = rng.randint(0, tokens.shape[1] - seqlen - 1) if tokens.shape[1] > seqlen else 0
                chunks.append(tokens[:, start : start + seqlen])
                if len(chunks) >= samples:
                    return TokenizerWrapper(torch.hstack(chunks))
    raise RuntimeError(f"Only found {len(chunks)} usable C4 samples")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def option_text_example(row):
    answer = str(row["answer"]).strip().lower()
    if answer in {"true", "false"}:
        prompt = str(row["instruction"]).rsplit("\n\nAnswer format:", 1)[0].rstrip()
        return prompt, ("true", "false"), 0 if answer == "true" else 1
    match = re.fullmatch(r"([a-z_]+)(\d+)", answer)
    if not match:
        raise ValueError(f"Unsupported answer label {answer!r}")
    prefix = match.group(1)
    instruction = str(row["instruction"])
    option_matches = list(
        re.finditer(rf"(?i)\b{re.escape(prefix)}(\d+):\s*", instruction)
    )
    prompt = instruction[: option_matches[0].start()].rstrip()
    answer_format = instruction.lower().find("\n\nanswer format:", option_matches[-1].end())
    option_end = len(instruction) if answer_format < 0 else answer_format
    options = []
    indices = []
    for index, option_match in enumerate(option_matches):
        stop = option_matches[index + 1].start() if index + 1 < len(option_matches) else option_end
        options.append(" ".join(instruction[option_match.end() : stop].split()))
        indices.append(int(option_match.group(1)))
    return prompt, tuple(options), indices.index(int(match.group(2)))


@torch.no_grad()
def score_pairs(model, tokenizer, pairs, batch_size=32, max_length=1024):
    scores = []
    pad = tokenizer.pad_token_id
    for batch_start in range(0, len(pairs), batch_size):
        batch = pairs[batch_start : batch_start + batch_size]
        encoded = []
        for prompt, candidate in batch:
            prompt_ids = tokenizer(prompt, add_special_tokens=True).input_ids
            continuation = tokenizer(" " + candidate, add_special_tokens=False).input_ids
            prompt_ids = prompt_ids[-(max_length - len(continuation)) :]
            encoded.append((prompt_ids + continuation, len(prompt_ids), continuation))
        width = max(len(item[0]) for item in encoded)
        input_ids = torch.full((len(encoded), width), pad, dtype=torch.long, device="cuda:0")
        attention = torch.zeros_like(input_ids)
        spans = []
        for row_index, (tokens, prompt_length, continuation) in enumerate(encoded):
            left = width - len(tokens)
            input_ids[row_index, left:] = torch.tensor(tokens, device="cuda:0")
            attention[row_index, left:] = 1
            spans.append((left + prompt_length, continuation))
        logits = model(input_ids=input_ids, attention_mask=attention, use_cache=False).logits
        selected_logits = []
        targets = []
        owners = []
        for row_index, (start, continuation) in enumerate(spans):
            for offset, token in enumerate(continuation):
                selected_logits.append(logits[row_index, start + offset - 1])
                targets.append(token)
                owners.append(row_index)
        selected = torch.stack(selected_logits).float()
        target_tensor = torch.tensor(targets, device=selected.device)
        token_scores = torch.log_softmax(selected, dim=-1).gather(
            1, target_tensor.unsqueeze(1)
        ).squeeze(1)
        batch_scores = torch.zeros(len(encoded), device=selected.device)
        token_counts = torch.zeros(len(encoded), device=selected.device)
        for token_score, owner in zip(token_scores, owners):
            batch_scores[owner] += token_score
            token_counts[owner] += 1
        scores.extend(float(value) for value in (batch_scores / token_counts).cpu())
    return scores


@torch.no_grad()
def evaluate_task(model, tokenizer, task):
    path = LOCAL_TASK_ROOT / task / "test.json"
    rows = json.loads(path.read_text(encoding="utf-8"))
    pairs = []
    slices = []
    for row in rows:
        prompt, candidates, target_index = option_text_example(row)
        start = len(pairs)
        pairs.extend((prompt, candidate) for candidate in candidates)
        slices.append((start, len(pairs), target_index))
    scores = score_pairs(model, tokenizer, pairs)
    correct = 0
    for start, stop, target_index in slices:
        selected = max(range(stop - start), key=lambda offset: scores[start + offset])
        correct += int(selected == target_index)
    return {
        "accuracy": correct / len(rows),
        "correct": correct,
        "total": len(rows),
        "dataset_path": str(path),
        "dataset_sha256": sha256(path),
        "protocol": "zero-shot option-text length-normalized conditional log-likelihood",
    }


def atomic_json(path, payload):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--samples", type=int, default=128)
    parser.add_argument("--seqlen", type=int, default=2048)
    args = parser.parse_args()

    random.seed(0)
    torch.manual_seed(0)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "results.json"
    result = {
        "method": "GPTQ",
        "implementation": "AutoGPTQ 0.7.1",
        "model_path": args.model_path,
        "quantization": {
            "bits": 4,
            "group_size": 128,
            "symmetric": True,
            "desc_act": True,
            "true_sequential": True,
            "damp_percent": 0.01,
            "calibration_samples": args.samples,
            "calibration_seqlen": args.seqlen,
        },
        "status": "loading",
        "metrics": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_json(result_path, result)

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    train_loader, test_loader = get_loaders(
        "wikitext-2",
        nsamples=args.samples,
        seed=0,
        seqlen=args.seqlen,
        tokenizer=tokenizer,
    )
    examples = []
    for input_ids, _ in train_loader:
        examples.append(
            {
                "input_ids": input_ids,
                "attention_mask": torch.ones_like(input_ids),
            }
        )

    quantize_config = BaseQuantizeConfig(
        bits=4,
        group_size=128,
        damp_percent=0.01,
        desc_act=True,
        static_groups=False,
        sym=True,
        true_sequential=True,
    )
    model = AutoGPTQForCausalLM.from_pretrained(
        args.model_path,
        quantize_config=quantize_config,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        local_files_only=True,
    )
    result["status"] = "quantizing"
    atomic_json(result_path, result)
    quant_started = time.perf_counter()
    if hasattr(model.model.model, "rotary_emb"):
        model.model.model.rotary_emb = model.model.model.rotary_emb.to("cuda:0")
    model.quantize(
        examples,
        batch_size=1,
        use_triton=False,
        use_cuda_fp16=True,
        cache_examples_on_gpu=False,
    )
    result["quantization_seconds"] = time.perf_counter() - quant_started
    result["status"] = "evaluating_wikitext2"
    atomic_json(result_path, result)
    model.model.to("cuda:0")
    model.model.eval()
    eval_started = time.perf_counter()
    ppl = llama_eval(model.model, test_loader, "cuda", seqlen=2048)
    result["metrics"]["wikitext2"] = {
        "ppl": float(ppl),
        "seconds": time.perf_counter() - eval_started,
    }
    atomic_json(result_path, result)
    for dataset, encoded in (
        ("c4", load_c4_eval(tokenizer, 2048, 256, 0)),
        ("ptb", load_ptb_test(tokenizer, 2048)),
    ):
        result["status"] = f"evaluating_{dataset}"
        atomic_json(result_path, result)
        eval_started = time.perf_counter()
        ppl = llama_eval(model.model, encoded, "cuda", seqlen=2048)
        result["metrics"][dataset] = {
            "ppl": float(ppl),
            "seconds": time.perf_counter() - eval_started,
        }
        atomic_json(result_path, result)
    tokenizer.padding_side = "left"
    for task in TASKS:
        result["status"] = f"evaluating_{task}"
        atomic_json(result_path, result)
        eval_started = time.perf_counter()
        metric = evaluate_task(model.model, tokenizer, task)
        metric["seconds"] = time.perf_counter() - eval_started
        result["metrics"][task] = metric
        atomic_json(result_path, result)
        print(f"{task} accuracy={metric['accuracy']:.10f}", flush=True)
    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_json(result_path, result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
