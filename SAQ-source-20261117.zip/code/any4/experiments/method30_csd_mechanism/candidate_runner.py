import argparse
import contextlib
import gc
import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from safetensors import safe_open


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
for path in (ROOT, METHOD24_DIR, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from layer_timing import (  # noqa: E402
    LINEAR_TO_ACTIVATION,
    activation_paths,
    load_activations,
)
from method24_shape import build_awq_scale  # noqa: E402
from method30_outlier_quant import select_group_outliers  # noqa: E402
from method30_refine import (  # noqa: E402
    initialize_state,
    reconstruct_from_state,
    refine_state,
    state_diagnostics,
)
from state_cache import file_sha256, tensor_sha256  # noqa: E402


SCHEMA_VERSION = 1
METHOD_NAME = "method30_csd_predictor_candidate_grid_v1"
MASK_MODES = ("fixed_alpha0", "reselect_post_scaling")


def canonical_hash(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def atomic_write_json_once(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, indent=2, sort_keys=False) + "\n"
    if path.exists():
        current = path.read_text(encoding="utf-8")
        if current != encoded:
            raise FileExistsError(f"Refusing to overwrite different output: {path}")
        return False
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(temporary, path)
    return True


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(index):
        raise RuntimeError(f"Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}")
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    used, utilization = (int(value.strip()) for value in output.strip().split(","))
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(
            f"GPU {index} is not empty: {used} MiB, {utilization}% utilization"
        )


def layer_parts(name):
    parts = name.split(".")
    return int(parts[2]), ".".join(parts[3:])


def safe_token(value):
    return f"{float(value):.8f}".rstrip("0").rstrip(".").replace(".", "p")


class WeightStore:
    def __init__(self, model_path):
        self.root = Path(model_path)
        index_path = self.root / "model.safetensors.index.json"
        if index_path.exists():
            index = json.loads(index_path.read_text(encoding="utf-8"))
            self.weight_map = dict(index["weight_map"])
        else:
            files = sorted(self.root.glob("*.safetensors"))
            if len(files) != 1:
                raise FileNotFoundError(
                    f"Expected one safetensors file or an index in {self.root}"
                )
            with safe_open(files[0], framework="pt", device="cpu") as handle:
                self.weight_map = {key: files[0].name for key in handle.keys()}
        self.stack = contextlib.ExitStack()
        self.handles = {}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return self.stack.__exit__(exc_type, exc, traceback)

    def get(self, key):
        filename = self.weight_map.get(key)
        if filename is None:
            raise KeyError(f"Model tensor is missing: {key}")
        if filename not in self.handles:
            self.handles[filename] = self.stack.enter_context(
                safe_open(self.root / filename, framework="pt", device="cpu")
            )
        return self.handles[filename].get_tensor(key).contiguous()


@torch.no_grad()
def grouped_csd(scaled_weight, group_size, outlier_positions=None, row_chunk=256):
    rows, cols = scaled_weight.shape
    groups_per_row = cols // group_size
    if groups_per_row <= 1:
        return 0.0
    total = 0.0
    pairwise_factor = 2.0 * groups_per_row / (groups_per_row - 1)
    for start in range(0, rows, row_chunk):
        stop = min(start + row_chunk, rows)
        groups = scaled_weight[start:stop].reshape(
            stop - start, groups_per_row, group_size
        )
        if outlier_positions is not None:
            mask = torch.ones_like(groups, dtype=torch.bool)
            mask.scatter_(2, outlier_positions[start:stop].long().unsqueeze(2), False)
            groups = groups[mask].reshape(stop - start, groups_per_row, group_size - 1)
        sorted_groups = groups.sort(dim=2).values
        minimum = sorted_groups[:, :, :1]
        value_range = sorted_groups[:, :, -1:] - minimum
        normalized = torch.where(
            value_range >= 1e-6,
            (sorted_groups - minimum) / value_range.clamp_min(1e-6),
            torch.zeros_like(sorted_groups),
        )
        mean_curve = normalized.mean(dim=1, keepdim=True)
        row_scores = (
            (normalized - mean_curve).square().mean(dim=(1, 2))
            * pairwise_factor
        )
        total += row_scores.double().sum().item()
    return float(total / max(rows, 1))


@torch.no_grad()
def final_output_error(activation, source, reconstructed):
    x = activation.to(device=source.device, dtype=torch.float32)
    source32 = source.float()
    reconstructed32 = reconstructed.float()
    reference = x @ source32.t()
    residual = x @ (source32 - reconstructed32).t()
    denominator = reference.square().sum().double().item()
    numerator = residual.square().sum().double().item()
    del x, source32, reconstructed32, reference, residual
    return float(numerator), float(max(denominator, 1e-12))


def load_selection(path, model_key):
    path = Path(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("status") != "complete" or payload.get("model_key") != model_key:
        raise RuntimeError(f"Invalid selection manifest: {path}")
    return payload


def deterministic_shards(selection, count):
    workloads = []
    for name, entry in selection["candidate_sources"].items():
        rows, cols = (int(value) for value in entry["weight_shape"])
        cost = rows * cols * int(entry["candidate_count"])
        workloads.append((cost, name))
    assignments = [[] for _ in range(count)]
    totals = [0 for _ in range(count)]
    for cost, name in sorted(workloads, key=lambda item: (-item[0], item[1])):
        target = min(range(count), key=lambda index: (totals[index], index))
        assignments[target].append(name)
        totals[target] += cost
    return [sorted(names, key=lambda name: (layer_parts(name)[0], name)) for names in assignments], totals


def candidate_records(entry):
    path = Path(entry["path"])
    if file_sha256(path) != entry["sha256"]:
        raise AssertionError(f"Candidate source hash mismatch: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = sorted(payload["candidates"], key=lambda item: float(item["alpha"]))
    if len(records) != int(entry["candidate_count"]):
        raise AssertionError(f"Candidate count mismatch: {path}")
    if not any(float(item["alpha"]) == 0.0 for item in records):
        raise AssertionError(f"Candidate set lacks alpha=0: {path}")
    return records


def unit_path(output_dir, model, mode, name, alpha):
    return (
        Path(output_dir)
        / "units"
        / model
        / mode
        / name
        / f"alpha_{safe_token(alpha)}.json"
    )


def unit_is_complete(path, run_fingerprint):
    path = Path(path)
    if not path.exists():
        return False
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("status") != "complete" or payload.get("run_fingerprint") != run_fingerprint:
        raise RuntimeError(f"Existing unit does not match this run: {path}")
    return True


def validate_diagnostics(diagnostics, label):
    losses = [float(value) for value in diagnostics["losses"]]
    if not losses or not all(math.isfinite(value) for value in losses):
        raise AssertionError(f"Non-finite optimizer loss: {label}")
    if not diagnostics["loss_monotonic"]:
        raise AssertionError(f"Non-monotonic optimizer loss: {label}")
    if diagnostics["rollback_reason"] == "non_finite_loss":
        raise AssertionError(f"Non-finite rollback: {label}")


@torch.no_grad()
def quantize_candidate(
    args,
    source,
    fisher,
    calibration,
    validation,
    name,
    record,
    mode,
    positions,
    fixed_positions,
    identity,
    layer_inputs,
):
    alpha = float(record["alpha"])
    scale = build_awq_scale(calibration.abs().mean(dim=0), alpha).to("cuda:0")
    started = time.perf_counter()
    state = initialize_state(
        source,
        scale,
        fisher,
        group_size=args.group_size,
        initializer="sklearn",
        parallel_jobs=args.parallel_jobs,
        relative_tol=1e-6,
        ridge=1e-6,
        scale_eps=1e-6,
        chunk_rows=128,
        importance_chunk_rows=512,
        loss_increase_rtol=1e-7,
        outlier_positions_override=positions,
    )
    state = refine_state(source, state, args.iterations)
    diagnostics = state_diagnostics(state)
    validate_diagnostics(diagnostics, f"{name} alpha={alpha:g} mode={mode}")
    if not torch.equal(state["outlier_positions"].long(), positions.long()):
        raise AssertionError(f"Optimizer changed the requested outlier mask: {name}")
    reconstructed = reconstruct_from_state(source, state)
    rows, cols = source.shape
    grouped_source = source.reshape(rows, cols // args.group_size, args.group_size)
    grouped_reconstructed = reconstructed.reshape(
        rows, cols // args.group_size, args.group_size
    )
    exact_source = grouped_source.gather(2, positions.long().unsqueeze(2))
    exact_reconstructed = grouped_reconstructed.gather(
        2, positions.long().unsqueeze(2)
    )
    exact_outlier_max_abs_error = float(
        (exact_source.float() - exact_reconstructed.float()).abs().max().item()
    )
    if exact_outlier_max_abs_error != 0.0:
        raise AssertionError(
            f"Exact outlier reconstruction failed for {name}: "
            f"max_abs_error={exact_outlier_max_abs_error}"
        )
    output_numerator, output_denominator = final_output_error(
        validation, source, reconstructed
    )
    scaled_source = source.float() * scale.reshape(1, -1)
    csd_recomputed = grouped_csd(scaled_source, args.group_size)
    candidate_csd = float(record["shape_score"])
    tolerance = max(2e-8, abs(candidate_csd) * 2e-5)
    if abs(csd_recomputed - candidate_csd) > tolerance:
        raise AssertionError(
            f"CSD mismatch for {name} alpha={alpha:g}: "
            f"candidate={candidate_csd}, recomputed={csd_recomputed}"
        )
    regular_csd = grouped_csd(
        scaled_source, args.group_size, outlier_positions=positions
    )
    outlier_agreement = float(
        (positions == fixed_positions).float().mean().item()
    )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "method": METHOD_NAME,
        "status": "complete",
        "run_fingerprint": identity["run_fingerprint"],
        "model_key": args.model,
        "linear": name,
        "mask_mode": mode,
        "mask_definition": (
            "outlier positions selected once from the unscaled (alpha=0) weight"
            if mode == "fixed_alpha0"
            else "outlier positions reselected after applying this candidate scale"
        ),
        "alpha": alpha,
        "candidate_output_rel_mse": float(record["output_rel_mse"]),
        "candidate_csd": candidate_csd,
        "recomputed_csd": csd_recomputed,
        "regular_csd_post_outlier": regular_csd,
        "final_output_error_numerator": output_numerator,
        "final_output_error_denominator": output_denominator,
        "final_output_rel_mse": output_numerator / output_denominator,
        "final_j_numerator": float(diagnostics["weighted_loss_numerator"]),
        "final_j_denominator": float(diagnostics["weighted_loss_denominator"]),
        "final_j": float(diagnostics["final_weighted_loss"]),
        "outlier_positions_sha256": tensor_sha256(positions),
        "fixed_alpha0_positions_sha256": tensor_sha256(fixed_positions),
        "outlier_agreement_with_fixed": outlier_agreement,
        "outlier_groups": int(positions.numel()),
        "exact_outlier_max_abs_error": exact_outlier_max_abs_error,
        "optimizer": {
            "initializer": "sklearn",
            "iterations_requested": int(args.iterations),
            "iterations_completed": int(diagnostics["iterations"]),
            "losses": diagnostics["losses"],
            "loss_monotonic": bool(diagnostics["loss_monotonic"]),
            "rollback": bool(diagnostics["rollback"]),
            "rollback_reason": diagnostics["rollback_reason"],
            "converged": bool(diagnostics["converged"]),
        },
        "timings": {
            "candidate_seconds": float(time.perf_counter() - started),
            "initialization_seconds": float(diagnostics["initialization_seconds"]),
            "optimization_seconds": float(diagnostics["optimization_seconds"]),
        },
        "provenance": identity,
        "layer_inputs": layer_inputs,
    }
    del state, reconstructed, scaled_source, scale
    torch.cuda.empty_cache()
    return payload


@torch.no_grad()
def execute(args):
    assert_empty_gpu(args.physical_gpu)
    torch.manual_seed(args.seed)
    selection = load_selection(args.selection, args.model)
    shards, shard_costs = deterministic_shards(selection, args.num_shards)
    names = shards[args.shard_index]
    if args.only_linear:
        if args.only_linear not in selection["candidate_sources"]:
            raise KeyError(args.only_linear)
        names = [args.only_linear]
    fisher_payload = torch.load(args.fisher, map_location="cpu")
    fisher_map = fisher_payload["fisher"]
    implementation_files = [
        Path(__file__),
        EXP_DIR / "method30_refine.py",
        EXP_DIR / "method30_outlier_quant.py",
        EXP_DIR / "hybrid_init.py",
        EXP_DIR / "state_cache.py",
    ]
    identity = {
        "selection": str(Path(args.selection).resolve()),
        "selection_sha256": file_sha256(args.selection),
        "model_path": str(Path(args.model_path).resolve()),
        "fisher": str(Path(args.fisher).resolve()),
        "fisher_sha256": file_sha256(args.fisher),
        "calibration_cache": str(Path(args.calibration_cache).resolve()),
        "validation_cache": str(Path(args.validation_cache).resolve()),
        "validation_manifest_sha256": file_sha256(
            Path(args.validation_cache) / "manifest.json"
        ),
        "group_size": int(args.group_size),
        "bits": 4,
        "exact_outliers_per_group": 1,
        "initializer": "sklearn",
        "iterations": int(args.iterations),
        "seed": int(args.seed),
        "implementation_sha256": {
            path.name: file_sha256(path) for path in implementation_files
        },
    }
    identity["run_fingerprint"] = canonical_hash(identity)
    run_manifest = {
        "status": "running",
        "method": METHOD_NAME,
        "model_key": args.model,
        "physical_gpu": str(args.physical_gpu),
        "shard_index": int(args.shard_index),
        "num_shards": int(args.num_shards),
        "shard_cost": int(shard_costs[args.shard_index]),
        "layers": names,
        "candidate_count": sum(
            int(selection["candidate_sources"][name]["candidate_count"])
            for name in names
        ),
        "mask_modes": list(MASK_MODES),
        "provenance": identity,
    }
    manifest_path = (
        Path(args.output_dir)
        / "manifests"
        / f"{args.model}_shard_{args.shard_index:02d}.json"
    )
    if manifest_path.exists():
        previous = json.loads(manifest_path.read_text(encoding="utf-8"))
        if previous.get("provenance", {}).get("run_fingerprint") != identity["run_fingerprint"]:
            raise RuntimeError(f"Existing shard manifest differs: {manifest_path}")
    else:
        atomic_write_json_once(manifest_path, run_manifest)

    completed = 0
    skipped = 0
    started = time.perf_counter()
    with WeightStore(args.model_path) as weights:
        current_block = None
        calibration_activations = None
        validation_activations = None
        block_input_hashes = None
        for layer_index, name in enumerate(names, 1):
            block, local_name = layer_parts(name)
            if local_name not in LINEAR_TO_ACTIVATION:
                raise AssertionError(f"Unexpected non-searchable Linear: {name}")
            if block != current_block:
                del calibration_activations, validation_activations
                gc.collect()
                calibration_activations = load_activations(args.calibration_cache, block)
                validation_activations = load_activations(args.validation_cache, block)
                block_input_hashes = {
                    "calibration_activation_files": {
                        key: {
                            "path": str(path.resolve()),
                            "sha256": file_sha256(path),
                        }
                        for key, path in activation_paths(args.calibration_cache, block).items()
                    },
                    "validation_activation_files": {
                        key: {
                            "path": str(path.resolve()),
                            "sha256": file_sha256(path),
                        }
                        for key, path in activation_paths(args.validation_cache, block).items()
                    },
                }
                current_block = block
            activation_key = LINEAR_TO_ACTIVATION[local_name]
            calibration = calibration_activations[activation_key]
            validation = validation_activations[activation_key]
            source_cpu = weights.get(name + ".weight")
            expected_shape = selection["candidate_sources"][name]["weight_shape"]
            if list(source_cpu.shape) != list(expected_shape):
                raise AssertionError(f"Weight shape mismatch for {name}")
            source = source_cpu.to("cuda:0")
            fisher = fisher_map[name].to("cuda:0", dtype=torch.float32)
            layer_inputs = {
                "candidate_source": selection["candidate_sources"][name],
                "weight_tensor_sha256": tensor_sha256(source_cpu),
                "fisher_tensor_sha256": tensor_sha256(fisher_map[name]),
                **block_input_hashes,
            }
            _, fixed_positions, _ = select_group_outliers(source.float(), args.group_size)
            records = candidate_records(selection["candidate_sources"][name])
            for candidate_index, record in enumerate(records, 1):
                alpha = float(record["alpha"])
                paths = {
                    mode: unit_path(args.output_dir, args.model, mode, name, alpha)
                    for mode in MASK_MODES
                }
                existing = {
                    mode: unit_is_complete(path, identity["run_fingerprint"])
                    for mode, path in paths.items()
                }
                if all(existing.values()):
                    skipped += len(MASK_MODES)
                    continue
                scale = build_awq_scale(calibration.abs().mean(dim=0), alpha).to("cuda:0")
                _, reselected_positions, _ = select_group_outliers(
                    source.float() * scale.reshape(1, -1), args.group_size
                )
                del scale
                computed = {}
                if not existing["fixed_alpha0"]:
                    computed["fixed_alpha0"] = quantize_candidate(
                        args,
                        source,
                        fisher,
                        calibration,
                        validation,
                        name,
                        record,
                        "fixed_alpha0",
                        fixed_positions,
                        fixed_positions,
                        identity,
                        layer_inputs,
                    )
                    atomic_write_json_once(paths["fixed_alpha0"], computed["fixed_alpha0"])
                    completed += 1
                else:
                    skipped += 1
                masks_identical = torch.equal(fixed_positions, reselected_positions)
                if not existing["reselect_post_scaling"]:
                    if masks_identical:
                        fixed_payload = computed.get("fixed_alpha0")
                        if fixed_payload is None:
                            fixed_payload = json.loads(paths["fixed_alpha0"].read_text(encoding="utf-8"))
                        payload = dict(fixed_payload)
                        payload["mask_mode"] = "reselect_post_scaling"
                        payload["mask_definition"] = (
                            "outlier positions reselected after applying this candidate scale"
                        )
                        payload["reused_identical_fixed_result"] = True
                    else:
                        payload = quantize_candidate(
                            args,
                            source,
                            fisher,
                            calibration,
                            validation,
                            name,
                            record,
                            "reselect_post_scaling",
                            reselected_positions,
                            fixed_positions,
                            identity,
                            layer_inputs,
                        )
                        payload["reused_identical_fixed_result"] = False
                    atomic_write_json_once(paths["reselect_post_scaling"], payload)
                    completed += 1
                else:
                    skipped += 1
                del reselected_positions, computed
                print(
                    f"[{layer_index}/{len(names)} {candidate_index}/{len(records)}] "
                    f"{name} alpha={alpha:g} masks_identical={masks_identical}",
                    flush=True,
                )
            del source, source_cpu, fisher, fixed_positions
            torch.cuda.empty_cache()
            gc.collect()

    complete_manifest = dict(run_manifest)
    complete_manifest.update(
        {
            "status": "complete",
            "completed_units_this_invocation": int(completed),
            "skipped_units_this_invocation": int(skipped),
            "seconds": float(time.perf_counter() - started),
        }
    )
    complete_path = manifest_path.with_name(manifest_path.stem + ".complete.json")
    atomic_write_json_once(complete_path, complete_manifest)
    print(json.dumps(complete_manifest, indent=2))
    return complete_manifest


def build_parser():
    parser = argparse.ArgumentParser(description="Run every CSD candidate through final shared-LUT quantization")
    parser.add_argument("--model", choices=("1b", "8b"), required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--selection", required=True)
    parser.add_argument("--fisher", required=True)
    parser.add_argument("--calibration-cache", required=True)
    parser.add_argument("--validation-cache", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--shard-index", type=int, required=True)
    parser.add_argument("--num-shards", type=int, required=True)
    parser.add_argument("--only-linear")
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--iterations", type=int, default=10)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()
    if args.shard_index < 0 or args.shard_index >= args.num_shards:
        parser.error("--shard-index must be in [0, --num-shards)")
    return args


if __name__ == "__main__":
    execute(build_parser())
