import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders  # noqa: E402


REPRESENTATIVES = {
    "qkv": "self_attn.q_proj",
    "gate_up": "mlp.gate_proj",
    "down": "mlp.down_proj",
}


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(index):
        raise RuntimeError(f"Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}")
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    used, utilization = (int(value.strip()) for value in output.strip().split(","))
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(
            f"GPU {index} is not empty: {used} MiB, {utilization}% utilization"
        )


def activation_path(cache_dir, block, unit):
    prefix = f"model.layers.{block}"
    if unit == "qkv":
        stem = (
            f"{prefix}.self_attn.q_proj__{prefix}.self_attn.k_proj__"
            f"{prefix}.self_attn.v_proj_256_2048.pt"
        )
    elif unit == "gate_up":
        stem = f"{prefix}.mlp.gate_proj__{prefix}.mlp.up_proj_256_2048.pt"
    elif unit == "down":
        stem = f"{prefix}.mlp.down_proj_256_8192.pt"
    else:
        raise ValueError(unit)
    return Path(cache_dir) / stem


def atomic_torch_save(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite validation cache: {path}")
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    torch.save(payload, temporary)
    os.replace(temporary, path)


@torch.no_grad()
def execute(args):
    assert_empty_gpu(args.physical_gpu)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        use_fast=False,
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map={"": "cuda:0"},
        low_cpu_mem_usage=True,
    ).eval()
    _, testenc = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        nsamples=1,
        seed=args.seed,
        seqlen=args.sequence_length,
    )
    all_ids = testenc.input_ids
    stop = args.token_start + args.sequence_length
    if stop > all_ids.shape[1]:
        raise ValueError(
            f"Requested validation tokens [{args.token_start}, {stop}) exceed "
            f"the test corpus length {all_ids.shape[1]}."
        )
    input_ids = all_ids[:, args.token_start:stop].contiguous()
    chosen = torch.linspace(
        0,
        args.sequence_length - 1,
        steps=args.validation_tokens,
    ).round().long()
    modules = dict(model.named_modules())
    captured = {}
    handles = []

    def make_hook(name):
        def hook(module, inputs, output):
            value = inputs[0].detach().reshape(-1, inputs[0].shape[-1])
            captured[name] = value.index_select(
                0, chosen.to(value.device)
            ).float().cpu().contiguous()
        return hook

    for block in range(len(model.model.layers)):
        prefix = f"model.layers.{block}"
        for local_name in REPRESENTATIVES.values():
            name = f"{prefix}.{local_name}"
            handles.append(modules[name].register_forward_hook(make_hook(name)))
    started = time.perf_counter()
    try:
        model(input_ids.to("cuda:0"), use_cache=False)
    finally:
        for handle in handles:
            handle.remove()

    expected = len(model.model.layers) * len(REPRESENTATIVES)
    if len(captured) != expected:
        raise AssertionError(f"Captured {len(captured)} tensors, expected {expected}.")
    outputs = []
    for block in range(len(model.model.layers)):
        prefix = f"model.layers.{block}"
        for unit, local_name in REPRESENTATIVES.items():
            name = f"{prefix}.{local_name}"
            tensor = captured[name]
            if tensor.shape[0] != args.validation_tokens or not torch.isfinite(tensor).all():
                raise ValueError(f"Invalid validation activation {name}: {tuple(tensor.shape)}")
            path = activation_path(args.output_dir, block, unit)
            atomic_torch_save(
                path,
                {
                    "method": "method30_csd_mechanism_validation_activations_v1",
                    "model_path": str(Path(args.model_path).resolve()),
                    "dataset": "wikitext-2-raw-v1",
                    "split": "test",
                    "token_start": int(args.token_start),
                    "sequence_length": int(args.sequence_length),
                    "validation_tokens": int(args.validation_tokens),
                    "selection": "evenly_spaced_within_fixed_test_interval",
                    "block": int(block),
                    "unit": unit,
                    "actual_width": int(tensor.shape[1]),
                    "x": tensor,
                },
            )
            outputs.append({
                "path": str(path.resolve()),
                "bytes": path.stat().st_size,
                "sha256": file_sha256(path),
            })
    manifest = {
        "status": "complete",
        "model_key": args.model,
        "model_path": str(Path(args.model_path).resolve()),
        "dataset": "wikitext-2-raw-v1",
        "split": "test",
        "token_start": int(args.token_start),
        "sequence_length": int(args.sequence_length),
        "validation_tokens": int(args.validation_tokens),
        "files": outputs,
        "seconds": time.perf_counter() - started,
    }
    manifest_path = Path(args.output_dir) / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "complete",
        "model": args.model,
        "files": len(outputs),
        "output_dir": str(Path(args.output_dir).resolve()),
        "seconds": manifest["seconds"],
    }, indent=2))
    return manifest


def build_parser():
    parser = argparse.ArgumentParser(description="Collect held-out CSD mechanism activations")
    parser.add_argument("--model", choices=("1b", "8b"), required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--token-start", type=int, default=4096)
    parser.add_argument("--sequence-length", type=int, default=512)
    parser.add_argument("--validation-tokens", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20260808)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
