import copy
import hashlib
import json
import os
from pathlib import Path

import torch


CACHE_SCHEMA_VERSION = 1


def tensor_sha256(value):
    tensor = torch.as_tensor(value).detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(tensor.shape)).encode("utf-8"))
    digest.update(str(tensor.dtype).encode("utf-8"))
    digest.update(tensor.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def canonical_fingerprint(payload):
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(temporary, path)


def _clone(value, device=None):
    if isinstance(value, torch.Tensor):
        result = value.detach().clone()
        return result.to(device=device) if device is not None else result
    if isinstance(value, dict):
        return {key: _clone(item, device=device) for key, item in value.items()}
    if isinstance(value, list):
        return [_clone(item, device=device) for item in value]
    return copy.deepcopy(value)


def clone_state(state, device=None):
    return _clone(state, device=device)


def outlier_mask_from_positions(positions, cols, group_size):
    rows, groups = positions.shape
    if groups * group_size != cols:
        raise ValueError("Outlier position shape does not match the weight shape.")
    mask = torch.zeros(
        (rows, groups, group_size),
        dtype=torch.bool,
        device=positions.device,
    )
    mask.scatter_(2, positions.long().unsqueeze(2), True)
    return mask.reshape(rows, cols)


def pack_assignment(assignment, outlier_positions, group_size):
    assignment = assignment.detach().cpu().long()
    rows, cols = assignment.shape
    mask = outlier_mask_from_positions(
        outlier_positions.detach().cpu().long(), cols, group_size
    )
    compact = assignment[~mask].reshape(-1)
    if compact.numel() and (compact.min() < 0 or compact.max() > 15):
        raise ValueError("Assignment labels must fit in four bits.")
    count = int(compact.numel())
    if count % 2:
        compact = torch.cat([compact, torch.zeros(1, dtype=compact.dtype)])
    packed = compact[0::2].to(torch.uint8) | (
        compact[1::2].to(torch.uint8) << 4
    )
    return packed.contiguous(), count


def unpack_assignment(packed, count, weight_shape, positions, group_size):
    packed = packed.detach().cpu().to(torch.uint8).reshape(-1)
    compact = torch.empty(packed.numel() * 2, dtype=torch.long)
    compact[0::2] = (packed & 0x0F).long()
    compact[1::2] = ((packed >> 4) & 0x0F).long()
    compact = compact[: int(count)]
    rows, cols = (int(value) for value in weight_shape)
    mask = outlier_mask_from_positions(
        positions.detach().cpu().long(), cols, group_size
    )
    if compact.numel() != int((~mask).sum().item()):
        raise ValueError("Packed assignment length does not match its mask.")
    assignment = torch.zeros((rows, cols), dtype=torch.long)
    assignment[~mask] = compact
    return assignment


def _state_for_cache(state):
    result = clone_state(state, device="cpu")
    packed, count = pack_assignment(
        result.pop("assignment"),
        result["outlier_positions"],
        int(result["group_size"]),
    )
    result["packed_assignment"] = packed
    result["packed_assignment_count"] = count
    result["lut"] = result["lut"].float().contiguous()
    result["scales"] = result["scales"].float().contiguous()
    result["offsets"] = result["offsets"].float().contiguous()
    result["outlier_positions"] = result["outlier_positions"].to(
        torch.uint8 if int(result["group_size"]) <= 256 else torch.int32
    ).contiguous()
    result["exact_outlier_values"] = (
        result["exact_outlier_values"].half().contiguous()
    )
    result["channel_scale"] = result["channel_scale"].float().contiguous()
    result["scaled_fisher"] = result["scaled_fisher"].float().contiguous()
    return result


def _state_from_cache(payload):
    state = clone_state(payload, device="cpu")
    packed = state.pop("packed_assignment")
    count = state.pop("packed_assignment_count")
    state["outlier_positions"] = state["outlier_positions"].long()
    state["exact_outlier_values"] = state["exact_outlier_values"].float()
    state["assignment"] = unpack_assignment(
        packed,
        count,
        state["weight_shape"],
        state["outlier_positions"],
        int(state["group_size"]),
    )
    return state


def _hash_cached_state(state):
    ignored = {
        "initializer_diagnostics",
        "initialization_seconds",
        "optimization_seconds",
        "total_seconds",
    }
    digest = hashlib.sha256()
    for key in sorted(state):
        if key in ignored:
            continue
        digest.update(key.encode("utf-8"))
        value = state[key]
        if isinstance(value, torch.Tensor):
            digest.update(tensor_sha256(value).encode("ascii"))
        else:
            digest.update(
                json.dumps(
                    value, sort_keys=True, separators=(",", ":")
                ).encode("utf-8")
            )
    return digest.hexdigest()


def safe_layer_name(layer_name):
    return str(layer_name).replace(".", "__").replace("/", "_")


def cache_file(cache_dir, run_fingerprint, layer_name, checkpoint):
    return (
        Path(cache_dir)
        / run_fingerprint
        / safe_layer_name(layer_name)
        / f"iter_{int(checkpoint):04d}.pt"
    )


def save_state_cache(path, metadata, state):
    path = Path(path)
    cached_state = _state_for_cache(state)
    state_hash = _hash_cached_state(cached_state)
    payload = {
        "schema_version": CACHE_SCHEMA_VERSION,
        "metadata": metadata,
        "state_hash": state_hash,
        "state": cached_state,
    }
    if path.exists():
        _, existing = load_state_cache(path, metadata)
        if existing["state_hash"] != state_hash:
            raise RuntimeError(
                f"Existing valid cache has a different state hash: {path}"
            )
        return existing, False
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    torch.save(payload, temporary)
    os.replace(temporary, path)
    return payload, True


def load_state_cache(path, expected_metadata):
    path = Path(path)
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("schema_version") != CACHE_SCHEMA_VERSION:
        raise RuntimeError(f"Unsupported state cache schema: {path}")
    if payload.get("metadata") != expected_metadata:
        raise RuntimeError(f"State cache metadata mismatch: {path}")
    cached_state = payload.get("state")
    if not isinstance(cached_state, dict):
        raise RuntimeError(f"State cache payload is missing: {path}")
    if _hash_cached_state(cached_state) != payload.get("state_hash"):
        raise RuntimeError(f"State cache hash mismatch: {path}")
    return _state_from_cache(cached_state), payload


def state_cache_size_bytes(path):
    return int(Path(path).stat().st_size)
