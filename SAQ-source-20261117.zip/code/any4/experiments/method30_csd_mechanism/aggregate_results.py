import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats


MASK_MODES = ("fixed_alpha0", "reselect_post_scaling")
SELECTORS = ("no_scaling", "output_only", "csd_only", "output_csd", "candidate_grid_oracle")
JOINT_LAMBDA = 0.3
BOOTSTRAP_SEED = 20260808


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def safe_token(value):
    return f"{float(value):.8f}".rstrip("0").rstrip(".").replace(".", "p")


def percentile_ci(values, statistic=np.median, samples=10000, seed=BOOTSTRAP_SEED):
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    if not len(values):
        return [None, None]
    generator = np.random.default_rng(seed)
    estimates = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        sample = generator.choice(values, size=len(values), replace=True)
        estimates[index] = statistic(sample)
    return [float(value) for value in np.percentile(estimates, [2.5, 97.5])]


def select_indices(records):
    baseline = next(index for index, item in enumerate(records) if item["alpha"] == 0.0)
    error0 = max(records[baseline]["candidate_output_rel_mse"], 1e-12)
    csd0 = max(records[baseline]["candidate_csd"], 1e-12)
    return {
        "no_scaling": baseline,
        "output_only": min(
            range(len(records)),
            key=lambda index: (records[index]["candidate_output_rel_mse"], records[index]["alpha"]),
        ),
        "csd_only": min(
            range(len(records)),
            key=lambda index: (
                records[index]["candidate_csd"],
                records[index]["candidate_output_rel_mse"],
                records[index]["alpha"],
            ),
        ),
        "output_csd": min(
            range(len(records)),
            key=lambda index: (
                records[index]["candidate_output_rel_mse"] / error0
                + JOINT_LAMBDA * records[index]["candidate_csd"] / csd0,
                records[index]["candidate_output_rel_mse"],
                records[index]["alpha"],
            ),
        ),
        "candidate_grid_oracle": min(
            range(len(records)),
            key=lambda index: (records[index]["final_output_rel_mse"], records[index]["alpha"]),
        ),
    }


def fixed_effect_regression(layer_records):
    blocks = []
    for layer, records in layer_records.items():
        d = np.asarray([item["candidate_csd"] for item in records], dtype=np.float64)
        e = np.asarray([item["candidate_output_rel_mse"] for item in records], dtype=np.float64)
        y = np.asarray([item["final_output_rel_mse"] for item in records], dtype=np.float64)
        if min(d.std(), e.std(), y.std()) <= 0:
            continue
        block = np.column_stack(
            [
                (d - d.mean()) / d.std(ddof=0),
                (e - e.mean()) / e.std(ddof=0),
                (y - y.mean()) / y.std(ddof=0),
            ]
        )
        blocks.append((layer, block))
    if len(blocks) < 3:
        return None
    x = np.concatenate([block[:, :2] for _, block in blocks], axis=0)
    y = np.concatenate([block[:, 2] for _, block in blocks], axis=0)
    inverse = np.linalg.pinv(x.T @ x)
    beta = inverse @ x.T @ y
    residual = y - x @ beta
    meat = np.zeros((2, 2), dtype=np.float64)
    offset = 0
    for _, block in blocks:
        count = len(block)
        xg = x[offset : offset + count]
        ug = residual[offset : offset + count]
        score = xg.T @ ug
        meat += np.outer(score, score)
        offset += count
    groups = len(blocks)
    observations, predictors = x.shape
    correction = (groups / (groups - 1)) * ((observations - 1) / (observations - predictors))
    covariance = correction * inverse @ meat @ inverse
    standard_error = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    t_value = beta / np.maximum(standard_error, 1e-15)
    p_value = 2.0 * stats.t.sf(np.abs(t_value), df=groups - 1)

    generator = np.random.default_rng(BOOTSTRAP_SEED)
    boot = np.empty((10000, 2), dtype=np.float64)
    for sample_index in range(len(boot)):
        chosen = generator.integers(0, groups, size=groups)
        sample = np.concatenate([blocks[index][1] for index in chosen], axis=0)
        sample_x = sample[:, :2]
        sample_y = sample[:, 2]
        boot[sample_index] = np.linalg.pinv(sample_x.T @ sample_x) @ sample_x.T @ sample_y
    intervals = np.percentile(boot, [2.5, 97.5], axis=0)
    return {
        "specification": (
            "within-layer standardized OLS: final_error_z = beta_D*CSD_z + "
            "beta_E*search_output_error_z; layer-cluster-robust inference"
        ),
        "layers": groups,
        "observations": observations,
        "beta_csd": float(beta[0]),
        "beta_output_error": float(beta[1]),
        "cluster_se_csd": float(standard_error[0]),
        "cluster_se_output_error": float(standard_error[1]),
        "p_two_sided_csd": float(p_value[0]),
        "p_two_sided_output_error": float(p_value[1]),
        "bootstrap_95_ci_csd": [float(intervals[0, 0]), float(intervals[1, 0])],
        "bootstrap_95_ci_output_error": [float(intervals[0, 1]), float(intervals[1, 1])],
    }


def summarize_mode(model, mode, layer_records):
    layer_stats = []
    selector_rows = []
    for layer, records in sorted(layer_records.items()):
        csd = np.asarray([item["candidate_csd"] for item in records], dtype=np.float64)
        final = np.asarray([item["final_output_rel_mse"] for item in records], dtype=np.float64)
        spearman = stats.spearmanr(csd, final).statistic
        pearson = stats.pearsonr(csd, final).statistic
        selected = select_indices(records)
        oracle = records[selected["candidate_grid_oracle"]]
        row = {
            "model": model,
            "mask_mode": mode,
            "linear": layer,
            "candidate_count": len(records),
            "spearman_rho": float(spearman),
            "pearson_r": float(pearson),
            "oracle_alpha": oracle["alpha"],
            "oracle_final_error": oracle["final_output_rel_mse"],
        }
        layer_stats.append(row)
        for selector, index in selected.items():
            item = records[index]
            absolute = item["final_output_rel_mse"] - oracle["final_output_rel_mse"]
            relative = absolute / max(oracle["final_output_rel_mse"], 1e-12)
            selector_rows.append(
                {
                    "model": model,
                    "mask_mode": mode,
                    "linear": layer,
                    "selector": selector,
                    "alpha": item["alpha"],
                    "final_output_rel_mse": item["final_output_rel_mse"],
                    "oracle_alpha": oracle["alpha"],
                    "oracle_final_output_rel_mse": oracle["final_output_rel_mse"],
                    "absolute_oracle_regret": absolute,
                    "relative_oracle_regret": relative,
                    "hits_oracle": bool(item["alpha"] == oracle["alpha"]),
                }
            )
    spearman_values = [item["spearman_rho"] for item in layer_stats]
    pearson_values = [item["pearson_r"] for item in layer_stats]
    selector_summary = {}
    for selector in SELECTORS:
        rows = [item for item in selector_rows if item["selector"] == selector]
        absolute = [item["absolute_oracle_regret"] for item in rows]
        relative = [item["relative_oracle_regret"] for item in rows]
        selector_summary[selector] = {
            "layers": len(rows),
            "oracle_hit_fraction": float(np.mean([item["hits_oracle"] for item in rows])),
            "median_absolute_oracle_regret": float(np.median(absolute)),
            "median_absolute_oracle_regret_bootstrap_95_ci": percentile_ci(absolute),
            "median_relative_oracle_regret": float(np.median(relative)),
            "median_relative_oracle_regret_bootstrap_95_ci": percentile_ci(relative),
            "mean_relative_oracle_regret": float(np.mean(relative)),
        }
    by_selector_layer = {
        (item["selector"], item["linear"]): item for item in selector_rows
    }
    outcomes = {"win": 0, "tie": 0, "loss": 0}
    for layer in layer_records:
        joint = by_selector_layer[("output_csd", layer)]["final_output_rel_mse"]
        output = by_selector_layer[("output_only", layer)]["final_output_rel_mse"]
        tolerance = max(1e-15, abs(output) * 1e-10)
        if joint < output - tolerance:
            outcomes["win"] += 1
        elif joint > output + tolerance:
            outcomes["loss"] += 1
        else:
            outcomes["tie"] += 1
    total = len(layer_records)
    comparison = {
        "joint_vs_output_only_counts": outcomes,
        "joint_win_fraction": outcomes["win"] / total,
        "joint_nonloss_fraction": (outcomes["win"] + outcomes["tie"]) / total,
    }
    summary = {
        "model": model,
        "mask_mode": mode,
        "layers": len(layer_records),
        "candidates": sum(len(records) for records in layer_records.values()),
        "correlation": {
            "median_within_layer_spearman": float(np.nanmedian(spearman_values)),
            "median_within_layer_spearman_bootstrap_95_ci": percentile_ci(spearman_values),
            "positive_spearman_layer_fraction": float(np.mean(np.asarray(spearman_values) > 0)),
            "median_within_layer_pearson": float(np.nanmedian(pearson_values)),
            "median_within_layer_pearson_bootstrap_95_ci": percentile_ci(pearson_values),
            "positive_pearson_layer_fraction": float(np.mean(np.asarray(pearson_values) > 0)),
        },
        "fixed_effect_regression": fixed_effect_regression(layer_records),
        "selectors": selector_summary,
        "joint_vs_output_only": comparison,
    }
    return summary, layer_stats, selector_rows


def zscore_rows(layer_records):
    rows = []
    for layer, records in layer_records.items():
        csd = np.asarray([item["candidate_csd"] for item in records], dtype=np.float64)
        final = np.asarray([item["final_output_rel_mse"] for item in records], dtype=np.float64)
        if csd.std() <= 0 or final.std() <= 0:
            continue
        z_csd = (csd - csd.mean()) / csd.std(ddof=0)
        z_final = (final - final.mean()) / final.std(ddof=0)
        for item, x, y in zip(records, z_csd, z_final):
            rows.append(
                {
                    "linear": layer,
                    "alpha": item["alpha"],
                    "csd_z": float(x),
                    "final_error_z": float(y),
                }
            )
    return rows


def plot_correlation(output_dir, mode, data):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), constrained_layout=True)
    for axis, model in zip(axes, ("1b", "8b")):
        rows = zscore_rows(data[model][mode])
        x = np.asarray([item["csd_z"] for item in rows])
        y = np.asarray([item["final_error_z"] for item in rows])
        axis.scatter(x, y, s=8, alpha=0.20, color="#1f77b4", edgecolors="none")
        edges = np.quantile(x, np.linspace(0, 1, 11))
        centers, medians = [], []
        for left, right in zip(edges[:-1], edges[1:]):
            chosen = (x >= left) & (x <= right)
            if chosen.any():
                centers.append(np.median(x[chosen]))
                medians.append(np.median(y[chosen]))
        axis.plot(centers, medians, "o-", color="#d62728", linewidth=1.5, markersize=3)
        axis.axhline(0, color="#777777", linewidth=0.5)
        axis.axvline(0, color="#777777", linewidth=0.5)
        axis.set_title("Llama 3.2 1B" if model == "1b" else "Llama 3 8B")
        axis.set_xlabel("Within-layer standardized CSD")
        axis.set_ylabel("Within-layer standardized final error")
        axis.grid(alpha=0.15, linewidth=0.5)
    name = "fixed_mask" if mode == "fixed_alpha0" else "reselected_mask"
    for suffix in ("pdf", "svg", "png"):
        fig.savefig(Path(output_dir) / f"csd_predictor_{name}.{suffix}", dpi=300)
    plt.close(fig)


def plot_regret(output_dir, mode, summaries):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), constrained_layout=True)
    selectors = ("no_scaling", "output_only", "csd_only", "output_csd")
    labels = ("No scale", "Output", "CSD", "Output+CSD")
    colors = ("#999999", "#4c78a8", "#f58518", "#54a24b")
    for axis, model in zip(axes, ("1b", "8b")):
        values, lower, upper = [], [], []
        for selector in selectors:
            item = summaries[model][mode]["selectors"][selector]
            value = item["median_relative_oracle_regret"]
            interval = item["median_relative_oracle_regret_bootstrap_95_ci"]
            values.append(value)
            lower.append(value - interval[0])
            upper.append(interval[1] - value)
        positions = np.arange(len(selectors))
        axis.bar(positions, values, color=colors, width=0.72)
        axis.errorbar(positions, values, yerr=[lower, upper], fmt="none", color="black", capsize=3, linewidth=0.8)
        axis.set_xticks(positions, labels, rotation=15, ha="right")
        axis.set_ylabel("Median relative oracle regret")
        axis.set_title("Llama 3.2 1B" if model == "1b" else "Llama 3 8B")
        axis.grid(axis="y", alpha=0.15, linewidth=0.5)
    name = "fixed_mask" if mode == "fixed_alpha0" else "reselected_mask"
    for suffix in ("pdf", "svg", "png"):
        fig.savefig(Path(output_dir) / f"oracle_regret_{name}.{suffix}", dpi=300)
    plt.close(fig)


def write_csv(path, rows):
    if not rows:
        return
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def execute(args):
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    selections = {
        "1b": read_json(args.selection_1b),
        "8b": read_json(args.selection_8b),
    }
    data = {model: {mode: {} for mode in MASK_MODES} for model in selections}
    candidate_rows = []
    for model, selection in selections.items():
        for name, entry in selection["candidate_sources"].items():
            source = read_json(entry["path"])
            alphas = sorted(float(item["alpha"]) for item in source["candidates"])
            for mode in MASK_MODES:
                records = []
                for alpha in alphas:
                    path = (
                        Path(args.run_dir)
                        / "units"
                        / model
                        / mode
                        / name
                        / f"alpha_{safe_token(alpha)}.json"
                    )
                    if not path.exists():
                        raise FileNotFoundError(path)
                    item = read_json(path)
                    if item.get("status") != "complete" or item.get("linear") != name:
                        raise RuntimeError(f"Invalid unit: {path}")
                    if not item["optimizer"]["loss_monotonic"]:
                        raise AssertionError(f"Non-monotonic unit: {path}")
                    if item["optimizer"]["rollback_reason"] == "non_finite_loss":
                        raise AssertionError(f"Non-finite rollback: {path}")
                    record = {
                        "model": model,
                        "mask_mode": mode,
                        "linear": name,
                        "alpha": float(item["alpha"]),
                        "candidate_output_rel_mse": float(item["candidate_output_rel_mse"]),
                        "candidate_csd": float(item["candidate_csd"]),
                        "regular_csd_post_outlier": float(item["regular_csd_post_outlier"]),
                        "final_j": float(item["final_j"]),
                        "final_output_rel_mse": float(item["final_output_rel_mse"]),
                        "outlier_agreement_with_fixed": float(item["outlier_agreement_with_fixed"]),
                        "rollback": bool(item["optimizer"]["rollback"]),
                        "rollback_reason": item["optimizer"]["rollback_reason"],
                        "unit_path": str(path.resolve()),
                    }
                    records.append(record)
                    candidate_rows.append(record)
                data[model][mode][name] = records

    summaries = {model: {} for model in selections}
    layer_rows, selector_rows = [], []
    for model in selections:
        for mode in MASK_MODES:
            summary, layers, selectors = summarize_mode(model, mode, data[model][mode])
            summaries[model][mode] = summary
            layer_rows.extend(layers)
            selector_rows.extend(selectors)
    if not args.skip_plots:
        for mode in MASK_MODES:
            plot_correlation(output_dir, mode, data)
            plot_regret(output_dir, mode, summaries)
    write_csv(output_dir / "candidate_results.csv", candidate_rows)
    write_csv(output_dir / "layer_correlations.csv", layer_rows)
    write_csv(output_dir / "selector_oracle_results.csv", selector_rows)
    payload = {
        "status": "complete",
        "joint_lambda": JOINT_LAMBDA,
        "lambda_protocol": (
            "lambda=0.3 inherited from the established 1B setup and applied unchanged to 8B"
        ),
        "mask_modes": {
            "fixed_alpha0": "main mechanism-isolation experiment",
            "reselect_post_scaling": "supplementary actual-algorithm experiment",
        },
        "summaries": summaries,
    }
    (output_dir / "results.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return payload


def build_parser():
    parser = argparse.ArgumentParser(description="Aggregate CSD predictor and candidate-grid oracle experiment")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--selection-1b", required=True)
    parser.add_argument("--selection-8b", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--skip-plots", action="store_true")
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
