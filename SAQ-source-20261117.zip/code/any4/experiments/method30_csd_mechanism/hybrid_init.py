import time

import numpy as np
import torch
from joblib import Parallel, delayed
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits

from method30_outlier_quant import (
    _initialize_weighted_centroids,
    _lloyd_assignment,
    _lloyd_loss,
    _normal_group_parameters,
)


def _compact_importance(scaled_fisher, outlier_mask, start, stop):
    full = scaled_fisher.reshape(1, -1).expand(stop - start, -1)
    return full[~outlier_mask[start:stop]].reshape(stop - start, -1).contiguous()


def gpu_compact_weighted_lloyd(
    normalized,
    scaled_fisher,
    outlier_mask,
    code_count=16,
    max_iter=10,
    tol=1e-4,
    chunk_rows=64,
    loss_increase_rtol=1e-6,
):
    rows, compact_cols = normalized.shape
    assignment = torch.empty(
        (rows, compact_cols), dtype=torch.long, device=normalized.device
    )
    lut = torch.empty(
        (rows, code_count), dtype=torch.float32, device=normalized.device
    )
    initial_numerator = 0.0
    final_numerator = 0.0
    total_importance = 0.0
    chunk_iterations = []
    monotonic = True
    started = time.perf_counter()

    for start in range(0, rows, int(chunk_rows)):
        stop = min(start + int(chunk_rows), rows)
        values = normalized[start:stop]
        importance = _compact_importance(
            scaled_fisher, outlier_mask, start, stop
        )
        empty = importance.sum(dim=1, keepdim=True) <= 0
        importance = torch.where(empty, torch.ones_like(importance), importance)
        centroids = _initialize_weighted_centroids(
            values, importance, code_count, "weighted_quantile"
        )
        labels = _lloyd_assignment(values, centroids)
        previous_loss = _lloyd_loss(values, importance, labels, centroids)
        initial_numerator += float(previous_loss.item())
        total_importance += float(importance.sum().item())
        accepted = 0

        for iteration in range(int(max_iter)):
            numerator = torch.zeros_like(centroids)
            denominator = torch.zeros_like(centroids)
            numerator.scatter_add_(1, labels, importance * values)
            denominator.scatter_add_(1, labels, importance)
            candidate = torch.where(
                denominator > 1e-12,
                numerator / denominator.clamp_min(1e-12),
                centroids,
            )
            candidate = torch.sort(candidate, dim=1).values
            candidate_labels = _lloyd_assignment(values, candidate)
            candidate_loss = _lloyd_loss(
                values, importance, candidate_labels, candidate
            )
            old_value = float(previous_loss.item())
            new_value = float(candidate_loss.item())
            allowed = max(1e-12, abs(old_value) * float(loss_increase_rtol))
            if new_value > old_value + allowed:
                monotonic = False
                break
            relative = (old_value - new_value) / max(abs(old_value), 1e-12)
            centroids = candidate
            labels = candidate_labels
            previous_loss = candidate_loss
            accepted = iteration + 1
            if relative <= float(tol):
                break

        assignment[start:stop] = labels
        lut[start:stop] = centroids
        final_numerator += float(previous_loss.item())
        chunk_iterations.append(accepted)

    denominator = max(total_importance, 1e-12)
    return assignment, lut, {
        "backend": "gpu_weighted_lloyd_initializer",
        "max_iter": int(max_iter),
        "chunk_rows": int(chunk_rows),
        "chunks": len(chunk_iterations),
        "iterations_min": min(chunk_iterations, default=0),
        "iterations_max": max(chunk_iterations, default=0),
        "iterations_mean": float(
            sum(chunk_iterations) / max(len(chunk_iterations), 1)
        ),
        "initial_normalized_loss": initial_numerator / denominator,
        "final_normalized_loss": final_numerator / denominator,
        "loss_monotonic": bool(monotonic),
        "seconds": float(time.perf_counter() - started),
    }


def _cpu_polish_row(
    values,
    fisher,
    positions,
    initial_centroids,
    groups,
    group_size,
    max_iter,
):
    fisher_grouped = fisher.reshape(groups, group_size)
    normal_mask = np.ones((groups, group_size), dtype=bool)
    normal_mask[np.arange(groups), positions.astype(np.int64)] = False
    sample_weight = fisher_grouped[normal_mask].reshape(-1).astype(np.float64)
    x = np.asarray(values, dtype=np.float64).reshape(-1, 1)
    initial = np.asarray(initial_centroids, dtype=np.float64).reshape(16, 1)
    initial_labels = np.abs(x - initial.reshape(1, 16)).argmin(axis=1)
    initial_values = initial.reshape(16)[initial_labels]
    initial_inertia = float(
        np.sum(sample_weight * (x.reshape(-1) - initial_values) ** 2)
    )
    if np.unique(x).size < 16:
        return initial_labels, initial.reshape(16), initial_inertia, initial_inertia, 0, True

    with threadpool_limits(limits=1):
        clusters = KMeans(
            n_clusters=16,
            init=initial,
            n_init=1,
            random_state=0,
            algorithm="lloyd",
            max_iter=int(max_iter),
            tol=1e-6,
        ).fit(x, sample_weight=sample_weight)
    final_inertia = float(clusters.inertia_)
    fallback = final_inertia > initial_inertia + max(
        1e-12, initial_inertia * 1e-8
    )
    if fallback:
        return (
            initial_labels,
            initial.reshape(16),
            initial_inertia,
            initial_inertia,
            int(clusters.n_iter_),
            True,
        )
    return (
        clusters.labels_.astype(np.int64),
        clusters.cluster_centers_.reshape(16),
        initial_inertia,
        final_inertia,
        int(clusters.n_iter_),
        False,
    )


def initialize_gpu_cpu(
    scaled_weight,
    scaled_fisher,
    outlier_mask,
    outlier_positions,
    group_size,
    parallel_jobs,
    gpu_iters,
    cpu_iters,
    gpu_chunk_rows=64,
):
    rows, cols = scaled_weight.shape
    groups = cols // group_size
    normalized, scales, offsets = _normal_group_parameters(
        scaled_weight, outlier_mask, group_size
    )
    _, gpu_lut, gpu_diagnostics = gpu_compact_weighted_lloyd(
        normalized,
        scaled_fisher,
        outlier_mask,
        max_iter=gpu_iters,
        chunk_rows=gpu_chunk_rows,
    )
    if scaled_weight.is_cuda:
        torch.cuda.synchronize()
    cpu_started = time.perf_counter()
    values_np = normalized.detach().cpu().float().numpy()
    fisher_np = scaled_fisher.detach().cpu().float().numpy()
    positions_np = outlier_positions.detach().cpu().numpy()
    centroids_np = gpu_lut.detach().cpu().float().numpy()
    results = Parallel(
        n_jobs=int(parallel_jobs),
        backend="loky",
        batch_size="auto",
        pre_dispatch="2*n_jobs",
    )(
        delayed(_cpu_polish_row)(
            values_np[row], fisher_np, positions_np[row], centroids_np[row],
            groups, group_size, cpu_iters
        )
        for row in range(rows)
    )
    compact_assignment = torch.from_numpy(
        np.stack([item[0] for item in results])
    ).to(device=scaled_weight.device, dtype=torch.long)
    lut = torch.from_numpy(np.stack([item[1] for item in results])).to(
        device=scaled_weight.device, dtype=torch.float32
    )
    assignment = torch.zeros_like(scaled_weight, dtype=torch.long)
    assignment[~outlier_mask] = compact_assignment.reshape(-1)
    initial_inertia = sum(item[2] for item in results)
    final_inertia = sum(item[3] for item in results)
    iterations = [item[4] for item in results]
    diagnostics = {
        "backend": "gpu_initializer_cpu_sklearn_polish",
        "normal_values_per_group": int(group_size - 1),
        "parallel_jobs": int(parallel_jobs),
        "gpu": gpu_diagnostics,
        "cpu": {
            "max_iter": int(cpu_iters),
            "tol": 1e-6,
            "n_init": 1,
            "seconds": float(time.perf_counter() - cpu_started),
            "initial_inertia": float(initial_inertia),
            "final_inertia": float(final_inertia),

            "relative_improvement": float(
                (initial_inertia - final_inertia)
                / max(abs(initial_inertia), 1e-12)
            ),
            "iterations_min": min(iterations, default=0),
            "iterations_max": max(iterations, default=0),
            "iterations_mean": float(
                sum(iterations) / max(len(iterations), 1)
            ),
            "fallback_rows": sum(bool(item[5]) for item in results),
        },
    }
    return assignment, lut, scales, offsets, diagnostics
