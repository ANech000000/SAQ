import argparse
import json
import math
import os
from collections import Counter
from pathlib import Path


MASK_MODES = ("fixed_alpha0", "reselect_post_scaling")
EXPECTED = {"1b": (96, 892), "8b": (192, 1718)}


def safe_token(value):
    return f"{float(value):.8f}".rstrip("0").rstrip(".").replace(".", "p")


def atomic_write_once(path, payload):
    path = Path(path)
    encoded = json.dumps(payload, indent=2) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != encoded:
            raise FileExistsError(f"Refusing to overwrite different validation: {path}")
        return
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(temporary, path)


def execute(args):
    run_dir = Path(args.run_dir)
    selections = {
        "1b": json.loads(Path(args.selection_1b).read_text(encoding="utf-8")),
        "8b": json.loads(Path(args.selection_8b).read_text(encoding="utf-8")),
    }
    report = {"status": "validating", "models": {}}
    total_units = 0
    for model, selection in selections.items():
        expected_layers, expected_candidates = EXPECTED[model]
        if len(selection["candidate_sources"]) != expected_layers:
            raise AssertionError(f"{model}: searchable layer count mismatch")
        if sum(int(item["candidate_count"]) for item in selection["candidate_sources"].values()) != expected_candidates:
            raise AssertionError(f"{model}: candidate count mismatch")
        model_fingerprints = set()
        rollback_reasons = Counter()
        reused_units = 0
        changed_reselect_candidates = 0
        unit_count = 0
        for name, entry in selection["candidate_sources"].items():
            source = json.loads(Path(entry["path"]).read_text(encoding="utf-8"))
            source_records = sorted(source["candidates"], key=lambda item: float(item["alpha"]))
            expected_alphas = [float(item["alpha"]) for item in source_records]
            expected_by_alpha = {float(item["alpha"]): item for item in source_records}
            fixed_hashes = set()
            mode_payloads = {}
            for mode in MASK_MODES:
                payloads = []
                for alpha in expected_alphas:
                    path = (
                        run_dir
                        / "units"
                        / model
                        / mode
                        / name
                        / f"alpha_{safe_token(alpha)}.json"
                    )
                    if not path.exists():
                        raise FileNotFoundError(path)
                    item = json.loads(path.read_text(encoding="utf-8"))
                    if item.get("status") != "complete" or item.get("linear") != name:
                        raise AssertionError(f"Invalid result unit: {path}")
                    if item.get("mask_mode") != mode or float(item["alpha"]) != alpha:
                        raise AssertionError(f"Unit identity mismatch: {path}")
                    source_record = expected_by_alpha[alpha]
                    if float(item["candidate_output_rel_mse"]) != float(source_record["output_rel_mse"]):
                        raise AssertionError(f"Candidate output error mismatch: {path}")
                    candidate_csd = float(source_record["shape_score"])
                    if float(item["candidate_csd"]) != candidate_csd:
                        raise AssertionError(f"Candidate CSD mismatch: {path}")
                    tolerance = max(2e-8, abs(candidate_csd) * 2e-5)
                    if abs(float(item["recomputed_csd"]) - candidate_csd) > tolerance:
                        raise AssertionError(f"Recomputed CSD mismatch: {path}")
                    finite_values = (
                        item["final_output_rel_mse"],
                        item["final_output_error_numerator"],
                        item["final_output_error_denominator"],
                        item["final_j"],
                        item["final_j_numerator"],
                        item["final_j_denominator"],
                        item["regular_csd_post_outlier"],
                    )
                    if not all(math.isfinite(float(value)) for value in finite_values):
                        raise AssertionError(f"Non-finite metric: {path}")
                    optimizer = item["optimizer"]
                    if not optimizer["loss_monotonic"]:
                        raise AssertionError(f"Non-monotonic loss: {path}")
                    if optimizer["rollback_reason"] == "non_finite_loss":
                        raise AssertionError(f"Non-finite rollback: {path}")
                    rollback_reasons[str(optimizer["rollback_reason"])] += int(bool(optimizer["rollback"]))
                    if float(item["exact_outlier_max_abs_error"]) != 0.0:
                        raise AssertionError(f"Inexact outlier: {path}")
                    rows, cols = (int(value) for value in entry["weight_shape"])
                    if int(item["outlier_groups"]) != rows * (cols // 128):
                        raise AssertionError(f"Outlier count mismatch: {path}")
                    candidate_source = item["layer_inputs"]["candidate_source"]
                    if candidate_source != entry:
                        raise AssertionError(f"Candidate provenance mismatch: {path}")
                    model_fingerprints.add(item["run_fingerprint"])
                    reused_units += int(bool(item.get("reused_identical_fixed_result", False)))
                    if mode == "fixed_alpha0":
                        fixed_hashes.add(item["outlier_positions_sha256"])
                    elif float(item["outlier_agreement_with_fixed"]) < 1.0:
                        changed_reselect_candidates += 1
                    payloads.append(item)
                    unit_count += 1
                mode_payloads[mode] = payloads
            if len(fixed_hashes) != 1:
                raise AssertionError(f"Fixed mask changed across candidates: {model} {name}")
            fixed0 = next(item for item in mode_payloads["fixed_alpha0"] if item["alpha"] == 0.0)
            reselected0 = next(item for item in mode_payloads["reselect_post_scaling"] if item["alpha"] == 0.0)
            if fixed0["outlier_positions_sha256"] != reselected0["outlier_positions_sha256"]:
                raise AssertionError(f"alpha=0 mask mismatch: {model} {name}")
        if len(model_fingerprints) != 1:
            raise AssertionError(f"{model}: multiple run fingerprints")
        expected_units = 2 * expected_candidates
        if unit_count != expected_units:
            raise AssertionError(f"{model}: result unit count mismatch")
        model_report = {
            "status": "complete",
            "searchable_layers": expected_layers,
            "candidate_count_per_mask": expected_candidates,
            "result_units": unit_count,
            "run_fingerprint": next(iter(model_fingerprints)),
            "rollback_reasons": dict(rollback_reasons),
            "reused_identical_fixed_units": reused_units,
            "changed_reselect_candidates": changed_reselect_candidates,
            "checks": {
                "candidate_coverage": True,
                "candidate_metrics_match_sources": True,
                "recomputed_csd_matches": True,
                "finite_metrics": True,
                "monotonic_losses": True,
                "no_nonfinite_rollback": True,
                "one_exact_outlier_per_group": True,
                "exact_outlier_zero_error": True,
                "fixed_mask_invariant_within_layer": True,
                "alpha0_masks_identical_across_modes": True,
                "single_run_fingerprint": True,
            },
        }
        report["models"][model] = model_report
        total_units += unit_count
    if total_units != 5220:
        raise AssertionError(f"Total unit count is {total_units}, expected 5220")
    report["status"] = "complete"
    report["total_result_units"] = total_units
    atomic_write_once(args.output, report)
    print(json.dumps(report, indent=2))
    return report


def build_parser():
    parser = argparse.ArgumentParser(description="Validate the complete CSD mechanism grid")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--selection-1b", required=True)
    parser.add_argument("--selection-8b", required=True)
    parser.add_argument("--output", required=True)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
