#!/usr/bin/env bash
set -euo pipefail

physical_gpu="${1:?physical GPU is required}"
cpu_set="${2:?CPU set is required}"
run=/data/lsz/any4/experiments/method30_csd_mechanism/runs/csd_predictor_20260808
runner=/data/lsz/any4/experiments/method30_csd_mechanism/candidate_runner.py
python=/data/lsz/any4/venv/bin/python

targets=(
  '92:model.layers.24.self_attn.k_proj'
  '93:model.layers.24.mlp.down_proj'
  '94:model.layers.24.self_attn.q_proj'
  '95:model.layers.24.mlp.up_proj'
)

for target in "${targets[@]}"; do
  shard_index="${target%%:*}"
  linear="${target#*:}"
  echo "EXTRA_HELPER_START gpu=$physical_gpu shard=$shard_index linear=$linear"
  CUDA_VISIBLE_DEVICES="$physical_gpu" taskset -c "$cpu_set" "$python" "$runner" \
    --model 8b \
    --model-path /data/model/models--meta-llama--Meta-Llama-3-8B \
    --selection /data/lsz/any4/experiments/method30_csd_ablation/runs/csd_selection_ablation_20260807/selections/8b.json \
    --fisher /data/lsz/any4/experiments/llama3_8b_reproduction/cache/fisher/wiki2_fisher_diag.pt \
    --calibration-cache /data/lsz/any4/experiments/llama3_8b_reproduction/cache/activations \
    --validation-cache "$run/validation_activations/8b" \
    --output-dir "$run" \
    --physical-gpu "$physical_gpu" \
    --shard-index "$shard_index" \
    --num-shards 100 \
    --only-linear "$linear" \
    --parallel-jobs 16
  echo "EXTRA_HELPER_DONE gpu=$physical_gpu shard=$shard_index linear=$linear"
done

echo "EXTRA_HELPER_COMPLETE gpu=$physical_gpu"
