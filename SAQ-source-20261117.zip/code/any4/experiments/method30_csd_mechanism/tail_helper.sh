#!/usr/bin/env bash
set -euo pipefail

worker="${1:?worker index is required}"
physical_gpu="${2:?physical GPU is required}"
cpu_set="${3:?CPU set is required}"

run=/data/lsz/any4/experiments/method30_csd_mechanism/runs/csd_predictor_20260808
runner=/data/lsz/any4/experiments/method30_csd_mechanism/candidate_runner.py
python=/data/lsz/any4/venv/bin/python
selection=/data/lsz/any4/experiments/method30_csd_ablation/runs/csd_selection_ablation_20260807/selections/8b.json
model=/data/model/models--meta-llama--Meta-Llama-3-8B
fisher=/data/lsz/any4/experiments/llama3_8b_reproduction/cache/fisher/wiki2_fisher_diag.pt
calibration=/data/lsz/any4/experiments/llama3_8b_reproduction/cache/activations
validation="$run/validation_activations/8b"

case "$worker" in
  0)
    targets=(
      '50:model.layers.26.self_attn.k_proj'
      '51:model.layers.27.self_attn.q_proj'
      '52:model.layers.28.mlp.down_proj'
      '53:model.layers.30.mlp.gate_proj'
      '54:model.layers.30.self_attn.v_proj'
      '55:model.layers.31.mlp.up_proj'
      '56:model.layers.31.self_attn.k_proj'
      '57:model.layers.26.mlp.gate_proj'
      '58:model.layers.26.self_attn.q_proj'
      '59:model.layers.27.mlp.gate_proj'
      '60:model.layers.27.self_attn.k_proj'
      '61:model.layers.27.self_attn.v_proj'
    )
    ;;
  1)
    targets=(
      '62:model.layers.28.mlp.up_proj'
      '63:model.layers.31.self_attn.q_proj'
      '64:model.layers.25.self_attn.v_proj'
      '65:model.layers.26.mlp.up_proj'
      '66:model.layers.28.mlp.gate_proj'
      '67:model.layers.28.self_attn.k_proj'
      '68:model.layers.29.mlp.down_proj'
      '69:model.layers.30.mlp.down_proj'
      '70:model.layers.30.self_attn.q_proj'
      '71:model.layers.25.mlp.gate_proj'
      '72:model.layers.27.mlp.down_proj'
      '73:model.layers.28.self_attn.q_proj'
    )
    ;;
  2)
    targets=(
      '74:model.layers.28.self_attn.v_proj'
      '75:model.layers.29.mlp.gate_proj'
      '76:model.layers.29.self_attn.k_proj'
      '77:model.layers.31.mlp.down_proj'
      '78:model.layers.29.mlp.up_proj'
      '79:model.layers.29.self_attn.q_proj'
      '80:model.layers.29.self_attn.v_proj'
      '81:model.layers.30.mlp.up_proj'
      '82:model.layers.30.self_attn.k_proj'
      '83:model.layers.31.mlp.gate_proj'
      '84:model.layers.31.self_attn.v_proj'
    )
    ;;
  3)
    targets=(
      '85:model.layers.25.self_attn.q_proj'
      '86:model.layers.25.self_attn.k_proj'
      '87:model.layers.25.mlp.up_proj'
      '88:model.layers.25.mlp.down_proj'
      '89:model.layers.26.self_attn.v_proj'
      '90:model.layers.26.mlp.down_proj'
      '91:model.layers.27.mlp.up_proj'
    )
    ;;
  *)
    echo "unknown worker: $worker" >&2
    exit 2
    ;;
esac

for target in "${targets[@]}"; do
  shard_index="${target%%:*}"
  linear="${target#*:}"
  echo "TAIL_HELPER_START worker=$worker gpu=$physical_gpu shard=$shard_index linear=$linear"
  CUDA_VISIBLE_DEVICES="$physical_gpu" taskset -c "$cpu_set" "$python" "$runner" \
    --model 8b \
    --model-path "$model" \
    --selection "$selection" \
    --fisher "$fisher" \
    --calibration-cache "$calibration" \
    --validation-cache "$validation" \
    --output-dir "$run" \
    --physical-gpu "$physical_gpu" \
    --shard-index "$shard_index" \
    --num-shards 100 \
    --only-linear "$linear" \
    --parallel-jobs 16
  echo "TAIL_HELPER_DONE worker=$worker gpu=$physical_gpu shard=$shard_index linear=$linear"
done

echo "TAIL_HELPER_COMPLETE worker=$worker gpu=$physical_gpu"
