import importlib.util
import sys
from pathlib import Path

import torch


ROOT = Path("/data/lsz/any4")
SEARCH_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, SEARCH_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def load_search_module():
    spec = importlib.util.spec_from_file_location(
        "cross_arch_full_search", SEARCH_DIR / "full_search.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PHI_LINEAR_TO_ACTIVATION = {
    "self_attn.q_proj": "qkv",
    "self_attn.k_proj": "qkv",
    "self_attn.v_proj": "qkv",
    "mlp.fc1": "mlp_in",
    "mlp.fc2": "mlp_out",
}


def load_generic_activations(cache_dir, block):
    values = {}
    for key in sorted(set(PHI_LINEAR_TO_ACTIVATION.values())):
        path = Path(cache_dir) / f"block_{int(block):03d}_{key}.pt"
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("block") != int(block) or payload.get("unit") != key:
            raise RuntimeError(f"Activation metadata mismatch: {path}")
        tensor = payload.get("x")
        if not isinstance(tensor, torch.Tensor) or tensor.ndim != 2:
            raise RuntimeError(f"Invalid activation tensor: {path}")
        values[key] = tensor.float().contiguous()
    return values


def main():
    search = load_search_module()
    search.LINEAR_TO_ACTIVATION = PHI_LINEAR_TO_ACTIVATION
    search.load_activations = load_generic_activations
    args = search.build_parser().parse_args()
    return search.execute(args)


if __name__ == "__main__":
    raise SystemExit(main())
