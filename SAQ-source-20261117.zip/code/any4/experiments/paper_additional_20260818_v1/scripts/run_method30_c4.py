import argparse
import importlib.util
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

ROOT = Path("/data/lsz/any4")
METHOD_DIR = ROOT / "experiments" / "method30"
for path in (ROOT, METHOD_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

spec = importlib.util.spec_from_file_location(
    "paper_method30_runner",
    METHOD_DIR / "runner.py",
)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

from data_gptq import llama_eval  # noqa: E402
from run_local_c4_ptb_ppl import load_c4_eval  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument(
        "--c4-dir",
        default="/data/lsz/llm_dataset/pretraining/C4",
    )
    parser.add_argument("--c4-eval-samples", type=int, default=256)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    def evaluate_c4(model, tokenizer, loader_samples, seqlen):
        del loader_samples
        testenc = load_c4_eval(
            args.c4_dir,
            tokenizer,
            seqlen,
            args.c4_eval_samples,
            args.seed,
        )
        return llama_eval(model, testenc, "cuda:0", seqlen=seqlen)

    run_args = runner.build_parser().parse_args([])
    run_args.output = args.output
    run_args.physical_gpu = args.physical_gpu
    run_args.parallel_jobs = 16
    runner.evaluate_wiki2 = evaluate_c4

    try:
        result = runner.execute(run_args)
    except Exception as error:
        runner.mark_failed(args.output, error)
        raise

    summary = {
        "status": "complete",
        "model_path": result["model_path"],
        "method": "method30_no_exact_outlier",
        "dataset": "c4",
        "seqlen": result["seqlen"],
        "eval_samples": args.c4_eval_samples,
        "c4_ppl": result["wiki2_ppl"],
        "source_result": str(Path(args.output).resolve()),
    }
    summary_path = Path(args.output).with_name("c4_summary.json")
    summary_path.write_text(
        json.dumps(summary, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
