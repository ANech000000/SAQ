import argparse
import importlib.util
import json
import sys
from pathlib import Path


ROOT = Path("/data/lsz/any4")
OUTLIER_DIR = ROOT / "experiments" / "method30_outlier"
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
for path in (ROOT, OUTLIER_DIR, REFINE_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from state_cache import safe_layer_name, save_state_cache


def load_runner():
    spec = importlib.util.spec_from_file_location(
        "paper_group_state_runner", OUTLIER_DIR / "runner.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    wrapper = argparse.ArgumentParser(add_help=False)
    wrapper.add_argument("--state-cache-root", required=True)
    wrapper.add_argument("--layer-order-results", required=True)
    wrapper_args, runner_argv = wrapper.parse_known_args()

    runner = load_runner()
    runner_args = runner.build_parser().parse_args(runner_argv)
    previous = json.loads(Path(wrapper_args.layer_order_results).read_text())
    layer_names = list(previous["layers"])
    if not layer_names:
        raise ValueError("Layer order is empty")
    cache_root = Path(wrapper_args.state_cache_root)
    original = runner.method30_reconstruct_tensor
    counter = {"value": 0}

    def reconstruct_and_save(*args, **kwargs):
        result = original(*args, **kwargs)
        if len(result) != 3:
            raise RuntimeError("Expected reconstruct_tensor to return state")
        reconstructed, diagnostics, state = result
        # The outlier runner returns the optimized tensors only.  The packed
        # checkpoint cache also needs the static reconstruction inputs that the
        # post-AWQ refiner normally attaches to its state.
        weight = args[0] if args else kwargs["weight"]
        channel_scale = args[1] if len(args) > 1 else kwargs["channel_scale"]
        group_size = kwargs.get("group_size", 128)
        state = dict(state)
        state["weight_shape"] = list(weight.shape)
        state["group_size"] = int(group_size)
        state["channel_scale"] = channel_scale.detach().float()
        index = counter["value"]
        if index >= len(layer_names):
            raise RuntimeError("Reconstructed more layers than expected")
        layer_name = layer_names[index]
        metadata = {
            "method": "paper_group_size_state_cache_v1",
            "model_path": runner_args.model_path,
            "layer_name": layer_name,
            "weight_shape": list(state["weight_shape"]),
            "group_size": int(state["group_size"]),
            "checkpoint": 10,
        }
        destination = (
            cache_root / safe_layer_name(layer_name) / "iter_0010.pt"
        )
        save_state_cache(destination, metadata, state)
        counter["value"] += 1
        print(
            f"state-cache [{counter['value']}/{len(layer_names)}] {layer_name}",
            flush=True,
        )
        return reconstructed, diagnostics, state

    runner.method30_reconstruct_tensor = reconstruct_and_save
    result = runner.execute(runner_args)
    if counter["value"] != len(layer_names):
        raise RuntimeError(
            f"Saved {counter['value']} states, expected {len(layer_names)}"
        )
    return result


if __name__ == "__main__":
    raise SystemExit(main())
