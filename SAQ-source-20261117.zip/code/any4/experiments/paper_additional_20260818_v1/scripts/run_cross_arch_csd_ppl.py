import argparse
import importlib.util
import sys
from pathlib import Path

import torch


ROOT = Path("/data/lsz/any4")
OUTLIER_DIR = ROOT / "experiments" / "method30_outlier"
SEARCH_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
for path in (ROOT, OUTLIER_DIR, SEARCH_DIR, METHOD24_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method24_shape import build_awq_scale


ARCHITECTURES = {
    "qwen2": {
        "mapping": {
            "self_attn.q_proj": "qkv",
            "self_attn.k_proj": "qkv",
            "self_attn.v_proj": "qkv",
            "mlp.gate_proj": "gate_up",
            "mlp.up_proj": "gate_up",
            "mlp.down_proj": "down",
        },
        "fallbacks": {"self_attn.o_proj"},
        "cache_kind": "legacy",
    },
    "gemma2": {
        "mapping": {
            "self_attn.q_proj": "qkv",
            "self_attn.k_proj": "qkv",
            "self_attn.v_proj": "qkv",
            "mlp.gate_proj": "gate_up",
            "mlp.up_proj": "gate_up",
            "mlp.down_proj": "down",
        },
        "fallbacks": {"self_attn.o_proj"},
        "cache_kind": "legacy",
    },
    "phi": {
        "mapping": {
            "self_attn.q_proj": "qkv",
            "self_attn.k_proj": "qkv",
            "self_attn.v_proj": "qkv",
            "mlp.fc1": "mlp_in",
            "mlp.fc2": "mlp_out",
        },
        "fallbacks": {"self_attn.dense"},
        "cache_kind": "generic",
    },
}


def load_runner():
    spec = importlib.util.spec_from_file_location(
        "cross_arch_outlier_runner", OUTLIER_DIR / "runner.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def generic_activations(cache_dir, block, mapping):
    values = {}
    for key in sorted(set(mapping.values())):
        path = Path(cache_dir) / f"block_{int(block):03d}_{key}.pt"
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("block") != int(block) or payload.get("unit") != key:
            raise RuntimeError(f"Activation metadata mismatch: {path}")
        values[key] = payload["x"].float().contiguous()
    return values


def main():
    wrapper = argparse.ArgumentParser(add_help=False)
    wrapper.add_argument("--architecture", choices=tuple(ARCHITECTURES), required=True)
    wrapper_args, runner_argv = wrapper.parse_known_args()

    runner = load_runner()
    args = runner.build_parser().parse_args(runner_argv)
    architecture = ARCHITECTURES[wrapper_args.architecture]
    mapping = architecture["mapping"]
    fallbacks = architecture["fallbacks"]

    selection = __import__("json").loads(Path(args.alpha_selection_path).read_text())
    alpha_count = len(selection["selected_alphas"][args.alpha_key])
    fisher_payload = torch.load(args.fisher_path, map_location="cpu", weights_only=False)
    fisher_count = len(fisher_payload["fisher"])
    fallback_count = fisher_count - alpha_count
    if fallback_count <= 0:
        raise RuntimeError("No fallback Linear layers were found")

    runner.base.EXPECTED_ALPHA_COUNT = alpha_count
    runner.base.EXPECTED_LINEAR_COUNT = fisher_count
    runner.base.EXPECTED_FALLBACK_COUNT = fallback_count
    runner.base.LINEAR_TO_ACTIVATION = mapping

    def validate_sources(model, alphas, fisher, group_size):
        linears = [
            (name, module)
            for name, module in model.named_modules()
            if isinstance(module, torch.nn.Linear) and name != "lm_head"
        ]
        names = {name for name, _ in linears}
        searchable = set()
        fallback = set()
        for name, module in linears:
            _, local = runner.base.layer_and_local_name(name)
            if local in mapping:
                searchable.add(name)
            elif local in fallbacks:
                fallback.add(name)
            else:
                raise ValueError(f"No alpha policy for {name}")
            if module.weight.shape[1] % group_size:
                raise ValueError(f"{name} width is not divisible by G={group_size}")
        if len(linears) != fisher_count or len(fallback) != fallback_count:
            raise ValueError("Linear coverage count mismatch")
        if set(alphas) != searchable:
            raise ValueError("Alpha coverage mismatch")
        if set(fisher) != names:
            raise ValueError("Fisher coverage mismatch")
        for name, module in linears:
            if fisher[name].numel() != module.weight.shape[1]:
                raise ValueError(f"Fisher width mismatch: {name}")
        return linears, searchable, fallback

    def build_channel_scale(full_name, module, alphas, activations):
        _, local = runner.base.layer_and_local_name(full_name)
        if full_name not in alphas:
            if local not in fallbacks:
                raise ValueError(f"Missing alpha: {full_name}")
            return torch.ones(module.weight.shape[1], dtype=torch.float32), 0.0
        activation = activations[mapping[local]]
        if activation.shape[1] != module.weight.shape[1]:
            raise ValueError(f"Activation width mismatch: {full_name}")
        alpha = float(alphas[full_name])
        scale = build_awq_scale(activation.abs().mean(dim=0), alpha)
        return scale.detach().cpu().float(), alpha

    runner.base.validate_sources = validate_sources
    runner.base.build_channel_scale = build_channel_scale
    if architecture["cache_kind"] == "generic":
        runner.load_activations = lambda cache_dir, block: generic_activations(
            cache_dir, block, mapping
        )
    return runner.execute(args)


if __name__ == "__main__":
    raise SystemExit(main())
