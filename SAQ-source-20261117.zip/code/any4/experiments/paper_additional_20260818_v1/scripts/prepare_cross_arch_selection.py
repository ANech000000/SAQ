import argparse
import collections
import hashlib
import json
import os
from pathlib import Path


JOINT_LAMBDA = 0.3


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def select(records):
    baseline = next(item for item in records if float(item["alpha"]) == 0.0)
    error0 = max(float(baseline["output_rel_mse"]), 1e-12)
    csd0 = max(float(baseline["shape_score"]), 1e-12)
    chosen = min(
        records,
        key=lambda item: (
            float(item["output_rel_mse"]) / error0
            + JOINT_LAMBDA * float(item["shape_score"]) / csd0,
            float(item["output_rel_mse"]),
            float(item["alpha"]),
        ),
    )
    return {
        "alpha": float(chosen["alpha"]),
        "output_rel_mse": float(chosen["output_rel_mse"]),
        "csd": float(chosen["shape_score"]),
        "output_ratio_vs_alpha0": float(chosen["output_rel_mse"]) / error0,
        "csd_ratio_vs_alpha0": float(chosen["shape_score"]) / csd0,
        "joint_objective": (
            float(chosen["output_rel_mse"]) / error0
            + JOINT_LAMBDA * float(chosen["shape_score"]) / csd0
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-key", required=True)
    parser.add_argument("--search-results", nargs="+", required=True)
    parser.add_argument("--expected-linears", type=int, required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    searches = []
    linears = {}
    model_path = None
    group_size = None
    for source_name in args.search_results:
        source_path = Path(source_name).resolve()
        source = json.loads(source_path.read_text(encoding="utf-8"))
        if source.get("status") != "complete":
            raise RuntimeError(f"Incomplete search: {source_path}")
        if model_path is None:
            model_path = source["model_path"]
            group_size = int(source["group_size"])
        elif source["model_path"] != model_path or int(source["group_size"]) != group_size:
            raise RuntimeError("Search shards have incompatible provenance")
        overlap = set(linears) & set(source["linears"])
        if overlap:
            raise RuntimeError(f"Duplicate linears: {sorted(overlap)[:3]}")
        linears.update(source["linears"])
        searches.append({"path": str(source_path), "sha256": sha256(source_path)})
    if len(linears) != args.expected_linears:
        raise RuntimeError(f"Expected {args.expected_linears} linears, found {len(linears)}")

    selected = {}
    diagnostics = {}
    candidate_sources = {}
    histogram = collections.Counter()
    for name, entry in sorted(linears.items()):
        unit_path = Path(entry["unit_file"]).resolve()
        unit = json.loads(unit_path.read_text(encoding="utf-8"))
        if unit.get("status") != "complete" or unit.get("linear") != name:
            raise RuntimeError(f"Invalid candidate unit: {unit_path}")
        records = unit["candidates"]
        choice = select(records)
        selected[name] = choice["alpha"]
        diagnostics[name] = choice
        histogram[str(choice["alpha"])] += 1
        candidate_sources[name] = {
            "path": str(unit_path),
            "sha256": sha256(unit_path),
            "candidate_count": len(records),
            "weight_shape": list(unit["weight_shape"]),
        }

    payload = {
        "schema_version": 1,
        "status": "complete",
        "model_key": args.model_key,
        "model_path": model_path,
        "group_size": group_size,
        "searchable_linears": len(linears),
        "selection_protocol": {
            "strategy": "output_csd",
            "joint_lambda": JOINT_LAMBDA,
            "objective": "E(alpha)/E(0) + 0.3*CSD(alpha)/CSD(0)",
        },
        "source_searches": searches,
        "alpha_histogram": dict(sorted(histogram.items(), key=lambda item: float(item[0]))),
        "selected_alphas": {"output_csd": selected},
        "diagnostics": {"output_csd": diagnostics},
        "candidate_sources": candidate_sources,
    }
    atomic_json(args.output, payload)
    print(json.dumps({
        "status": "complete",
        "model_key": args.model_key,
        "searchable_linears": len(linears),
        "alpha_histogram": payload["alpha_histogram"],
        "output": str(Path(args.output).resolve()),
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
