import argparse
import json
import sys
from pathlib import Path


PACKED_DIR = Path(
    "/data/lsz/any4/experiments/method30_outlier/packed_runtime"
)
if str(PACKED_DIR) not in sys.path:
    sys.path.insert(0, str(PACKED_DIR))

from packed_format import (
    FORMAT_NAME,
    FORMAT_VERSION,
    atomic_write_json,
    export_layer,
    safe_layer_name,
    utc_now,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-state-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--group-size", type=int, required=True)
    parser.add_argument("--metadata-dtype", choices=("fp16", "mixed", "fp32"), default="fp16")
    parser.add_argument("--expected-linears", type=int, default=112)
    args = parser.parse_args()

    manifest_path = args.output_dir / "manifest.json"
    if manifest_path.exists():
        raise FileExistsError(manifest_path)
    sources = sorted(args.source_state_root.glob("*/iter_0010.pt"))
    if len(sources) != args.expected_linears:
        raise RuntimeError(
            f"Expected {args.expected_linears} source states, found {len(sources)}"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    layers = []
    components = {}
    for index, source in enumerate(sources, 1):
        import torch

        payload = torch.load(source, map_location="cpu", weights_only=False)
        layer_name = payload["metadata"]["layer_name"]
        state_group_size = int(payload["state"]["group_size"])
        if state_group_size != args.group_size:
            raise ValueError(
                f"{layer_name}: state G={state_group_size}, expected {args.group_size}"
            )
        output = args.output_dir / f"{safe_layer_name(layer_name)}.safetensors"
        if output.exists():
            raise FileExistsError(output)
        record = export_layer(source, output, args.metadata_dtype)
        layers.append(record)
        for key, value in record["components_bytes"].items():
            components[key] = components.get(key, 0) + int(value)
        print(f"[{index}/{len(sources)}] {layer_name}", flush=True)

    total_weights = sum(item["weight_count"] for item in layers)
    tensor_bytes = sum(item["tensor_bytes"] for item in layers)
    file_bytes = sum(item["file_bytes"] for item in layers)
    manifest = {
        "format": FORMAT_NAME,
        "format_version": FORMAT_VERSION,
        "status": "complete",
        "method": "method30_post_awq_22a_group_ablation",
        "model_path": args.model_path,
        "source_state_root": str(args.source_state_root),
        "metadata_dtype": args.metadata_dtype,
        "linears": len(layers),
        "group_size": args.group_size,
        "lut_entries": 16,
        "normal_values_per_group": args.group_size - 1,
        "total_quantized_weights": total_weights,
        "components_bytes": components,
        "tensor_bytes": tensor_bytes,
        "physical_layer_file_bytes": file_bytes,
        "tensor_bpw": 8.0 * tensor_bytes / total_weights,
        "physical_layer_file_bpw": 8.0 * file_bytes / total_weights,
        "created_at": utc_now(),
        "layers": layers,
    }
    atomic_write_json(manifest_path, manifest)
    print(json.dumps({
        "group_size": manifest["group_size"],
        "linears": manifest["linears"],
        "tensor_bpw": manifest["tensor_bpw"],
        "physical_layer_file_bpw": manifest["physical_layer_file_bpw"],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
