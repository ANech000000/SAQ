import argparse
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path("/data/lsz/any4")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders, llama_eval
from pre_process.awq.quantizer import pseudo_quantize_tensor


@torch.no_grad()
def quantize_rtn(model, group_size):
    count = 0
    for name, module in model.named_modules():
        if not isinstance(module, nn.Linear) or name == "lm_head":
            continue
        module.weight.data = pseudo_quantize_tensor(
            module.weight.data,
            n_bit=4,
            zero_point=True,
            q_group_size=group_size,
        ).to(module.weight.dtype)
        count += 1
    return count


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    args = parser.parse_args()

    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    ).to("cuda")
    model.eval()
    linear_count = quantize_rtn(model, args.group_size)
    quantized_at = time.perf_counter()

    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=args.seqlen,
        nsamples=args.loader_samples,
    )
    ppl = float(llama_eval(model, testloader, "cuda", seqlen=args.seqlen))
    finished = time.perf_counter()
    result = {
        "status": "complete",
        "method": "RTN",
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "weight_bits": 4,
        "activation_bits": 16,
        "group_size": args.group_size,
        "zero_point": True,
        "lm_head_quantized": False,
        "linear_count": linear_count,
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "ppl": ppl,
        "quantization_seconds": quantized_at - started,
        "evaluation_seconds": finished - quantized_at,
        "total_seconds": finished - started,
    }
    atomic_json(args.output, result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
