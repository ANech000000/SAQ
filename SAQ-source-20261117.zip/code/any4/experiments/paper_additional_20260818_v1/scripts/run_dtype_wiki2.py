import argparse
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path("/data/lsz/any4")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders, llama_eval


DTYPES = {
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
    "float32": torch.float32,
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--dtype", choices=tuple(DTYPES), required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    args = parser.parse_args()

    output = Path(args.output)
    if output.exists():
        raise FileExistsError(output)
    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=DTYPES[args.dtype],
        device_map=None,
        low_cpu_mem_usage=True,
    ).to("cuda")
    model.eval()
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=args.seqlen,
        nsamples=args.loader_samples,
    )
    ppl = float(llama_eval(model, testloader, "cuda", seqlen=args.seqlen))
    result = {
        "status": "complete",
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "dtype": args.dtype,
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "ppl": ppl,
        "seconds": time.perf_counter() - started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, output)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
