import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path("/data/lsz/any4")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders


ARCH_UNITS = {
    "phi": {
        "qkv": "self_attn.q_proj",
        "mlp_in": "mlp.fc1",
        "mlp_out": "mlp.fc2",
    },
    "qwen2": {
        "qkv": "self_attn.q_proj",
        "gate_up": "mlp.gate_proj",
        "down": "mlp.down_proj",
    },
    "gemma2": {
        "qkv": "self_attn.q_proj",
        "gate_up": "mlp.gate_proj",
        "down": "mlp.down_proj",
    },
}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--token-start", type=int, default=4096)
    parser.add_argument("--sequence-length", type=int, default=512)
    parser.add_argument("--validation-tokens", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20260808)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "manifest.json"
    if manifest_path.exists():
        raise FileExistsError(manifest_path)

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True, use_fast=False
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map={"": "cuda:0"},
        low_cpu_mem_usage=True,
    ).eval()
    model_type = str(model.config.model_type)
    if model_type not in ARCH_UNITS:
        raise ValueError(f"Unsupported model_type={model_type!r}")
    representatives = ARCH_UNITS[model_type]
    layers = model.model.layers
    modules = dict(model.named_modules())

    _, testenc = get_loaders(
        "wikitext-2", tokenizer=tokenizer, nsamples=1, seed=args.seed,
        seqlen=args.sequence_length,
    )
    stop = args.token_start + args.sequence_length
    input_ids = testenc.input_ids[:, args.token_start:stop].contiguous()
    if input_ids.shape[1] != args.sequence_length:
        raise ValueError("Validation interval exceeds WikiText-2 tokens")
    chosen = torch.linspace(
        0, args.sequence_length - 1, steps=args.validation_tokens
    ).round().long()

    captured = {}
    handles = []
    for block in range(len(layers)):
        prefix = f"model.layers.{block}"
        for unit, local_name in representatives.items():
            name = f"{prefix}.{local_name}"
            if name not in modules:
                raise KeyError(name)

            def hook(_module, inputs, _output, name=name):
                value = inputs[0].detach().reshape(-1, inputs[0].shape[-1])
                captured[name] = value.index_select(
                    0, chosen.to(value.device)
                ).float().cpu().contiguous()

            handles.append(modules[name].register_forward_hook(hook))

    started = time.perf_counter()
    try:
        model(input_ids.to("cuda:0"), use_cache=False)
    finally:
        for handle in handles:
            handle.remove()

    outputs = []
    for block in range(len(layers)):
        prefix = f"model.layers.{block}"
        for unit, local_name in representatives.items():
            name = f"{prefix}.{local_name}"
            tensor = captured[name]
            path = output_dir / f"block_{block:03d}_{unit}.pt"
            if path.exists():
                raise FileExistsError(path)
            temporary = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
            torch.save(
                {
                    "method": "cross_arch_validation_activations_v1",
                    "model_path": str(Path(args.model_path).resolve()),
                    "model_type": model_type,
                    "dataset": "wikitext-2-raw-v1",
                    "block": block,
                    "unit": unit,
                    "representative": name,
                    "actual_width": int(tensor.shape[1]),
                    "x": tensor,
                },
                temporary,
            )
            os.replace(temporary, path)
            outputs.append({
                "path": str(path.resolve()),
                "block": block,
                "unit": unit,
                "representative": name,
                "shape": list(tensor.shape),
                "sha256": sha256(path),
            })

    manifest = {
        "status": "complete",
        "model_path": str(Path(args.model_path).resolve()),
        "model_type": model_type,
        "dataset": "wikitext-2-raw-v1",
        "token_start": args.token_start,
        "sequence_length": args.sequence_length,
        "validation_tokens": args.validation_tokens,
        "representatives": representatives,
        "files": outputs,
        "seconds": time.perf_counter() - started,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "complete",
        "model_type": model_type,
        "files": len(outputs),
        "seconds": manifest["seconds"],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
