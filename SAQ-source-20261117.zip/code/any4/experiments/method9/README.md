# Method9: Fisher-Weighted Any4

Uses the original Any4 4bit scikit kmeans path, but changes the row-wise kmeans sample weight to a SqueezeLLM-style Fisher proxy:

```
sample_weight = E[input^2] * (weight != 0)
```

`E[input^2]` is collected by `calibrate(square=True)`. The experiment runs WikiText-2 PPL on one visible empty GPU.
