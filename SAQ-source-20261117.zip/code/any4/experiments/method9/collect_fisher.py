import argparse
import gc
import json
import os
import subprocess
import sys
from pathlib import Path

import torch
from tqdm import tqdm

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders
from run_wiki2_ppl import load_model_and_tokenizer
from utils import get_lm_head_from_model, remove_all_hooks


EXP_DIR = Path(__file__).resolve().parent
CONFIG = json.loads((EXP_DIR / "config.json").read_text())


def check_single_empty_gpu(max_used_mib):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    if visible and len([x for x in visible.split(",") if x.strip()]) != 1:
        raise SystemExit("Fisher collection requires exactly one visible GPU.")
    try:
        output = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=index,memory.used", "--format=csv,noheader,nounits"],
            text=True,
        )
    except Exception as exc:
        print(f"Warning: unable to verify empty GPU with nvidia-smi: {exc}")
        return
    rows = [line.strip().split(",") for line in output.splitlines() if line.strip()]
    if visible:
        gpu_index = visible.split(",")[0].strip()
    else:
        if len(rows) != 1:
            raise SystemExit("Set CUDA_VISIBLE_DEVICES to one empty GPU before collecting Fisher.")
        gpu_index = rows[0][0].strip()
    used_by_index = {idx.strip(): int(used.strip()) for idx, used in rows}
    used = used_by_index.get(gpu_index)
    if used is None:
        raise SystemExit(f"CUDA_VISIBLE_DEVICES={gpu_index} was not found by nvidia-smi.")
    if used > max_used_mib:
        raise SystemExit(f"GPU {gpu_index} is not empty enough: {used} MiB used > {max_used_mib} MiB.")


def collect_activation_hessian_diag(model, tokenizer, nsamples, seqlen, seed, skip_modules):
    sums = {}
    counts = {}

    def make_hook(name):
        def hook(module, inputs, output):
            x = inputs[0] if isinstance(inputs, (tuple, list)) else inputs
            x = x.detach().float()
            x = x.reshape(-1, x.shape[-1])
            x2 = torch.nan_to_num(x.pow(2), nan=0.0, posinf=0.0, neginf=0.0).sum(dim=0).cpu()
            if name not in sums:
                sums[name] = x2
                counts[name] = x.shape[0]
            else:
                sums[name].add_(x2)
                counts[name] += x.shape[0]
        return hook

    handles = []
    for name, module in model.named_modules():
        if isinstance(module, torch.nn.Linear) and name not in skip_modules and module not in skip_modules:
            handles.append(module.register_forward_hook(make_hook(name)))

    trainloader, _ = get_loaders("wikitext-2", tokenizer=tokenizer, nsamples=nsamples, seed=seed, seqlen=seqlen)
    model.eval()
    with torch.no_grad():
        for inp, _ in tqdm(trainloader, desc="Collecting Fisher diag", unit="sample"):
            inp = inp.to(model.device)
            model(inp)
            del inp
            torch.cuda.empty_cache()

    for handle in handles:
        handle.remove()
    remove_all_hooks(model)

    fisher = {name: (sums[name] / max(counts[name], 1)).float() for name in sums}
    return fisher, counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--output", default=CONFIG["fisher"]["path"])
    parser.add_argument("--nsamples", type=int, default=CONFIG["fisher"]["nsamples"])
    parser.add_argument("--seqlen", type=int, default=CONFIG["fisher"]["seqlen"])
    parser.add_argument("--seed", type=int, default=CONFIG["fisher"]["seed"])
    parser.add_argument("--max-empty-memory-mib", type=int, default=CONFIG["gpu_policy"]["max_empty_memory_mib"])
    args = parser.parse_args()

    check_single_empty_gpu(args.max_empty_memory_mib)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)

    model, tokenizer = load_model_and_tokenizer(args.model_path, torch.float16)
    lm_head = get_lm_head_from_model(model)
    skip_modules = [lm_head, "lm_head"]
    fisher, counts = collect_activation_hessian_diag(model, tokenizer, args.nsamples, args.seqlen, args.seed, skip_modules)

    payload = {
        "metadata": {
            "kind": "activation_hessian_diagonal",
            "model_path": args.model_path,
            "dataset": "wikitext-2-raw-v1",
            "nsamples": args.nsamples,
            "seqlen": args.seqlen,
            "seed": args.seed,
            "skip_modules": ["lm_head"],
            "note": "Per Linear input Hessian/Fisher diagonal E[x^2], suitable as Any4 kmeans sample_weight.",
        },
        "fisher": fisher,
        "counts": counts,
    }
    torch.save(payload, output)
    summary = {
        "output": str(output),
        "num_layers": len(fisher),
        "total_values": int(sum(v.numel() for v in fisher.values())),
        "layers": {name: list(t.shape) for name, t in fisher.items()},
    }
    (output.parent / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))

    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
