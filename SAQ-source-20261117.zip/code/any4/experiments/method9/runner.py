import argparse
import gc
import json
import os
import subprocess
import sys
from pathlib import Path

import torch

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from calibrate import calibrate
from quantize import quant_methods, quantize_model
from run_wiki2_ppl import eval_wiki2, load_model_and_tokenizer


EXP_DIR = Path(__file__).resolve().parent
CONFIG = json.loads((EXP_DIR / "config.json").read_text())
RUN_DIR = EXP_DIR / "runs" / "wiki2_ppl"


def check_single_empty_gpu(max_used_mib):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    if visible and len([x for x in visible.split(",") if x.strip()]) != 1:
        raise SystemExit("Method9 runner requires exactly one visible GPU.")
    try:
        output = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=index,memory.used",
                "--format=csv,noheader,nounits",
            ],
            text=True,
        )
    except Exception as exc:
        print(f"Warning: unable to verify empty GPU with nvidia-smi: {exc}")
        return
    rows = [line.strip().split(",") for line in output.splitlines() if line.strip()]
    if visible:
        gpu_index = visible.split(",")[0].strip()
    else:
        if len(rows) != 1:
            raise SystemExit("Set CUDA_VISIBLE_DEVICES to one empty GPU before running method9.")
        gpu_index = rows[0][0].strip()
    used_by_index = {idx.strip(): int(used.strip()) for idx, used in rows}
    used = used_by_index.get(gpu_index)
    if used is None:
        raise SystemExit(f"CUDA_VISIBLE_DEVICES={gpu_index} was not found by nvidia-smi.")
    if used > max_used_mib:
        raise SystemExit(f"GPU {gpu_index} is not empty enough: {used} MiB used > {max_used_mib} MiB.")


def load_fisher_sample_weight(path):
    if not path:
        return None
    payload = torch.load(path, map_location="cpu")
    if isinstance(payload, dict) and "fisher" in payload:
        return payload["fisher"]
    return payload


def run(args):
    model, tokenizer = load_model_and_tokenizer(args.model_path, torch.float16)
    fisher_sample_weight = load_fisher_sample_weight(args.fisher_path) if args.fisher_path else calibrate
    calibrate_args = {} if args.fisher_path else dict(CONFIG["calibrate_args"])
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=quant_methods["anyq"],
        tokenizer=tokenizer,
        calibrate_args=calibrate_args,
        n_bit=CONFIG["n_bit"],
        group_size=CONFIG["group_size"],
        skip_modules=CONFIG["skip_modules"],
        sample_weight=fisher_sample_weight,
        fisher_sample_weight=CONFIG["fisher_sample_weight"],
        scale_sample_weight=CONFIG["scale_sample_weight"],
        cluster_row=CONFIG["cluster_row"],
    )
    model.eval()
    ppl = eval_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()
    return ppl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--seqlen", type=int, default=CONFIG["seqlen"])
    parser.add_argument("--loader-samples", type=int, default=CONFIG["loader_samples"])
    parser.add_argument("--output", default=str(RUN_DIR / "results.json"))
    parser.add_argument("--fisher-path", default=CONFIG.get("fisher", {}).get("path"))
    args = parser.parse_args()

    check_single_empty_gpu(CONFIG["gpu_policy"]["max_empty_memory_mib"])
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)

    results = {
        "method_name": CONFIG["method_name"],
        "model_path": args.model_path,
        "dataset": CONFIG["dataset"],
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "quant_args": {
            "n_bit": CONFIG["n_bit"],
            "group_size": CONFIG["group_size"],
            "cluster_row": CONFIG["cluster_row"],
            "fisher_sample_weight": CONFIG["fisher_sample_weight"],
            "scale_sample_weight": CONFIG["scale_sample_weight"],
            "calibrate_args": CONFIG["calibrate_args"],
            "fisher_path": args.fisher_path,
        },
        "baselines": CONFIG["baselines"],
    }
    ppl = run(args)
    results["method9_4bit_ppl"] = float(ppl)
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
