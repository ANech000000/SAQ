"""Evaluate the cached 8B Post-AWQ 22A model on the remaining Table-1 tasks."""

import argparse
import gc
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTHONUNBUFFERED", "1")

import torch


ROOT = Path("/data/lsz/any4")
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
REPRO_DIR = ROOT / "experiments" / "llama3_8b_reproduction"
for path in (ROOT, REFINE_DIR, REPRO_DIR):
    sys.path.insert(0, str(path))

import eval_suite as eight
import runner_any4_table as table


DEFAULT_OUTPUT = REPRO_DIR / "runs" / "table1_postawq_22a"
DEFAULT_PPL = REPRO_DIR / "runs" / "ppl" / "postawq_22a.json"


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--physical-gpu", default="6")
    parser.add_argument("--model-path", default=eight.CONFIG["model_path"])
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--ppl-result", default=str(DEFAULT_PPL))
    parser.add_argument("--stats-bundle", default=eight.CONFIG["paths"]["stats_bundle"])
    parser.add_argument("--state-cache-dir", default=eight.CONFIG["paths"]["state_cache"])
    parser.add_argument("--checkpoint", type=int, default=10)
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--harness-batch-size", type=int, default=8)
    parser.add_argument(
        "--tasks",
        nargs="+",
        default=("mmlu", "hellaswag", "gsm8k", "bbh"),
    )
    return parser


def initial_result(args):
    ppl = json.loads(Path(args.ppl_result).read_text())
    source = ppl["metrics"]
    return {
        "status": "restoring_postawq_22a",
        "method": "postawq_22a",
        "model_path": args.model_path,
        "physical_gpu": str(args.physical_gpu),
        "checkpoint": args.checkpoint,
        "limit": args.limit,
        "tasks": [
            "wikitext2", "c4", "ptb", "codeparrot", "humaneval", "mbpp",
            *args.tasks,
        ],
        "protocol": {
            "ppl": "reused from llama3_8b_reproduction/runs/ppl/postawq_22a.json",
            "remaining_tasks": "same local evaluator and fixed settings as Table-1 baselines",
        },
        "metrics": {
            "wikitext2": source["wiki2"],
            "c4": source["c4"],
            "ptb": source["ptb"],
        },
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def main():
    args = build_parser().parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "results.json"
    if result_path.exists():
        result = json.loads(result_path.read_text())
        if result.get("status") == "complete":
            print(json.dumps(result, indent=2), flush=True)
            return
    else:
        result = initial_result(args)
        table.atomic_write_json(result_path, result)

    model, tokenizer, cache_info = eight.apply_postawq_cache(args)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    result["cache"] = cache_info
    table.atomic_write_json(result_path, result)

    table._run_code(args, result_path, result, model, tokenizer)
    table._run_harness(args, result_path, result, model, tokenizer)
    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    table.atomic_write_json(result_path, result)
    print(json.dumps(result["metrics"], indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
