import argparse
import gc
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

EXP_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in EXP_DIR.parents
    if (parent / "quantize.py").exists()
)
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
for path in (ROOT, REFINE_DIR):
    sys.path.insert(0, str(path))

from calibrate import calibrate
from data_gptq import get_loaders, llama_eval
from experiment_runtime import build_run_identity, layer_metadata
from method30_refine import reconstruct_from_state
from quantize import quant_methods, quantize_model
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test
from state_cache import atomic_write_json, cache_file, load_state_cache
from stats_bundle import load_stats_bundle, validate_bundle_model

CONFIG = json.loads((EXP_DIR / "config.json").read_text())


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(index):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}"
        )
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    used, utilization = (
        int(value.strip())
        for value in output.strip().split(",")
    )
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(
            f"GPU {index} is not empty: "
            f"{used} MiB, {utilization}%"
        )
    return {
        "memory_used_mib": used,
        "utilization_percent": utilization,
    }


def load_model(model_path, device):
    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    if device:
        model.to(device)
    return model.eval(), tokenizer


def apply_postawq_cache(args):
    bundle = load_stats_bundle(args.stats_bundle)
    model, tokenizer = load_model(args.model_path, None)
    linears = validate_bundle_model(
        model, bundle, args.group_size
    )
    identity_args = SimpleNamespace(
        model_path=args.model_path,
        stats_bundle=args.stats_bundle,
        group_size=args.group_size,
        parallel_jobs=args.parallel_jobs,
        initializer="sklearn",
        gpu_iters=10,
        cpu_iters=10,
        gpu_chunk_rows=64,
        relative_tol=1e-6,
        ridge=1e-6,
        scale_eps=1e-6,
        chunk_rows=128,
        importance_chunk_rows=512,
        loss_increase_rtol=1e-7,
    )
    identity, fingerprint = build_run_identity(
        identity_args, args.stats_bundle
    )
    started = time.perf_counter()
    for index, (name, module, stats) in enumerate(
        linears, 1
    ):
        metadata = layer_metadata(
            identity, name, stats, args.checkpoint
        )
        path = cache_file(
            args.state_cache_dir,
            fingerprint,
            name,
            args.checkpoint,
        )
        state, _ = load_state_cache(path, metadata)
        source = module.weight.detach().to("cuda:0")
        reconstructed = reconstruct_from_state(
            source, state
        ).detach().cpu().to(module.weight.dtype)
        module.weight.data.copy_(reconstructed)
        print(
            f"[{index}/{len(linears)}] restored {name}",
            flush=True,
        )
        del source, reconstructed, state
        next_block = (
            int(linears[index][2]["block"])
            if index < len(linears)
            else None
        )
        if int(stats["block"]) != next_block:
            torch.cuda.empty_cache()
            gc.collect()
    model.to("cuda:0").eval()
    return model, tokenizer, {
        "fingerprint": fingerprint,
        "linears": len(linears),
        "apply_seconds": time.perf_counter() - started,
    }


def evaluate_all(model, tokenizer, args, result, output):
    metrics = result.setdefault("metrics", {})
    if "wiki2" not in metrics:
        _, testenc = get_loaders(
            "wikitext-2",
            tokenizer=tokenizer,
            seed=args.seed,
            seqlen=args.seqlen,
            nsamples=128,
        )
        started = time.perf_counter()
        value = float(
            llama_eval(
                model, testenc, "cuda", seqlen=args.seqlen
            )
        )
        metrics["wiki2"] = {
            "ppl": value,
            "segments": int(
                testenc.input_ids.numel() // args.seqlen
            ),
            "evaluation_seconds": (
                time.perf_counter() - started
            ),
        }
        atomic_write_json(output, result)
        print(f"WikiText-2 PPL={value:.10f}", flush=True)
        del testenc
    if "c4" not in metrics:
        testenc = load_c4_eval(
            args.c4_dir,
            tokenizer,
            args.seqlen,
            args.c4_eval_samples,
            args.seed,
        )
        started = time.perf_counter()
        value = float(
            llama_eval(
                model, testenc, "cuda", seqlen=args.seqlen
            )
        )
        metrics["c4"] = {
            "ppl": value,
            "segments": int(
                testenc.input_ids.numel() // args.seqlen
            ),
            "evaluation_seconds": (
                time.perf_counter() - started
            ),
        }
        atomic_write_json(output, result)
        print(f"C4 PPL={value:.10f}", flush=True)
        del testenc
        torch.cuda.empty_cache()
    if "ptb" not in metrics:
        testenc = load_ptb_test(
            args.ptb_dir, tokenizer, args.seqlen
        )
        started = time.perf_counter()
        value = float(
            llama_eval(
                model, testenc, "cuda", seqlen=args.seqlen
            )
        )
        metrics["ptb"] = {
            "ppl": value,
            "segments": int(
                testenc.input_ids.numel() // args.seqlen
            ),
            "evaluation_seconds": (
                time.perf_counter() - started
            ),
        }
        atomic_write_json(output, result)
        print(f"PTB PPL={value:.10f}", flush=True)
        del testenc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--method",
        choices=("fp16", "original_any4", "postawq_22a"),
        required=True,
    )
    parser.add_argument(
        "--model-path", default=CONFIG["model_path"]
    )
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument(
        "--output-dir",
        default=CONFIG["paths"]["eval_results"],
    )
    parser.add_argument(
        "--stats-bundle",
        default=CONFIG["paths"]["stats_bundle"],
    )
    parser.add_argument(
        "--state-cache-dir",
        default=CONFIG["paths"]["state_cache"],
    )
    parser.add_argument("--checkpoint", type=int, default=10)
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument(
        "--c4-eval-samples", type=int, default=256
    )
    parser.add_argument(
        "--c4-dir", default=CONFIG["paths"]["c4"]
    )
    parser.add_argument(
        "--ptb-dir", default=CONFIG["paths"]["ptb"]
    )
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    os.environ["HF_DATASETS_CACHE"] = (
        CONFIG["paths"]["dataset_cache"]
    )

    gpu_before = assert_empty_gpu(args.physical_gpu)
    output = (
        Path(args.output_dir) / f"{args.method}.json"
    )
    if output.exists():
        result = json.loads(output.read_text())
        if result.get("status") == "complete":
            print(json.dumps(result, indent=2))
            return
    else:
        result = {
            "status": "running",
            "method": args.method,
            "model_path": args.model_path,
            "dtype": "torch.float16",
            "gpu_before": gpu_before,
            "protocol": {
                "seqlen": args.seqlen,
                "c4_samples": args.c4_eval_samples,
                "seed": args.seed,
            },
            "metrics": {},
        }
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(output, result)

    started = time.perf_counter()
    if args.method == "postawq_22a":
        model, tokenizer, cache_info = apply_postawq_cache(
            args
        )
        result["cache"] = cache_info
    else:
        model, tokenizer = load_model(
            args.model_path, "cuda:0"
        )
        if args.method == "original_any4":
            quant_started = time.perf_counter()
            model = quantize_model(
                model,
                layer_from=torch.nn.Linear,
                layer_to=quant_methods["anyq"],
                tokenizer=tokenizer,
                n_bit=4,
                group_size=args.group_size,
                skip_modules="lm_head",
                sample_weight=calibrate,
                scale_sample_weight=True,
                parallelize=True,
                parallel_jobs=args.parallel_jobs,
                parallel_backend="loky",
                parallel_inner_threads=1,
                memory_cleanup_interval=7,
            )
            result["quantization_seconds"] = (
                time.perf_counter() - quant_started
            )
            atomic_write_json(output, result)
    evaluate_all(
        model, tokenizer, args, result, output
    )
    result["status"] = "complete"
    result["wall_seconds"] = (
        time.perf_counter() - started
    )
    atomic_write_json(output, result)
    print(json.dumps(result, indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
