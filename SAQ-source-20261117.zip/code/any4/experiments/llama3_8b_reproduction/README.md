# Llama-3-8B Any4 Reproduction

This directory is isolated from the existing 1B experiments. It reproduces
FP16, original Any4, and the selected 10-iteration Post-AWQ 22A method on
WikiText-2, C4, and PTB.

The Post-AWQ chain is:

1. collect 256-token method27 activation caches and 128x2048 Fisher diagonals;
2. run the historical method25/27 true-Any4 alpha candidate search;
3. select alpha with the method27 lambda=0.3 objective;
4. build a dynamic 224-Linear stats bundle (192 searched, 32 o_proj alpha=0);
5. run the pure-sklearn initializer and 10 alternating iterations;
6. reconstruct from final-state cache and evaluate all three PPL datasets.

All commands must expose exactly one verified empty physical GPU.
