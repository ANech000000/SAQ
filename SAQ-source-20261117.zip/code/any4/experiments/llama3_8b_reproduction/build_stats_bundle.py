import argparse
import json
import os
import sys
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM

EXP_DIR = Path(__file__).resolve().parent
ROOT = next(
    parent for parent in EXP_DIR.parents
    if (parent / "quantize.py").exists()
)
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, REFINE_DIR, METHOD24_DIR, METHOD25_DIR):
    sys.path.insert(0, str(path))

from layer_timing import LINEAR_TO_ACTIVATION, load_activations
from method24_shape import build_awq_scale
from state_cache import file_sha256, tensor_sha256

CONFIG = json.loads((EXP_DIR / "config.json").read_text())


def load_alpha(path):
    payload = json.loads(Path(path).read_text())
    values = payload.get("selected_alphas", {}).get(
        "method27_lambda_0p3"
    )
    if not isinstance(values, dict) or not values:
        raise ValueError("Missing method27_lambda_0p3 alpha selection")
    return {name: float(value) for name, value in values.items()}


def load_fisher(path):
    payload = torch.load(
        path, map_location="cpu", weights_only=False
    )
    fisher = payload.get("fisher")
    if not isinstance(fisher, dict):
        raise ValueError(
            "Fisher payload does not contain a dictionary"
        )
    return {
        name: torch.as_tensor(value).float().contiguous()
        for name, value in fisher.items()
    }


def layer_parts(name):
    parts = name.split(".")
    return int(parts[2]), ".".join(parts[3:])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument(
        "--alpha-selection",
        default=CONFIG["paths"]["alpha_selection"],
    )
    parser.add_argument(
        "--activation-cache",
        default=CONFIG["paths"]["activation_cache"],
    )
    parser.add_argument(
        "--fisher", default=CONFIG["paths"]["fisher"]
    )
    parser.add_argument(
        "--output", default=CONFIG["paths"]["stats_bundle"]
    )
    parser.add_argument("--group-size", type=int, default=128)
    args = parser.parse_args()

    output = Path(args.output)
    if output.exists():
        raise FileExistsError(
            f"Refusing to overwrite stats bundle: {output}"
        )
    alphas = load_alpha(args.alpha_selection)
    fisher = load_fisher(args.fisher)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    ).eval()
    linears = [
        (name, module)
        for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    ]
    searchable = {
        name for name, _ in linears
        if layer_parts(name)[1] in LINEAR_TO_ACTIVATION
    }
    fallback = {
        name for name, _ in linears
        if layer_parts(name)[1] == "self_attn.o_proj"
    }
    if searchable != set(alphas):
        missing = sorted(searchable - set(alphas))
        extra = sorted(set(alphas) - searchable)
        raise ValueError(
            f"Alpha coverage mismatch: missing={missing[:3]}, "
            f"extra={extra[:3]}"
        )
    if set(fisher) != {name for name, _ in linears}:
        raise ValueError(
            "Fisher coverage does not match transformer Linears"
        )

    layers = {}
    current_block = None
    activations = None
    for index, (name, module) in enumerate(linears, 1):
        block, local_name = layer_parts(name)
        if block != current_block:
            activations = load_activations(
                args.activation_cache, block
            )
            current_block = block
        if name in alphas:
            alpha = alphas[name]
            activation = activations[
                LINEAR_TO_ACTIVATION[local_name]
            ]
            if activation.shape[1] != module.weight.shape[1]:
                raise ValueError(
                    f"Activation width mismatch for {name}"
                )
            channel_scale = build_awq_scale(
                activation.abs().mean(dim=0), alpha
            ).cpu().float().contiguous()
            alpha_source = "method27_lambda_0p3"
        elif name in fallback:
            alpha = 0.0
            channel_scale = torch.ones(
                module.weight.shape[1], dtype=torch.float32
            )
            alpha_source = "o_proj_alpha0_fallback"
        else:
            raise ValueError(f"No alpha policy for {name}")

        source = module.weight.detach().cpu().contiguous()
        layer_fisher = fisher[name]
        if (
            source.shape[1] % args.group_size
            or layer_fisher.numel() != source.shape[1]
        ):
            raise ValueError(
                f"Invalid group or Fisher width for {name}"
            )
        layers[name] = {
            "weight_shape": list(source.shape),
            "weight_dtype": str(source.dtype),
            "weight_sha256": tensor_sha256(source),
            "channel_scale": channel_scale,
            "channel_scale_sha256": tensor_sha256(channel_scale),
            "fisher": layer_fisher,
            "fisher_sha256": tensor_sha256(layer_fisher),
            "alpha": float(alpha),
            "alpha_source": alpha_source,
            "block": int(block),
            "local_name": local_name,
        }
        print(
            f"[{index}/{len(linears)}] prepared {name}",
            flush=True,
        )

    metadata = {
        "model_path": str(Path(args.model_path).resolve()),
        "alpha_selection_path": str(
            Path(args.alpha_selection).resolve()
        ),
        "alpha_key": "method27_lambda_0p3",
        "alpha_selection_sha256": file_sha256(
            args.alpha_selection
        ),
        "activation_cache": str(
            Path(args.activation_cache).resolve()
        ),
        "fisher_path": str(Path(args.fisher).resolve()),
        "fisher_sha256": file_sha256(args.fisher),
        "group_size": int(args.group_size),
        "outlier_selection_domain": "post_awq",
        "outlier_rule": (
            "max_abs_first_tie_scaled_post_awq"
        ),
        "linears": len(linears),
        "searchable_linears": len(searchable),
        "fallback_linears": len(fallback),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(
        output.name + f".tmp.{os.getpid()}"
    )
    torch.save(
        {
            "schema_version": 1,
            "metadata": metadata,
            "layers": layers,
        },
        temporary,
    )
    os.replace(temporary, output)
    print(json.dumps({
        "output": str(output),
        "linears": metadata["linears"],
        "searchable_linears": metadata["searchable_linears"],
        "fallback_linears": metadata["fallback_linears"],
    }, indent=2))


if __name__ == "__main__":
    main()
