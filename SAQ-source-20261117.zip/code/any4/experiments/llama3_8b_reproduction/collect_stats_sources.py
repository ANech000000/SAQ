import argparse
import gc
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders
from pre_process.awq.calib_data import get_calib_dataset

CONFIG = json.loads((EXP_DIR / "config.json").read_text())
REPRESENTATIVES = {
    "self_attn.q_proj": ("self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj"),
    "self_attn.o_proj": ("self_attn.o_proj",),
    "mlp.gate_proj": ("mlp.gate_proj", "mlp.up_proj"),
    "mlp.down_proj": ("mlp.down_proj",),
}


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(index):
        raise RuntimeError(f"Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}")
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    used, utilization = (int(value.strip()) for value in output.strip().split(","))
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(
            f"GPU {index} is not empty: {used} MiB, {utilization}% utilization"
        )
    return {"memory_used_mib": used, "utilization_percent": utilization}


def activation_paths(cache_dir, block):
    prefix = f"model.layers.{block}"
    root = Path(cache_dir)
    return {
        "qkv": root / (
            f"{prefix}.self_attn.q_proj__{prefix}.self_attn.k_proj__"
            f"{prefix}.self_attn.v_proj_256_2048.pt"
        ),
        "gate_up": root / (
            f"{prefix}.mlp.gate_proj__{prefix}.mlp.up_proj_256_2048.pt"
        ),
        # The historical method27 loader hard-codes this suffix. The payload
        # records and validates the actual Llama-3-8B width (14336).
        "down": root / f"{prefix}.mlp.down_proj_256_8192.pt",
    }


def validate_model_linears(model):
    linears = {
        name: module
        for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    }
    expected = len(model.model.layers) * 7
    if len(linears) != expected:
        raise ValueError(f"Expected {expected} transformer Linears, got {len(linears)}")
    return linears


def representative_names(model):
    return [
        f"model.layers.{block}.{local_name}"
        for block in range(len(model.model.layers))
        for local_name in REPRESENTATIVES
    ]


@torch.no_grad()
def collect_search_activations(
    model, tokenizer, cache_dir, samples, seqlen, limit, batch_size
):
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    calibration = get_calib_dataset(
        data="wikitext2",
        tokenizer=tokenizer,
        n_samples=samples,
        block_size=seqlen,
    )
    if not calibration:
        raise ValueError("AWQ activation calibration returned no token blocks")
    block_count = len(calibration)
    total_tokens = sum(
        int(item.numel()) for item in calibration
    )
    selected_global = torch.linspace(
        0, total_tokens - 1, steps=limit
    ).round().long()
    selected = {}
    active_positions = None

    def make_hook(name):
        def hook(module, inputs, output):
            x = inputs[0].detach().reshape(-1, inputs[0].shape[-1])
            chosen = x.index_select(
                0, active_positions.to(x.device)
            ).float().cpu()
            selected.setdefault(name, []).append(chosen)
        return hook

    modules = dict(model.named_modules())
    handles = [
        modules[name].register_forward_hook(make_hook(name))
        for name in representative_names(model)
    ]
    started = time.perf_counter()
    try:
        for start in range(0, block_count, batch_size):
            stop = min(start + batch_size, block_count)
            ids = torch.cat(calibration[start:stop], dim=0)
            token_start = start * seqlen
            token_stop = stop * seqlen
            mask = (
                (selected_global >= token_start)
                & (selected_global < token_stop)
            )
            active_positions = selected_global[mask] - token_start
            if active_positions.numel():
                model(ids.to("cuda:0"), use_cache=False)
            print(f"activation block {stop}/{block_count}", flush=True)
    finally:
        for handle in handles:
            handle.remove()

    tensors = {
        name: torch.cat(parts, dim=0).contiguous()
        for name, parts in selected.items()
    }
    for name, tensor in tensors.items():
        if tensor.shape[0] != limit or not torch.isfinite(tensor).all():
            raise ValueError(
                f"Invalid activation cache for {name}: {tuple(tensor.shape)}"
            )

    for block in range(len(model.model.layers)):
        prefix = f"model.layers.{block}"
        payloads = {
            "qkv": tensors[f"{prefix}.self_attn.q_proj"],
            "gate_up": tensors[f"{prefix}.mlp.gate_proj"],
            "down": tensors[f"{prefix}.mlp.down_proj"],
        }
        for key, path in activation_paths(cache_dir, block).items():
            if path.exists():
                old = torch.load(
                    path, map_location="cpu", weights_only=False
                )
                if not torch.equal(old.get("x"), payloads[key]):
                    raise RuntimeError(
                        f"Existing activation cache differs: {path}"
                    )
                continue
            torch.save(
                {
                    "method": "llama3_8b_method27_activation_cache",
                    "model_path": CONFIG["model_path"],
                    "block": block,
                    "unit": key,
                    "source_samples": samples,
                    "source_blocks": block_count,
                    "source_tokens": total_tokens,
                    "source_seqlen": seqlen,
                    "search_tokens": limit,
                    "actual_width": int(payloads[key].shape[1]),
                    "x": payloads[key],
                },
                path,
            )
    return {
        "seconds": time.perf_counter() - started,
        "representative_tensors": len(tensors),
    }


@torch.no_grad()
def collect_fisher(model, tokenizer, output, nsamples, seqlen, seed):
    modules = dict(model.named_modules())
    sums = {}
    counts = {}

    def make_hook(name):
        def hook(module, inputs, result):
            x = inputs[0].detach().float().reshape(
                -1, inputs[0].shape[-1]
            )
            value = torch.nan_to_num(
                x.square(), nan=0.0, posinf=0.0, neginf=0.0
            ).sum(dim=0).cpu()
            if name in sums:
                sums[name].add_(value)
                counts[name] += x.shape[0]
            else:
                sums[name] = value
                counts[name] = x.shape[0]
        return hook

    representatives = representative_names(model)
    handles = [
        modules[name].register_forward_hook(make_hook(name))
        for name in representatives
    ]
    trainloader, _ = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        nsamples=nsamples,
        seed=seed,
        seqlen=seqlen,
    )
    started = time.perf_counter()
    try:
        for index, (input_ids, _) in enumerate(trainloader, 1):
            model(input_ids.to("cuda:0"), use_cache=False)
            if index % 16 == 0:
                reserved = torch.cuda.memory_reserved()
                allocated = torch.cuda.memory_allocated()
                if reserved - allocated > 4 * 1024**3:
                    torch.cuda.empty_cache()
            print(f"fisher sample {index}/{nsamples}", flush=True)
    finally:
        for handle in handles:
            handle.remove()

    fisher = {}
    fisher_counts = {}
    layers = len(model.model.layers)
    for block in range(layers):
        prefix = f"model.layers.{block}"
        for representative, aliases in REPRESENTATIVES.items():
            source_name = f"{prefix}.{representative}"
            value = (
                sums[source_name] / max(counts[source_name], 1)
            ).float().contiguous()
            for alias in aliases:
                name = f"{prefix}.{alias}"
                fisher[name] = value.clone()
                fisher_counts[name] = int(counts[source_name])
    expected = layers * 7
    if len(fisher) != expected or any(
        not torch.isfinite(value).all() for value in fisher.values()
    ):
        raise ValueError(f"Invalid Fisher coverage: {len(fisher)} != {expected}")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(
            f"Refusing to overwrite Fisher cache: {output}"
        )
    torch.save(
        {
            "metadata": {
                "kind": "activation_hessian_diagonal",
                "model_path": CONFIG["model_path"],
                "dataset": "wikitext-2-raw-v1",
                "nsamples": nsamples,
                "seqlen": seqlen,
                "seed": seed,
                "representative_hook_deduplication": REPRESENTATIVES,
            },
            "fisher": fisher,
            "counts": fisher_counts,
        },
        output,
    )
    return {
        "seconds": time.perf_counter() - started,
        "linears": len(fisher),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument(
        "--activation-cache",
        default=CONFIG["paths"]["activation_cache"],
    )
    parser.add_argument(
        "--fisher-output", default=CONFIG["paths"]["fisher"]
    )
    parser.add_argument("--activation-batch-size", type=int, default=8)
    parser.add_argument("--skip-activations", action="store_true")
    parser.add_argument("--skip-fisher", action="store_true")
    args = parser.parse_args()

    before = assert_empty_gpu(args.physical_gpu)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    ).to("cuda:0").eval()
    validate_model_linears(model)
    result = {"model_path": args.model_path, "gpu_before": before}
    if not args.skip_activations:
        result["activations"] = collect_search_activations(
            model,
            tokenizer,
            args.activation_cache,
            CONFIG["activation_samples"],
            CONFIG["activation_seqlen"],
            CONFIG["activation_search_tokens"],
            args.activation_batch_size,
        )
    if not args.skip_fisher:
        result["fisher"] = collect_fisher(
            model,
            tokenizer,
            args.fisher_output,
            CONFIG["fisher_samples"],
            CONFIG["fisher_seqlen"],
            CONFIG["seed"],
        )
    summary = EXP_DIR / "runs" / "stats_sources.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
