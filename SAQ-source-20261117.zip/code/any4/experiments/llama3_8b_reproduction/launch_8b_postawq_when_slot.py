"""Start the 8B Post-AWQ evaluation on GPU 6 when one of three slots is free."""

import os
import subprocess
import time
from pathlib import Path


RUNNER = "/data/lsz/any4/experiments/llama3_8b_reproduction/runner_8b_postawq_table.py"
PYTHON = "/home/ubuntu/anaconda3/envs/verl/bin/python"
PYTHONPATH = "/data/lsz/any4/venv/lib/python3.10/site-packages"
OUTPUT = Path(
    "/data/lsz/any4/experiments/llama3_8b_reproduction/runs/"
    "table1_postawq_22a"
)


def active_table_jobs():
    output = subprocess.run(
        ["pgrep", "-af", "runner_any4_table_baselines.py|runner_8b_postawq_table.py"],
        text=True,
        capture_output=True,
        check=False,
    ).stdout
    return sum(
        "python" in line and "pgrep -af" not in line
        for line in output.splitlines()
    )


def gpu6_free():
    output = subprocess.check_output(
        [
            "nvidia-smi", "--id=6",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    ).strip()
    used, utilization = (int(value.strip()) for value in output.split(","))
    return used <= 256 and utilization <= 5


def log(message):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}", flush=True)


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    while active_table_jobs() >= 3 or not gpu6_free():
        log(f"waiting: active_table_jobs={active_table_jobs()}, gpu6_free={gpu6_free()}")
        time.sleep(60)
    log("slot available; starting 8B Post-AWQ 22A on GPU 6")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "6"
    env["PYTHONPATH"] = PYTHONPATH
    os.execve(
        "/usr/bin/taskset",
        [
            "taskset", "-c", "32-47", PYTHON, RUNNER,
            "--physical-gpu", "6",
            "--output-dir", str(OUTPUT),
        ],
        env,
    )


if __name__ == "__main__":
    main()
