import argparse
import json
from pathlib import Path


def select(records, regularization):
    baseline = next(
        record for record in records
        if float(record["alpha"]) == 0.0
    )
    error0 = max(float(baseline["output_rel_mse"]), 1e-12)
    shape0 = max(float(baseline["shape_score"]), 1e-12)

    def objective(record):
        return (
            float(record["output_rel_mse"]) / error0
            + regularization * float(record["shape_score"]) / shape0
        )

    best = min(
        records,
        key=lambda record: (
            objective(record),
            float(record["alpha"]),
        ),
    )
    return best, objective(best)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--search-results", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--regularization", type=float, default=0.3)
    args = parser.parse_args()

    source = json.loads(Path(args.search_results).read_text())
    if source.get("status") != "complete":
        raise RuntimeError("Alpha search is not complete")
    key = "method27_lambda_0p3"
    selected = {}
    diagnostics = {}
    for name, entry in source["linears"].items():
        unit = json.loads(Path(entry["unit_file"]).read_text())
        best, objective = select(
            unit["candidates"], args.regularization
        )
        selected[name] = float(best["alpha"])
        diagnostics[name] = {
            "alpha": float(best["alpha"]),
            "objective": float(objective),
            "output_rel_mse": float(best["output_rel_mse"]),
            "shape_score": float(best["shape_score"]),
        }
    payload = {
        "status": "complete",
        "search": (
            "method27_lambda_retune_from_cached_true_any4_candidates"
        ),
        "model_path": source["model_path"],
        "group_size": source["group_size"],
        "source_search": str(Path(args.search_results).resolve()),
        "methods": {
            key: (
                "normalized output error + 0.3 * "
                "normalized shape score"
            )
        },
        "selected_alphas": {key: selected},
        "diagnostics": {key: diagnostics},
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({
        "output": str(output),
        "selected": len(selected),
    }, indent=2))


if __name__ == "__main__":
    main()
