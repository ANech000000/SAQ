import argparse
import gc
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
BASE_DIR = ROOT / "experiments" / "method30"
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

_base_spec = importlib.util.spec_from_file_location(
    "method30_base_runner",
    BASE_DIR / "runner.py",
)
base = importlib.util.module_from_spec(_base_spec)
sys.path.insert(0, str(BASE_DIR))
try:
    _base_spec.loader.exec_module(base)
finally:
    sys.path.remove(str(BASE_DIR))

from layer_timing import load_activations
from method30_outlier_quant import METHOD_NAME, method30_reconstruct_tensor


CONFIG = json.loads((EXP_DIR / "config.json").read_text())
VARIANT_NAMES = {
    ("pre_awq", "exact"): "method30_22a_exact",
    ("pre_awq", "clustered"): "method30_22b_clustered",
    ("post_awq", "exact"): "method30_post_awq_22a_exact",
}
CACHE_METHOD = "method22_group_outlier"
CACHE_VERSION = 2
CACHE_BACKEND = "scikit_kmeans"


def tensor_hash(tensor):
    array = tensor.detach().cpu().float().contiguous().numpy()
    digest = hashlib.sha256()
    digest.update(str(array.shape).encode("utf-8"))
    digest.update(str(array.dtype).encode("utf-8"))
    digest.update(array.tobytes())
    return digest.hexdigest()


def build_cache_index(cache_dir):
    index = {}
    for path in sorted(Path(cache_dir).glob("*.pt")):
        payload = torch.load(path, map_location="cpu")
        metadata = payload.get("metadata", {})
        centroids = payload.get("centroids")
        if (
            metadata.get("method") != CACHE_METHOD
            or metadata.get("version") != CACHE_VERSION
            or metadata.get("kind") != "outlier"
            or metadata.get("backend") != CACHE_BACKEND
        ):
            continue
        if not isinstance(centroids, torch.Tensor) or tuple(centroids.shape) != (16,):
            continue
        index.setdefault(str(metadata.get("layer_name")), []).append(
            {
                "path": str(path),
                "metadata": metadata,
                "centroids": centroids.detach().float().contiguous(),
            }
        )
    return index


def matching_outlier_cache(index, layer_name, weight, model_path, group_size):
    expected = {
        "model_path": str(model_path),
        "layer_name": layer_name,
        "weight_shape": list(weight.shape),
        "weight_hash": tensor_hash(weight),
        "group_size": int(group_size),
        "n_bit": 4,
        "n_clusters": 16,
        "outlier_rule": "max_abs_first_tie",
        "backend": CACHE_BACKEND,
        "version": CACHE_VERSION,
        "domain": "raw_fp16_weight",
        "scale_sample_weight": False,
        "random_state": 0,
        "n_init": "auto",
        "max_iter": 300,
        "tol": 1e-4,
    }
    matches = []
    for entry in index.get(layer_name, []):
        metadata = entry["metadata"]
        if all(metadata.get(key) == value for key, value in expected.items()):
            matches.append(entry)
    if len(matches) != 1:
        raise RuntimeError(
            f"Expected exactly one compatible method22B cache for {layer_name}, "
            f"found {len(matches)}."
        )
    return matches[0]


def nearest_centroid_values(values, centroids, chunk_size=65536):
    flat = values.detach().cpu().float().reshape(-1)
    centroids = centroids.detach().cpu().float().reshape(16)
    reconstructed = torch.empty_like(flat)
    assignments = torch.empty(flat.shape, dtype=torch.uint8)
    for start in range(0, flat.numel(), chunk_size):
        stop = min(start + chunk_size, flat.numel())
        labels = (flat[start:stop, None] - centroids[None, :]).abs().argmin(dim=1)
        assignments[start:stop] = labels.to(torch.uint8)
        reconstructed[start:stop] = centroids[labels]
    return reconstructed.reshape_as(values), assignments.reshape_as(values)


def storage_stats(rows, cols, variant, group_size=128):
    groups_per_row = cols // group_size
    group_count = rows * groups_per_row
    position_bits = math.ceil(math.log2(group_size))
    components = {
        "normal_assignments": group_count * (group_size - 1) * 4,
        "outlier_positions": group_count * position_bits,
        "scales_and_zeros": group_count * 2 * 16,
        "normal_lut": rows * 16 * 16,
    }
    if variant == "exact":
        components["outlier_payload"] = group_count * 16
        components["outlier_lut"] = 0
    elif variant == "clustered":
        components["outlier_payload"] = group_count * 4
        components["outlier_lut"] = 16 * 16
    else:
        raise ValueError(f"Unknown variant {variant!r}.")
    theoretical_bits = sum(components.values())
    return {
        "weight_count": rows * cols,
        "group_count": group_count,
        "components_bits": components,
        "theoretical_bits": theoretical_bits,
        "theoretical_bpw": theoretical_bits / (rows * cols),
    }


def aggregate_storage(layers, variant):
    totals = {
        "weight_count": 0,
        "group_count": 0,
        "theoretical_bits": 0,
    }
    components = {}
    for entry in layers.values():
        stats = entry["storage"][variant]
        for key in totals:
            totals[key] += int(stats[key])
        for key, value in stats["components_bits"].items():
            components[key] = components.get(key, 0) + int(value)
    totals["components_bits"] = components
    totals["theoretical_bpw"] = (
        totals["theoretical_bits"] / totals["weight_count"]
    )
    return totals


def parse_cpu_list(value, physical_gpu, jobs):
    if value == "auto":
        start = 0 if int(physical_gpu) < 4 else 36
        cpus = list(range(start, start + int(jobs)))
    else:
        cpus = []
        for part in value.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                first, last = (int(item) for item in part.split("-", 1))
                cpus.extend(range(first, last + 1))
            else:
                cpus.append(int(part))
    cpus = sorted(set(cpus))
    if len(cpus) < jobs:
        raise ValueError(
            f"CPU set provides {len(cpus)} CPUs for {jobs} sklearn workers."
        )
    return cpus


def apply_clustered_outliers(model, replacements, group_size):
    with torch.no_grad():
        for layer_name, payload in replacements.items():
            module = model.get_submodule(layer_name)
            rows, cols = module.weight.shape
            groups = cols // group_size
            positions = payload["positions"].to(
                device=module.weight.device,
                dtype=torch.long,
            )
            values = payload["values"].to(
                device=module.weight.device,
                dtype=module.weight.dtype,
            )
            grouped = module.weight.data.reshape(rows, groups, group_size)
            grouped.scatter_(2, positions.unsqueeze(2), values.unsqueeze(2))


def write_variant(output_dir, variant, ppl, evaluation_seconds, result):
    selection_domain = result["parameters"]["outlier_selection_domain"]
    name = VARIANT_NAMES[(selection_domain, variant)]
    payload = {
        "method_name": name,
        "status": "complete",
        "variant": variant,
        "outlier_selection_domain": selection_domain,
        "wiki2_ppl": float(ppl),
        "delta_vs_method30": float(ppl - CONFIG["baselines"]["method30_ppl"]),
        "evaluation_seconds": float(evaluation_seconds),
        "shared_quantization_seconds": result["quantization_seconds"],
        "storage": result["storage"][variant],
        "shared_result": str(Path(output_dir) / "results.json"),
    }
    base.atomic_write_json(Path(output_dir) / f"{name}.json", payload)
    return payload


def execute(args):
    if not torch.cuda.is_available():
        raise RuntimeError("The full Method30 outlier run requires CUDA.")
    if args.variant not in ("all", "exact", "clustered"):
        raise ValueError(f"Unsupported variant {args.variant!r}.")
    if args.outlier_selection_domain not in ("pre_awq", "post_awq"):
        raise ValueError(f"Unsupported selection domain {args.outlier_selection_domain!r}.")
    if (
        args.outlier_selection_domain == "post_awq"
        and args.variant != "exact"
    ):
        raise ValueError(
            "post_awq currently supports only --variant exact; "
            "the pre-AWQ method22B cache is not valid for changed positions."
        )
    cpu_set = parse_cpu_list(args.cpu_list, args.physical_gpu, args.parallel_jobs)
    os.sched_setaffinity(0, cpu_set)
    initial_memory = base.check_single_empty_gpu(
        args.physical_gpu,
        args.empty_threshold_mib,
    )
    os.environ["HF_DATASETS_CACHE"] = args.dataset_cache
    torch.backends.cuda.matmul.allow_tf32 = False
    device = torch.device("cuda:0")
    output_dir = Path(args.output_dir)
    combined_output = output_dir / "results.json"

    alphas, alpha_payload = base.load_alpha_selection(
        args.alpha_selection_path,
        args.alpha_key,
    )
    fisher, fisher_metadata = base.load_fisher(args.fisher_path)
    cache_index = (
        build_cache_index(args.method22_outlier_cache)
        if (
            args.outlier_selection_domain == "pre_awq"
            and args.variant in ("all", "clustered")
        )
        else {}
    )
    selection_step = (
        "raw_fp16_top_abs_outlier_mask"
        if args.outlier_selection_domain == "pre_awq"
        else "awq_scaled_weight_top_abs_outlier_mask"
    )
    leading_steps = (
        [selection_step, "method27_lambda_0p3_awq_scale"]
        if args.outlier_selection_domain == "pre_awq"
        else ["method27_lambda_0p3_awq_scale", selection_step]
    )

    result = {
        "method_name": METHOD_NAME,
        "status": "loading_model",
        "sequence": leading_steps + [
            "method9_fisher_weighted_16_centroid_initialization_on_127_normal_values",
            "masked_weighted_4bit_joint_lut_affine_optimization",
            "method22a_exact_then_method22b_cached_clustered_outlier",
        ],
        "model_path": args.model_path,
        "dataset": CONFIG["dataset"],
        "seqlen": args.seqlen,
        "loader_samples": args.loader_samples,
        "n_bit": 4,
        "group_size": args.group_size,
        "physical_gpu": str(args.physical_gpu),
        "initial_gpu_memory_mib": int(initial_memory),
        "cpu_affinity": cpu_set,
        "sources": {
            "alpha_selection_path": args.alpha_selection_path,
            "alpha_key": args.alpha_key,
            "alpha_selection_sha256": base.file_sha256(args.alpha_selection_path),
            "alpha_source_search": alpha_payload.get("source_search"),
            "activation_cache": args.activation_cache,
            "fisher_path": args.fisher_path,
            "fisher_sha256": base.file_sha256(args.fisher_path),
            "fisher_metadata": fisher_metadata,
            "method22_outlier_cache": args.method22_outlier_cache,
        },
        "parameters": {
            "variant": args.variant,
            "parallel_jobs": args.parallel_jobs,
            "max_iter": args.max_iter,
            "relative_tol": args.relative_tol,
            "ridge": args.ridge,
            "scale_eps": args.scale_eps,
            "chunk_rows": args.chunk_rows,
            "loss_increase_rtol": args.loss_increase_rtol,
            "importance_mode": "broadcast",
            "importance_chunk_rows": args.importance_chunk_rows,
            "initializer": "sklearn",
            "outlier_selection_domain": args.outlier_selection_domain,
            "outlier_rule": (
                "max_abs_first_tie_raw_pre_awq"
                if args.outlier_selection_domain == "pre_awq"
                else "max_abs_first_tie_scaled_post_awq"
            ),
            "outliers_per_group": 1,
            "fisher_residual_selection": False,
        },
        "baselines": CONFIG["baselines"],
        "layers": {},
        "completed_linears": 0,
    }
    base.atomic_write_json(combined_output, result)

    model, tokenizer = base.load_model_and_tokenizer(args.model_path)
    linears, searchable_names, fallback_names = base.validate_sources(
        model,
        alphas,
        fisher,
        args.group_size,
    )
    result["coverage"] = {
        "quantized_linears": len(linears),
        "method27_scaled_linears": len(searchable_names),
        "alpha_zero_fallback_linears": len(fallback_names),
        "fisher_layers": len(fisher),
        "method22b_cache_layers": len(cache_index),
    }
    result["status"] = "quantizing_shared_normal_weights"
    base.atomic_write_json(combined_output, result)

    replacements = {}
    active_block = None
    layer_activations = None
    cleanup_stats = base.new_cleanup_stats(
        args.cleanup_policy,
        args.cleanup_threshold_mib,
    )
    quantization_started = time.perf_counter()
    for index, (full_name, module) in enumerate(linears, 1):
        block, _ = base.layer_and_local_name(full_name)
        if block != active_block:
            del layer_activations
            layer_activations = load_activations(args.activation_cache, block)
            active_block = block

        channel_scale, alpha = base.build_channel_scale(
            full_name,
            module,
            alphas,
            layer_activations,
        )
        source_cpu = module.weight.detach().cpu().float().contiguous()
        source_weight = source_cpu.to(device=device)
        cache_entry = None
        if (
            args.outlier_selection_domain == "pre_awq"
            and args.variant in ("all", "clustered")
        ):
            cache_entry = matching_outlier_cache(
                cache_index,
                full_name,
                source_cpu,
                args.model_path,
                args.group_size,
            )

        layer_started = time.perf_counter()
        reconstructed, diagnostics, state = method30_reconstruct_tensor(
            source_weight,
            channel_scale,
            fisher[full_name],
            group_size=args.group_size,
            max_iter=args.max_iter,
            relative_tol=args.relative_tol,
            ridge=args.ridge,
            scale_eps=args.scale_eps,
            chunk_rows=args.chunk_rows,
            loss_increase_rtol=args.loss_increase_rtol,
            parallelize=not args.no_parallelize,
            parallel_jobs=args.parallel_jobs,
            return_state=True,
            importance_mode="broadcast",
            importance_chunk_rows=args.importance_chunk_rows,
            initializer="sklearn",
            outlier_selection_domain=args.outlier_selection_domain,
        )
        positions = state["outlier_positions"].detach().cpu().to(torch.uint8)
        exact_values = state["exact_outlier_values"].detach().cpu().float()
        if cache_entry is not None:
            clustered_values, clustered_assignments = nearest_centroid_values(
                exact_values,
                cache_entry["centroids"],
            )
            replacements[full_name] = {
                "positions": positions,
                "values": clustered_values.to(torch.float16),
            }
        else:
            clustered_assignments = None

        module.weight.data.copy_(
            reconstructed.detach().cpu().to(module.weight.dtype)
        )
        rows, cols = module.weight.shape
        result["layers"][full_name] = {
            "alpha": float(alpha),
            "alpha_source": (
                args.alpha_key
                if full_name in alphas
                else "o_proj_alpha0_fallback"
            ),
            "weight_shape": [rows, cols],
            "layer_seconds": float(time.perf_counter() - layer_started),
            "diagnostics": diagnostics,
            "outlier": {
                "count": int(positions.numel()),
                "positions_dtype": str(positions.dtype),
                "method22b_cache_path": (
                    cache_entry["path"] if cache_entry is not None else None
                ),
                "method22b_cache_sha256": (
                    base.file_sha256(cache_entry["path"])
                    if cache_entry is not None
                    else None
                ),
                "clustered_assignment_min": (
                    int(clustered_assignments.min().item())
                    if clustered_assignments is not None
                    else None
                ),
                "clustered_assignment_max": (
                    int(clustered_assignments.max().item())
                    if clustered_assignments is not None
                    else None
                ),
            },
            "storage": {
                variant: storage_stats(rows, cols, variant, args.group_size)
                for variant in ("exact", "clustered")
            },
        }
        result["completed_linears"] = index
        result["active_linear"] = full_name
        result["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        base.atomic_write_json(combined_output, result)
        print(
            f"[{index}/{len(linears)}] {full_name}: alpha={alpha:g}, "
            f"normal_loss={diagnostics['initial_weighted_loss']:.8e}"
            f"->{diagnostics['final_weighted_loss']:.8e}, "
            f"iters={diagnostics['iterations']}",
            flush=True,
        )

        next_block = (
            base.layer_and_local_name(linears[index][0])[0]
            if index < len(linears)
            else None
        )
        del source_cpu, source_weight, reconstructed, channel_scale, state
        base.maybe_cleanup_cuda(
            args.cleanup_policy,
            args.cleanup_threshold_mib,
            next_block != block,
            full_name,
            cleanup_stats,
        )

    del layer_activations
    result["quantization_seconds"] = time.perf_counter() - quantization_started
    result["cleanup"] = cleanup_stats
    result["storage"] = {
        variant: aggregate_storage(result["layers"], variant)
        for variant in ("exact", "clustered")
    }
    result["status"] = "evaluating"
    result["active_linear"] = None
    base.atomic_write_json(combined_output, result)

    variants = ["exact", "clustered"] if args.variant == "all" else [args.variant]
    result["variants"] = {}
    model.to(device)
    model.eval()
    for variant in variants:
        if variant == "clustered":
            apply_clustered_outliers(model, replacements, args.group_size)
        evaluation_started = time.perf_counter()
        ppl = base.evaluate_wiki2(
            model,
            tokenizer,
            args.loader_samples,
            args.seqlen,
        )
        evaluation_seconds = time.perf_counter() - evaluation_started
        result["variants"][variant] = write_variant(
            output_dir,
            variant,
            ppl,
            evaluation_seconds,
            result,
        )
        result["status"] = f"evaluated_{variant}"
        base.atomic_write_json(combined_output, result)

    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    result["all_normal_losses_monotonic"] = all(
        entry["diagnostics"]["loss_monotonic"]
        for entry in result["layers"].values()
    )
    base.atomic_write_json(combined_output, result)
    print(json.dumps(result["variants"], indent=2), flush=True)

    del model, tokenizer, replacements
    torch.cuda.empty_cache()
    gc.collect()
    return result


def build_parser():
    joint = CONFIG["joint_affine"]
    parser = argparse.ArgumentParser(description=METHOD_NAME)
    parser.add_argument("--variant", choices=("all", "exact", "clustered"), default="all")
    parser.add_argument(
        "--outlier-selection-domain",
        choices=("pre_awq", "post_awq"),
        default="pre_awq",
    )
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--dataset-cache", default=CONFIG["dataset_cache"])
    parser.add_argument("--alpha-selection-path", default=CONFIG["alpha_selection_path"])
    parser.add_argument("--alpha-key", default=CONFIG["alpha_key"])
    parser.add_argument("--activation-cache", default=CONFIG["activation_cache"])
    parser.add_argument("--fisher-path", default=CONFIG["fisher_path"])
    parser.add_argument(
        "--method22-outlier-cache",
        default=CONFIG["method22_outlier_cache"],
    )
    parser.add_argument("--output-dir", default=CONFIG["output_dir"])
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument(
        "--empty-threshold-mib",
        type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    parser.add_argument("--parallel-jobs", type=int, default=CONFIG["parallel_jobs"])
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument("--seqlen", type=int, default=CONFIG["seqlen"])
    parser.add_argument("--loader-samples", type=int, default=CONFIG["loader_samples"])
    parser.add_argument("--max-iter", type=int, default=joint["max_iter"])
    parser.add_argument("--relative-tol", type=float, default=joint["relative_tol"])
    parser.add_argument("--ridge", type=float, default=joint["ridge"])
    parser.add_argument("--scale-eps", type=float, default=joint["scale_eps"])
    parser.add_argument("--chunk-rows", type=int, default=joint["chunk_rows"])
    parser.add_argument(
        "--loss-increase-rtol",
        type=float,
        default=joint["loss_increase_rtol"],
    )
    parser.add_argument(
        "--importance-chunk-rows",
        type=int,
        default=joint["importance_chunk_rows"],
    )
    parser.add_argument(
        "--cleanup-policy",
        choices=base.CLEANUP_POLICIES,
        default="block_or_threshold",
    )
    parser.add_argument("--cleanup-threshold-mib", type=float, default=4096)
    parser.add_argument("--no-parallelize", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    try:
        execute(args)
    except Exception as error:
        output = Path(args.output_dir) / "results.json"
        base.mark_failed(output, error)
        raise


if __name__ == "__main__":
    main()
