import argparse
import json
import os
import sys
from pathlib import Path

import torch

EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method30_outlier_quant import (
    _normal_group_parameters,
    method30_reconstruct_tensor,
    select_group_outliers,
    transform_fisher,
)
from runner import (
    CONFIG,
    base,
    build_cache_index,
    matching_outlier_cache,
    nearest_centroid_values,
    storage_stats,
)


def assert_pre_awq_selection():
    weight = torch.zeros(1, 128)
    weight[0, 3] = 5.0
    weight[0, 7] = 4.0
    scale = torch.ones(128)
    scale[7] = 10.0
    mask, positions, values = select_group_outliers(weight, 128)
    assert positions.item() == 3
    assert values.item() == 5.0
    assert mask.sum().item() == 1
    assert (weight * scale)[0, 7].abs() > (weight * scale)[0, 3].abs()



def assert_post_awq_selection_and_restore():
    torch.manual_seed(3000)
    weight = torch.randn(2, 128) * 0.05
    weight[:, 3] = 5.0
    weight[:, 7] = 4.0
    scale = torch.ones(128)
    scale[7] = 2.0
    fisher = torch.ones(128)
    common = dict(
        channel_scale=scale,
        fisher=fisher,
        group_size=128,
        max_iter=0,
        parallelize=False,
        parallel_jobs=1,
        return_state=True,
        importance_mode="broadcast",
        initializer="sklearn",
    )
    pre_output, pre_diag, pre_state = method30_reconstruct_tensor(
        weight,
        outlier_selection_domain="pre_awq",
        **common,
    )
    post_output, post_diag, post_state = method30_reconstruct_tensor(
        weight,
        outlier_selection_domain="post_awq",
        **common,
    )
    assert torch.equal(pre_state["outlier_positions"], torch.full((2, 1), 3))
    assert torch.equal(post_state["outlier_positions"], torch.full((2, 1), 7))
    post_mask = torch.zeros_like(weight, dtype=torch.bool)
    post_mask[:, 7] = True
    assert torch.equal(post_output[post_mask], weight[post_mask])
    assert pre_diag["outlier_selection_domain"] == "pre_awq"
    assert post_diag["outlier_selection_domain"] == "post_awq"

def assert_group_parameters_exclude_outlier():
    weight = torch.linspace(-1.0, 1.0, 128).reshape(1, 128)
    weight[0, 0] = 100.0
    mask, _, _ = select_group_outliers(weight, 128)
    normalized, scales, offsets = _normal_group_parameters(weight, mask, 128)
    normal = weight[~mask]
    assert torch.allclose(offsets[0, 0], normal.min())
    assert torch.allclose(scales[0, 0], (normal.max() - normal.min()) / 15.0)
    assert normalized.shape == (1, 127)
    assert normalized.max() <= 15.0 + 1e-5


def assert_masked_fisher_equivalence():
    torch.manual_seed(3001)
    weight = torch.randn(3, 256)
    reconstructed = torch.randn(3, 256)
    channel_scale = torch.rand(256) + 0.2
    fisher = torch.rand(256) + 0.1
    mask, _, _ = select_group_outliers(weight, 128)
    scaled_weight = weight * channel_scale
    scaled_reconstructed = reconstructed * channel_scale
    scaled_fisher = transform_fisher(fisher, channel_scale, normalize=False)
    original = (
        fisher.reshape(1, -1)
        * (~mask)
        * (weight - reconstructed).square()
    ).sum()
    scaled = (
        scaled_fisher.reshape(1, -1)
        * (~mask)
        * (scaled_weight - scaled_reconstructed).square()
    ).sum()
    assert torch.allclose(original, scaled, rtol=1e-5, atol=1e-5)


def run_masked_optimization_case():
    torch.manual_seed(3002)
    weight = torch.randn(4, 256) * 0.15
    grouped = weight.reshape(4, 2, 128)
    grouped[:, :, 5] = torch.tensor(
        [[4.0, -4.1], [4.2, -4.3], [4.4, -4.5], [4.6, -4.7]]
    )
    weight = grouped.reshape(4, 256)
    modified = weight.clone().reshape(4, 2, 128)
    modified[:, :, 5] *= 3.0
    modified = modified.reshape(4, 256)
    channel_scale = torch.rand(256) + 0.4
    fisher = torch.rand(256) + 0.05

    common = dict(
        channel_scale=channel_scale,
        fisher=fisher,
        group_size=128,
        max_iter=2,
        relative_tol=1e-8,
        chunk_rows=2,
        parallelize=False,
        parallel_jobs=1,
        return_state=True,
        importance_mode="broadcast",
        importance_chunk_rows=2,
        initializer="sklearn",
    )
    output_a, diagnostics_a, state_a = method30_reconstruct_tensor(weight, **common)
    output_changed, diagnostics_changed, state_changed = method30_reconstruct_tensor(
        modified,
        **common,
    )
    mask, positions, exact = select_group_outliers(weight, 128)
    changed_mask, changed_positions, _ = select_group_outliers(modified, 128)

    assert torch.equal(positions, changed_positions)
    assert torch.equal(mask, changed_mask)
    assert torch.equal(output_a[mask], weight[mask])
    assert torch.equal(output_changed[mask], modified[mask])
    assert torch.allclose(output_a[~mask], output_changed[~mask], rtol=0, atol=1e-6)
    assert diagnostics_a["loss_monotonic"]
    assert diagnostics_changed["loss_monotonic"]
    assert diagnostics_a["final_weighted_loss"] <= diagnostics_a["initial_weighted_loss"]
    assert state_a["lut"].shape == (4, 16)
    assert state_changed["lut"].shape == (4, 16)
    assert torch.isfinite(output_a).all()
    assert (state_a["scales"] > 0).all()
    assert torch.equal(state_a["outlier_positions"], positions)
    assert torch.equal(state_a["exact_outlier_values"], exact)
    return diagnostics_a


def assert_clustered_assignment():
    values = torch.tensor([[-3.0, -0.4, 0.7, 2.8]])
    centroids = torch.linspace(-3.0, 3.0, 16)
    reconstructed, assignments = nearest_centroid_values(values, centroids)
    expected = centroids[
        (values.reshape(-1, 1) - centroids.reshape(1, -1)).abs().argmin(dim=1)
    ].reshape_as(values)
    assert torch.equal(reconstructed, expected)
    assert assignments.dtype == torch.uint8
    assert assignments.min() >= 0 and assignments.max() <= 15


def assert_storage():
    exact = storage_stats(2048, 2048, "exact")
    clustered = storage_stats(2048, 2048, "clustered")
    group_count = 2048 * (2048 // 128)
    assert exact["group_count"] == group_count
    assert exact["components_bits"]["outlier_payload"] == group_count * 16
    assert clustered["components_bits"]["outlier_payload"] == group_count * 4
    assert clustered["components_bits"]["outlier_lut"] == 16 * 16
    assert exact["theoretical_bpw"] > clustered["theoretical_bpw"]


def check_cache_coverage(model_path):
    model, tokenizer = base.load_model_and_tokenizer(model_path)
    alphas, _ = base.load_alpha_selection(
        CONFIG["alpha_selection_path"],
        CONFIG["alpha_key"],
    )
    fisher, _ = base.load_fisher(CONFIG["fisher_path"])
    linears, searchable, fallback = base.validate_sources(
        model,
        alphas,
        fisher,
        CONFIG["group_size"],
    )
    index = build_cache_index(CONFIG["method22_outlier_cache"])
    matched = []
    for name, module in linears:
        entry = matching_outlier_cache(
            index,
            name,
            module.weight.detach().cpu().float(),
            model_path,
            CONFIG["group_size"],
        )
        matched.append(entry["path"])
    assert len(matched) == 112
    assert len(searchable) == 96
    assert len(fallback) == 16
    return {"matched_layers": len(matched), "indexed_layers": len(index)}


def run_real_linear(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    base.check_single_empty_gpu(
        args.physical_gpu,
        CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    alphas, _ = base.load_alpha_selection(
        CONFIG["alpha_selection_path"],
        CONFIG["alpha_key"],
    )
    fisher, _ = base.load_fisher(CONFIG["fisher_path"])
    model, tokenizer = base.load_model_and_tokenizer(args.model_path)
    linears, _, _ = base.validate_sources(
        model,
        alphas,
        fisher,
        CONFIG["group_size"],
    )
    name = "model.layers.0.self_attn.k_proj"
    module = dict(linears)[name]
    activations = base.load_activations(CONFIG["activation_cache"], 0)
    channel_scale, alpha = base.build_channel_scale(
        name,
        module,
        alphas,
        activations,
    )
    source = module.weight.detach().clone()
    output, diagnostics, state = method30_reconstruct_tensor(
        source.to("cuda", torch.float32),
        channel_scale,
        fisher[name],
        group_size=128,
        max_iter=2,
        parallel_jobs=args.parallel_jobs,
        return_state=True,
    )
    assert torch.equal(module.weight, source)
    assert diagnostics["loss_monotonic"]
    assert torch.isfinite(output).all()
    assert state["lut"].shape[1] == 16
    return {
        "linear": name,
        "alpha": alpha,
        "initial_loss": diagnostics["initial_weighted_loss"],
        "final_loss": diagnostics["final_weighted_loss"],
    }


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--check-cache-coverage", action="store_true")
    parser.add_argument("--real-linear", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    assert_pre_awq_selection()
    assert_post_awq_selection_and_restore()
    assert_group_parameters_exclude_outlier()
    assert_masked_fisher_equivalence()
    diagnostics = run_masked_optimization_case()
    assert_clustered_assignment()
    assert_storage()
    result = {
        "synthetic": {
            "status": "passed",
            "initial_loss": diagnostics["initial_weighted_loss"],
            "final_loss": diagnostics["final_weighted_loss"],
        }
    }
    if args.check_cache_coverage:
        result["cache_coverage"] = check_cache_coverage(args.model_path)
    if args.real_linear:
        result["real_linear"] = run_real_linear(args)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
