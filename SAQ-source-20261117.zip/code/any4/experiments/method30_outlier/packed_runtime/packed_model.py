import json
import os
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from accelerate import init_empty_weights
from accelerate.utils import set_module_tensor_to_device
from safetensors import safe_open
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

EXTENSION_DIR = Path(__file__).resolve().parent / 'psop_tinygemm_ext'
if str(EXTENSION_DIR) not in sys.path:
    sys.path.insert(0, str(EXTENSION_DIR))
import psop_tinygemm_cuda  # noqa: F401


REQUIRED_KEYS = {
    'qweight_tinygemm',
    'lut',
    'scales_and_zeros',
    'inv_channel_scale',
    'outlier_pos',
    'outlier_residual_scaled',
}

DEFAULT_TINYGEMM_MAX_M = 64


def resolve_tinygemm_max_m(value=None):
    if value is None:
        value = os.environ.get('PSOP_TINYGEMM_MAX_M', DEFAULT_TINYGEMM_MAX_M)
    try:
        value = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError('TinyGemm M threshold must be an integer') from error
    if value < -1:
        raise ValueError('TinyGemm M threshold must be -1 or non-negative')
    return value


def memory_stats():
    return {
        'allocated_mib': torch.cuda.memory_allocated() / 2**20,
        'reserved_mib': torch.cuda.memory_reserved() / 2**20,
        'max_allocated_mib': torch.cuda.max_memory_allocated() / 2**20,
        'max_reserved_mib': torch.cuda.max_memory_reserved() / 2**20,
    }


def load_tinygemm_tensors(path, device):
    tensors = {}
    with safe_open(path, framework='pt', device=str(device)) as handle:
        metadata = handle.metadata()
        for key in handle.keys():
            tensors[key] = handle.get_tensor(key)
    missing = REQUIRED_KEYS.difference(tensors)
    if missing:
        raise RuntimeError(f'Missing tensors {sorted(missing)} in {path}')
    if metadata.get('format') != 'method30_post_awq_22a_tinygemm':
        raise RuntimeError(f'Unexpected format in {path}')
    return tensors, metadata


class PackedPostAWQ22ALinear(torch.nn.Module):
    def __init__(self, tensors, metadata, bias=None, tinygemm_max_m=None):
        super().__init__()
        rows, cols = json.loads(metadata['weight_shape'])
        self.in_features = int(cols)
        self.out_features = int(rows)
        self.group_size = int(metadata['group_size'])
        self.tinygemm_max_m = resolve_tinygemm_max_m(tinygemm_max_m)
        for key in sorted(REQUIRED_KEYS):
            self.register_buffer(key, tensors[key].contiguous(), persistent=True)
        if bias is None:
            bias = torch.empty(
                0, device=self.lut.device, dtype=torch.float16
            )
        self.register_buffer('bias', bias.contiguous(), persistent=True)

    def forward(self, input_tensor):
        if input_tensor.dtype != torch.float16:
            input_tensor = input_tensor.to(torch.float16)
        original_shape = input_tensor.shape[:-1]
        x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
        use_tinygemm = self.tinygemm_max_m < 0 or x.shape[0] <= self.tinygemm_max_m
        if use_tinygemm:
            output = torch.ops.psop_tinygemm.linear_f16rm_any4(
                x,
                self.qweight_tinygemm,
                self.scales_and_zeros,
                self.lut,
                self.inv_channel_scale,
                self.outlier_pos,
                self.outlier_residual_scaled,
                self.bias,
            )
        else:
            dense_weight = torch.ops.psop_tinygemm.dequantize_f16_any4(
                self.qweight_tinygemm,
                self.scales_and_zeros,
                self.lut,
                self.inv_channel_scale,
                self.outlier_pos,
                self.outlier_residual_scaled,
            )
            bias = self.bias if self.bias.numel() else None
            output = F.linear(x, dense_weight, bias)
        return output.reshape(*original_shape, self.out_features)

    def extra_repr(self):
        return (
            f'in_features={self.in_features}, out_features={self.out_features}, '
            f'group_size={self.group_size}, bias={self.bias.numel() != 0}, '
            f'tinygemm_max_m={self.tinygemm_max_m}'
        )


def replace_module(root, qualified_name, module):
    parent_name, attribute = qualified_name.rsplit('.', 1)
    parent = root.get_submodule(parent_name)
    old = getattr(parent, attribute)
    if not isinstance(old, torch.nn.Linear):
        raise RuntimeError(f'{qualified_name} is not a Linear')
    if tuple(old.weight.shape) != (module.out_features, module.in_features):
        raise RuntimeError(f'Shape mismatch for {qualified_name}')
    setattr(parent, attribute, module)


def build_empty_model(checkpoint_dir):
    config = AutoConfig.from_pretrained(
        checkpoint_dir, local_files_only=True, trust_remote_code=True
    )
    config.torch_dtype = torch.float16
    config._attn_implementation = 'sdpa'
    with init_empty_weights(include_buffers=False):
        model = AutoModelForCausalLM.from_config(
            config, trust_remote_code=True, torch_dtype=torch.float16
        )
    return model


def load_packed_model(checkpoint_dir, device='cuda:0', tinygemm_max_m=None):
    checkpoint_dir = Path(checkpoint_dir)
    tinygemm_max_m = resolve_tinygemm_max_m(tinygemm_max_m)
    manifest = json.loads((checkpoint_dir / 'manifest.json').read_text())
    if manifest.get('status') != 'complete' or manifest.get('linears') != 224:
        raise RuntimeError('Incomplete TinyGemm checkpoint manifest')
    started = time.perf_counter()
    device = torch.device(device)
    torch.cuda.init()
    torch.cuda.reset_peak_memory_stats()
    model = build_empty_model(checkpoint_dir)

    for index, entry in enumerate(manifest['layers'], start=1):
        tensors, metadata = load_tinygemm_tensors(
            checkpoint_dir / entry['file'], device
        )
        module = PackedPostAWQ22ALinear(
            tensors, metadata, tinygemm_max_m=tinygemm_max_m
        )
        replace_module(model, entry['layer_name'], module)
        if index % 32 == 0 or index == len(manifest['layers']):
            print(f'[{index:03d}/224] loaded packed Linear', flush=True)

    loaded_parameters = set()
    for shard in manifest['nonquantized_shards']:
        path = checkpoint_dir / shard['file']
        with safe_open(path, framework='pt', device='cpu') as handle:
            for key in handle.keys():
                value = handle.get_tensor(key)
                target_dtype = torch.float16 if value.is_floating_point() else value.dtype
                if value.dtype != target_dtype:
                    value = value.to(target_dtype)
                set_module_tensor_to_device(
                    model, key, device=device, value=value, dtype=target_dtype
                )
                loaded_parameters.add(key)
        print(f'loaded {path.name}', flush=True)

    meta_parameters = [
        name for name, value in model.named_parameters() if value.device.type == 'meta'
    ]
    if meta_parameters:
        raise RuntimeError(f'Unloaded meta parameters: {meta_parameters[:8]}')
    model.to(device)
    model.eval()
    torch.cuda.synchronize()
    load_result = {
        'seconds': time.perf_counter() - started,
        'tinygemm_max_m': tinygemm_max_m,
        'packed_linears': len(manifest['layers']),
        'nonquantized_parameters_loaded': len(loaded_parameters),
        'memory': memory_stats(),
    }
    return model, manifest, load_result


def load_tokenizer(checkpoint_dir):
    tokenizer = AutoTokenizer.from_pretrained(
        checkpoint_dir, local_files_only=True, trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer
