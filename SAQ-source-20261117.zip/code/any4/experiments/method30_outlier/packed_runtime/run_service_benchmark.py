import argparse
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import requests
import torch
import uvicorn
from transformers import AutoModelForCausalLM, AutoTokenizer

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from packed_model import load_packed_model, load_tokenizer, memory_stats
from serve_runtime import create_app


def assert_empty_gpu(index):
    output = subprocess.check_output([
        'nvidia-smi', f'--id={index}',
        '--query-gpu=memory.used,utilization.gpu',
        '--format=csv,noheader,nounits',
    ], text=True)
    used, utilization = (int(item.strip()) for item in output.strip().split(','))
    if used > 256 or utilization > 5:
        raise RuntimeError(f'GPU {index} is not empty: {used} MiB, {utilization}%')


def load_runtime(args):
    if args.runtime == 'packed':
        tokenizer = load_tokenizer(args.checkpoint)
        model, _, load_result = load_packed_model(args.checkpoint)
        return model, tokenizer, load_result
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    started = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path, local_files_only=True, torch_dtype=torch.float16,
        low_cpu_mem_usage=True, device_map={'': 'cuda:0'},
        attn_implementation='sdpa',
    ).eval()
    torch.cuda.synchronize()
    return model, tokenizer, {
        'seconds': time.perf_counter() - started, 'memory': memory_stats()
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', choices=('packed', 'fp16'), required=True)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--model-path', default='/data/model/models--meta-llama--Meta-Llama-3-8B')
    parser.add_argument('--physical-gpu', required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    assert_empty_gpu(args.physical_gpu)
    model, tokenizer, load_result = load_runtime(args)
    app = create_app(model, tokenizer, args.runtime, load_result)
    config = uvicorn.Config(
        app, host='127.0.0.1', port=args.port, log_level='warning'
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=False)
    thread.start()
    url = f'http://127.0.0.1:{args.port}'
    try:
        for _ in range(120):
            try:
                if requests.get(f'{url}/health', timeout=1).ok:
                    break
            except requests.RequestException:
                time.sleep(0.25)
        else:
            raise RuntimeError('Service did not become ready')
        subprocess.run([
            sys.executable, str(HERE / 'benchmark_service.py'),
            '--url', url,
            '--output', str(args.output),
        ], check=True)
    finally:
        server.should_exit = True
        thread.join(timeout=60)
        if thread.is_alive():
            raise RuntimeError('Uvicorn did not shut down cleanly')


if __name__ == '__main__':
    main()
