import argparse
import json
import sys
from pathlib import Path

import torch


HERE = Path(__file__).resolve().parent
REPO = Path('/data/lsz/any4')
sys.path[:0] = [str(HERE), str(REPO)]

from packed_format import load_layer, reconstruct_weight
from packed_model import load_tinygemm_tensors
from tinygemm_composite import (
    dequantize_weight,
    psop_tinygemm_fused,
    psop_tinygemm_hybrid,
)


def find_entry(manifest, layer_name):
    return next(
        entry for entry in manifest['layers']
        if entry['layer_name'] == layer_name
    )


def relative_mse(observed, reference):
    difference = observed.float() - reference.float()
    return (
        float(
            difference.square().mean() /
            reference.float().square().mean().clamp_min(1e-12)
        ),
        float(difference.abs().max()),
    )


def benchmark(callable_, repeats):
    for _ in range(min(3, repeats)):
        callable_()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    samples = []
    for _ in range(repeats):
        start.record()
        callable_()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end))
    values = torch.tensor(samples, dtype=torch.float64)
    return {
        'median_ms': float(values.median()),
        'min_ms': float(values.min()),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--reference-checkpoint', type=Path, required=True)
    parser.add_argument(
        '--layer-name', default='model.layers.0.self_attn.q_proj'
    )
    parser.add_argument('--m-values', default='1,32,128')
    parser.add_argument('--tinygemm-max-m', type=int, default=64)
    parser.add_argument('--timing-repeats', type=int, default=0)
    args = parser.parse_args()

    device = torch.device('cuda:0')
    manifest = json.loads((args.checkpoint / 'manifest.json').read_text())
    entry = find_entry(manifest, args.layer_name)
    tensors, metadata = load_tinygemm_tensors(
        args.checkpoint / entry['file'], device
    )
    rows, cols = entry['weight_shape']
    runtime = {
        **tensors,
        'rows': rows,
        'cols': cols,
        'group_size': int(metadata['group_size']),
        'w_inner_k': 4,
    }

    reference_manifest = json.loads(
        (args.reference_checkpoint / 'manifest.json').read_text()
    )
    reference_entry = find_entry(reference_manifest, args.layer_name)
    reference_tensors, reference_metadata = load_layer(
        args.reference_checkpoint / reference_entry['file'], device='cpu'
    )
    weight = reconstruct_weight(
        reference_tensors,
        reference_metadata,
        output_dtype=torch.float16,
        device=device,
    )

    with torch.inference_mode():
        dense_weight = dequantize_weight(runtime)
        weight_mse, weight_max_abs = relative_mse(dense_weight, weight)
        measurements = []
        generator = torch.Generator(device=device).manual_seed(20260804)
        for m in [int(value) for value in args.m_values.split(',')]:
            x = torch.randn(
                (m, cols), device=device, dtype=torch.float16,
                generator=generator,
            )
            reference = x @ weight.t()
            hybrid = psop_tinygemm_hybrid(
                x,
                runtime,
                tinygemm_max_m=args.tinygemm_max_m,
            )
            mse, max_abs = relative_mse(hybrid, reference)
            route = (
                'tinygemm'
                if args.tinygemm_max_m < 0 or m <= args.tinygemm_max_m
                else 'transient_fp16_cublas'
            )
            measurements.append({
                'm': m,
                'route': route,
                'relative_mse': mse,
                'max_abs': max_abs,
            })
            if args.timing_repeats > 0:
                legacy_timing = benchmark(
                    lambda: psop_tinygemm_fused(x, runtime),
                    args.timing_repeats,
                )
                hybrid_timing = benchmark(
                    lambda: psop_tinygemm_hybrid(
                        x,
                        runtime,
                        tinygemm_max_m=args.tinygemm_max_m,
                    ),
                    args.timing_repeats,
                )
                fp16_timing = benchmark(
                    lambda: x @ weight.t(), args.timing_repeats
                )
                measurements[-1]['timing'] = {
                    'legacy_tinygemm': legacy_timing,
                    'hybrid': hybrid_timing,
                    'resident_fp16_cublas': fp16_timing,
                    'hybrid_speedup_vs_legacy': (
                        legacy_timing['median_ms'] /
                        hybrid_timing['median_ms']
                    ),
                }

        x = torch.randn(
            (1, cols), device=device, dtype=torch.float16,
            generator=generator,
        )
        legacy = psop_tinygemm_fused(x, runtime)
        hybrid = psop_tinygemm_hybrid(
            x, runtime, tinygemm_max_m=args.tinygemm_max_m
        )
        decode_dispatch_equal = bool(torch.equal(legacy, hybrid))

    result = {
        'status': 'complete',
        'gpu': torch.cuda.get_device_name(device),
        'layer': args.layer_name,
        'shape': [rows, cols],
        'tinygemm_max_m': args.tinygemm_max_m,
        'dequantized_weight_relative_mse': weight_mse,
        'dequantized_weight_max_abs': weight_max_abs,
        'decode_dispatch_bitwise_equal': decode_dispatch_equal,
        'measurements': measurements,
    }
    if weight_mse > 1e-5:
        raise RuntimeError(f'Dequantized weight relative MSE {weight_mse}')
    if not decode_dispatch_equal:
        raise RuntimeError('Decode dispatch changed the fused TinyGemm result')
    if any(item['relative_mse'] > 1e-5 for item in measurements):
        raise RuntimeError('Hybrid output relative MSE exceeded tolerance')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
