from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='psop-tinygemm',
    version='0.1.1',
    ext_modules=[
        CUDAExtension(
            name='psop_tinygemm_cuda',
            sources=['csrc/Bindings.cpp', 'csrc/PSOPTinyGemm.cu'],
            extra_compile_args={
                'cxx': ['-O3'],
                'nvcc': ['-O3', '--use_fast_math', '-lineinfo'],
            },
        )
    ],
    cmdclass={'build_ext': BuildExtension},
)
