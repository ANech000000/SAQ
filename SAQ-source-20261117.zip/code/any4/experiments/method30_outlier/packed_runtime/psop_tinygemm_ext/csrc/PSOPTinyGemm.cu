#include "MatrixLayoutA.cuh"
#include "MatrixLayoutB.cuh"
#include "TinyGemmImpl.cuh"

#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <c10/cuda/CUDAGuard.h>
#include <cuda_fp16.h>
#include <torch/extension.h>

#include <algorithm>

namespace psop_tinygemm {

namespace {

__global__ void dequantize_f16_any4_kernel(
    const int32_t* __restrict__ packed_weight,
    const half* __restrict__ scales_and_zeros,
    const half* __restrict__ lut,
    const half* __restrict__ inv_channel_scale,
    const uint8_t* __restrict__ outlier_positions,
    const half* __restrict__ outlier_residual,
    half* __restrict__ output,
    int32_t n,
    int32_t k,
    int32_t groups,
    int32_t k_super_tiles,
    int32_t inner_k_tiles) {
  const int64_t total = static_cast<int64_t>(n) * k;
  for (int64_t linear_index =
           static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
       linear_index < total;
       linear_index += static_cast<int64_t>(blockDim.x) * gridDim.x) {
    const int32_t row = linear_index / k;
    const int32_t column = linear_index - static_cast<int64_t>(row) * k;
    const int32_t n_tile = row / 8;
    const int32_t lane = (row % 8) * 4 + ((column % 8) / 2);
    const int32_t k_tile = column / 16;
    const int32_t inner_k_tile = k_tile % inner_k_tiles;
    const int32_t k_super_tile = k_tile / inner_k_tiles;
    const int32_t packed_inner = inner_k_tile / 2;
    const int32_t packed_inner_size = inner_k_tiles / 2;
    const int64_t packed_index =
        (((static_cast<int64_t>(n_tile) * k_super_tiles + k_super_tile) * 32 +
          lane) *
         packed_inner_size) +
        packed_inner;

    const uint32_t packed = static_cast<uint32_t>(packed_weight[packed_index]);
    const int32_t within_tile = column % 16;
    const int32_t value_in_tile =
        within_tile < 8 ? (within_tile % 2) : (2 + within_tile % 2);
    const int32_t packed_value = (inner_k_tile % 2) * 4 + value_in_tile;
    const int32_t shift =
        ((packed_value & 1) ? 16 : 0) + (packed_value / 2) * 4;
    const int32_t code = (packed >> shift) & 0xF;

    const int32_t group = column / 128;
    const int64_t affine_index =
        (static_cast<int64_t>(group) * n + row) * 2;
    half reconstructed = __hfma(
        lut[static_cast<int64_t>(row) * 16 + code],
        scales_and_zeros[affine_index],
        scales_and_zeros[affine_index + 1]);

    const int64_t outlier_index = static_cast<int64_t>(row) * groups + group;
    if ((column % 128) == outlier_positions[outlier_index]) {
      reconstructed = __hadd(reconstructed, outlier_residual[outlier_index]);
    }
    output[linear_index] = __hmul(reconstructed, inv_channel_scale[column]);
  }
}

} // namespace

torch::Tensor psop_dequantize_f16_any4(
    torch::Tensor packed_weight,
    torch::Tensor scales_and_zeros,
    torch::Tensor lut,
    torch::Tensor inv_channel_scale,
    torch::Tensor outlier_positions,
    torch::Tensor outlier_residual) {
  TORCH_CHECK(packed_weight.is_cuda());
  TORCH_CHECK(
      packed_weight.dim() == 4 && packed_weight.dtype() == torch::kInt32 &&
      packed_weight.is_contiguous());
  TORCH_CHECK(
      scales_and_zeros.is_cuda() && scales_and_zeros.dtype() == torch::kFloat16 &&
      scales_and_zeros.is_contiguous());
  TORCH_CHECK(lut.is_cuda() && lut.dtype() == torch::kFloat16 && lut.is_contiguous());
  TORCH_CHECK(
      inv_channel_scale.is_cuda() && inv_channel_scale.dtype() == torch::kFloat16 &&
      inv_channel_scale.is_contiguous());
  TORCH_CHECK(
      outlier_positions.is_cuda() && outlier_positions.dtype() == torch::kUInt8 &&
      outlier_positions.is_contiguous());
  TORCH_CHECK(
      outlier_residual.is_cuda() && outlier_residual.dtype() == torch::kFloat16 &&
      outlier_residual.is_contiguous());

  c10::cuda::CUDAGuard guard(packed_weight.device());
  const auto stream = at::cuda::getCurrentCUDAStream();
  const int32_t n = lut.size(0);
  const int32_t k = inv_channel_scale.numel();
  const int32_t groups = k / 128;
  const int32_t inner_k_tiles = packed_weight.size(3) * 2;
  const int32_t k_super_tiles = packed_weight.size(1);

  TORCH_CHECK(k % 128 == 0);
  TORCH_CHECK(inner_k_tiles == 2 || inner_k_tiles == 4 || inner_k_tiles == 8);
  TORCH_CHECK(packed_weight.size(0) == divUp(n, 8));
  TORCH_CHECK(packed_weight.size(2) == kWarpSize);
  TORCH_CHECK(k_super_tiles * inner_k_tiles * 16 == k);
  TORCH_CHECK(scales_and_zeros.sizes() == torch::IntArrayRef({groups, n, 2}));
  TORCH_CHECK(lut.sizes() == torch::IntArrayRef({n, 16}));
  TORCH_CHECK(outlier_positions.sizes() == torch::IntArrayRef({n, groups}));
  TORCH_CHECK(outlier_residual.sizes() == torch::IntArrayRef({n, groups}));

  auto output = torch::empty(
      {n, k},
      torch::TensorOptions().dtype(torch::kFloat16).device(packed_weight.device()));
  constexpr int32_t threads = 256;
  const int64_t total = static_cast<int64_t>(n) * k;
  const int32_t blocks = static_cast<int32_t>(
      std::min<int64_t>(divUp(total, static_cast<int64_t>(threads)), 4096));
  dequantize_f16_any4_kernel<<<blocks, threads, 0, stream>>>(
      packed_weight.data_ptr<int32_t>(),
      reinterpret_cast<const half*>(scales_and_zeros.data_ptr()),
      reinterpret_cast<const half*>(lut.data_ptr()),
      reinterpret_cast<const half*>(inv_channel_scale.data_ptr()),
      outlier_positions.data_ptr<uint8_t>(),
      reinterpret_cast<const half*>(outlier_residual.data_ptr()),
      reinterpret_cast<half*>(output.data_ptr()),
      n,
      k,
      groups,
      k_super_tiles,
      inner_k_tiles);
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return output;
}

torch::Tensor psop_linear_f16rm_any4(
    torch::Tensor activation,
    torch::Tensor packed_weight,
    torch::Tensor scales_and_zeros,
    torch::Tensor lut,
    torch::Tensor inv_channel_scale,
    torch::Tensor outlier_positions,
    torch::Tensor outlier_residual,
    torch::Tensor bias) {
  constexpr int32_t kMTileSize = 16;
  constexpr int32_t kNTileSize = 8;
  constexpr int32_t kKTileSize = 16;
  constexpr int kWarps = 8;
  constexpr int kKTilesPerWarp = 8;

  TORCH_CHECK(activation.is_cuda() && packed_weight.is_cuda());
  TORCH_CHECK(activation.dtype() == torch::kFloat16);
  TORCH_CHECK(activation.dim() == 2 && activation.is_contiguous());
  TORCH_CHECK(
      packed_weight.dim() == 4 && packed_weight.dtype() == torch::kInt32 &&
      packed_weight.is_contiguous());
  TORCH_CHECK(scales_and_zeros.dtype() == torch::kFloat16);
  TORCH_CHECK(lut.dtype() == torch::kFloat16);
  TORCH_CHECK(inv_channel_scale.dtype() == torch::kFloat16);
  TORCH_CHECK(outlier_positions.dtype() == torch::kUInt8);
  TORCH_CHECK(outlier_residual.dtype() == torch::kFloat16);
  TORCH_CHECK(bias.numel() == 0 || bias.dtype() == torch::kFloat16);

  c10::cuda::CUDAGuard guard(activation.device());
  const auto stream = at::cuda::getCurrentCUDAStream();
  const int32_t m = activation.size(0);
  const int32_t k = activation.size(1);
  const int32_t mTiles = divUp(m, kMTileSize);
  const int32_t kTiles = divUp(k, kKTileSize);
  const int32_t nTiles = packed_weight.size(0);
  const int32_t n = nTiles * kNTileSize;
  const int32_t innerKTiles = packed_weight.size(3) * 2;
  const int32_t groups = k / 128;

  TORCH_CHECK(k % 128 == 0);
  TORCH_CHECK(
      innerKTiles == 2 || innerKTiles == 4 || innerKTiles == 8);
  TORCH_CHECK(packed_weight.size(1) == divUp(kTiles, innerKTiles));
  TORCH_CHECK(packed_weight.size(2) == kWarpSize);
  TORCH_CHECK(scales_and_zeros.sizes() == torch::IntArrayRef({groups, n, 2}));
  TORCH_CHECK(lut.sizes() == torch::IntArrayRef({n, 16}));
  TORCH_CHECK(inv_channel_scale.numel() == k);
  TORCH_CHECK(outlier_positions.sizes() == torch::IntArrayRef({n, groups}));
  TORCH_CHECK(outlier_residual.sizes() == torch::IntArrayRef({n, groups}));
  TORCH_CHECK(bias.numel() == 0 || bias.numel() == n);

  auto dqInfo = DequantInfo::empty();
  dqInfo.qInfo1 = scales_and_zeros.data_ptr();
  dqInfo.qInfo2 = lut.data_ptr();
  dqInfo.qInfo3 = inv_channel_scale.data_ptr();
  dqInfo.qInfo4 = outlier_positions.data_ptr();
  dqInfo.qInfo5 = outlier_residual.data_ptr();
  dqInfo.qInfo6 = bias.numel() == 0 ? nullptr : bias.data_ptr();
  dqInfo.qInfo7 = activation.data_ptr();
  dqInfo.iInfo1 = 16;
  dqInfo.iInfo2 = groups;
  dqInfo.iInfo3 = k;
  dqInfo.iInfo4 = bias.numel() == 0 ? 0 : 1;

  auto output = torch::empty(
      {m, n}, torch::TensorOptions().dtype(torch::kFloat16).device(activation.device()));

#define RUN_PSOP(B_INNER_K_TILES)                                             \
  do {                                                                         \
    using ALayout = ALayout_RM<kWarps, FloatType::Float16>;                    \
    using BLayout = BLayout_TC_int4<                                           \
        kWarps,                                                                 \
        FloatType::Float16,                                                     \
        B_INNER_K_TILES,                                                        \
        128,                                                                    \
        Int4_QType::Any4_RowWise_Grouped>;                                     \
    using CLayout = ALayout;                                                    \
    launch_tinygemm_kernel<                                                     \
        FloatType::Float16,                                                     \
        ALayout,                                                                \
        BLayout,                                                                \
        CLayout,                                                                \
        kWarps,                                                                 \
        kKTilesPerWarp>(                                                        \
        activation,                                                            \
        packed_weight,                                                         \
        dqInfo,                                                                 \
        output,                                                                 \
        mTiles,                                                                 \
        nTiles,                                                                 \
        kTiles,                                                                 \
        m,                                                                      \
        n,                                                                      \
        k,                                                                      \
        stream);                                                                \
  } while (false)

  if (innerKTiles == 2) {
    RUN_PSOP(2);
  } else if (innerKTiles == 4) {
    RUN_PSOP(4);
  } else {
    RUN_PSOP(8);
  }
#undef RUN_PSOP

  return output;
}

} // namespace psop_tinygemm
