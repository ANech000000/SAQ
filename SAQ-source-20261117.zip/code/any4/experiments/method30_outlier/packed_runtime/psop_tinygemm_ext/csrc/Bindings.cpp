#include <torch/extension.h>

namespace psop_tinygemm {
torch::Tensor psop_linear_f16rm_any4(
    torch::Tensor activation,
    torch::Tensor packed_weight,
    torch::Tensor scales_and_zeros,
    torch::Tensor lut,
    torch::Tensor inv_channel_scale,
    torch::Tensor outlier_positions,
    torch::Tensor outlier_residual,
    torch::Tensor bias);

torch::Tensor psop_dequantize_f16_any4(
    torch::Tensor packed_weight,
    torch::Tensor scales_and_zeros,
    torch::Tensor lut,
    torch::Tensor inv_channel_scale,
    torch::Tensor outlier_positions,
    torch::Tensor outlier_residual);
} // namespace psop_tinygemm

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.doc() = "Fused Post-AWQ 22A Any4 TinyGemm kernel";
}

TORCH_LIBRARY(psop_tinygemm, module) {
  module.def(
      "linear_f16rm_any4(Tensor activation, Tensor packed_weight, "
      "Tensor scales_and_zeros, Tensor lut, Tensor inv_channel_scale, "
      "Tensor outlier_positions, Tensor outlier_residual, Tensor bias) -> Tensor");
  module.def(
      "dequantize_f16_any4(Tensor packed_weight, Tensor scales_and_zeros, "
      "Tensor lut, Tensor inv_channel_scale, Tensor outlier_positions, "
      "Tensor outlier_residual) -> Tensor");
}

TORCH_LIBRARY_IMPL(psop_tinygemm, CUDA, module) {
  module.impl(
      "linear_f16rm_any4",
      TORCH_FN(psop_tinygemm::psop_linear_f16rm_any4));
  module.impl(
      "dequantize_f16_any4",
      TORCH_FN(psop_tinygemm::psop_dequantize_f16_any4));
}
