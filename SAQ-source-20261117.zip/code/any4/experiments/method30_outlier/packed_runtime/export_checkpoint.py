import argparse
import json
import sys
from pathlib import Path

from packed_format import (
    FORMAT_NAME,
    FORMAT_VERSION,
    atomic_write_json,
    export_layer,
    safe_layer_name,
    utc_now,
)


DEFAULT_SOURCE = Path(
    "/data/lsz/any4/experiments/llama3_8b_reproduction/cache/final_state/"
    "f3c0aa632a54d28d6f32f311"
)
DEFAULT_OUTPUT = Path(
    "/data/lsz/any4/experiments/method30_outlier/checkpoints/"
    "llama3_8b_postawq_22a/fp16_meta"
)
DEFAULT_MODEL = "/data/model/models--meta-llama--Meta-Llama-3-8B"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-state-root", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--model-path", default=DEFAULT_MODEL)
    parser.add_argument(
        "--metadata-dtype",
        choices=("fp16", "mixed", "fp32"),
        default="mixed",
    )
    parser.add_argument("--expected-linears", type=int, default=224)
    return parser.parse_args()


def main():
    args = parse_args()
    manifest_path = args.output_dir / "manifest.json"
    if manifest_path.exists():
        raise RuntimeError(f"Refusing to overwrite existing checkpoint: {manifest_path}")
    sources = sorted(args.source_state_root.glob("*/iter_0010.pt"))
    if len(sources) != args.expected_linears:
        raise RuntimeError(
            f"Expected {args.expected_linears} source states, found {len(sources)}"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    layers = []
    components = {}
    for index, source in enumerate(sources, 1):
        import torch
        payload = torch.load(source, map_location="cpu", weights_only=False)
        layer_name = payload["metadata"]["layer_name"]
        output = args.output_dir / f"{safe_layer_name(layer_name)}.safetensors"
        if output.exists():
            raise RuntimeError(f"Refusing to overwrite layer: {output}")
        record = export_layer(source, output, args.metadata_dtype)
        layers.append(record)
        for key, value in record["components_bytes"].items():
            components[key] = components.get(key, 0) + int(value)
        print(
            f"[{index}/{len(sources)}] {layer_name} "
            f"{record['file_bpw']:.6f} file BPW",
            flush=True,
        )
    total_weights = sum(item["weight_count"] for item in layers)
    tensor_bytes = sum(item["tensor_bytes"] for item in layers)
    file_bytes = sum(item["file_bytes"] for item in layers)
    manifest = {
        "format": FORMAT_NAME,
        "format_version": FORMAT_VERSION,
        "status": "complete",
        "method": "method30_post_awq_22a",
        "model_path": args.model_path,
        "source_state_root": str(args.source_state_root),
        "source_fingerprint": args.source_state_root.name,
        "metadata_dtype": args.metadata_dtype,
        "linears": len(layers),
        "group_size": 128,
        "lut_entries": 16,
        "normal_values_per_group": 127,
        "total_quantized_weights": total_weights,
        "components_bytes": components,
        "tensor_bytes": tensor_bytes,
        "physical_layer_file_bytes": file_bytes,
        "tensor_bpw": 8.0 * tensor_bytes / total_weights,
        "physical_layer_file_bpw": 8.0 * file_bytes / total_weights,
        "created_at": utc_now(),
        "layers": layers,
    }
    atomic_write_json(manifest_path, manifest)
    print(json.dumps({key: manifest[key] for key in (
        "linears", "total_quantized_weights", "tensor_bytes",
        "physical_layer_file_bytes", "tensor_bpw", "physical_layer_file_bpw"
    )}, indent=2))


if __name__ == "__main__":
    main()
