import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from packed_model import load_packed_model, load_tokenizer, memory_stats


def assert_empty_gpu(index):
    output = subprocess.check_output([
        'nvidia-smi', f'--id={index}',
        '--query-gpu=memory.used,utilization.gpu',
        '--format=csv,noheader,nounits',
    ], text=True)
    used, utilization = (int(item.strip()) for item in output.strip().split(','))
    if used > 256 or utilization > 5:
        raise RuntimeError(f'GPU {index} is not empty: {used} MiB, {utilization}%')
    return {'memory_used_mib': used, 'utilization_percent': utilization}


def load_runtime(runtime, checkpoint, model_path):
    if runtime == 'packed':
        tokenizer = load_tokenizer(checkpoint)
        model, manifest, load_result = load_packed_model(checkpoint)
        return model, tokenizer, load_result, manifest
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    started = time.perf_counter()
    torch.cuda.reset_peak_memory_stats()
    model = AutoModelForCausalLM.from_pretrained(
        model_path, local_files_only=True, torch_dtype=torch.float16,
        low_cpu_mem_usage=True, device_map={'': 'cuda:0'},
        attn_implementation='sdpa',
    ).eval()
    torch.cuda.synchronize()
    return model, tokenizer, {
        'seconds': time.perf_counter() - started, 'memory': memory_stats()
    }, None


def make_prompt(tokenizer, length, batch):
    text = ('Post-scaling outlier-preserved lookup-table quantization for '
            'large language models. ') * (length // 8 + 8)
    tokens = tokenizer(text, add_special_tokens=False).input_ids
    if len(tokens) < length:
        raise RuntimeError('Prompt construction failed')
    ids = torch.tensor(tokens[:length], dtype=torch.long, device='cuda:0')
    return ids.unsqueeze(0).expand(batch, -1).contiguous()


def elapsed(fn, repeats=3):
    for _ in range(1):
        fn()
    torch.cuda.synchronize()
    values = []
    for _ in range(repeats):
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record(); fn(); end.record(); torch.cuda.synchronize()
        values.append(start.elapsed_time(end))
    values.sort()
    return {'median_ms': values[len(values)//2], 'values_ms': values}


def measure(model, input_ids, output_tokens):
    batch, prompt_length = input_ids.shape
    torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode():
        prefill = elapsed(
            lambda: model(input_ids=input_ids, use_cache=True), repeats=3
        )
        outputs = model(input_ids=input_ids, use_cache=True)
        cache = outputs.past_key_values
        token = outputs.logits[:, -1:].argmax(dim=-1)
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(output_tokens):
            outputs = model(
                input_ids=token, past_key_values=cache, use_cache=True
            )
            cache = outputs.past_key_values
            token = outputs.logits[:, -1:].argmax(dim=-1)
        torch.cuda.synchronize()
        decode_seconds = time.perf_counter() - start
    return {
        'batch': batch,
        'prompt_tokens': prompt_length,
        'output_tokens_per_request': output_tokens,
        'prefill': {
            **prefill,
            'tokens_per_second': batch * prompt_length /
                (prefill['median_ms'] * 1e-3),
        },
        'decode': {
            'seconds': decode_seconds,
            'output_tokens_per_second': batch * output_tokens / decode_seconds,
            'milliseconds_per_step': 1000.0 * decode_seconds / output_tokens,
        },
        'memory': memory_stats(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', choices=('packed', 'fp16'), required=True)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--model-path', default='/data/model/models--meta-llama--Meta-Llama-3-8B')
    parser.add_argument('--physical-gpu', required=True)
    parser.add_argument('--batches', default='1,4,8')
    parser.add_argument('--prompt-lengths', default='128,512,2048')
    parser.add_argument('--output-tokens', type=int, default=128)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    gpu_before = assert_empty_gpu(args.physical_gpu)
    model, tokenizer, load_result, manifest = load_runtime(
        args.runtime, args.checkpoint, args.model_path
    )
    measurements = []
    for batch in [int(x) for x in args.batches.split(',')]:
        for prompt_length in [int(x) for x in args.prompt_lengths.split(',')]:
            ids = make_prompt(tokenizer, prompt_length, batch)
            result = measure(model, ids, args.output_tokens)
            measurements.append(result)
            print(
                f'B={batch} L={prompt_length}: prefill '
                f'{result["prefill"]["tokens_per_second"]:.1f} tok/s, decode '
                f'{result["decode"]["output_tokens_per_second"]:.1f} tok/s',
                flush=True,
            )
            del ids
            torch.cuda.empty_cache()
    payload = {
        'status': 'complete',
        'runtime': args.runtime,
        'gpu': torch.cuda.get_device_name(0),
        'physical_gpu': args.physical_gpu,
        'gpu_before': gpu_before,
        'load': load_result,
        'storage': None if manifest is None else {
            'linear_file_bpw': manifest['linear_file_bpw'],
            'whole_model_file_bpw': manifest['whole_model_file_bpw'],
        },
        'measurements': measurements,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps({'status': 'complete', 'measurements': len(measurements)}))


if __name__ == '__main__':
    main()
