import argparse
import csv
import json
from pathlib import Path


def load(path):
    return json.loads(Path(path).read_text())


def write_csv(path, rows):
    if not rows:
        return
    with Path(path).open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    args = parser.parse_args()
    outputs = [
        args.run_root / 'paper_metrics.json',
        args.run_root / 'paper_kernel.csv',
        args.run_root / 'paper_model.csv',
        args.run_root / 'paper_service.csv',
    ]
    if any(path.exists() for path in outputs):
        raise FileExistsError('Refusing to overwrite paper metric artifacts')

    manifest = load(args.checkpoint / 'manifest.json')
    kernel = load(args.run_root / 'kernel/tinygemm_fused_all_shapes.json')
    wiki = load(args.run_root / 'model/tinygemm_wiki2.json')
    c4 = load(args.run_root / 'model/tinygemm_c4.json')
    ptb = load(args.run_root / 'model/tinygemm_ptb.json')
    packed_model = load(args.run_root / 'model/throughput_packed.json')
    fp16_model = load(args.run_root / 'model/throughput_fp16.json')
    packed_service = load(args.run_root / 'service/packed.json')
    fp16_service = load(args.run_root / 'service/fp16.json')

    kernel_rows = []
    for layer in kernel['layers']:
        for measurement in layer['measurements']:
            kernel_rows.append({
                'layer': layer['layer'],
                'n': layer['shape'][0],
                'k': layer['shape'][1],
                'm': measurement['m'],
                'relative_mse': measurement['relative_mse'],
                'fp16_ms': measurement['timing']['fp16_cublas']['median_ms'],
                'psop_fused_ms': measurement['timing']['psop_fused']['median_ms'],
                'speedup_vs_fp16': measurement['fused_speedup_vs_fp16'],
                'psop_tflops': measurement['timing']['psop_fused']['tflops'],
            })

    packed_by_key = {
        (item['batch'], item['prompt_tokens']): item
        for item in packed_model['measurements']
    }
    fp16_by_key = {
        (item['batch'], item['prompt_tokens']): item
        for item in fp16_model['measurements']
    }
    model_rows = []
    for key in sorted(packed_by_key):
        packed = packed_by_key[key]
        fp16 = fp16_by_key[key]
        model_rows.append({
            'batch': key[0],
            'prompt_tokens': key[1],
            'packed_prefill_tokens_s': packed['prefill']['tokens_per_second'],
            'fp16_prefill_tokens_s': fp16['prefill']['tokens_per_second'],
            'prefill_speedup': packed['prefill']['tokens_per_second'] /
                fp16['prefill']['tokens_per_second'],
            'packed_decode_tokens_s': packed['decode']['output_tokens_per_second'],
            'fp16_decode_tokens_s': fp16['decode']['output_tokens_per_second'],
            'decode_speedup': packed['decode']['output_tokens_per_second'] /
                fp16['decode']['output_tokens_per_second'],
            'packed_peak_allocated_mib': packed['memory']['max_allocated_mib'],
            'fp16_peak_allocated_mib': fp16['memory']['max_allocated_mib'],
        })

    packed_service_by_c = {
        item['concurrency']: item for item in packed_service['measurements']
    }
    fp16_service_by_c = {
        item['concurrency']: item for item in fp16_service['measurements']
    }
    service_rows = []
    for concurrency in sorted(packed_service_by_c):
        packed = packed_service_by_c[concurrency]
        fp16 = fp16_service_by_c[concurrency]
        service_rows.append({
            'concurrency': concurrency,
            'packed_output_tokens_s': packed['output_tokens_per_second'],
            'fp16_output_tokens_s': fp16['output_tokens_per_second'],
            'throughput_speedup': packed['output_tokens_per_second'] /
                fp16['output_tokens_per_second'],
            'packed_ttft_p50_ms': packed['ttft_ms_p50'],
            'fp16_ttft_p50_ms': fp16['ttft_ms_p50'],
            'packed_itl_p50_ms': packed['itl_ms_p50'],
            'fp16_itl_p50_ms': fp16['itl_ms_p50'],
        })

    pseudo_ppl = {
        'wiki2': 6.3587446212768555,
        'c4': 8.193648338317871,
        'ptb': 11.473586082458496,
    }
    packed_ppl = {
        'wiki2': wiki['metrics']['wiki2']['ppl'],
        'c4': c4['metrics']['c4']['ppl'],
        'ptb': ptb['metrics']['ptb']['ppl'],
    }
    payload = {
        'method': 'method30_post_awq_22a',
        'checkpoint': {
            key: manifest[key] for key in (
                'linear_tensor_bpw', 'linear_file_bpw',
                'whole_model_tensor_bpw', 'whole_model_file_bpw',
                'model_file_bytes',
            )
        },
        'accuracy': {
            dataset: {
                'pseudo_ppl': pseudo_ppl[dataset],
                'packed_fused_ppl': packed_ppl[dataset],
                'delta': packed_ppl[dataset] - pseudo_ppl[dataset],
            } for dataset in pseudo_ppl
        },
        'memory': {
            'packed_load_allocated_mib': wiki['memory_after_load']['allocated_mib'],
            'packed_load_reserved_mib': wiki['memory_after_load']['reserved_mib'],
            'fp16_load_allocated_mib': fp16_model['load']['memory']['allocated_mib'],
            'fp16_load_reserved_mib': fp16_model['load']['memory']['reserved_mib'],
        },
        'kernel_summary': {
            'decode_m1_speedups': [
                row['speedup_vs_fp16'] for row in kernel_rows if row['m'] == 1
            ],
            'prefill_m2048_speedups': [
                row['speedup_vs_fp16'] for row in kernel_rows if row['m'] == 2048
            ],
        },
        'limitations': [
            'The current TinyGemm kernel is optimized for decode-sized M and is slower than FP16 cuBLAS for large prefill M.',
            'The lightweight HTTP server serializes concurrent requests and does not implement continuous batching.',
        ],
    }
    args.run_root.mkdir(parents=True, exist_ok=True)
    (args.run_root / 'paper_metrics.json').write_text(
        json.dumps(payload, indent=2) + '\n'
    )
    write_csv(args.run_root / 'paper_kernel.csv', kernel_rows)
    write_csv(args.run_root / 'paper_model.csv', model_rows)
    write_csv(args.run_root / 'paper_service.csv', service_rows)
    print(json.dumps(payload, indent=2))


if __name__ == '__main__':
    main()
