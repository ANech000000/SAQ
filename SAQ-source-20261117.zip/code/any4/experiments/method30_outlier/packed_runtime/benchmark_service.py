import argparse
import concurrent.futures
import json
import statistics
import threading
import time
from pathlib import Path

import requests


def percentile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    index = min(len(ordered) - 1, int(round((len(ordered) - 1) * q)))
    return ordered[index]


def one_request(url, prompt, output_tokens, barrier):
    payload = {
        'model': 'method30-post-awq-22a',
        'prompt': prompt,
        'max_tokens': output_tokens,
        'stream': True,
    }
    barrier.wait()
    started = time.perf_counter()
    arrivals = []
    with requests.post(
        f'{url}/v1/completions', json=payload, stream=True, timeout=1800
    ) as response:
        response.raise_for_status()
        for line in response.iter_lines():
            if not line or line == b'data: [DONE]':
                continue
            if line.startswith(b'data: {'):
                arrivals.append(time.perf_counter())
    finished = time.perf_counter()
    if len(arrivals) != output_tokens:
        raise RuntimeError(f'Expected {output_tokens} chunks, got {len(arrivals)}')
    intervals = [
        1000.0 * (arrivals[index] - arrivals[index - 1])
        for index in range(1, len(arrivals))
    ]
    return {
        'ttft_ms': 1000.0 * (arrivals[0] - started),
        'total_seconds': finished - started,
        'output_tokens': len(arrivals),
        'itl_ms': intervals,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', default='http://127.0.0.1:18030')
    parser.add_argument('--concurrency', default='1,4,8,16')
    parser.add_argument('--output-tokens', type=int, default=128)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    health = requests.get(f'{args.url}/health', timeout=60).json()
    prompt = (
        'Post-scaling outlier-preserved lookup-table quantization improves '
        'weight-only model deployment. '
    ) * 18
    measurements = []
    for concurrency in [int(x) for x in args.concurrency.split(',')]:
        barrier = threading.Barrier(concurrency)
        wall_started = time.perf_counter()
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = [
                pool.submit(
                    one_request, args.url, prompt, args.output_tokens, barrier
                ) for _ in range(concurrency)
            ]
            requests_result = [future.result() for future in futures]
        wall_seconds = time.perf_counter() - wall_started
        ttft = [item['ttft_ms'] for item in requests_result]
        itl = [value for item in requests_result for value in item['itl_ms']]
        total_output = sum(item['output_tokens'] for item in requests_result)
        measurement = {
            'concurrency': concurrency,
            'requests': concurrency,
            'output_tokens': total_output,
            'wall_seconds': wall_seconds,
            'output_tokens_per_second': total_output / wall_seconds,
            'ttft_ms_p50': percentile(ttft, 0.5),
            'ttft_ms_p95': percentile(ttft, 0.95),
            'itl_ms_p50': percentile(itl, 0.5),
            'itl_ms_p95': percentile(itl, 0.95),
            'request_seconds_mean': statistics.mean(
                item['total_seconds'] for item in requests_result
            ),
        }
        measurements.append(measurement)
        print(json.dumps(measurement), flush=True)
    payload = {
        'status': 'complete',
        'url': args.url,
        'health': health,
        'protocol': {
            'concurrency': [int(x) for x in args.concurrency.split(',')],
            'output_tokens_per_request': args.output_tokens,
            'streaming': True,
        },
        'measurements': measurements,
        'server_metrics': requests.get(f'{args.url}/metrics', timeout=60).json(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + '\n')


if __name__ == '__main__':
    main()
