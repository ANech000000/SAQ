import argparse
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
REPO = Path('/data/lsz/any4')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO))

import tinygemm  # noqa: F401
from packed_format import load_layer, reconstruct_weight
from tinygemm_composite import (
    apply_outlier_residual,
    prepare_tinygemm_runtime,
    psop_tinygemm_composite,
    psop_tinygemm_fused,
    runtime_tensor_bytes,
    tinygemm_main,
)


def benchmark(fn, warmup=20, repeats=100):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    values = []
    for _ in range(repeats):
        start.record()
        fn()
        end.record()
        torch.cuda.synchronize()
        values.append(start.elapsed_time(end))
    tensor = torch.tensor(values, dtype=torch.float64)
    return {
        'median_ms': float(tensor.median()),
        'mean_ms': float(tensor.mean()),
        'min_ms': float(tensor.min()),
    }


def locate(checkpoint, needle):
    manifest = json.loads((checkpoint / 'manifest.json').read_text())
    entry = next(item for item in manifest['layers'] if needle in item['layer_name'])
    return checkpoint / entry['file'], entry


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--layer', default='layers.0.self_attn.q_proj')
    parser.add_argument('--m', type=int, default=4)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()

    layer_path, entry = locate(args.checkpoint, args.layer)
    tensors, metadata = load_layer(layer_path, device='cpu')
    runtime = prepare_tinygemm_runtime(tensors, metadata, device='cuda:0')
    rows, cols = json.loads(metadata['weight_shape'])
    weight = reconstruct_weight(tensors, metadata, output_dtype=torch.float16, device='cuda:0')
    generator = torch.Generator(device='cuda:0').manual_seed(20260728)
    x = torch.randn((args.m, cols), device='cuda:0', dtype=torch.float16, generator=generator)

    y_ref = x @ weight.t()
    y = psop_tinygemm_composite(x, runtime)
    y_fused = psop_tinygemm_fused(x, runtime)
    fused_diff = y_fused.float() - y_ref.float()
    fused_relative_mse = float(
        fused_diff.square().mean() / y_ref.float().square().mean().clamp_min(1e-12)
    )
    x_scaled = x * runtime['inv_channel_scale']
    residual_scratch = tinygemm_main(x_scaled, runtime)
    diff = y.float() - y_ref.float()
    relative_mse = float(diff.square().mean() / y_ref.float().square().mean().clamp_min(1e-12))
    result = {
        'layer': entry['layer_name'],
        'shape': [rows, cols],
        'm': args.m,
        'relative_mse': relative_mse,
        'max_abs': float(diff.abs().max()),
        'fused_relative_mse': fused_relative_mse,
        'fused_max_abs': float(fused_diff.abs().max()),
        'runtime_tensor_bytes': runtime_tensor_bytes(runtime),
        'runtime_linear_bpw': 8.0 * runtime_tensor_bytes(runtime) / (rows * cols),
        'timing': {
            'fp16': benchmark(lambda: x @ weight.t()),
            'psop_composite': benchmark(lambda: psop_tinygemm_composite(x, runtime)),
            'psop_fused': benchmark(lambda: psop_tinygemm_fused(x, runtime)),
            'input_scale': benchmark(lambda: x * runtime['inv_channel_scale']),
            'tinygemm_main_pre_scaled': benchmark(lambda: tinygemm_main(x_scaled, runtime)),
            'outlier_residual_inplace': benchmark(
                lambda: apply_outlier_residual(x_scaled, residual_scratch, runtime)
            ),
        },
    }
    result['composite_speedup_vs_fp16'] = (
        result['timing']['fp16']['median_ms'] / result['timing']['psop_composite']['median_ms']
    )
    result['fused_speedup_vs_fp16'] = (
        result['timing']['fp16']['median_ms'] / result['timing']['psop_fused']['median_ms']
    )
    if relative_mse > 1e-5 or fused_relative_mse > 1e-5:
        raise RuntimeError(
            f'Relative MSE composite={relative_mse}, fused={fused_relative_mse} exceeds 1e-5'
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
