import json
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REFINE = ROOT / "experiments" / "method30_postawq_refine"
sys.path.insert(0, str(REFINE))

from method30_refine import reconstruct_from_state
from state_cache import load_state_cache
from packed_format import (
    atomic_write_json,
    export_layer,
    load_layer,
    reconstruct_weight,
    reference_linear,
    sha256_tensor,
)

SOURCE = Path(
    "/data/lsz/any4/experiments/llama3_8b_reproduction/cache/final_state/"
    "f3c0aa632a54d28d6f32f311/model__layers__0__self_attn__q_proj/iter_0010.pt"
)
OUTPUT = Path(
    "/data/lsz/any4/experiments/method30_outlier/runs/llama3_8b/"
    "postawq_22a_packed/smoke"
)


def run_variant(metadata_dtype, oracle):
    path = OUTPUT / f"q_proj_{metadata_dtype}.safetensors"
    if not path.exists():
        export_layer(SOURCE, path, metadata_dtype)
    tensors, metadata = load_layer(path)
    reconstructed = reconstruct_weight(tensors, metadata)
    difference = reconstructed.float() - oracle.float()
    torch.manual_seed(0)
    activation = torch.randn(4, oracle.shape[1], dtype=torch.float16)
    oracle_output = F.linear(activation, oracle)
    packed_output = reference_linear(activation, tensors, metadata)
    output_difference = packed_output.float() - oracle_output.float()
    return {
        "path": str(path),
        "file_bytes": path.stat().st_size,
        "weight_sha256": sha256_tensor(reconstructed),
        "weight_exact": bool(torch.equal(reconstructed, oracle)),
        "weight_max_abs": float(difference.abs().max()),
        "weight_relative_mse": float(
            difference.square().sum() / oracle.float().square().sum().clamp_min(1e-30)
        ),
        "output_max_abs": float(output_difference.abs().max()),
        "output_relative_mse": float(
            output_difference.square().sum()
            / oracle_output.float().square().sum().clamp_min(1e-30)
        ),
    }


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    payload = torch.load(SOURCE, map_location="cpu", weights_only=False)
    state, _ = load_state_cache(SOURCE, payload["metadata"])
    rows, cols = state["weight_shape"]
    oracle = reconstruct_from_state(
        torch.zeros((rows, cols), dtype=torch.float16), state
    )
    result = {
        "status": "complete",
        "source": str(SOURCE),
        "source_state_hash": payload["state_hash"],
        "oracle_sha256": sha256_tensor(oracle),
        "fp32": run_variant("fp32", oracle),
        "mixed": run_variant("mixed", oracle),
        "fp16": run_variant("fp16", oracle),
    }
    result["acceptance"] = {
        "fp32_exact": result["fp32"]["weight_exact"],
        "mixed_weight_relative_mse_max": 1e-6,
        "mixed_output_relative_mse_max": 1e-6,
        "mixed_pass": (
            result["mixed"]["weight_relative_mse"] <= 1e-6
            and result["mixed"]["output_relative_mse"] <= 1e-6
        ),
        "fp16_is_ppl_candidate": result["fp16"]["output_relative_mse"] <= 5e-6,
    }
    atomic_write_json(OUTPUT / "results_v2.json", result)
    print(json.dumps(result, indent=2))
    if not result["acceptance"]["fp32_exact"]:
        raise AssertionError("FP32 packed reference does not match the source state.")
    if not result["acceptance"]["mixed_pass"]:
        raise AssertionError("Mixed metadata exceeds the smoke error threshold.")


if __name__ == "__main__":
    main()
