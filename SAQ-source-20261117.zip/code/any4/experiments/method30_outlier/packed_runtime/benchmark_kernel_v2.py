import json
import os
from pathlib import Path

import torch
import torch.nn.functional as F

from packed_format import atomic_write_json, load_layer, reconstruct_weight
from triton_kernel import make_runtime_tensors
from triton_kernel_v2 import psop_linear_v2

LAYER = Path(
    "/data/lsz/any4/experiments/method30_outlier/checkpoints/"
    "llama3_8b_postawq_22a/fp16_meta/model__layers__0__self_attn__q_proj.safetensors"
)
OUTPUT = Path(
    "/data/lsz/any4/experiments/method30_outlier/runs/llama3_8b/"
    "postawq_22a_packed/kernel/tile_search_v2.json"
)
CONFIGS = {
    1: [(16, 16, 4), (16, 32, 4), (16, 64, 4), (16, 64, 8)],
    4: [(16, 16, 4), (16, 32, 4), (16, 64, 4), (16, 64, 8)],
    16: [(16, 16, 4), (16, 32, 4), (16, 64, 4), (16, 64, 8)],
    128: [(16, 32, 4), (32, 32, 4), (32, 64, 4), (32, 64, 8), (64, 32, 8)],
}


def benchmark(callable_, warmup=10, repeats=50):
    for _ in range(warmup):
        callable_()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    samples = []
    for _ in range(repeats):
        start.record()
        callable_()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end))
    values = torch.tensor(samples)
    return {
        "median_ms": float(values.median()),
        "p95_ms": float(values.kthvalue(max(1, int(0.95 * repeats)))[0]),
    }


def main():
    tensors, metadata = load_layer(LAYER)
    runtime = make_runtime_tensors(tensors, metadata)
    weight = reconstruct_weight(tensors, metadata).cuda()
    rows, cols = weight.shape
    results = {}
    for m, configs in CONFIGS.items():
        torch.manual_seed(m)
        x = torch.randn(m, cols, device="cuda", dtype=torch.float16)
        reference = F.linear(x, weight)
        baseline = benchmark(lambda: F.linear(x, weight))
        records = []
        for block_m, block_n, warps in configs:
            observed = psop_linear_v2(
                x, runtime, block_m=block_m, block_n=block_n, num_warps=warps
            )
            difference = observed.float() - reference.float()
            timing = benchmark(
                lambda bm=block_m, bn=block_n, nw=warps: psop_linear_v2(
                    x, runtime, block_m=bm, block_n=bn, num_warps=nw
                )
            )
            record = {
                "block_m": block_m,
                "block_n": block_n,
                "num_warps": warps,
                "relative_mse": float(
                    difference.square().sum()
                    / reference.float().square().sum().clamp_min(1e-30)
                ),
                "max_abs": float(difference.abs().max()),
                "timing": timing,
                "speedup_vs_fp16": baseline["median_ms"] / timing["median_ms"],
            }
            records.append(record)
            print(m, record, flush=True)
        best = min(records, key=lambda item: item["timing"]["median_ms"])
        results[str(m)] = {"fp16": baseline, "configs": records, "best": best}
    output = {
        "status": "complete",
        "layer": str(LAYER),
        "gpu": torch.cuda.get_device_name(0),
        "weight_shape": [rows, cols],
        "results": results,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        raise RuntimeError(f"Refusing to overwrite {OUTPUT}")
    atomic_write_json(OUTPUT, output)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
