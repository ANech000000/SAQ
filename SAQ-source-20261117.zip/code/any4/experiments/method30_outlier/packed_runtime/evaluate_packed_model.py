import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('HF_DATASETS_OFFLINE', '1')
os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPRO = ROOT / 'experiments' / 'llama3_8b_reproduction'
sys.path[:0] = [str(HERE), str(ROOT), str(REPRO)]

from data_gptq import get_loaders, llama_eval
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test
from packed_format import atomic_write_json, utc_now
from packed_model import load_packed_model, load_tokenizer, memory_stats

DEFAULT_C4 = '/data/lsz/llm_dataset/pretraining/C4'
DEFAULT_PTB = '/data/lsz/llm_dataset/language_modeling/PTB'


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get('CUDA_VISIBLE_DEVICES', '')
    if visible != str(index):
        raise RuntimeError(f'Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}')
    output = subprocess.check_output(
        [
            'nvidia-smi', f'--id={index}',
            '--query-gpu=memory.used,utilization.gpu',
            '--format=csv,noheader,nounits',
        ], text=True,
    )
    used, utilization = (int(value.strip()) for value in output.strip().split(','))
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(f'GPU {index} is not empty: {used} MiB, {utilization}%')
    return {'memory_used_mib': used, 'utilization_percent': utilization}


def evaluate(model, tokenizer, selected, seqlen, c4_samples, seed):
    metrics = {}
    if 'wiki2' in selected:
        _, testenc = get_loaders(
            'wikitext-2', tokenizer=tokenizer, seed=seed,
            seqlen=seqlen, nsamples=128,
        )
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, 'cuda', seqlen=seqlen))
        metrics['wiki2'] = {
            'ppl': ppl,
            'segments': int(testenc.input_ids.numel() // seqlen),
            'seconds': time.perf_counter() - started,
        }
        print(f'WikiText-2 PPL={ppl:.10f}', flush=True)
    if 'c4' in selected:
        testenc = load_c4_eval(DEFAULT_C4, tokenizer, seqlen, c4_samples, seed)
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, 'cuda', seqlen=seqlen))
        metrics['c4'] = {
            'ppl': ppl,
            'segments': int(testenc.input_ids.numel() // seqlen),
            'seconds': time.perf_counter() - started,
        }
        print(f'C4 PPL={ppl:.10f}', flush=True)
    if 'ptb' in selected:
        testenc = load_ptb_test(DEFAULT_PTB, tokenizer, seqlen)
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, 'cuda', seqlen=seqlen))
        metrics['ptb'] = {
            'ppl': ppl,
            'segments': int(testenc.input_ids.numel() // seqlen),
            'seconds': time.perf_counter() - started,
        }
        print(f'PTB PPL={ppl:.10f}', flush=True)
    return metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--physical-gpu', required=True)
    parser.add_argument('--datasets', default='wiki2')
    parser.add_argument('--seqlen', type=int, default=2048)
    parser.add_argument('--c4-samples', type=int, default=256)
    parser.add_argument('--seed', type=int, default=0)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)

    gpu_before = assert_empty_gpu(args.physical_gpu)
    started = time.perf_counter()
    tokenizer = load_tokenizer(args.checkpoint_dir)
    model, manifest, load_result = load_packed_model(args.checkpoint_dir)
    memory_after_load = memory_stats()
    selected = {item.strip() for item in args.datasets.split(',') if item.strip()}
    metrics = evaluate(
        model, tokenizer, selected, args.seqlen, args.c4_samples, args.seed
    )
    torch.cuda.synchronize()
    result = {
        'status': 'complete',
        'method': 'method30_post_awq_22a_tinygemm_fused',
        'checkpoint_dir': str(args.checkpoint_dir),
        'physical_gpu': args.physical_gpu,
        'gpu_before': gpu_before,
        'protocol': {
            'datasets': sorted(selected),
            'seqlen': args.seqlen,
            'c4_samples': args.c4_samples,
            'seed': args.seed,
        },
        'storage': {
            key: manifest[key] for key in (
                'quantized_weights', 'nonquantized_parameters', 'total_parameters',
                'linear_tensor_bpw', 'linear_file_bpw',
                'whole_model_tensor_bpw', 'whole_model_file_bpw',
                'model_file_bytes',
            )
        },
        'load': load_result,
        'memory_after_load': memory_after_load,
        'metrics': metrics,
        'wall_seconds': time.perf_counter() - started,
        'finished_at': utc_now(),
    }
    atomic_write_json(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
