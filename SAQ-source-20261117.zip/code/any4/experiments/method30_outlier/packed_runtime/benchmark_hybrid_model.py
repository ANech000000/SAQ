import argparse
import json
import sys
from pathlib import Path

import torch


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from packed_model import PackedPostAWQ22ALinear, load_packed_model, memory_stats


def set_threshold(model, value):
    count = 0
    for module in model.modules():
        if isinstance(module, PackedPostAWQ22ALinear):
            module.tinygemm_max_m = value
            count += 1
    if count != 224:
        raise RuntimeError(f'Expected 224 packed Linear modules, got {count}')


def benchmark(callable_, warmup, repeats):
    for _ in range(warmup):
        result = callable_()
        del result
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    samples = []
    for _ in range(repeats):
        start.record()
        result = callable_()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end))
        del result
    values = torch.tensor(samples, dtype=torch.float64)
    return {
        'median_ms': float(values.median()),
        'min_ms': float(values.min()),
        'mean_ms': float(values.mean()),
    }


def relative_mse(observed, reference):
    difference = observed.float() - reference.float()
    return (
        float(
            difference.square().mean() /
            reference.float().square().mean().clamp_min(1e-12)
        ),
        float(difference.abs().max()),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint-dir', type=Path, required=True)
    parser.add_argument('--sequence-lengths', default='128,512,2048')
    parser.add_argument('--tinygemm-max-m', type=int, default=64)
    parser.add_argument('--warmup', type=int, default=1)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.output is not None and args.output.exists():
        raise FileExistsError(args.output)

    model, _, load_result = load_packed_model(
        args.checkpoint_dir,
        tinygemm_max_m=args.tinygemm_max_m,
    )
    generator = torch.Generator(device='cuda:0').manual_seed(20260804)
    results = []
    with torch.inference_mode():
        for sequence_length in [
            int(value) for value in args.sequence_lengths.split(',')
        ]:
            input_ids = torch.randint(
                0,
                model.config.vocab_size,
                (1, sequence_length),
                device='cuda:0',
                generator=generator,
            )

            set_threshold(model, -1)
            legacy_logits = model(input_ids=input_ids, use_cache=False).logits
            legacy_timing = benchmark(
                lambda: model(input_ids=input_ids, use_cache=False).logits,
                args.warmup,
                args.repeats,
            )

            set_threshold(model, args.tinygemm_max_m)
            hybrid_logits = model(input_ids=input_ids, use_cache=False).logits
            hybrid_timing = benchmark(
                lambda: model(input_ids=input_ids, use_cache=False).logits,
                args.warmup,
                args.repeats,
            )
            mse, max_abs = relative_mse(hybrid_logits, legacy_logits)
            results.append({
                'sequence_length': sequence_length,
                'legacy_tinygemm': legacy_timing,
                'hybrid': hybrid_timing,
                'hybrid_speedup_vs_legacy': (
                    legacy_timing['median_ms'] /
                    hybrid_timing['median_ms']
                ),
                'logits_relative_mse': mse,
                'logits_max_abs': max_abs,
            })
            del input_ids, legacy_logits, hybrid_logits

    result = {
        'status': 'complete',
        'gpu': torch.cuda.get_device_name(0),
        'tinygemm_max_m': args.tinygemm_max_m,
        'warmup': args.warmup,
        'repeats': args.repeats,
        'load_memory': load_result['memory'],
        'final_memory': memory_stats(),
        'results': results,
    }
    if any(item['logits_relative_mse'] > 1e-4 for item in results):
        raise RuntimeError('Hybrid logits relative MSE exceeded tolerance')
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
