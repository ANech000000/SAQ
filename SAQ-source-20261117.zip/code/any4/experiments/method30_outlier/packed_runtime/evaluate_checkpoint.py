import argparse
import gc
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPRO = ROOT / "experiments" / "llama3_8b_reproduction"
sys.path[:0] = [str(HERE), str(ROOT), str(REPRO)]

from data_gptq import get_loaders, llama_eval
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test
from packed_format import atomic_write_json, load_layer, reconstruct_weight, utc_now

DEFAULT_MODEL = "/data/model/models--meta-llama--Meta-Llama-3-8B"
DEFAULT_C4 = "/data/lsz/llm_dataset/pretraining/C4"
DEFAULT_PTB = "/data/lsz/llm_dataset/language_modeling/PTB"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--model-path", default=DEFAULT_MODEL)
    parser.add_argument("--datasets", default="wiki2")
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--c4-samples", type=int, default=256)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def assert_empty_gpu(index, max_memory=256, max_utilization=5):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(index):
        raise RuntimeError(f"Expected CUDA_VISIBLE_DEVICES={index}, got {visible!r}")
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    used, utilization = (int(value.strip()) for value in output.strip().split(","))
    if used > max_memory or utilization > max_utilization:
        raise RuntimeError(f"GPU {index} is not empty: {used} MiB, {utilization}%")
    return {"memory_used_mib": used, "utilization_percent": utilization}


def memory_stats():
    return {
        "allocated_mib": torch.cuda.memory_allocated() / 2**20,
        "reserved_mib": torch.cuda.memory_reserved() / 2**20,
        "max_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
        "max_reserved_mib": torch.cuda.max_memory_reserved() / 2**20,
    }


def load_model(model_path):
    tokenizer = AutoTokenizer.from_pretrained(
        model_path, local_files_only=True, trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map={"": "cuda:0"},
    )
    return model.eval(), tokenizer


def apply_checkpoint(model, checkpoint_dir, manifest):
    modules = dict(model.named_modules())
    started = time.perf_counter()
    torch.cuda.reset_peak_memory_stats()
    previous_block = None
    hashes = {}
    for index, record in enumerate(manifest["layers"], 1):
        name = record["layer_name"]
        module = modules.get(name)
        if module is None or not isinstance(module, torch.nn.Linear):
            raise RuntimeError(f"Missing Linear module: {name}")
        if list(module.weight.shape) != record["weight_shape"]:
            raise RuntimeError(f"Weight shape mismatch for {name}")
        tensors, metadata = load_layer(checkpoint_dir / record["file"], "cuda:0")
        reconstructed = reconstruct_weight(
            tensors, metadata, output_dtype=module.weight.dtype, device="cuda:0"
        )
        module.weight.data.copy_(reconstructed)
        hashes[name] = record["source_state_hash"]
        block = name.split(".")[2] if name.startswith("model.layers.") else name
        del tensors, reconstructed
        if previous_block is not None and block != previous_block:
            torch.cuda.empty_cache()
            gc.collect()
        previous_block = block
        if index % 16 == 0 or index == len(manifest["layers"]):
            print(f"[{index}/{len(manifest['layers'])}] applied {name}", flush=True)
    torch.cuda.synchronize()
    return {
        "seconds": time.perf_counter() - started,
        "linears": len(hashes),
        "memory": memory_stats(),
    }


def evaluate(model, tokenizer, args, selected):
    metrics = {}
    if "wiki2" in selected:
        _, testenc = get_loaders(
            "wikitext-2", tokenizer=tokenizer, seed=args.seed,
            seqlen=args.seqlen, nsamples=128,
        )
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, "cuda", seqlen=args.seqlen))
        metrics["wiki2"] = {
            "ppl": ppl,
            "segments": int(testenc.input_ids.numel() // args.seqlen),
            "seconds": time.perf_counter() - started,
        }
        print(f"WikiText-2 PPL={ppl:.10f}", flush=True)
        del testenc
    if "c4" in selected:
        testenc = load_c4_eval(
            DEFAULT_C4, tokenizer, args.seqlen, args.c4_samples, args.seed
        )
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, "cuda", seqlen=args.seqlen))
        metrics["c4"] = {
            "ppl": ppl,
            "segments": int(testenc.input_ids.numel() // args.seqlen),
            "seconds": time.perf_counter() - started,
        }
        print(f"C4 PPL={ppl:.10f}", flush=True)
        del testenc
    if "ptb" in selected:
        testenc = load_ptb_test(DEFAULT_PTB, tokenizer, args.seqlen)
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, "cuda", seqlen=args.seqlen))
        metrics["ptb"] = {
            "ppl": ppl,
            "segments": int(testenc.input_ids.numel() // args.seqlen),
            "seconds": time.perf_counter() - started,
        }
        print(f"PTB PPL={ppl:.10f}", flush=True)
        del testenc
    return metrics


def main():
    args = parse_args()
    if args.output.exists():
        raise RuntimeError(f"Refusing to overwrite result: {args.output}")
    gpu_before = assert_empty_gpu(args.physical_gpu)
    manifest = json.loads((args.checkpoint_dir / "manifest.json").read_text())
    started = time.perf_counter()
    model, tokenizer = load_model(args.model_path)
    torch.cuda.synchronize()
    after_model_load = memory_stats()
    total_parameters = sum(parameter.numel() for parameter in model.parameters())
    quantized_weights = int(manifest["total_quantized_weights"])
    apply_result = apply_checkpoint(model, args.checkpoint_dir, manifest)
    after_apply = memory_stats()
    nonquantized_parameters = total_parameters - quantized_weights
    physical_checkpoint_bytes = int(manifest["physical_layer_file_bytes"])
    estimated_full_checkpoint_bytes = physical_checkpoint_bytes + 2 * nonquantized_parameters
    selected = {value.strip() for value in args.datasets.split(",") if value.strip()}
    metrics = evaluate(model, tokenizer, args, selected)
    torch.cuda.synchronize()
    result = {
        "status": "complete",
        "method": "method30_post_awq_22a_packed_reference",
        "model_path": args.model_path,
        "checkpoint_dir": str(args.checkpoint_dir),
        "metadata_dtype": manifest["metadata_dtype"],
        "physical_gpu": args.physical_gpu,
        "gpu_before": gpu_before,
        "protocol": {
            "datasets": sorted(selected), "seqlen": args.seqlen,
            "c4_samples": args.c4_samples, "seed": args.seed,
        },
        "storage": {
            "quantized_linear_weights": quantized_weights,
            "total_model_parameters": total_parameters,
            "nonquantized_parameters": nonquantized_parameters,
            "packed_linear_file_bytes": physical_checkpoint_bytes,
            "packed_linear_file_bpw": manifest["physical_layer_file_bpw"],
            "estimated_full_checkpoint_bytes": estimated_full_checkpoint_bytes,
            "estimated_full_model_bpw": 8.0 * estimated_full_checkpoint_bytes / total_parameters,
        },
        "memory": {
            "after_fp16_model_load": after_model_load,
            "apply_peak": apply_result["memory"],
            "after_packed_reference_apply": after_apply,
        },
        "apply": apply_result,
        "metrics": metrics,
        "wall_seconds": time.perf_counter() - started,
        "finished_at": utc_now(),
    }
    atomic_write_json(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
