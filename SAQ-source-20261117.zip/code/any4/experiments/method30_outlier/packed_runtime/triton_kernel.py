import math

import torch
import triton
import triton.language as tl

from packed_format import unpack_assignment


@triton.jit
def _psop_linear_kernel(
    x_ptr,
    qweight_ptr,
    lut_ptr,
    scales_ptr,
    offsets_ptr,
    outlier_pos_ptr,
    outlier_value_ptr,
    channel_scale_ptr,
    output_ptr,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k_start in range(0, K, BLOCK_K):
        offs_k = k_start + tl.arange(0, BLOCK_K)
        k_mask = offs_k < K
        x = tl.load(
            x_ptr + offs_m[:, None] * K + offs_k[None, :],
            mask=(offs_m[:, None] < M) & k_mask[None, :],
            other=0.0,
        )
        channel = tl.load(
            channel_scale_ptr + offs_k,
            mask=k_mask,
            other=1.0,
        )
        x_scaled = (x / channel[None, :]).to(tl.float16)

        packed = tl.load(
            qweight_ptr
            + offs_n[:, None] * (K // 2)
            + (offs_k[None, :] // 2),
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=0,
        )
        low_code = packed & 0x0F
        high_code = (packed >> 4) & 0x0F
        code = tl.where((offs_k[None, :] & 1) == 0, low_code, high_code)
        group = offs_k[None, :] // 128
        group_index = offs_n[:, None] * GROUPS + group
        scale = tl.load(
            scales_ptr + group_index,
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=0.0,
        )
        offset = tl.load(
            offsets_ptr + group_index,
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=0.0,
        )
        position = tl.load(
            outlier_pos_ptr + group_index,
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=255,
        )
        outlier = tl.load(
            outlier_value_ptr + group_index,
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=0.0,
        )
        centroid = tl.load(
            lut_ptr + offs_n[:, None] * 16 + code,
            mask=(offs_n[:, None] < N) & k_mask[None, :],
            other=0.0,
        )
        ordinary = scale * centroid + offset
        protected = outlier * channel[None, :]
        weight_scaled = tl.where(
            (offs_k[None, :] % 128) == position,
            protected,
            ordinary,
        ).to(tl.float16)
        accumulator += tl.dot(x_scaled, tl.trans(weight_scaled))

    tl.store(
        output_ptr + offs_m[:, None] * N + offs_n[None, :],
        accumulator,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )


def compact_to_aligned_qweight(tensors, metadata, device="cpu"):
    assignment, _ = unpack_assignment(tensors, metadata, device=device)
    if assignment.shape[1] % 2:
        raise ValueError("Aligned four-bit packing requires an even K dimension.")
    assignment = assignment.to(torch.uint8).contiguous()
    aligned = assignment[:, 0::2] | (assignment[:, 1::2] << 4)
    return aligned.contiguous()


def psop_linear(input_tensor, runtime_tensors, bias=None):
    if input_tensor.device.type != "cuda":
        raise ValueError("PSOP Triton kernel requires a CUDA input.")
    if input_tensor.dtype not in (torch.float16, torch.bfloat16):
        raise ValueError("PSOP Triton kernel supports FP16 or BF16 activations.")
    original_shape = input_tensor.shape[:-1]
    x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
    M, K = x.shape
    qweight = runtime_tensors["qweight_aligned"]
    N = qweight.shape[0]
    if qweight.shape[1] * 2 != K:
        raise ValueError("Packed weight K dimension does not match the input.")
    groups = K // 128
    output = torch.empty((M, N), device=x.device, dtype=x.dtype)
    block_m = 16 if M <= 16 else 32
    block_n = 32
    block_k = 64
    grid = (triton.cdiv(M, block_m), triton.cdiv(N, block_n))
    _psop_linear_kernel[grid](
        x,
        qweight,
        runtime_tensors["lut"],
        runtime_tensors["scales"],
        runtime_tensors["offsets"],
        runtime_tensors["outlier_pos"],
        runtime_tensors["outlier_value"],
        runtime_tensors["channel_scale"],
        output,
        M=M,
        N=N,
        K=K,
        GROUPS=groups,
        BLOCK_M=block_m,
        BLOCK_N=block_n,
        BLOCK_K=block_k,
        num_warps=4,
        num_stages=3,
    )
    if bias is not None:
        output.add_(bias)
    return output.reshape(*original_shape, N)


def make_runtime_tensors(tensors, metadata, device="cuda:0"):
    result = {
        key: value.to(device=device, non_blocking=False).contiguous()
        for key, value in tensors.items()
        if key != "qweight"
    }
    result["qweight_aligned"] = compact_to_aligned_qweight(
        tensors, metadata, device="cpu"
    ).to(device=device)
    return result


def runtime_tensor_bytes(runtime_tensors):
    return sum(value.numel() * value.element_size() for value in runtime_tensors.values())
