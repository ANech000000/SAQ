import argparse
import json
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
REPO = Path('/data/lsz/any4')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO))

import tinygemm  # noqa: F401
from packed_format import load_layer, reconstruct_weight, unpack_assignment


def synchronize():
    torch.cuda.synchronize()


def benchmark(fn, warmup=20, repeats=100):
    for _ in range(warmup):
        fn()
    synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    times = []
    for _ in range(repeats):
        start.record()
        fn()
        end.record()
        synchronize()
        times.append(start.elapsed_time(end))
    values = torch.tensor(times, dtype=torch.float64)
    return {
        'median_ms': float(values.median()),
        'mean_ms': float(values.mean()),
        'min_ms': float(values.min()),
    }


def locate_layer(checkpoint, needle):
    manifest = json.loads((checkpoint / 'manifest.json').read_text())
    candidates = [entry for entry in manifest['layers'] if needle in entry['layer_name']]
    if not candidates:
        raise RuntimeError(f'No layer matching {needle}')
    entry = candidates[0]
    return checkpoint / entry['file'], entry


def prepare(tensors, metadata, device):
    assignment, _ = unpack_assignment(tensors, metadata, device=device)
    assignment = assignment.to(torch.int32)
    converted = torch.ops.tinygemm.convert_matrix_to_m16n8k16_Bint4_layout(assignment, 4)
    scales = tensors['scales'].to(device=device, dtype=torch.float16)
    offsets = tensors['offsets'].to(device=device, dtype=torch.float16)
    scales_and_zeros = torch.stack((scales.transpose(0, 1), offsets.transpose(0, 1)), dim=-1).contiguous()
    return assignment, converted, scales_and_zeros


def correction(x_scaled, tensors, group_size):
    positions = tensors['outlier_pos'].long()
    _, groups = positions.shape
    group_start = torch.arange(groups, device=x_scaled.device).view(1, groups) * group_size
    columns = group_start + positions
    scales = tensors['scales'].float()
    offsets = tensors['offsets'].float()
    lut0 = tensors['lut'][:, :1].float()
    base_scaled = scales * lut0 + offsets
    channel_scale = tensors['channel_scale'].float()
    desired_scaled = tensors['outlier_value'].float() * channel_scale[columns]
    residual = desired_scaled - base_scaled
    selected_x = x_scaled.float()[:, columns]
    return (selected_x * residual.unsqueeze(0)).sum(dim=-1).to(x_scaled.dtype)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--layer', default='layers.0.self_attn.q_proj')
    parser.add_argument('--m', type=int, default=4)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError('CUDA is required')
    device = torch.device('cuda:0')
    layer_path, entry = locate_layer(args.checkpoint, args.layer)
    cpu_tensors, metadata = load_layer(layer_path, device='cpu')
    tensors = {key: value.to(device) for key, value in cpu_tensors.items()}
    rows, cols = json.loads(metadata['weight_shape'])
    group_size = int(metadata['group_size'])
    assignment, converted, scales_and_zeros = prepare(tensors, metadata, device)
    lut = tensors['lut'].to(torch.float16)
    channel_scale = tensors['channel_scale'].to(torch.float16)

    generator = torch.Generator(device=device).manual_seed(20260728)
    x = torch.randn((args.m, cols), generator=generator, device=device, dtype=torch.float16)
    x_scaled = x / channel_scale

    def main_kernel():
        return torch.ops.tinygemm.tinygemm_y_f16RM_x_f16RM_w_any4TC(
            x_scaled, converted, group_size, scales_and_zeros, lut, True
        )

    y_main = main_kernel()
    y_composite = y_main + correction(x_scaled, tensors, group_size)
    weight_ref = reconstruct_weight(tensors, metadata, output_dtype=torch.float16, device=device)
    y_ref = x @ weight_ref.t()

    main_diff = y_main.float() - y_ref.float()
    composite_diff = y_composite.float() - y_ref.float()
    denom = y_ref.float().square().mean().clamp_min(1e-12)

    def composite_kernel():
        return main_kernel() + correction(x_scaled, tensors, group_size)

    result = {
        'layer': entry['layer_name'],
        'shape': [rows, cols],
        'm': args.m,
        'group_size': group_size,
        'offset_nonzero_fraction': float((tensors['offsets'] != 0).float().mean()),
        'assignment_bytes_unconverted': assignment.numel() * assignment.element_size(),
        'tinygemm_layout_shape': list(converted.shape),
        'tinygemm_layout_dtype': str(converted.dtype),
        'tinygemm_layout_bytes': converted.numel() * converted.element_size(),
        'tinygemm_layout_bpw': 8.0 * converted.numel() * converted.element_size() / (rows * cols),
        'main_relative_mse': float(main_diff.square().mean() / denom),
        'composite_relative_mse': float(composite_diff.square().mean() / denom),
        'composite_max_abs': float(composite_diff.abs().max()),
        'timing': {
            'fp16_gemm': benchmark(lambda: x @ weight_ref.t()),
            'tinygemm_main': benchmark(main_kernel),
            'outlier_correction_torch': benchmark(lambda: correction(x_scaled, tensors, group_size)),
            'composite': benchmark(composite_kernel),
        },
        'timestamp': time.time(),
    }
    if result['composite_relative_mse'] > 1e-5:
        raise RuntimeError(f"Composite relative MSE is too high: {result['composite_relative_mse']}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
