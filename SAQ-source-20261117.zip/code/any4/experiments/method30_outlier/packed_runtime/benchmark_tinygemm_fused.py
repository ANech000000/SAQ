import argparse
import json
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
REPO = Path('/data/lsz/any4')
sys.path[:0] = [str(HERE), str(REPO)]

import tinygemm  # noqa: F401
from packed_format import load_layer, reconstruct_weight
from packed_model import load_tinygemm_tensors
from tinygemm_composite import (
    dequantize_weight,
    psop_tinygemm_composite,
    psop_tinygemm_fused,
    psop_tinygemm_hybrid,
    tinygemm_main,
)

LAYER_SUFFIXES = (
    'self_attn.q_proj', 'self_attn.k_proj', 'self_attn.v_proj',
    'self_attn.o_proj', 'mlp.gate_proj', 'mlp.up_proj', 'mlp.down_proj',
)


def repeats_for_m(m):
    if m <= 16:
        return 100
    if m <= 128:
        return 50
    if m <= 512:
        return 20
    return 10


def benchmark(fn, repeats):
    for _ in range(min(20, repeats)):
        fn()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    values = []
    for _ in range(repeats):
        start.record()
        fn()
        end.record()
        torch.cuda.synchronize()
        values.append(start.elapsed_time(end))
    tensor = torch.tensor(values, dtype=torch.float64)
    return {
        'median_ms': float(tensor.median()),
        'mean_ms': float(tensor.mean()),
        'min_ms': float(tensor.min()),
    }


def runtime_from_file(path):
    tensors, metadata = load_tinygemm_tensors(path, 'cuda:0')
    rows, cols = json.loads(metadata['weight_shape'])
    return {
        **tensors,
        'rows': int(rows),
        'cols': int(cols),
        'group_size': int(metadata['group_size']),
        'w_inner_k': 4,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--reference-checkpoint', type=Path, required=True)
    parser.add_argument('--m-values', default='1,4,16,64,128,512,2048')
    parser.add_argument('--tinygemm-max-m', type=int, default=64)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)

    manifest = json.loads((args.checkpoint / 'manifest.json').read_text())
    reference_manifest = json.loads(
        (args.reference_checkpoint / 'manifest.json').read_text()
    )
    reference_by_name = {
        entry['layer_name']: entry for entry in reference_manifest['layers']
    }
    entry_by_suffix = {}
    for suffix in LAYER_SUFFIXES:
        name = f'model.layers.0.{suffix}'
        entry_by_suffix[suffix] = next(
            entry for entry in manifest['layers'] if entry['layer_name'] == name
        )

    m_values = [int(value) for value in args.m_values.split(',')]
    results = []
    generator = torch.Generator(device='cuda:0').manual_seed(20260728)
    for suffix in LAYER_SUFFIXES:
        entry = entry_by_suffix[suffix]
        runtime = runtime_from_file(args.checkpoint / entry['file'])
        reference_entry = reference_by_name[entry['layer_name']]
        reference_tensors, reference_metadata = load_layer(
            args.reference_checkpoint / reference_entry['file'], device='cpu'
        )
        weight = reconstruct_weight(
            reference_tensors, reference_metadata,
            output_dtype=torch.float16, device='cuda:0'
        )
        rows, cols = entry['weight_shape']
        dense_weight = dequantize_weight(runtime)
        weight_diff = dense_weight.float() - weight.float()
        weight_relative_mse = float(
            weight_diff.square().mean() /
            weight.float().square().mean().clamp_min(1e-12)
        )
        weight_max_abs = float(weight_diff.abs().max())
        if weight_relative_mse > 1e-5:
            raise RuntimeError(
                f'{entry["layer_name"]} dequantized weight relative MSE '
                f'{weight_relative_mse}'
            )
        del dense_weight, weight_diff
        layer_result = {
            'layer': entry['layer_name'],
            'shape': [rows, cols],
            'groups': cols // 128,
            'runtime_tensor_bytes': sum(
                value.numel() * value.element_size()
                for value in runtime.values() if isinstance(value, torch.Tensor)
            ),
            'dequantized_weight_relative_mse': weight_relative_mse,
            'dequantized_weight_max_abs': weight_max_abs,
            'measurements': [],
        }
        for m in m_values:
            x = torch.randn(
                (m, cols), device='cuda:0', dtype=torch.float16,
                generator=generator,
            )
            y_ref = x @ weight.t()
            y_hybrid = psop_tinygemm_hybrid(
                x, runtime, tinygemm_max_m=args.tinygemm_max_m
            )
            hybrid_diff = y_hybrid.float() - y_ref.float()
            hybrid_relative_mse = float(
                hybrid_diff.square().mean() /
                y_ref.float().square().mean().clamp_min(1e-12)
            )
            hybrid_max_abs = float(hybrid_diff.abs().max())
            if hybrid_relative_mse > 1e-5:
                raise RuntimeError(
                    f'{entry["layer_name"]} M={m} hybrid relative MSE '
                    f'{hybrid_relative_mse}'
                )
            if m == min(m_values):
                y_fused = psop_tinygemm_fused(x, runtime)
                diff = y_fused.float() - y_ref.float()
                relative_mse = float(
                    diff.square().mean() /
                    y_ref.float().square().mean().clamp_min(1e-12)
                )
                max_abs = float(diff.abs().max())
                if relative_mse > 1e-5:
                    raise RuntimeError(
                        f'{entry["layer_name"]} relative MSE {relative_mse}'
                    )
            else:
                relative_mse = None
                max_abs = None
            del y_ref, y_hybrid, hybrid_diff
            repeats = repeats_for_m(m)
            x_scaled = x * runtime['inv_channel_scale']
            timings = {
                'fp16_cublas': benchmark(lambda: x @ weight.t(), repeats),
                'any4_tinygemm_main_only': benchmark(
                    lambda: tinygemm_main(x_scaled, runtime), repeats
                ),
                'psop_composite': benchmark(
                    lambda: psop_tinygemm_composite(x, runtime), repeats
                ),
                'psop_fused': benchmark(
                    lambda: psop_tinygemm_fused(x, runtime), repeats
                ),
                'dequantize_weight': benchmark(
                    lambda: dequantize_weight(runtime), repeats
                ),
                'psop_hybrid': benchmark(
                    lambda: psop_tinygemm_hybrid(
                        x, runtime, tinygemm_max_m=args.tinygemm_max_m
                    ),
                    repeats,
                ),
            }
            for name, value in timings.items():
                if name == 'dequantize_weight':
                    continue
                value['tflops'] = (
                    2.0 * m * rows * cols /
                    (value['median_ms'] * 1e-3) / 1e12
                )
            measurement = {
                'm': m,
                'repeats': repeats,
                'relative_mse': relative_mse,
                'max_abs': max_abs,
                'hybrid_relative_mse': hybrid_relative_mse,
                'hybrid_max_abs': hybrid_max_abs,
                'timing': timings,
                'fused_speedup_vs_fp16': (
                    timings['fp16_cublas']['median_ms'] /
                    timings['psop_fused']['median_ms']
                ),
                'composite_speedup_vs_fp16': (
                    timings['fp16_cublas']['median_ms'] /
                    timings['psop_composite']['median_ms']
                ),
                'hybrid_speedup_vs_fp16': (
                    timings['fp16_cublas']['median_ms'] /
                    timings['psop_hybrid']['median_ms']
                ),
            }
            layer_result['measurements'].append(measurement)
            print(
                f'{suffix} M={m}: fused={timings["psop_fused"]["median_ms"]:.4f} ms '
                f'hybrid={timings["psop_hybrid"]["median_ms"]:.4f} ms '
                f'speedup={measurement["hybrid_speedup_vs_fp16"]:.3f}x',
                flush=True,
            )
            del x, x_scaled
        results.append(layer_result)
        del runtime, reference_tensors, weight
        torch.cuda.empty_cache()

    payload = {
        'status': 'complete',
        'method': 'method30_post_awq_22a_tinygemm_fused',
        'gpu': torch.cuda.get_device_name(0),
        'm_values': m_values,
        'tinygemm_max_m': args.tinygemm_max_m,
        'layers': results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps({'status': 'complete', 'layers': len(results)}, indent=2))


if __name__ == '__main__':
    main()
