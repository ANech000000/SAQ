import argparse
import json
import sys
import time
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from packed_model import load_packed_model, load_tokenizer, memory_stats


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    tokenizer = load_tokenizer(args.checkpoint_dir)
    model, manifest, load_result = load_packed_model(args.checkpoint_dir)
    encoded = tokenizer('Post-scaling quantization', return_tensors='pt').to('cuda:0')
    torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()
    with torch.inference_mode():
        output = model(**encoded, use_cache=True)
        generated = model.generate(
            **encoded, max_new_tokens=4, do_sample=False, use_cache=True
        )
    torch.cuda.synchronize()
    logits = output.logits
    result = {
        'status': 'complete',
        'load': load_result,
        'forward_seconds': time.perf_counter() - started,
        'logits_shape': list(logits.shape),
        'logits_finite': bool(torch.isfinite(logits).all()),
        'generated_text': tokenizer.decode(generated[0], skip_special_tokens=True),
        'memory': memory_stats(),
        'linear_tensor_bpw': manifest['linear_tensor_bpw'],
        'whole_model_tensor_bpw': manifest['whole_model_tensor_bpw'],
    }
    if not result['logits_finite']:
        raise RuntimeError('Non-finite logits')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
