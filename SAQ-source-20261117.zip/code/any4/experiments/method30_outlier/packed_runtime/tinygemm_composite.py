import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
import triton
import triton.language as tl

from packed_format import unpack_assignment

EXTENSION_DIR = Path(__file__).resolve().parent / 'psop_tinygemm_ext'
if str(EXTENSION_DIR) not in sys.path:
    sys.path.insert(0, str(EXTENSION_DIR))


@triton.jit
def _apply_outlier_residual_kernel(
    x_scaled_ptr,
    output_ptr,
    outlier_pos_ptr,
    residual_ptr,
    bias_ptr,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    mask_m = offs_m < M
    mask_n = offs_n < N
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for group in range(0, GROUPS):
        meta_offset = offs_n * GROUPS + group
        position = tl.load(outlier_pos_ptr + meta_offset, mask=mask_n, other=0).to(tl.int32)
        residual = tl.load(residual_ptr + meta_offset, mask=mask_n, other=0.0)
        column = group * GROUP_SIZE + position
        selected = tl.load(
            x_scaled_ptr + offs_m[:, None] * K + column[None, :],
            mask=mask_m[:, None] & mask_n[None, :],
            other=0.0,
        )
        accumulator += selected * residual[None, :]

    output_offset = offs_m[:, None] * N + offs_n[None, :]
    output_mask = mask_m[:, None] & mask_n[None, :]
    value = tl.load(output_ptr + output_offset, mask=output_mask, other=0.0)
    value += accumulator
    if HAS_BIAS:
        bias = tl.load(bias_ptr + offs_n, mask=mask_n, other=0.0)
        value += bias[None, :]
    tl.store(output_ptr + output_offset, value, mask=output_mask)


@triton.jit
def _apply_outlier_residual_vector_kernel(
    x_scaled_ptr,
    output_ptr,
    outlier_pos_ptr,
    residual_ptr,
    bias_ptr,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_G: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    row_start = pid_m * BLOCK_M
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_g = tl.arange(0, BLOCK_G)
    mask_n = offs_n < N
    mask_g = offs_g < GROUPS
    meta_offset = offs_n[:, None] * GROUPS + offs_g[None, :]
    meta_mask = mask_n[:, None] & mask_g[None, :]
    position = tl.load(outlier_pos_ptr + meta_offset, mask=meta_mask, other=0).to(tl.int32)
    residual = tl.load(residual_ptr + meta_offset, mask=meta_mask, other=0.0).to(tl.float32)
    column = offs_g[None, :] * GROUP_SIZE + position
    if HAS_BIAS:
        bias = tl.load(bias_ptr + offs_n, mask=mask_n, other=0.0).to(tl.float32)

    for local_m in range(0, BLOCK_M):
        row = row_start + local_m
        selected = tl.load(
            x_scaled_ptr + row * K + column,
            mask=(row < M) & meta_mask,
            other=0.0,
        ).to(tl.float32)
        correction = tl.sum(selected * residual, axis=1)
        output_offset = row * N + offs_n
        output_mask = (row < M) & mask_n
        value = tl.load(output_ptr + output_offset, mask=output_mask, other=0.0).to(tl.float32)
        value += correction
        if HAS_BIAS:
            value += bias
        tl.store(output_ptr + output_offset, value, mask=output_mask)


def prepare_tinygemm_runtime(tensors, metadata, device='cuda:0', w_inner_k=4):
    rows, cols = json.loads(metadata['weight_shape'])
    group_size = int(metadata['group_size'])
    if group_size != 128:
        raise ValueError(f'Expected group size 128, got {group_size}')
    assignment, _ = unpack_assignment(tensors, metadata, device='cpu')
    assignment = assignment.to(device=device, dtype=torch.int32)
    converted = torch.ops.tinygemm.convert_matrix_to_m16n8k16_Bint4_layout(
        assignment, w_inner_k
    )
    del assignment

    lut = tensors['lut'].to(device=device, dtype=torch.float16).contiguous()
    scales = tensors['scales'].to(device=device, dtype=torch.float16).contiguous()
    offsets = tensors['offsets'].to(device=device, dtype=torch.float16).contiguous()
    channel_scale = tensors['channel_scale'].to(device=device, dtype=torch.float16).contiguous()
    outlier_pos = tensors['outlier_pos'].to(device=device, dtype=torch.uint8).contiguous()
    outlier_value = tensors['outlier_value'].to(device=device, dtype=torch.float16).contiguous()
    scales_and_zeros = torch.stack(
        (scales.transpose(0, 1), offsets.transpose(0, 1)), dim=-1
    ).contiguous()

    groups = cols // group_size
    group_start = torch.arange(groups, device=device).view(1, groups) * group_size
    columns = group_start + outlier_pos.long()
    base_scaled = scales * lut[:, :1] + offsets
    desired_scaled = outlier_value * channel_scale[columns]
    residual = (desired_scaled - base_scaled).to(torch.float16).contiguous()

    return {
        'qweight_tinygemm': converted,
        'lut': lut,
        'scales_and_zeros': scales_and_zeros,
        'inv_channel_scale': channel_scale.reciprocal().contiguous(),
        'outlier_pos': outlier_pos,
        'outlier_residual_scaled': residual,
        'rows': rows,
        'cols': cols,
        'group_size': group_size,
        'w_inner_k': w_inner_k,
    }


def runtime_tensor_bytes(runtime):
    return sum(
        value.numel() * value.element_size()
        for value in runtime.values()
        if isinstance(value, torch.Tensor)
    )


def tinygemm_main(x_scaled, runtime):
    return torch.ops.tinygemm.tinygemm_y_f16RM_x_f16RM_w_any4TC(
        x_scaled,
        runtime['qweight_tinygemm'],
        runtime['group_size'],
        runtime['scales_and_zeros'],
        runtime['lut'],
        True,
    )


def apply_outlier_residual(x_scaled, output, runtime, bias=None):
    m, k = x_scaled.shape
    n = runtime['rows']
    block_m = 1 if m == 1 else (4 if m <= 4 else (8 if m <= 16 else 16))
    block_n = 64
    grid = (triton.cdiv(m, block_m), triton.cdiv(n, block_n))
    bias_ptr = bias if bias is not None else output
    groups = k // runtime['group_size']
    _apply_outlier_residual_vector_kernel[grid](
        x_scaled,
        output,
        runtime['outlier_pos'],
        runtime['outlier_residual_scaled'],
        bias_ptr,
        M=m,
        N=n,
        K=k,
        GROUPS=groups,
        GROUP_SIZE=runtime['group_size'],
        HAS_BIAS=bias is not None,
        BLOCK_M=block_m,
        BLOCK_N=block_n,
        BLOCK_G=triton.next_power_of_2(groups),
        num_warps=8 if groups > 64 else 4,
        num_stages=2,
    )
    return output


def psop_tinygemm_composite(input_tensor, runtime, bias=None):
    if input_tensor.device.type != 'cuda':
        raise ValueError('CUDA input required')
    if input_tensor.dtype != torch.float16:
        raise ValueError('TinyGemm Post-AWQ 22A runtime currently requires FP16')
    original_shape = input_tensor.shape[:-1]
    x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
    m, k = x.shape
    if k != runtime['cols']:
        raise ValueError(f'Input K={k} does not match runtime K={runtime["cols"]}')
    x_scaled = x * runtime['inv_channel_scale']
    output = tinygemm_main(x_scaled, runtime)
    apply_outlier_residual(x_scaled, output, runtime, bias=bias)
    return output.reshape(*original_shape, runtime['rows'])


def psop_tinygemm_fused(input_tensor, runtime, bias=None):
    import psop_tinygemm_cuda  # noqa: F401

    if input_tensor.device.type != 'cuda' or input_tensor.dtype != torch.float16:
        raise ValueError('Fused PSOP TinyGemm requires a CUDA FP16 input')
    original_shape = input_tensor.shape[:-1]
    x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
    if x.shape[1] != runtime['cols']:
        raise ValueError('Input K does not match the packed runtime')
    if bias is None:
        bias = torch.empty(0, device=x.device, dtype=torch.float16)
    output = torch.ops.psop_tinygemm.linear_f16rm_any4(
        x,
        runtime['qweight_tinygemm'],
        runtime['scales_and_zeros'],
        runtime['lut'],
        runtime['inv_channel_scale'],
        runtime['outlier_pos'],
        runtime['outlier_residual_scaled'],
        bias,
    )
    return output.reshape(*original_shape, runtime['rows'])


def dequantize_weight(runtime):
    """Materialize one original-domain FP16 weight matrix from packed tensors."""
    import psop_tinygemm_cuda  # noqa: F401

    return torch.ops.psop_tinygemm.dequantize_f16_any4(
        runtime['qweight_tinygemm'],
        runtime['scales_and_zeros'],
        runtime['lut'],
        runtime['inv_channel_scale'],
        runtime['outlier_pos'],
        runtime['outlier_residual_scaled'],
    )


def psop_tinygemm_hybrid(input_tensor, runtime, bias=None, tinygemm_max_m=64):
    """Use TinyGemm for decode-sized M and transient FP16/cuBLAS otherwise."""
    if tinygemm_max_m < -1:
        raise ValueError('tinygemm_max_m must be -1 or non-negative')
    if input_tensor.device.type != 'cuda' or input_tensor.dtype != torch.float16:
        raise ValueError('Hybrid PSOP runtime requires a CUDA FP16 input')
    original_shape = input_tensor.shape[:-1]
    x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
    if x.shape[1] != runtime['cols']:
        raise ValueError('Input K does not match the packed runtime')
    if tinygemm_max_m < 0 or x.shape[0] <= tinygemm_max_m:
        return psop_tinygemm_fused(input_tensor, runtime, bias=bias)

    weight = dequantize_weight(runtime)
    output = F.linear(x, weight, bias)
    return output.reshape(*original_shape, runtime['rows'])
