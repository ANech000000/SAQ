# Method30 Post-AWQ 22A Packed Runtime

This directory implements deployment artifacts and runtime validation for the
existing Method30 Post-AWQ 22A experiment. It does not rerun clustering or
change the accepted quantization algorithm.

The Llama-3-8B exporter consumes the 224 existing `iter_0010.pt` final states
from `experiments/llama3_8b_reproduction/cache/final_state`. Each state already
contains compact 127-value four-bit assignments, a 16-entry row LUT, group
affine parameters, one outlier position and exact FP16 payload per group, and
the AWQ channel scale.

Outputs are written under:

- checkpoints: `experiments/method30_outlier/checkpoints/llama3_8b_postawq_22a`
- results: `experiments/method30_outlier/runs/llama3_8b/postawq_22a_packed`

No existing model, cache, result, or checkpoint is overwritten.

## TinyGemm deployment results

The deployment checkpoint is stored at:

`/data/lsz/any4/experiments/method30_outlier/checkpoints/llama3_8b_postawq_22a/tinygemm_fp16_meta`

It contains 224 Tensor Core-layout Linear layers plus the non-quantized model
parameters. The outlier FP16 payload is represented as an equivalent scaled-domain
FP16 residual, so the payload width and exact Post-AWQ 22A reconstruction are
preserved without materializing dense FP16 weights.

Measured storage and memory:

- quantized Linear tensor BPW: 4.4908353
- quantized Linear physical file BPW: 4.4910667
- whole-model safetensor BPW: 5.9972758
- whole-model safetensor bytes: 6,019,961,432
- complete checkpoint directory BPW: 6.0065945
- complete checkpoint directory bytes: 6,029,315,422
- packed GPU memory after load: 5,760.6 MiB allocated
- FP16 GPU memory after load: 15,316.5 MiB allocated

Fused-kernel PPL:

- WikiText-2: 6.3585243
- C4: 8.1937027
- PTB: 11.4735861

The fused CUDA kernel combines AWQ activation scaling, Any4 Tensor Core GEMM,
outlier residual restoration, and bias in one launch. It improves decode-sized
workloads and model decode throughput. The packed model now dispatches inputs with
`M <= 64` to this TinyGemm path. For larger M, it transiently materializes only the
current layer's reconstructed FP16 weight from the packed Tensor Core layout and
uses cuBLAS. This avoids keeping a second dense model resident while removing the
known large-M TinyGemm bottleneck. Set `PSOP_TINYGEMM_MAX_M=-1` to force the legacy
all-M TinyGemm path, or set it to another non-negative threshold after benchmarking.
The lightweight HTTP server still serializes concurrent requests and is not a
continuous-batching server.

Paper-ready outputs are under the run root:

- `paper_metrics_v2.json` (preferred complete physical-size accounting)
- `paper_metrics.json` (safetensor-only size accounting)
- `paper_kernel.csv`
- `paper_model.csv`
- `paper_service.csv`

Core implementation files are `packed_model.py`, `tinygemm_composite.py`, the
`psop_tinygemm_ext/` CUDA extension, `benchmark_model.py`, and
`run_service_benchmark.py`.
