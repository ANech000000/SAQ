import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path

import torch
import torch.nn.functional as F
from safetensors import safe_open
from safetensors.torch import save_file


FORMAT_NAME = "method30_post_awq_22a_packed"
FORMAT_VERSION = 1
REQUIRED_STATE_KEYS = {
    "weight_shape",
    "group_size",
    "lut",
    "scales",
    "offsets",
    "outlier_positions",
    "exact_outlier_values",
    "channel_scale",
    "packed_assignment",
    "packed_assignment_count",
}


def safe_layer_name(name):
    return str(name).replace(".", "__").replace("/", "_")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_tensor(value):
    tensor = torch.as_tensor(value).detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(tensor.shape)).encode("utf-8"))
    digest.update(str(tensor.dtype).encode("utf-8"))
    digest.update(tensor.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(temporary, path)


def load_source_state(path):
    path = Path(path)
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("schema_version") != 1:
        raise RuntimeError(f"Unsupported source cache schema: {path}")
    state = payload.get("state")
    missing = REQUIRED_STATE_KEYS.difference(state or {})
    if missing:
        raise RuntimeError(f"Missing source state keys {sorted(missing)}: {path}")
    metadata = payload.get("metadata") or {}
    layer_name = metadata.get("layer_name")
    if not layer_name:
        raise RuntimeError(f"Source cache has no layer name: {path}")
    return payload, state, metadata


def _metadata_dtypes(name):
    if name == "fp16":
        return {
            "lut": torch.float16,
            "scales": torch.float16,
            "offsets": torch.float16,
            "channel_scale": torch.float16,
        }
    if name == "mixed":
        return {
            "lut": torch.float16,
            "scales": torch.float32,
            "offsets": torch.float32,
            "channel_scale": torch.float16,
        }
    if name == "fp32":
        return {
            "lut": torch.float32,
            "scales": torch.float32,
            "offsets": torch.float32,
            "channel_scale": torch.float32,
        }
    raise ValueError(f"Unsupported metadata dtype profile: {name}")


def build_packed_tensors(state, metadata_dtype="fp16"):
    dtypes = _metadata_dtypes(metadata_dtype)
    rows, cols = (int(value) for value in state["weight_shape"])
    group_size = int(state["group_size"])
    if cols % group_size:
        raise ValueError("Weight columns are not divisible by group size.")
    groups = cols // group_size
    count = int(state["packed_assignment_count"])
    expected_count = rows * groups * (group_size - 1)
    if count != expected_count:
        raise ValueError(
            f"Packed assignment count mismatch: {count} != {expected_count}"
        )
    packed = state["packed_assignment"].detach().cpu().to(torch.uint8).contiguous()
    if packed.numel() != math.ceil(count / 2):
        raise ValueError("Packed assignment byte count is invalid.")
    positions = state["outlier_positions"].detach().cpu().to(torch.uint8).contiguous()
    if tuple(positions.shape) != (rows, groups):
        raise ValueError("Outlier position shape is invalid.")
    if positions.numel() and int(positions.max()) >= group_size:
        raise ValueError("Outlier position exceeds group size.")
    tensors = {
        "qweight": packed,
        "lut": state["lut"].detach().cpu().to(dtypes["lut"]).contiguous(),
        "scales": state["scales"].detach().cpu().to(dtypes["scales"]).contiguous(),
        "offsets": state["offsets"].detach().cpu().to(dtypes["offsets"]).contiguous(),
        "outlier_pos": positions,
        "outlier_value": state["exact_outlier_values"].detach().cpu().to(torch.float16).contiguous(),
        "channel_scale": state["channel_scale"].detach().cpu().to(dtypes["channel_scale"]).contiguous(),
    }
    expected_shapes = {
        "lut": (rows, 16),
        "scales": (rows, groups),
        "offsets": (rows, groups),
        "outlier_value": (rows, groups),
        "channel_scale": (cols,),
    }
    for key, shape in expected_shapes.items():
        if tuple(tensors[key].shape) != shape:
            raise ValueError(f"{key} shape {tuple(tensors[key].shape)} != {shape}")
    for key in ("lut", "scales", "offsets", "outlier_value", "channel_scale"):
        if not torch.isfinite(tensors[key].float()).all():
            raise ValueError(f"Non-finite values in {key}")
    if (tensors["scales"].float() <= 0).any():
        raise ValueError("Affine scales must be positive.")
    return tensors


def tensor_bytes(tensors):
    return {key: int(value.numel() * value.element_size()) for key, value in tensors.items()}


def export_layer(source_path, output_path, metadata_dtype="fp16"):
    source_path = Path(source_path)
    output_path = Path(output_path)
    payload, state, metadata = load_source_state(source_path)
    tensors = build_packed_tensors(state, metadata_dtype)
    rows, cols = (int(value) for value in state["weight_shape"])
    group_size = int(state["group_size"])
    count = int(state["packed_assignment_count"])
    file_metadata = {
        "format": FORMAT_NAME,
        "format_version": str(FORMAT_VERSION),
        "layer_name": str(metadata["layer_name"]),
        "weight_shape": json.dumps([rows, cols]),
        "group_size": str(group_size),
        "lut_entries": "16",
        "normal_values_per_group": str(group_size - 1),
        "packed_assignment_count": str(count),
        "metadata_dtype": metadata_dtype,
        "source_state_hash": str(payload.get("state_hash", "")),
        "source_weight_sha256": str(metadata.get("weight_sha256", "")),
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_name(output_path.name + f".tmp.{os.getpid()}")
    save_file(tensors, temporary, metadata=file_metadata)
    os.replace(temporary, output_path)
    components = tensor_bytes(tensors)
    weights = rows * cols
    return {
        "layer_name": metadata["layer_name"],
        "file": output_path.name,
        "weight_shape": [rows, cols],
        "weight_count": weights,
        "group_size": group_size,
        "group_count": rows * (cols // group_size),
        "packed_assignment_count": count,
        "metadata_dtype": metadata_dtype,
        "source": str(source_path),
        "source_state_hash": payload.get("state_hash"),
        "source_file_sha256": sha256_file(source_path),
        "components_bytes": components,
        "tensor_bytes": sum(components.values()),
        "file_bytes": output_path.stat().st_size,
        "file_sha256": sha256_file(output_path),
        "tensor_bpw": 8.0 * sum(components.values()) / weights,
        "file_bpw": 8.0 * output_path.stat().st_size / weights,
    }


def load_layer(path, device="cpu"):
    path = Path(path)
    tensors = {}
    with safe_open(path, framework="pt", device=str(device)) as handle:
        metadata = handle.metadata()
        for key in handle.keys():
            tensors[key] = handle.get_tensor(key)
    if metadata.get("format") != FORMAT_NAME:
        raise RuntimeError(f"Not a {FORMAT_NAME} layer: {path}")
    if int(metadata.get("format_version", -1)) != FORMAT_VERSION:
        raise RuntimeError(f"Unsupported packed format version: {path}")
    return tensors, metadata


def unpack_assignment(tensors, metadata, device=None):
    rows, cols = json.loads(metadata["weight_shape"])
    group_size = int(metadata["group_size"])
    groups = cols // group_size
    count = int(metadata["packed_assignment_count"])
    target = device or tensors["qweight"].device
    packed = tensors["qweight"].to(device=target, dtype=torch.uint8).reshape(-1)
    compact = torch.empty(packed.numel() * 2, dtype=torch.uint8, device=target)
    compact[0::2] = packed & 0x0F
    compact[1::2] = (packed >> 4) & 0x0F
    compact = compact[:count]
    positions = tensors["outlier_pos"].to(device=target, dtype=torch.long)
    mask = torch.zeros((rows, groups, group_size), dtype=torch.bool, device=target)
    mask.scatter_(2, positions.unsqueeze(2), True)
    assignment = torch.zeros((rows, groups, group_size), dtype=torch.uint8, device=target)
    assignment[~mask] = compact
    return assignment.reshape(rows, cols), mask.reshape(rows, cols)


def reconstruct_weight(tensors, metadata, output_dtype=torch.float16, device=None):
    rows, cols = json.loads(metadata["weight_shape"])
    group_size = int(metadata["group_size"])
    groups = cols // group_size
    target = device or tensors["qweight"].device
    assignment, mask = unpack_assignment(tensors, metadata, target)
    lut = tensors["lut"].to(device=target, dtype=torch.float32)
    codes = torch.gather(lut, 1, assignment.long())
    scales = tensors["scales"].to(device=target, dtype=torch.float32)
    offsets = tensors["offsets"].to(device=target, dtype=torch.float32)
    scaled = scales.unsqueeze(2) * codes.reshape(rows, groups, group_size)
    scaled = scaled + offsets.unsqueeze(2)
    reconstructed = scaled.reshape(rows, cols)
    reconstructed = reconstructed / tensors["channel_scale"].to(device=target, dtype=torch.float32).reshape(1, cols)
    grouped = reconstructed.reshape(rows, groups, group_size)
    grouped.scatter_(
        2,
        tensors["outlier_pos"].to(device=target, dtype=torch.long).unsqueeze(2),
        tensors["outlier_value"].to(device=target, dtype=torch.float32).unsqueeze(2),
    )
    if not torch.isfinite(reconstructed).all():
        raise ValueError("Packed reconstruction produced non-finite values.")
    return reconstructed.to(output_dtype)


def reference_linear(input_tensor, tensors, metadata, bias=None):
    weight = reconstruct_weight(
        tensors,
        metadata,
        output_dtype=input_tensor.dtype,
        device=input_tensor.device,
    )
    return F.linear(input_tensor, weight, bias)


def utc_now():
    return datetime.now(timezone.utc).isoformat()
