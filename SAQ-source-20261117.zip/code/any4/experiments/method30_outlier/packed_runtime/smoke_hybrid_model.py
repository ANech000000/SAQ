import argparse
import json
import sys
import time
from pathlib import Path

import torch


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from packed_model import load_packed_model, memory_stats


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint-dir', type=Path, required=True)
    parser.add_argument('--sequence-length', type=int, default=128)
    parser.add_argument('--tinygemm-max-m', type=int, default=64)
    args = parser.parse_args()

    model, manifest, load_result = load_packed_model(
        args.checkpoint_dir,
        tinygemm_max_m=args.tinygemm_max_m,
    )
    generator = torch.Generator(device='cuda:0').manual_seed(20260804)
    input_ids = torch.randint(
        0,
        model.config.vocab_size,
        (1, args.sequence_length),
        device='cuda:0',
        generator=generator,
    )
    torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()
    with torch.inference_mode():
        output = model(input_ids=input_ids, use_cache=False)
    torch.cuda.synchronize()
    result = {
        'status': 'complete',
        'sequence_length': args.sequence_length,
        'tinygemm_max_m': args.tinygemm_max_m,
        'route': (
            'tinygemm'
            if args.tinygemm_max_m < 0 or args.sequence_length <= args.tinygemm_max_m
            else 'transient_fp16_cublas'
        ),
        'seconds': time.perf_counter() - started,
        'logits_shape': list(output.logits.shape),
        'logits_finite': bool(torch.isfinite(output.logits).all()),
        'load_memory': load_result['memory'],
        'forward_memory': memory_stats(),
        'linear_tensor_bpw': manifest['linear_tensor_bpw'],
    }
    if not result['logits_finite']:
        raise RuntimeError('Non-finite logits')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
