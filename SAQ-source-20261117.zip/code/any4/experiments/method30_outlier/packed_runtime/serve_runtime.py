import argparse
import json
import os
import threading
import time
from pathlib import Path

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')

import torch
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from packed_model import load_packed_model, load_tokenizer, memory_stats


class CompletionRequest(BaseModel):
    model: str = 'method30-post-awq-22a'
    prompt: str
    max_tokens: int = 128
    stream: bool = True


def percentile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    index = min(len(ordered) - 1, int(round((len(ordered) - 1) * q)))
    return ordered[index]


def create_app(model, tokenizer, runtime, load_result):
    app = FastAPI(title='Method30 Post-AWQ 22A Service')
    generation_lock = threading.Lock()
    statistics_lock = threading.Lock()
    statistics = {
        'requests': 0,
        'input_tokens': 0,
        'output_tokens': 0,
        'request_seconds': [],
    }

    @app.get('/health')
    def health():
        return {
            'status': 'ok', 'runtime': runtime,
            'memory': memory_stats(), 'load': load_result,
        }

    @app.get('/metrics')
    def metrics():
        with statistics_lock:
            durations = list(statistics['request_seconds'])
            return {
                **{key: statistics[key] for key in (
                    'requests', 'input_tokens', 'output_tokens'
                )},
                'request_seconds_p50': percentile(durations, 0.5),
                'request_seconds_p95': percentile(durations, 0.95),
                'memory': memory_stats(),
            }

    def token_stream(request):
        started = time.perf_counter()
        encoded = tokenizer(
            request.prompt, return_tensors='pt', add_special_tokens=False
        )
        input_ids = encoded.input_ids.to('cuda:0')
        input_tokens = int(input_ids.numel())
        produced = 0
        with generation_lock, torch.inference_mode():
            outputs = model(input_ids=input_ids, use_cache=True)
            cache = outputs.past_key_values
            token = outputs.logits[:, -1:].argmax(dim=-1)
            for index in range(request.max_tokens):
                token_id = int(token.item())
                text = tokenizer.decode([token_id], skip_special_tokens=False)
                produced += 1
                chunk = {
                    'id': f'cmpl-{time.time_ns()}',
                    'object': 'text_completion',
                    'choices': [{
                        'index': 0, 'text': text,
                        'finish_reason': None if index + 1 < request.max_tokens else 'length',
                    }],
                }
                yield f'data: {json.dumps(chunk)}\n\n'
                if index + 1 < request.max_tokens:
                    outputs = model(
                        input_ids=token, past_key_values=cache, use_cache=True
                    )
                    cache = outputs.past_key_values
                    token = outputs.logits[:, -1:].argmax(dim=-1)
            yield 'data: [DONE]\n\n'
        duration = time.perf_counter() - started
        with statistics_lock:
            statistics['requests'] += 1
            statistics['input_tokens'] += input_tokens
            statistics['output_tokens'] += produced
            statistics['request_seconds'].append(duration)

    @app.post('/v1/completions')
    def completions(request: CompletionRequest):
        if request.max_tokens < 1 or request.max_tokens > 512:
            raise HTTPException(status_code=400, detail='max_tokens must be 1..512')
        if request.stream:
            return StreamingResponse(
                token_stream(request), media_type='text/event-stream'
            )
        chunks = []
        for event in token_stream(request):
            if event.startswith('data: {'):
                payload = json.loads(event[6:])
                chunks.append(payload['choices'][0]['text'])
        return JSONResponse({
            'id': f'cmpl-{time.time_ns()}',
            'object': 'text_completion',
            'choices': [{'index': 0, 'text': ''.join(chunks), 'finish_reason': 'length'}],
        })

    return app


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', choices=('packed', 'fp16'), required=True)
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--model-path', default='/data/model/models--meta-llama--Meta-Llama-3-8B')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    torch.cuda.reset_peak_memory_stats()
    if args.runtime == 'packed':
        tokenizer = load_tokenizer(args.checkpoint)
        model, _, load_result = load_packed_model(args.checkpoint)
    else:
        tokenizer = AutoTokenizer.from_pretrained(
            args.model_path, local_files_only=True
        )
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        started = time.perf_counter()
        model = AutoModelForCausalLM.from_pretrained(
            args.model_path, local_files_only=True,
            torch_dtype=torch.float16, low_cpu_mem_usage=True,
            device_map={'': 'cuda:0'}, attn_implementation='sdpa',
        ).eval()
        torch.cuda.synchronize()
        load_result = {
            'seconds': time.perf_counter() - started,
            'memory': memory_stats(),
        }
    app = create_app(model, tokenizer, args.runtime, load_result)
    uvicorn.run(app, host=args.host, port=args.port, log_level='info')


if __name__ == '__main__':
    main()
