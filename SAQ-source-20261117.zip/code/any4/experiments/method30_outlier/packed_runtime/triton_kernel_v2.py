import torch
import triton
import triton.language as tl

from triton_kernel import compact_to_aligned_qweight, make_runtime_tensors, runtime_tensor_bytes


@triton.jit
def _psop_linear_kernel_v2(
    x_ptr,
    qweight_ptr,
    lut_ptr,
    scales_ptr,
    offsets_ptr,
    outlier_pos_ptr,
    outlier_value_ptr,
    channel_scale_ptr,
    output_ptr,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    local_k = tl.arange(0, BLOCK_K)
    local_byte = tl.arange(0, BLOCK_K // 2)
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k_start in range(0, K, BLOCK_K):
        offs_k = k_start + local_k
        x = tl.load(
            x_ptr + offs_m[:, None] * K + offs_k[None, :],
            mask=offs_m[:, None] < M,
            other=0.0,
        )
        channel = tl.load(channel_scale_ptr + offs_k)
        x_scaled = (x / channel[None, :]).to(tl.float16)

        packed = tl.load(
            qweight_ptr
            + offs_n[:, None] * (K // 2)
            + (k_start // 2 + local_byte[None, :]),
            mask=offs_n[:, None] < N,
            other=0,
        )
        code = tl.interleave(packed & 0x0F, (packed >> 4) & 0x0F)
        group_index = offs_n * GROUPS + (k_start // BLOCK_K)
        n_mask = offs_n < N
        scale = tl.load(scales_ptr + group_index, mask=n_mask, other=0.0)
        offset = tl.load(offsets_ptr + group_index, mask=n_mask, other=0.0)
        position = tl.load(outlier_pos_ptr + group_index, mask=n_mask, other=255)
        outlier = tl.load(outlier_value_ptr + group_index, mask=n_mask, other=0.0)
        centroid = tl.load(
            lut_ptr + offs_n[:, None] * 16 + code,
            mask=n_mask[:, None],
            other=0.0,
        )
        ordinary = scale[:, None] * centroid + offset[:, None]
        protected = outlier[:, None] * channel[None, :]
        weight_scaled = tl.where(
            local_k[None, :] == position[:, None],
            protected,
            ordinary,
        ).to(tl.float16)
        accumulator += tl.dot(x_scaled, tl.trans(weight_scaled))

    tl.store(
        output_ptr + offs_m[:, None] * N + offs_n[None, :],
        accumulator,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )


def psop_linear_v2(
    input_tensor,
    runtime_tensors,
    bias=None,
    block_m=None,
    block_n=32,
    num_warps=4,
):
    original_shape = input_tensor.shape[:-1]
    x = input_tensor.contiguous().reshape(-1, input_tensor.shape[-1])
    M, K = x.shape
    qweight = runtime_tensors["qweight_aligned"]
    N = qweight.shape[0]
    if K % 128:
        raise ValueError("K must be divisible by 128.")
    if block_m is None:
        block_m = 16 if M <= 16 else 32
    output = torch.empty((M, N), device=x.device, dtype=x.dtype)
    grid = (triton.cdiv(M, block_m), triton.cdiv(N, block_n))
    _psop_linear_kernel_v2[grid](
        x,
        qweight,
        runtime_tensors["lut"],
        runtime_tensors["scales"],
        runtime_tensors["offsets"],
        runtime_tensors["outlier_pos"],
        runtime_tensors["outlier_value"],
        runtime_tensors["channel_scale"],
        output,
        M=M,
        N=N,
        K=K,
        GROUPS=K // 128,
        BLOCK_M=block_m,
        BLOCK_N=block_n,
        BLOCK_K=128,
        num_warps=num_warps,
        num_stages=3,
    )
    if bias is not None:
        output.add_(bias)
    return output.reshape(*original_shape, N)
