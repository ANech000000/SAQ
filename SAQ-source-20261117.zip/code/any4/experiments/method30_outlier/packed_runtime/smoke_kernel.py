import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")

import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from packed_format import atomic_write_json, load_layer, reconstruct_weight
from triton_kernel import make_runtime_tensors, psop_linear, runtime_tensor_bytes

LAYER = Path(
    "/data/lsz/any4/experiments/method30_outlier/checkpoints/"
    "llama3_8b_postawq_22a/fp16_meta/model__layers__0__self_attn__q_proj.safetensors"
)
OUTPUT = Path(
    "/data/lsz/any4/experiments/method30_outlier/runs/llama3_8b/"
    "postawq_22a_packed/kernel/smoke.json"
)


def benchmark(callable_, warmup=20, repeats=100):
    for _ in range(warmup):
        callable_()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    samples = []
    for _ in range(repeats):
        start.record()
        callable_()
        end.record()
        end.synchronize()
        samples.append(start.elapsed_time(end))
    values = torch.tensor(samples)
    return {
        "median_ms": float(values.median()),
        "p95_ms": float(values.kthvalue(max(1, int(0.95 * len(samples))))[0]),
        "mean_ms": float(values.mean()),
    }


def main():
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if not visible:
        raise RuntimeError("Expose exactly one empty GPU.")
    tensors, metadata = load_layer(LAYER)
    weight = reconstruct_weight(tensors, metadata).cuda()
    runtime = make_runtime_tensors(tensors, metadata)
    rows, cols = weight.shape
    cases = {}
    for m in (1, 4, 16, 128):
        torch.manual_seed(m)
        x = torch.randn(m, cols, device="cuda", dtype=torch.float16)
        reference = F.linear(x, weight)
        observed = psop_linear(x, runtime)
        difference = observed.float() - reference.float()
        relative_mse = float(
            difference.square().sum()
            / reference.float().square().sum().clamp_min(1e-30)
        )
        triton_time = benchmark(lambda: psop_linear(x, runtime))
        fp16_time = benchmark(lambda: F.linear(x, weight))
        cases[str(m)] = {
            "max_abs": float(difference.abs().max()),
            "relative_mse": relative_mse,
            "triton": triton_time,
            "fp16": fp16_time,
            "speedup_vs_fp16": fp16_time["median_ms"] / triton_time["median_ms"],
        }
        print(m, cases[str(m)], flush=True)
    compact_bytes = sum(value.numel() * value.element_size() for value in tensors.values())
    result = {
        "status": "complete",
        "layer": str(LAYER),
        "gpu": torch.cuda.get_device_name(0),
        "weight_shape": [rows, cols],
        "compact_tensor_bytes": compact_bytes,
        "runtime_tensor_bytes": runtime_tensor_bytes(runtime),
        "runtime_bpw": 8.0 * runtime_tensor_bytes(runtime) / weight.numel(),
        "cases": cases,
        "acceptance": {
            "relative_mse_max": 5e-5,
            "correct": all(item["relative_mse"] <= 5e-5 for item in cases.values()),
        },
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        raise RuntimeError(f"Refusing to overwrite {OUTPUT}")
    atomic_write_json(OUTPUT, result)
    print(json.dumps(result, indent=2))
    if not result["acceptance"]["correct"]:
        raise AssertionError("Triton kernel exceeds the correctness threshold.")


if __name__ == "__main__":
    main()
