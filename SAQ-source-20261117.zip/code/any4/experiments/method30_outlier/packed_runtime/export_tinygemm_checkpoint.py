import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

ROOT = Path(__file__).resolve().parent
REPO = Path('/data/lsz/any4')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO))

import tinygemm  # noqa: F401
from packed_format import load_layer
from tinygemm_composite import prepare_tinygemm_runtime


FORMAT = 'method30_post_awq_22a_tinygemm'
VERSION = 1
AUXILIARY_FILES = (
    'config.json',
    'generation_config.json',
    'tokenizer.json',
    'tokenizer_config.json',
    'special_tokens_map.json',
)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def bytes_by_tensor(tensors):
    return {key: int(value.numel() * value.element_size()) for key, value in tensors.items()}


def export_linear(source, destination, entry, device):
    tensors, metadata = load_layer(source, device='cpu')
    runtime = prepare_tinygemm_runtime(tensors, metadata, device=device)
    output = {
        'qweight_tinygemm': runtime['qweight_tinygemm'].cpu().contiguous(),
        'lut': runtime['lut'].cpu().contiguous(),
        'scales_and_zeros': runtime['scales_and_zeros'].cpu().contiguous(),
        'inv_channel_scale': runtime['inv_channel_scale'].cpu().contiguous(),
        'outlier_pos': runtime['outlier_pos'].cpu().contiguous(),
        'outlier_residual_scaled': runtime['outlier_residual_scaled'].cpu().contiguous(),
    }
    rows, cols = entry['weight_shape']
    file_metadata = {
        'format': FORMAT,
        'format_version': str(VERSION),
        'layer_name': entry['layer_name'],
        'weight_shape': json.dumps([rows, cols]),
        'group_size': '128',
        'lut_entries': '16',
        'outlier_rule': 'post_awq_top_abs_one_per_group',
        'outlier_payload': 'fp16_scaled_domain_residual',
        'source_file_sha256': entry['file_sha256'],
    }
    save_file(output, destination, metadata=file_metadata)
    components = bytes_by_tensor(output)
    weights = rows * cols
    return {
        'layer_name': entry['layer_name'],
        'file': destination.name,
        'weight_shape': [rows, cols],
        'weight_count': weights,
        'components_bytes': components,
        'tensor_bytes': sum(components.values()),
        'file_bytes': destination.stat().st_size,
        'tensor_bpw': 8.0 * sum(components.values()) / weights,
        'file_bpw': 8.0 * destination.stat().st_size / weights,
        'file_sha256': sha256(destination),
        'source_file': str(source),
        'source_file_sha256': entry['file_sha256'],
    }


def original_shards(model_path):
    index = json.loads((model_path / 'model.safetensors.index.json').read_text())
    return sorted(set(index['weight_map'].values()))


def export_nonquantized(model_path, destination, excluded_weights):
    records = []
    total_parameters = 0
    total_tensor_bytes = 0
    total_file_bytes = 0
    for shard_index, shard_name in enumerate(original_shards(model_path), start=1):
        source = model_path / shard_name
        tensors = {}
        with safe_open(source, framework='pt', device='cpu') as handle:
            for key in handle.keys():
                if key not in excluded_weights:
                    tensors[key] = handle.get_tensor(key)
        if not tensors:
            continue
        output = destination / f'nonquantized-{shard_index:05d}.safetensors'
        save_file(tensors, output, metadata={'format': FORMAT, 'kind': 'nonquantized'})
        tensor_bytes = sum(t.numel() * t.element_size() for t in tensors.values())
        parameters = sum(t.numel() for t in tensors.values())
        record = {
            'file': output.name,
            'source_file': shard_name,
            'tensor_count': len(tensors),
            'parameter_count': parameters,
            'tensor_bytes': tensor_bytes,
            'file_bytes': output.stat().st_size,
            'file_sha256': sha256(output),
            'keys': sorted(tensors),
        }
        records.append(record)
        total_parameters += parameters
        total_tensor_bytes += tensor_bytes
        total_file_bytes += output.stat().st_size
        print(f'nonquantized {output.name}: {parameters:,} parameters', flush=True)
    return records, total_parameters, total_tensor_bytes, total_file_bytes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-checkpoint', type=Path, required=True)
    parser.add_argument('--model-path', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--device', default='cuda:0')
    args = parser.parse_args()

    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}')
    args.output.mkdir(parents=True)
    source_manifest = json.loads((args.source_checkpoint / 'manifest.json').read_text())
    if source_manifest['linears'] != 224 or source_manifest['metadata_dtype'] != 'fp16':
        raise RuntimeError('Expected the verified 224-layer FP16 metadata checkpoint')

    linear_records = []
    component_totals = {}
    quantized_weights = 0
    for index, entry in enumerate(source_manifest['layers'], start=1):
        source = args.source_checkpoint / entry['file']
        destination = args.output / entry['file']
        record = export_linear(source, destination, entry, args.device)
        linear_records.append(record)
        quantized_weights += record['weight_count']
        for key, value in record['components_bytes'].items():
            component_totals[key] = component_totals.get(key, 0) + value
        print(f'[{index:03d}/224] {entry["layer_name"]}', flush=True)
        if index % 7 == 0:
            torch.cuda.empty_cache()

    excluded = {f'{entry["layer_name"]}.weight' for entry in source_manifest['layers']}
    nonquantized, nonquant_parameters, nonquant_tensor_bytes, nonquant_file_bytes = (
        export_nonquantized(args.model_path, args.output, excluded)
    )
    for filename in AUXILIARY_FILES:
        source = args.model_path / filename
        if source.exists():
            shutil.copy2(source, args.output / filename)

    linear_tensor_bytes = sum(item['tensor_bytes'] for item in linear_records)
    linear_file_bytes = sum(item['file_bytes'] for item in linear_records)
    total_parameters = quantized_weights + nonquant_parameters
    model_tensor_bytes = linear_tensor_bytes + nonquant_tensor_bytes
    model_file_bytes = linear_file_bytes + nonquant_file_bytes
    manifest = {
        'format': FORMAT,
        'format_version': VERSION,
        'status': 'complete',
        'method': 'method30_post_awq_22a',
        'source_checkpoint': str(args.source_checkpoint),
        'base_model': str(args.model_path),
        'linears': len(linear_records),
        'group_size': 128,
        'lut_entries': 16,
        'outlier_payload': 'one_fp16_scaled_domain_residual_per_group',
        'quantized_weights': quantized_weights,
        'nonquantized_parameters': nonquant_parameters,
        'total_parameters': total_parameters,
        'linear_components_bytes': component_totals,
        'linear_tensor_bytes': linear_tensor_bytes,
        'linear_file_bytes': linear_file_bytes,
        'linear_tensor_bpw': 8.0 * linear_tensor_bytes / quantized_weights,
        'linear_file_bpw': 8.0 * linear_file_bytes / quantized_weights,
        'nonquantized_tensor_bytes': nonquant_tensor_bytes,
        'nonquantized_file_bytes': nonquant_file_bytes,
        'model_tensor_bytes': model_tensor_bytes,
        'model_file_bytes': model_file_bytes,
        'whole_model_tensor_bpw': 8.0 * model_tensor_bytes / total_parameters,
        'whole_model_file_bpw': 8.0 * model_file_bytes / total_parameters,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'layers': linear_records,
        'nonquantized_shards': nonquantized,
    }
    manifest_path = args.output / 'manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in (
        'linears', 'quantized_weights', 'nonquantized_parameters',
        'linear_tensor_bpw', 'linear_file_bpw', 'whole_model_tensor_bpw',
        'whole_model_file_bpw', 'model_file_bytes')}, indent=2))


if __name__ == '__main__':
    main()
