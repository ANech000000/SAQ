import argparse
import json
from pathlib import Path

import numpy as np

from state_cache import atomic_write_json


EXP_DIR = Path(__file__).resolve().parent
CONFIG = json.loads((EXP_DIR / "config.json").read_text())


def execute(args):
    benchmark = json.loads(Path(args.benchmark).read_text())
    baseline = json.loads(Path(args.baseline).read_text())
    hybrid = json.loads(Path(args.hybrid).read_text())
    profile_name = benchmark["selection"]["profile"]
    profile = benchmark["selection"]["profile_parameters"]
    expected_initializer = {
        "initializer": "gpu_cpu",
        "gpu_iters": int(profile["gpu_iters"]),
        "cpu_iters": int(profile["cpu_iters"]),
        "gpu_chunk_rows": int(hybrid["initializer"]["gpu_chunk_rows"]),
    }
    if hybrid["initializer"] != expected_initializer:
        raise ValueError(
            f"Hybrid result initializer mismatch: {hybrid['initializer']} "
            f"!= {expected_initializer}"
        )
    checkpoint = int(baseline["selection"]["selected_checkpoint"])
    key = str(checkpoint)
    baseline_ppl = float(baseline["evaluations"][key]["wiki2_ppl"])
    hybrid_ppl = float(hybrid["evaluations"][key]["wiki2_ppl"])
    aggregate_ratio = float(
        hybrid["aggregates"][key]["weighted_loss_numerator"]
        / max(baseline["aggregates"][key]["weighted_loss_numerator"], 1e-20)
    )
    layer_ratios = np.asarray([
        hybrid["layers"][name]["checkpoints"][key]["diagnostics"][
            "final_weighted_loss"
        ]
        / max(
            baseline["layers"][name]["checkpoints"][key]["diagnostics"][
                "final_weighted_loss"
            ],
            1e-20,
        )
        for name in baseline["layers"]
    ])
    baseline_init = baseline["aggregates"][key]["initialization_seconds_sum"]
    hybrid_init = hybrid["aggregates"][key]["initialization_seconds_sum"]
    acceptance = CONFIG["hybrid_acceptance"]
    metrics = {
        "checkpoint": checkpoint,
        "baseline_ppl": baseline_ppl,
        "hybrid_ppl": hybrid_ppl,
        "ppl_delta": float(hybrid_ppl - baseline_ppl),
        "aggregate_loss_ratio": aggregate_ratio,
        "p95_layer_loss_ratio": float(np.quantile(layer_ratios, 0.95)),
        "maximum_layer_loss_ratio": float(layer_ratios.max()),
        "initialization_speedup": float(
            baseline_init / max(hybrid_init, 1e-12)
        ),
    }
    passed = bool(
        benchmark["selection"]["proxy_pass"]
        and metrics["ppl_delta"] <= acceptance["maximum_ppl_delta"]
        and metrics["aggregate_loss_ratio"] <= acceptance["aggregate_loss_ratio"]
        and metrics["p95_layer_loss_ratio"] <= acceptance["p95_layer_loss_ratio"]
        and metrics["initialization_speedup"]
        >= acceptance["minimum_initialization_speedup"]
    )
    result = {
        "status": "complete",
        "benchmark": str(Path(args.benchmark)),
        "baseline": str(Path(args.baseline)),
        "hybrid": str(Path(args.hybrid)),
        "selected_profile": profile_name,
        "profile_parameters": profile,
        "benchmark_proxy_pass": benchmark["selection"]["proxy_pass"],
        "metrics": metrics,
        "acceptance": acceptance,
        "hybrid_accepted": passed,
        "recommended_initializer": "gpu_cpu" if passed else "sklearn",
    }
    atomic_write_json(args.output, result)
    return result


def build_parser():
    parser = argparse.ArgumentParser(description="Finalize hybrid initializer result")
    parser.add_argument(
        "--benchmark",
        default=str(EXP_DIR / "runs" / "hybrid_initializer" / "benchmark.json"),
    )
    parser.add_argument(
        "--baseline",
        default=str(EXP_DIR / "runs" / "iteration_sweep" / "results.json"),
    )
    parser.add_argument(
        "--hybrid",
        default=str(EXP_DIR / "runs" / "hybrid_initializer" / "full" / "results.json"),
    )
    parser.add_argument(
        "--output",
        default=str(EXP_DIR / "runs" / "hybrid_initializer" / "results.json"),
    )
    return parser


def main():
    result = execute(build_parser().parse_args())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
