import argparse
import json
import os
import sys
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from experiment_runtime import (  # noqa: E402
    evaluate_checkpoint,
    parse_checkpoints,
    quantize_to_checkpoints,
)
from state_cache import atomic_write_json  # noqa: E402


CONFIG = json.loads((EXP_DIR / "config.json").read_text())


def _result_path(args):
    return Path(args.output_dir) / "results.json"


def evaluate_all(args, result_path):
    result_path = Path(result_path)
    if not result_path.exists():
        raise FileNotFoundError(f"Quantization result does not exist: {result_path}")
    result = json.loads(result_path.read_text())
    checkpoints = parse_checkpoints(args.checkpoints, args.target_iters)
    result["status"] = "evaluating"
    result.setdefault("evaluations", {})
    atomic_write_json(result_path, result)
    for checkpoint in checkpoints:
        evaluation = evaluate_checkpoint(args, checkpoint)
        result["evaluations"][str(checkpoint)] = evaluation
        atomic_write_json(result_path, result)
        print(
            f"checkpoint={checkpoint}: PPL={evaluation['wiki2_ppl']:.10f}, "
            f"apply={evaluation['apply_wall_seconds']:.3f}s",
            flush=True,
        )
    best_ppl = min(
        entry["wiki2_ppl"] for entry in result["evaluations"].values()
    )
    selected = min(
        int(checkpoint)
        for checkpoint, entry in result["evaluations"].items()
        if entry["wiki2_ppl"] <= best_ppl + 0.002
    )
    result["selection"] = {
        "best_ppl": float(best_ppl),
        "rule": "smallest_checkpoint_within_0p002_of_best",
        "selected_checkpoint": int(selected),
        "selected_ppl": float(
            result["evaluations"][str(selected)]["wiki2_ppl"]
        ),
    }
    result["baseline_reproduction"] = {
        "reference_ppl": CONFIG["baseline"]["wiki2_ppl_10_iters"],
        "observed_ppl": result["evaluations"].get("10", {}).get("wiki2_ppl"),
    }
    if result["baseline_reproduction"]["observed_ppl"] is not None:
        result["baseline_reproduction"]["absolute_delta"] = abs(
            result["baseline_reproduction"]["observed_ppl"]
            - result["baseline_reproduction"]["reference_ppl"]
        )
    result["status"] = "complete"
    atomic_write_json(result_path, result)
    return result


def validate_cache(args):
    reference_path = Path(args.reference_results or _result_path(args))
    reference = json.loads(reference_path.read_text())
    checkpoint = int(
        args.validation_checkpoint
        if args.validation_checkpoint is not None
        else reference["selection"]["selected_checkpoint"]
    )
    evaluation = evaluate_checkpoint(args, checkpoint)
    expected = reference["evaluations"][str(checkpoint)]
    hashes_equal = evaluation["reconstruction_hashes"] == expected[
        "reconstruction_hashes"
    ]
    ppl_delta = abs(evaluation["wiki2_ppl"] - expected["wiki2_ppl"])
    aggregate = reference["aggregates"][str(checkpoint)]
    cold_seconds = float(
        aggregate["initialization_seconds_sum"]
        + aggregate["optimization_seconds_sum"]
    )
    warm_seconds = float(evaluation["apply_wall_seconds"])
    warm_speedup = cold_seconds / max(warm_seconds, 1e-12)
    passed = (
        hashes_equal
        and ppl_delta <= CONFIG["cache_acceptance"]["maximum_ppl_delta"]
        and warm_speedup >= CONFIG["cache_acceptance"]["minimum_warm_speedup"]
    )
    result = {
        "status": "passed" if passed else "failed",
        "reference_results": str(reference_path),
        "checkpoint": checkpoint,
        "reference_ppl": expected["wiki2_ppl"],
        "cache_ppl": evaluation["wiki2_ppl"],
        "absolute_ppl_delta": float(ppl_delta),
        "reconstruction_hashes_equal": bool(hashes_equal),
        "cold_quantization_seconds": cold_seconds,
        "warm_apply_seconds": warm_seconds,
        "warm_speedup": float(warm_speedup),
        "acceptance": CONFIG["cache_acceptance"],
        "evaluation": evaluation,
    }
    output = Path(args.validation_output)
    atomic_write_json(output, result)
    print(json.dumps({
        "status": result["status"],
        "checkpoint": checkpoint,
        "ppl_delta": ppl_delta,
        "hashes_equal": hashes_equal,
        "warm_speedup": warm_speedup,
    }, indent=2))
    if not passed:
        raise RuntimeError("Final state cache validation failed.")
    return result


def build_parser():
    optimizer = CONFIG["optimizer"]
    parser = argparse.ArgumentParser(
        description="Post-AWQ 22A continuation and state-cache runner"
    )
    parser.add_argument(
        "--phase",
        choices=("quantize", "evaluate", "all", "validate-cache"),
        default="all",
    )
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--stats-bundle", default=CONFIG["stats_bundle"])
    parser.add_argument("--state-cache-dir", default=CONFIG["state_cache_dir"])
    parser.add_argument("--output-dir", default=CONFIG["output_dir"])
    parser.add_argument("--dataset-cache", default=CONFIG["dataset_cache"])
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument(
        "--checkpoints",
        default=",".join(str(value) for value in CONFIG["checkpoints"]),
    )
    parser.add_argument("--target-iters", type=int, default=CONFIG["target_iters"])
    parser.add_argument(
        "--initializer", choices=("sklearn", "gpu_cpu"), default="sklearn"
    )
    parser.add_argument("--gpu-iters", type=int, default=10)
    parser.add_argument("--cpu-iters", type=int, default=10)
    parser.add_argument("--gpu-chunk-rows", type=int, default=64)
    parser.add_argument("--parallel-jobs", type=int, default=CONFIG["parallel_jobs"])
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument(
        "--empty-threshold-mib",
        type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    parser.add_argument(
        "--empty-utilization-percent",
        type=int,
        default=CONFIG["gpu_policy"]["max_utilization_percent"],
    )
    parser.add_argument("--relative-tol", type=float, default=optimizer["relative_tol"])
    parser.add_argument("--ridge", type=float, default=optimizer["ridge"])
    parser.add_argument("--scale-eps", type=float, default=optimizer["scale_eps"])
    parser.add_argument("--chunk-rows", type=int, default=optimizer["chunk_rows"])
    parser.add_argument(
        "--importance-chunk-rows",
        type=int,
        default=optimizer["importance_chunk_rows"],
    )
    parser.add_argument(
        "--loss-increase-rtol",
        type=float,
        default=optimizer["loss_increase_rtol"],
    )
    parser.add_argument("--seqlen", type=int, default=CONFIG["seqlen"])
    parser.add_argument(
        "--loader-samples", type=int, default=CONFIG["loader_samples"]
    )
    parser.add_argument("--reference-results")
    parser.add_argument("--validation-checkpoint", type=int)
    parser.add_argument(
        "--validation-output",
        default=str(EXP_DIR / "runs" / "cache_validation" / "results.json"),
    )
    return parser


def main():
    args = build_parser().parse_args()
    os.environ["HF_DATASETS_CACHE"] = args.dataset_cache
    result_path = _result_path(args)
    if args.phase in ("quantize", "all"):
        quantize_to_checkpoints(args, result_path)
    if args.phase in ("evaluate", "all"):
        evaluate_all(args, result_path)
    if args.phase == "validate-cache":
        validate_cache(args)


if __name__ == "__main__":
    main()
