import gc
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
BASE_DIR = ROOT / "experiments" / "method30"
for path in (ROOT, EXP_DIR, BASE_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

_spec = importlib.util.spec_from_file_location(
    "method30_refine_base", BASE_DIR / "runner.py"
)
base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(base)

from method30_refine import (  # noqa: E402
    ALGORITHM_VERSION,
    initialize_state,
    reconstruct_from_state,
    refine_state,
    state_diagnostics,
)
from performance_topology import (  # noqa: E402
    allocate_cpu_sets,
    apply_cpu_affinity,
    assert_gpu_empty,
    parse_cpu_list,
)
from state_cache import (  # noqa: E402
    atomic_write_json,
    cache_file,
    canonical_fingerprint,
    file_sha256,
    load_state_cache,
    save_state_cache,
    state_cache_size_bytes,
    tensor_sha256,
)
from stats_bundle import load_stats_bundle, validate_bundle_model  # noqa: E402


_HARDWARE = None


def setup_hardware(args):
    global _HARDWARE
    if _HARDWARE is not None:
        return _HARDWARE
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    gpu = assert_gpu_empty(
        args.physical_gpu,
        args.empty_threshold_mib,
        args.empty_utilization_percent,
    )
    if args.cpu_list == "auto":
        allocation = allocate_cpu_sets([gpu], max_workers=args.parallel_jobs)[
            str(args.physical_gpu)
        ]
        cpus = allocation["cpus"]
    else:
        cpus = parse_cpu_list(args.cpu_list)
    if len(cpus) < int(args.parallel_jobs):
        raise RuntimeError(
            f"CPU affinity has {len(cpus)} cores for {args.parallel_jobs} workers."
        )
    cpus = cpus[: int(args.parallel_jobs)]
    affinity = apply_cpu_affinity(cpus)
    torch.backends.cuda.matmul.allow_tf32 = False
    _HARDWARE = (gpu, affinity)
    return _HARDWARE


def parse_checkpoints(value, target):
    if isinstance(value, str):
        checkpoints = [int(item) for item in value.split(",") if item.strip()]
    else:
        checkpoints = [int(item) for item in value]
    checkpoints = sorted(set(checkpoints))
    if not checkpoints or checkpoints[0] <= 0:
        raise ValueError("At least one positive checkpoint is required.")
    if checkpoints[-1] != int(target):
        raise ValueError("The largest checkpoint must equal target-iters.")
    return checkpoints


def initializer_options(args):
    if args.initializer == "sklearn":
        return {"initializer": "sklearn"}
    return {
        "initializer": "gpu_cpu",
        "gpu_iters": int(args.gpu_iters),
        "cpu_iters": int(args.cpu_iters),
        "gpu_chunk_rows": int(args.gpu_chunk_rows),
    }


def build_run_identity(args, bundle_path):
    optimizer = {
        "relative_tol": float(args.relative_tol),
        "ridge": float(args.ridge),
        "scale_eps": float(args.scale_eps),
        "chunk_rows": int(args.chunk_rows),
        "importance_chunk_rows": int(args.importance_chunk_rows),
        "loss_increase_rtol": float(args.loss_increase_rtol),
    }
    identity = {
        "algorithm_version": ALGORITHM_VERSION,
        "implementation_sha256": {
            "method30_refine.py": file_sha256(EXP_DIR / "method30_refine.py"),
            "hybrid_init.py": file_sha256(EXP_DIR / "hybrid_init.py"),
            "state_cache.py": file_sha256(EXP_DIR / "state_cache.py"),
        },
        "model_path": str(Path(args.model_path).resolve()),
        "stats_bundle": str(Path(bundle_path).resolve()),
        "stats_bundle_sha256": file_sha256(bundle_path),
        "n_bit": 4,
        "group_size": int(args.group_size),
        "outlier_selection_domain": "post_awq",
        "outlier_rule": "max_abs_first_tie_scaled_post_awq",
        "outliers_per_group": 1,
        "initializer": initializer_options(args),
        "parallel_jobs": int(args.parallel_jobs),
        "optimizer": optimizer,
    }
    return identity, canonical_fingerprint(identity)[:24]


def layer_metadata(identity, name, stats, checkpoint):
    return {
        "run_identity": identity,
        "layer_name": name,
        "weight_shape": list(stats["weight_shape"]),
        "weight_dtype": stats["weight_dtype"],
        "weight_sha256": stats["weight_sha256"],
        "channel_scale_sha256": stats["channel_scale_sha256"],
        "fisher_sha256": stats["fisher_sha256"],
        "alpha": float(stats["alpha"]),
        "alpha_source": stats["alpha_source"],
        "checkpoint": int(checkpoint),
    }


def load_context(args):
    bundle = load_stats_bundle(args.stats_bundle)
    model, tokenizer = base.load_model_and_tokenizer(args.model_path)
    linears = validate_bundle_model(model, bundle, args.group_size)
    return bundle, model, tokenizer, linears


def _checkpoint_entry(path, payload, state, cache_hit):
    diagnostics = state_diagnostics(state)
    return {
        "cache_path": str(path),
        "cache_hit": bool(cache_hit),
        "cache_state_sha256": payload["state_hash"],
        "cache_bytes": state_cache_size_bytes(path),
        "diagnostics": diagnostics,
    }


def _aggregate_checkpoint(layers, checkpoint):
    entries = [entry["checkpoints"][str(checkpoint)] for entry in layers.values()]
    diagnostics = [entry["diagnostics"] for entry in entries]
    numerator = sum(item["weighted_loss_numerator"] for item in diagnostics)
    denominator = sum(item["weighted_loss_denominator"] for item in diagnostics)
    return {
        "layers": len(entries),
        "weighted_loss": float(numerator / max(denominator, 1e-12)),
        "weighted_loss_numerator": float(numerator),
        "weighted_loss_denominator": float(denominator),
        "all_losses_monotonic": all(item["loss_monotonic"] for item in diagnostics),
        "rollback_layers": sum(bool(item["rollback"]) for item in diagnostics),
        "converged_layers": sum(bool(item["converged"]) for item in diagnostics),
        "accepted_iterations": sum(item["iterations"] for item in diagnostics),
        "initialization_seconds_sum": sum(
            item["initialization_seconds"] for item in diagnostics
        ),
        "optimization_seconds_sum": sum(
            item["optimization_seconds"] for item in diagnostics
        ),
        "cache_bytes": sum(entry["cache_bytes"] for entry in entries),
        "cache_hits": sum(bool(entry["cache_hit"]) for entry in entries),
    }


def quantize_to_checkpoints(args, result_path):
    gpu, affinity = setup_hardware(args)
    checkpoints = parse_checkpoints(args.checkpoints, args.target_iters)
    bundle, model, tokenizer, linears = load_context(args)
    identity, fingerprint = build_run_identity(args, args.stats_bundle)
    result = {
        "method_name": "method30_postawq_22a_refine_cache",
        "status": "quantizing",
        "model_path": args.model_path,
        "stats_bundle": args.stats_bundle,
        "run_identity": identity,
        "run_fingerprint": fingerprint,
        "initializer": initializer_options(args),
        "checkpoints": checkpoints,
        "target_iters": int(args.target_iters),
        "physical_gpu": str(args.physical_gpu),
        "gpu_before": gpu,
        "cpu_affinity": affinity,
        "layers": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write_json(result_path, result)
    wall_started = time.perf_counter()
    active_block = None

    for index, (name, module, stats) in enumerate(linears, 1):
        source = module.weight.detach().to(device="cuda:0")
        layer_entry = {
            "weight_shape": list(module.weight.shape),
            "alpha": float(stats["alpha"]),
            "alpha_source": stats["alpha_source"],
            "checkpoints": {},
        }
        prefix_state = None
        prefix_checkpoint = 0
        missing_seen = False
        for checkpoint in checkpoints:
            metadata = layer_metadata(identity, name, stats, checkpoint)
            path = cache_file(
                args.state_cache_dir, fingerprint, name, checkpoint
            )
            if path.exists() and not missing_seen:
                state, payload = load_state_cache(path, metadata)
                prefix_state = state
                prefix_checkpoint = checkpoint
                layer_entry["checkpoints"][str(checkpoint)] = _checkpoint_entry(
                    path, payload, state, True
                )
            else:
                missing_seen = True

        if missing_seen:
            if prefix_state is None:
                state = initialize_state(
                    source,
                    stats["channel_scale"],
                    stats["fisher"],
                    group_size=args.group_size,
                    parallel_jobs=args.parallel_jobs,
                    relative_tol=args.relative_tol,
                    ridge=args.ridge,
                    scale_eps=args.scale_eps,
                    chunk_rows=args.chunk_rows,
                    importance_chunk_rows=args.importance_chunk_rows,
                    loss_increase_rtol=args.loss_increase_rtol,
                    **initializer_options(args),
                )
            else:
                state = prefix_state
            for checkpoint in checkpoints:
                if checkpoint <= prefix_checkpoint:
                    continue
                metadata = layer_metadata(identity, name, stats, checkpoint)
                path = cache_file(
                    args.state_cache_dir, fingerprint, name, checkpoint
                )
                if path.exists():
                    raise RuntimeError(
                        f"Non-contiguous cache checkpoints for {name}: {path}"
                    )
                state = refine_state(source, state, checkpoint)
                payload, created = save_state_cache(path, metadata, state)
                layer_entry["checkpoints"][str(checkpoint)] = _checkpoint_entry(
                    path, payload, state, not created
                )
        result["layers"][name] = layer_entry
        result["completed_linears"] = index
        result["active_linear"] = name
        atomic_write_json(result_path, result)
        final = layer_entry["checkpoints"][str(checkpoints[-1])]["diagnostics"]
        print(
            f"[{index}/{len(linears)}] {name}: "
            f"loss={final['initial_weighted_loss']:.8e}->"
            f"{final['final_weighted_loss']:.8e}, iters={final['iterations']}",
            flush=True,
        )
        block = int(stats.get("block", -1))
        next_block = (
            int(linears[index][2].get("block", -1))
            if index < len(linears) else None
        )
        del source, state, prefix_state
        if block != next_block:
            torch.cuda.empty_cache()
            gc.collect()
        active_block = block

    result["status"] = "quantized"
    result["active_linear"] = None
    result["quantization_wall_seconds"] = float(time.perf_counter() - wall_started)
    result["aggregates"] = {
        str(checkpoint): _aggregate_checkpoint(result["layers"], checkpoint)
        for checkpoint in checkpoints
    }
    result["finished_quantization_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(result_path, result)
    del model, tokenizer, bundle
    torch.cuda.empty_cache()
    gc.collect()
    return result


def evaluate_checkpoint(args, checkpoint, result_path=None):
    setup_hardware(args)
    bundle, model, tokenizer, linears = load_context(args)
    identity, fingerprint = build_run_identity(args, args.stats_bundle)
    reconstruction_hashes = {}
    load_seconds = 0.0
    reconstruct_seconds = 0.0
    started = time.perf_counter()
    for index, (name, module, stats) in enumerate(linears, 1):
        metadata = layer_metadata(identity, name, stats, checkpoint)
        path = cache_file(args.state_cache_dir, fingerprint, name, checkpoint)
        load_started = time.perf_counter()
        state, payload = load_state_cache(path, metadata)
        load_seconds += time.perf_counter() - load_started
        source = module.weight.detach().to(device="cuda:0")
        reconstruct_started = time.perf_counter()
        reconstructed = reconstruct_from_state(source, state)
        torch.cuda.synchronize()
        reconstruct_seconds += time.perf_counter() - reconstruct_started
        reconstruction_hashes[name] = tensor_sha256(
            reconstructed.detach().cpu().to(module.weight.dtype)
        )
        module.weight.data.copy_(
            reconstructed.detach().cpu().to(module.weight.dtype)
        )
        del source, reconstructed, state, payload
        if index == len(linears) or int(linears[index][2].get("block", -1)) != int(
            stats.get("block", -1)
        ):
            torch.cuda.empty_cache()
            gc.collect()
    apply_seconds = time.perf_counter() - started
    model.to("cuda:0")
    model.eval()
    evaluation_started = time.perf_counter()
    ppl = base.evaluate_wiki2(model, tokenizer, args.loader_samples, args.seqlen)
    evaluation_seconds = time.perf_counter() - evaluation_started
    output = {
        "status": "complete",
        "checkpoint": int(checkpoint),
        "wiki2_ppl": float(ppl),
        "run_fingerprint": fingerprint,
        "load_seconds": float(load_seconds),
        "reconstruct_seconds": float(reconstruct_seconds),
        "apply_wall_seconds": float(apply_seconds),
        "evaluation_seconds": float(evaluation_seconds),
        "reconstruction_hashes": reconstruction_hashes,
    }
    if result_path is not None:
        atomic_write_json(result_path, output)
    del model, tokenizer, bundle
    torch.cuda.empty_cache()
    gc.collect()
    return output
