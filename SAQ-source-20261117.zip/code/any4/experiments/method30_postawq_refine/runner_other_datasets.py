import argparse
import gc
import json
import os
import random
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from data_gptq import llama_eval  # noqa: E402
from experiment_runtime import (  # noqa: E402
    build_run_identity,
    layer_metadata,
    load_context,
    setup_hardware,
)
from method30_refine import reconstruct_from_state  # noqa: E402
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test  # noqa: E402
from run_local_mbpp_gsm8k import (  # noqa: E402
    MBPP_EVALUATOR_VERSION,
    _ALLOWED_IMPORT_ROOTS,
    eval_gsm8k,
    eval_mbpp,
)
from state_cache import (  # noqa: E402
    atomic_write_json,
    cache_file,
    canonical_fingerprint,
    file_sha256,
    load_state_cache,
    tensor_sha256,
)


CONFIG = json.loads((EXP_DIR / "config.json").read_text())
METHOD_NAME = "method30_postawq_22a_refine10"
METHOD2_BASELINES = {
    "mbpp": {
        "metric": "pass@1",
        "value": 0.2801556420233463,
        "passed": 72,
        "total": 257,
        "higher_is_better": True,
    },
    "gsm8k": {
        "metric": "accuracy",
        "value": 0.043214556482183475,
        "correct": 57,
        "total": 1319,
        "higher_is_better": True,
    },
    "c4": {
        "metric": "ppl",
        "value": 12.763955116271973,
        "eval_samples": 256,
        "seqlen": 2048,
        "higher_is_better": False,
    },
    "ptb": {
        "metric": "ppl",
        "value": 19.235050201416016,
        "eval_samples": 46,
        "seqlen": 2048,
        "higher_is_better": False,
    },
}


def build_parser():
    optimizer = CONFIG["optimizer"]
    parser = argparse.ArgumentParser(
        description="Evaluate cached Post-AWQ 22A weights on local datasets."
    )
    parser.add_argument("--suite", choices=("tasks", "ppl"), required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--stats-bundle", default=CONFIG["stats_bundle"])
    parser.add_argument("--state-cache-dir", default=CONFIG["state_cache_dir"])
    parser.add_argument(
        "--reference-results",
        default=str(Path(CONFIG["output_dir"]) / "results.json"),
    )
    parser.add_argument("--checkpoint", type=int, default=10)
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument("--parallel-jobs", type=int, default=CONFIG["parallel_jobs"])
    parser.add_argument(
        "--empty-threshold-mib",
        type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    parser.add_argument(
        "--empty-utilization-percent",
        type=int,
        default=CONFIG["gpu_policy"]["max_utilization_percent"],
    )
    parser.add_argument("--relative-tol", type=float, default=optimizer["relative_tol"])
    parser.add_argument("--ridge", type=float, default=optimizer["ridge"])
    parser.add_argument("--scale-eps", type=float, default=optimizer["scale_eps"])
    parser.add_argument("--chunk-rows", type=int, default=optimizer["chunk_rows"])
    parser.add_argument(
        "--importance-chunk-rows",
        type=int,
        default=optimizer["importance_chunk_rows"],
    )
    parser.add_argument(
        "--loss-increase-rtol",
        type=float,
        default=optimizer["loss_increase_rtol"],
    )
    parser.add_argument("--mbpp-path", default="/data/lsz/llm_dataset/code/MBPP/mbpp_test.json")
    parser.add_argument("--gsm8k-path", default="/data/lsz/llm_dataset/math/GSM8K/test.json")
    parser.add_argument("--mbpp-limit", type=int)
    parser.add_argument("--gsm8k-limit", type=int)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--mbpp-max-new-tokens", type=int, default=256)
    parser.add_argument("--gsm-max-new-tokens", type=int, default=256)
    parser.add_argument("--mbpp-timeout-sec", type=int, default=3)
    parser.add_argument("--mbpp-prompt-style", choices=("bigcode", "plain"), default="bigcode")
    parser.add_argument("--c4-dir", default="/data/lsz/llm_dataset/pretraining/C4")
    parser.add_argument("--ptb-dir", default="/data/lsz/llm_dataset/language_modeling/PTB")
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--c4-eval-samples", type=int, default=256)
    parser.add_argument("--ptb-eval-samples", type=int)
    parser.add_argument("--seed", type=int, default=0)
    parser.set_defaults(
        initializer="sklearn",
        gpu_iters=10,
        cpu_iters=10,
        gpu_chunk_rows=64,
    )
    return parser


def _file_record(path):
    path = Path(path)
    return {
        "path": str(path.resolve()),
        "bytes": int(path.stat().st_size),
        "sha256": file_sha256(path),
    }


def _dataset_provenance(args):
    c4_files = sorted((Path(args.c4_dir) / "en").glob("c4-validation.*.json.gz"))
    return {
        "mbpp": _file_record(args.mbpp_path),
        "gsm8k": _file_record(args.gsm8k_path),
        "c4": {
            "path": str(Path(args.c4_dir).resolve()),
            "files": [
                {"name": path.name, "bytes": int(path.stat().st_size)}
                for path in c4_files
            ],
            "seed": int(args.seed),
        },
        "ptb": _file_record(Path(args.ptb_dir) / "test.jsonl"),
        "evaluator_sources": {
            "tasks": file_sha256(ROOT / "run_local_mbpp_gsm8k.py"),
            "ppl": file_sha256(ROOT / "run_local_c4_ptb_ppl.py"),
            "llama_eval": file_sha256(ROOT / "data_gptq.py"),
        },
    }


def _load_result(args):
    result_path = Path(args.output_dir) / "results.json"
    if result_path.exists():
        if not args.resume:
            raise FileExistsError(
                f"Result already exists; pass --resume to reuse it: {result_path}"
            )
        result = json.loads(result_path.read_text())
        expected = {
            "suite": args.suite,
            "checkpoint": int(args.checkpoint),
            "model_path": str(args.model_path),
        }
        observed = {key: result.get(key) for key in expected}
        if observed != expected:
            raise RuntimeError(
                f"Resume metadata mismatch: expected {expected}, got {observed}"
            )
        return result_path, result

    result = {
        "method": METHOD_NAME,
        "description": (
            "method27 lambda=0.3 AWQ + post-AWQ exact 1/128 outlier + "
            "Fisher Any4 + 10 accepted alternating-refinement iterations"
        ),
        "suite": args.suite,
        "status": "starting",
        "model_path": str(args.model_path),
        "checkpoint": int(args.checkpoint),
        "physical_gpu": str(args.physical_gpu),
        "reference_results": str(Path(args.reference_results).resolve()),
        "method2_baselines": METHOD2_BASELINES,
        "dataset_provenance": _dataset_provenance(args),
        "metrics": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write_json(result_path, result)
    return result_path, result


def _load_cached_model(args):
    gpu, affinity = setup_hardware(args)
    reference = json.loads(Path(args.reference_results).read_text())
    checkpoint_key = str(args.checkpoint)
    if checkpoint_key not in reference.get("evaluations", {}):
        raise RuntimeError(
            f"Reference result does not contain checkpoint {args.checkpoint}."
        )
    expected_hashes = reference["evaluations"][checkpoint_key][
        "reconstruction_hashes"
    ]

    bundle, model, tokenizer, linears = load_context(args)
    identity, fingerprint = build_run_identity(args, args.stats_bundle)
    if fingerprint != reference.get("run_fingerprint"):
        raise RuntimeError(
            "Evaluation arguments do not match the validated cache fingerprint: "
            f"{fingerprint} != {reference.get('run_fingerprint')}"
        )
    if len(expected_hashes) != len(linears):
        raise RuntimeError(
            f"Reference has {len(expected_hashes)} hashes for {len(linears)} linears."
        )

    reconstruction_hashes = {}
    load_seconds = 0.0
    reconstruct_seconds = 0.0
    started = time.perf_counter()
    for index, (name, module, stats) in enumerate(linears, 1):
        metadata = layer_metadata(identity, name, stats, args.checkpoint)
        path = cache_file(
            args.state_cache_dir, fingerprint, name, args.checkpoint
        )
        load_started = time.perf_counter()
        state, payload = load_state_cache(path, metadata)
        load_seconds += time.perf_counter() - load_started

        source_tensor = module.weight.detach().to(device="cuda:0")
        reconstruct_started = time.perf_counter()
        reconstructed = reconstruct_from_state(source_tensor, state)
        torch.cuda.synchronize()
        reconstruct_seconds += time.perf_counter() - reconstruct_started
        reconstructed_cpu = reconstructed.detach().cpu().to(module.weight.dtype)
        reconstruction_hashes[name] = tensor_sha256(reconstructed_cpu)
        module.weight.data.copy_(reconstructed_cpu)

        del source_tensor, reconstructed, reconstructed_cpu, state, payload
        current_block = int(stats.get("block", -1))
        next_block = (
            int(linears[index][2].get("block", -1))
            if index < len(linears)
            else None
        )
        if current_block != next_block:
            torch.cuda.empty_cache()
            gc.collect()

    mismatches = {
        name: {
            "expected": expected_hashes.get(name),
            "observed": observed,
        }
        for name, observed in reconstruction_hashes.items()
        if expected_hashes.get(name) != observed
    }
    if mismatches:
        first_name = next(iter(mismatches))
        raise RuntimeError(
            f"Reconstruction hash mismatch for {first_name}: {mismatches[first_name]}"
        )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    model.to("cuda:0")
    model.eval()
    apply_seconds = time.perf_counter() - started
    del bundle
    return model, tokenizer, {
        "run_fingerprint": fingerprint,
        "checkpoint": int(args.checkpoint),
        "linears": len(linears),
        "reconstruction_hashes_equal": True,
        "reconstruction_hash_digest": canonical_fingerprint(
            reconstruction_hashes
        ),
        "load_seconds": float(load_seconds),
        "reconstruct_seconds": float(reconstruct_seconds),
        "apply_wall_seconds": float(apply_seconds),
        "gpu_before": gpu,
        "cpu_affinity": affinity,
    }


def _comparison(dataset, observed, comparable):
    baseline = METHOD2_BASELINES[dataset]
    if not comparable:
        return {
            "comparable": False,
            "reason": "limited smoke run",
            "method2_value": baseline["value"],
        }
    delta = float(observed - baseline["value"])
    improvement = delta if baseline["higher_is_better"] else -delta
    return {
        "comparable": True,
        "method2_value": baseline["value"],
        "observed_value": float(observed),
        "observed_minus_method2": delta,
        "improvement_signed": float(improvement),
        "higher_is_better": baseline["higher_is_better"],
    }


def _run_tasks(args, result_path, result, model, tokenizer):
    mbpp_data = json.loads(Path(args.mbpp_path).read_text())
    gsm8k_data = json.loads(Path(args.gsm8k_path).read_text())
    if args.mbpp_limit is not None:
        mbpp_data = mbpp_data[: args.mbpp_limit]
    if args.gsm8k_limit is not None:
        gsm8k_data = gsm8k_data[: args.gsm8k_limit]

    if "mbpp" not in result["metrics"]:
        result["status"] = "evaluating_mbpp"
        atomic_write_json(result_path, result)
        started = time.perf_counter()
        mbpp = eval_mbpp(
            model,
            tokenizer,
            mbpp_data,
            args.batch_size,
            args.mbpp_max_new_tokens,
            args.mbpp_timeout_sec,
            args.mbpp_prompt_style,
        )
        atomic_write_json(
            Path(args.output_dir) / "mbpp_generations.json",
            mbpp.pop("records"),
        )
        mbpp["evaluation_seconds"] = float(time.perf_counter() - started)
        mbpp["comparison"] = _comparison(
            "mbpp", mbpp["pass@1"], args.mbpp_limit is None
        )
        mbpp["evaluator"] = {
            "version": MBPP_EVALUATOR_VERSION,
            "prompt_style": args.mbpp_prompt_style,
            "timeout_seconds": int(args.mbpp_timeout_sec),
            "controlled_imports": sorted(_ALLOWED_IMPORT_ROOTS),
        }
        result["metrics"]["mbpp"] = mbpp
        atomic_write_json(result_path, result)
        print(
            f"MBPP pass@1={mbpp['pass@1']:.10f} "
            f"({mbpp['passed']}/{mbpp['total']})",
            flush=True,
        )

    if "gsm8k" not in result["metrics"]:
        result["status"] = "evaluating_gsm8k"
        atomic_write_json(result_path, result)
        started = time.perf_counter()
        gsm8k = eval_gsm8k(
            model,
            tokenizer,
            gsm8k_data,
            args.batch_size,
            args.gsm_max_new_tokens,
        )
        atomic_write_json(
            Path(args.output_dir) / "gsm8k_generations.json",
            gsm8k.pop("records"),
        )
        gsm8k["evaluation_seconds"] = float(time.perf_counter() - started)
        gsm8k["comparison"] = _comparison(
            "gsm8k", gsm8k["accuracy"], args.gsm8k_limit is None
        )
        result["metrics"]["gsm8k"] = gsm8k
        atomic_write_json(result_path, result)
        print(
            f"GSM8K accuracy={gsm8k['accuracy']:.10f} "
            f"({gsm8k['correct']}/{gsm8k['total']})",
            flush=True,
        )


def _run_ppl(args, result_path, result, model, tokenizer):
    if "c4" not in result["metrics"]:
        result["status"] = "evaluating_c4"
        atomic_write_json(result_path, result)
        testenc = load_c4_eval(
            args.c4_dir,
            tokenizer,
            args.seqlen,
            args.c4_eval_samples,
            args.seed,
        )
        eval_tokens = int(testenc.input_ids.numel())
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, "cuda", seqlen=args.seqlen))
        metric = {
            "ppl": ppl,
            "eval_tokens": eval_tokens,
            "eval_samples": eval_tokens // args.seqlen,
            "seqlen": int(args.seqlen),
            "seed": int(args.seed),
            "evaluation_seconds": float(time.perf_counter() - started),
            "comparison": _comparison(
                "c4",
                ppl,
                args.c4_eval_samples == 256 and args.seqlen == 2048,
            ),
        }
        result["metrics"]["c4"] = metric
        atomic_write_json(Path(args.output_dir) / "c4.json", metric)
        atomic_write_json(result_path, result)
        print(f"C4 PPL={ppl:.10f}", flush=True)
        del testenc
        torch.cuda.empty_cache()

    if "ptb" not in result["metrics"]:
        result["status"] = "evaluating_ptb"
        atomic_write_json(result_path, result)
        testenc = load_ptb_test(args.ptb_dir, tokenizer, args.seqlen)
        if args.ptb_eval_samples is not None:
            limit = int(args.ptb_eval_samples) * int(args.seqlen)
            testenc.input_ids = testenc.input_ids[:, :limit]
        eval_tokens = int(testenc.input_ids.numel())
        started = time.perf_counter()
        ppl = float(llama_eval(model, testenc, "cuda", seqlen=args.seqlen))
        metric = {
            "ppl": ppl,
            "eval_tokens": eval_tokens,
            "eval_samples": eval_tokens // args.seqlen,
            "seqlen": int(args.seqlen),
            "evaluation_seconds": float(time.perf_counter() - started),
            "comparison": _comparison(
                "ptb",
                ppl,
                args.ptb_eval_samples is None and args.seqlen == 2048,
            ),
        }
        result["metrics"]["ptb"] = metric
        atomic_write_json(Path(args.output_dir) / "ptb.json", metric)
        atomic_write_json(result_path, result)
        print(f"PTB PPL={ppl:.10f}", flush=True)
        del testenc
        torch.cuda.empty_cache()


def main():
    args = build_parser().parse_args()
    if args.checkpoint != 10:
        raise ValueError("This comparison is fixed to the selected 10-iteration state.")
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    result_path, result = _load_result(args)
    if result.get("status") == "complete":
        print(json.dumps(result["metrics"], indent=2), flush=True)
        return

    wall_started = time.perf_counter()
    model = tokenizer = None
    try:
        result["status"] = "loading_validated_cache"
        atomic_write_json(result_path, result)
        model, tokenizer, cache_info = _load_cached_model(args)
        result["cache"] = cache_info
        atomic_write_json(result_path, result)
        if args.suite == "tasks":
            _run_tasks(args, result_path, result, model, tokenizer)
        else:
            _run_ppl(args, result_path, result, model, tokenizer)
        result["status"] = "complete"
        result["process_wall_seconds"] = float(time.perf_counter() - wall_started)
        result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        atomic_write_json(result_path, result)
        print(json.dumps(result["metrics"], indent=2), flush=True)
    finally:
        if model is not None:
            del model
        if tokenizer is not None:
            del tokenizer
        torch.cuda.empty_cache()
        gc.collect()


if __name__ == "__main__":
    main()
