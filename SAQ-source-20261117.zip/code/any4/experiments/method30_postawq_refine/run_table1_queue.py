"""Detached queue for the remaining Any4 Table-1 reproduction jobs."""

import json
import os
import subprocess
import time
from pathlib import Path


BASE = Path(
    "/data/lsz/any4/experiments/method30_postawq_refine/runs/"
    "table1_official_reproduction"
)
RUNNER = Path(
    "/data/lsz/any4/experiments/method30_postawq_refine/"
    "runner_any4_table_baselines.py"
)
PYTHON = "/home/ubuntu/anaconda3/envs/verl/bin/python"
PYTHONPATH = "/data/lsz/any4/venv/lib/python3.10/site-packages"
MODEL_8B = "/data/model/models--meta-llama--Meta-Llama-3-8B"
GPU_SLOTS = ((0, "0-15"), (1, "16-31"), (3, "48-63"))
ONE_B_RESULTS = tuple(
    BASE / "1b" / name / "results.json"
    for name in ("int4_verified", "fp4_verified", "nf4_verified")
)
VARIANTS_8B = ("fp16", "int4", "fp4", "nf4", "original_any4")
POLL_SECONDS = 60


def log(message):
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{stamp}] {message}", flush=True)


def result_complete(path):
    try:
        return json.loads(path.read_text()).get("status") == "complete"
    except (FileNotFoundError, json.JSONDecodeError):
        return False


def gpu_is_free(index):
    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={index}",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    ).strip()
    used, utilization = (int(value.strip()) for value in output.split(","))
    return used <= 256 and utilization <= 5


def start_job(variant, gpu, cpu_list):
    output_dir = BASE / "8b" / variant
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "results.json"
    command = [
        "taskset", "-c", cpu_list,
        PYTHON, str(RUNNER),
        "--variant", variant,
        "--physical-gpu", str(gpu),
        "--cpu-list", cpu_list,
        "--model-path", MODEL_8B,
        "--output-dir", str(output_dir),
    ]
    if result_path.exists():
        command.append("--resume")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu)
    env["PYTHONPATH"] = PYTHONPATH
    stream = (output_dir / "run.log").open("a", buffering=1)
    process = subprocess.Popen(
        command,
        stdout=stream,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        env=env,
        start_new_session=True,
    )
    log(f"started 8B {variant} on GPU {gpu}, pid={process.pid}")
    return process, stream


def main():
    log("waiting for the three resumed 1B jobs")
    while not all(result_complete(path) for path in ONE_B_RESULTS):
        time.sleep(POLL_SECONDS)
    log("all 1B numeric-format jobs complete")

    pending = [
        variant
        for variant in VARIANTS_8B
        if not result_complete(BASE / "8b" / variant / "results.json")
    ]
    active = {}
    failures = []

    while pending or active:
        for gpu, (variant, process, stream) in list(active.items()):
            code = process.poll()
            if code is None:
                continue
            stream.close()
            del active[gpu]
            result_path = BASE / "8b" / variant / "results.json"
            if code == 0 and result_complete(result_path):
                log(f"completed 8B {variant} on GPU {gpu}")
            else:
                failures.append((variant, code))
                log(f"8B {variant} stopped with exit code {code}; leaving artifacts for diagnosis")

        for gpu, cpu_list in GPU_SLOTS:
            if not pending or gpu in active or not gpu_is_free(gpu):
                continue
            variant = pending.pop(0)
            process, stream = start_job(variant, gpu, cpu_list)
            active[gpu] = (variant, process, stream)

        time.sleep(POLL_SECONDS)

    if failures:
        log(f"queue finished with failures: {failures}")
        raise SystemExit(1)
    log("all requested 8B Table-1 jobs complete")


if __name__ == "__main__":
    main()
