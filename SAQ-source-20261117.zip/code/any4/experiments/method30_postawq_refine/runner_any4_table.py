import argparse
import contextlib
import csv
import gc
import json
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTHONUNBUFFERED", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import datasets
import torch
from accelerate import Accelerator
from datasets import Dataset, DatasetDict


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import bigcode_eval.base as bigcode_base  # noqa: E402
import bigcode_eval.arguments  # noqa: E402
import bigcode_eval.tasks as bigcode_tasks  # noqa: E402
from bigcode_eval.evaluator import Evaluator as BigCodeEvaluator  # noqa: E402
from bigcode_eval.tasks.mbpp import MBPP as BigCodeMBPP  # noqa: E402
import lm_eval  # noqa: E402
from lm_eval.models.huggingface import HFLM  # noqa: E402

import data as any4_data  # noqa: E402
from runner_other_datasets import _load_cached_model  # noqa: E402
from state_cache import atomic_write_json, file_sha256  # noqa: E402


CONFIG = json.loads((EXP_DIR / "config.json").read_text())
DEFAULT_REFERENCE = Path(CONFIG["output_dir"]) / "results.json"

CODEPARROT_PATH = Path(
    "/data/lsz/llm_dataset/code/CodeParrot/file-000000000054.json.gz"
)
HUMANEVAL_PATH = Path(
    "/data/lsz/llm_dataset/code/HumanEval/human_eval_test.json"
)
MBPP_PATH = Path("/data/lsz/llm_dataset/code/MBPP/mbpp_test.json")
MMLU_ROOT = Path(
    "/data/lsz/project-resq/tri_stage_resq/eval_data/local_tasks/mmlu"
)
GSM8K_PATH = Path("/data/lsz/llm_dataset/math/GSM8K/test.json")
BBH_ROOT = Path("/data/lsz/llm_dataset/commonsense_reasoning/BBH")


def build_parser():
    optimizer = CONFIG["optimizer"]
    parser = argparse.ArgumentParser(
        description="Evaluate cached Llama-3.2-1B Post-AWQ 22A on the Any4 table tasks."
    )
    parser.add_argument("--suite", choices=("code", "harness"), required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--harness-batch-size",
        type=int,
        default=8,
        help="Fixed lm-eval batch size (default: 8).",
    )
    parser.add_argument(
        "--tasks",
        nargs="+",
        choices=("mmlu", "hellaswag", "gsm8k", "bbh"),
        default=("mmlu", "hellaswag", "gsm8k", "bbh"),
    )
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--stats-bundle", default=CONFIG["stats_bundle"])
    parser.add_argument("--state-cache-dir", default=CONFIG["state_cache_dir"])
    parser.add_argument("--reference-results", default=str(DEFAULT_REFERENCE))
    parser.add_argument("--checkpoint", type=int, default=10)
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument("--parallel-jobs", type=int, default=CONFIG["parallel_jobs"])
    parser.add_argument(
        "--empty-threshold-mib",
        type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"],
    )
    parser.add_argument(
        "--empty-utilization-percent",
        type=int,
        default=CONFIG["gpu_policy"]["max_utilization_percent"],
    )
    parser.add_argument("--relative-tol", type=float, default=optimizer["relative_tol"])
    parser.add_argument("--ridge", type=float, default=optimizer["ridge"])
    parser.add_argument("--scale-eps", type=float, default=optimizer["scale_eps"])
    parser.add_argument("--chunk-rows", type=int, default=optimizer["chunk_rows"])
    parser.add_argument(
        "--importance-chunk-rows",
        type=int,
        default=optimizer["importance_chunk_rows"],
    )
    parser.add_argument(
        "--loss-increase-rtol",
        type=float,
        default=optimizer["loss_increase_rtol"],
    )
    parser.set_defaults(
        initializer="sklearn",
        gpu_iters=10,
        cpu_iters=10,
        gpu_chunk_rows=64,
    )
    return parser


def _json_list(path):
    return json.loads(Path(path).read_text())


def _mmlu_dataset(subject):
    split_rows = {}
    for split in ("dev", "val", "test"):
        path = MMLU_ROOT / split / f"{subject}_{split}.csv"
        if not path.exists():
            continue
        rows = []
        with path.open(newline="", encoding="utf-8") as handle:
            for row in csv.reader(handle):
                if len(row) < 6:
                    raise ValueError(f"Malformed MMLU row in {path}: {row}")
                rows.append(
                    {
                        "question": row[0],
                        "choices": row[1:5],
                        "answer": "ABCD".index(row[5].strip()),
                    }
                )
        split_rows[split] = Dataset.from_list(rows)
    if "dev" not in split_rows or "test" not in split_rows:
        raise FileNotFoundError(f"Missing local MMLU dev/test split for {subject}")
    return DatasetDict(split_rows)


def _gsm8k_dataset():
    rows = []
    for item in _json_list(GSM8K_PATH):
        question = item.get("instruction") or item.get("question")
        rationale = str(item.get("output", "")).strip()
        answer = str(item.get("answer", "")).strip()
        rows.append(
            {
                "question": question,
                "answer": f"{rationale}\n#### {answer}",
            }
        )
    full = Dataset.from_list(rows)
    return DatasetDict({"train": full.select(range(5)), "test": full})


def _local_load_dataset(path=None, name=None, **kwargs):
    if path == "openai_humaneval":
        return DatasetDict({"test": Dataset.from_list(_json_list(HUMANEVAL_PATH))})
    if path == "mbpp":
        rows = []
        for item in _json_list(MBPP_PATH):
            record = dict(item)
            record["text"] = record.get("text") or record.get("prompt")
            rows.append(record)
        return DatasetDict({"test": Dataset.from_list(rows)})
    if path == "hails/mmlu_no_train":
        return _mmlu_dataset(name)
    if path == "gsm8k":
        return _gsm8k_dataset()
    if path == "lukaemon/bbh":
        parquet = BBH_ROOT / str(name) / "test-00000-of-00001.parquet"
        if not parquet.exists():
            raise FileNotFoundError(parquet)
        return DatasetDict({"test": Dataset.from_parquet(str(parquet))})
    return _ORIGINAL_LOAD_DATASET(path=path, name=name, **kwargs)


_ORIGINAL_LOAD_DATASET = datasets.load_dataset


@contextlib.contextmanager
def local_datasets():
    old_datasets = datasets.load_dataset
    old_bigcode = bigcode_base.load_dataset
    datasets.load_dataset = _local_load_dataset
    bigcode_base.load_dataset = _local_load_dataset
    try:
        yield
    finally:
        datasets.load_dataset = old_datasets
        bigcode_base.load_dataset = old_bigcode


class LocalMBPP(BigCodeMBPP):
    def get_dataset(self):
        return self.dataset["test"]


def _result_skeleton(args, load_metadata):
    return {
        "method": "method30_postawq_22a_refine10",
        "description": (
            "method27 lambda=0.3 AWQ + post-AWQ exact 1/128 outlier + "
            "Fisher Any4 + 10 alternating-refinement iterations"
        ),
        "suite": args.suite,
        "status": "running",
        "model_path": args.model_path,
        "checkpoint": args.checkpoint,
        "physical_gpu": str(args.physical_gpu),
        "limit": args.limit,
        "tasks": list(args.tasks),
        "load_metadata": load_metadata,
        "dataset_provenance": {
            "codeparrot": {"path": str(CODEPARROT_PATH), "sha256": file_sha256(CODEPARROT_PATH)},
            "humaneval": {"path": str(HUMANEVAL_PATH), "sha256": file_sha256(HUMANEVAL_PATH)},
            "mbpp": {"path": str(MBPP_PATH), "sha256": file_sha256(MBPP_PATH)},
            "mmlu": {"path": str(MMLU_ROOT)},
            "hellaswag": {"source": "Hugging Face local Arrow cache"},
            "gsm8k": {"path": str(GSM8K_PATH), "sha256": file_sha256(GSM8K_PATH)},
            "bbh": {"path": str(BBH_ROOT)},
        },
        "metrics": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _load_or_create_result(args, load_metadata):
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "results.json"
    if result_path.exists():
        if not args.resume:
            raise FileExistsError(
                f"Result already exists; pass --resume to reuse it: {result_path}"
            )
        result = json.loads(result_path.read_text())
        expected = {
            "suite": args.suite,
            "checkpoint": args.checkpoint,
            "model_path": args.model_path,
            "limit": args.limit,
            "tasks": list(args.tasks),
        }
        observed = {key: result.get(key) for key in expected}
        if observed != expected:
            raise RuntimeError(f"Resume mismatch: {observed} != {expected}")
        return result_path, result
    result = _result_skeleton(args, load_metadata)
    atomic_write_json(result_path, result)
    return result_path, result


def _codeparrot_ppl(model, tokenizer, limit):
    old_loader = any4_data.load_dataset

    def local_codeparrot_loader(dataset, config=None, split=None, streaming=False):
        return _ORIGINAL_LOAD_DATASET(
            "json",
            data_files=str(CODEPARROT_PATH),
            split="train",
            streaming=True,
        )

    any4_data.load_dataset = local_codeparrot_loader
    try:
        return any4_data.eval_perplexity(
            model=model,
            tokenizer=tokenizer,
            dataset="local-codeparrot",
            split="validation",
            field="content",
            batch_size=1,
            num_batches=limit if limit is not None else 256,
            max_seq_len=2048,
        )
    finally:
        any4_data.load_dataset = old_loader


def _run_code(args, result_path, result, model, tokenizer):
    if "codeparrot" not in result["metrics"]:
        result["status"] = "evaluating_codeparrot"
        atomic_write_json(result_path, result)
        started = time.perf_counter()
        ppl = _codeparrot_ppl(model, tokenizer, args.limit)
        result["metrics"]["codeparrot"] = {
            "ppl": float(ppl),
            "seqlen": 2048,
            "eval_batches": args.limit if args.limit is not None else 256,
            "batch_size": 1,
            "evaluation_seconds": time.perf_counter() - started,
        }
        atomic_write_json(result_path, result)
        print(f"CodeParrot PPL={ppl:.10f}", flush=True)

    from bigcode_eval.tasks.custom_metrics.code_eval import compute_code_eval
    from run_local_mbpp_gsm8k import eval_mbpp, generate_texts

    if "humaneval" not in result["metrics"]:
        result["status"] = "evaluating_humaneval"
        atomic_write_json(result_path, result)
        started = time.perf_counter()
        data = _json_list(HUMANEVAL_PATH)
        if args.limit is not None:
            data = data[: args.limit]
        prompts = [item["prompt"].strip() for item in data]
        generations = generate_texts(
            model,
            tokenizer,
            prompts,
            max_new_tokens=512,
            batch_size=8,
        )
        stop_words = ["\nclass", "\ndef", "\n#", "\n@", "\nprint", "\nif", "\n```", "<file_sep>"]
        predictions = []
        references = []
        records = []
        for item, prompt, generation in zip(data, prompts, generations):
            end = min(
                [generation.find(stop) for stop in stop_words if stop in generation]
                or [len(generation)]
            )
            code = prompt + generation[:end]
            reference = "\n" + item["test"] + "\n" + f"check({item['entry_point']})"
            predictions.append([code])
            references.append(reference)
            records.append(
                {
                    "task_id": item["task_id"],
                    "prompt": prompt,
                    "generation": generation,
                    "code": code,
                }
            )
        os.environ["HF_ALLOW_CODE_EVAL"] = "1"
        metric, details = compute_code_eval(
            references=references,
            predictions=predictions,
            k=[1],
            num_workers=16,
            timeout=3.0,
        )
        atomic_write_json(Path(args.output_dir) / "humaneval_generations.json", records)
        result["metrics"]["humaneval"] = {
            "result": _json_safe(metric),
            "details": _json_safe(details),
            "evaluation_seconds": time.perf_counter() - started,
            "protocol": "bigcode_prompt_explicit_eos",
            "max_new_tokens": 512,
            "batch_size": 8,
        }
        atomic_write_json(result_path, result)
        print(f"humaneval: {metric}", flush=True)

    if "mbpp" not in result["metrics"]:
        result["status"] = "evaluating_mbpp"
        atomic_write_json(result_path, result)
        started = time.perf_counter()
        data = _json_list(MBPP_PATH)
        if args.limit is not None:
            data = data[: args.limit]
        metric = eval_mbpp(
            model,
            tokenizer,
            data,
            batch_size=8,
            max_new_tokens=512,
            timeout_sec=3,
            prompt_style="bigcode",
        )
        atomic_write_json(
            Path(args.output_dir) / "mbpp_generations.json",
            metric.pop("records"),
        )
        result["metrics"]["mbpp"] = {
            "result": metric,
            "evaluation_seconds": time.perf_counter() - started,
            "protocol": "bigcode_prompt_explicit_eos_controlled_execution",
            "max_new_tokens": 512,
            "batch_size": 8,
        }
        atomic_write_json(result_path, result)
        print(f"mbpp: {metric}", flush=True)


def _json_safe(value):
    return json.loads(json.dumps(value, default=str))


def _run_harness(args, result_path, result, model, tokenizer):
    lm = HFLM(
        pretrained=model,
        tokenizer=tokenizer,
        device="cuda:0",
        batch_size=args.harness_batch_size,
        max_batch_size=args.harness_batch_size,
        max_length=2048,
        parallelize=False,
    )
    with local_datasets():
        task_manager = lm_eval.tasks.TaskManager()
        for task in args.tasks:
            if task in result["metrics"]:
                continue
            result["status"] = f"evaluating_{task}"
            atomic_write_json(result_path, result)
            started = time.perf_counter()
            output = lm_eval.simple_evaluate(
                model=lm,
                tasks=[task],
                limit=args.limit,
                num_fewshot=None,
                task_manager=task_manager,
                log_samples=False,
            )
            result["metrics"][task] = {
                "results": _json_safe(output.get("results", {})),
                "groups": _json_safe(output.get("groups", {})),
                "group_subtasks": _json_safe(output.get("group_subtasks", {})),
                "configs": _json_safe(output.get("configs", {})),
                "versions": _json_safe(output.get("versions", {})),
                "n-shot": _json_safe(output.get("n-shot", {})),
                "evaluation_seconds": time.perf_counter() - started,
                "protocol": "lm_eval_0.4.5",
            }
            atomic_write_json(result_path, result)
            print(lm_eval.utils.make_table(output), flush=True)


def main():
    args = build_parser().parse_args()
    model, tokenizer, load_metadata = _load_cached_model(args)
    result_path, result = _load_or_create_result(args, load_metadata)
    if args.suite == "code":
        _run_code(args, result_path, result, model, tokenizer)
    else:
        _run_harness(args, result_path, result, model, tokenizer)
    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_json(result_path, result)
    print(json.dumps(result["metrics"], indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
