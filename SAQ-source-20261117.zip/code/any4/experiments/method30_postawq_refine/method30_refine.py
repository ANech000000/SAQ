import math
import sys
import time
from pathlib import Path

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
OUTLIER_DIR = ROOT / "experiments" / "method30_outlier"
for path in (ROOT, OUTLIER_DIR, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from hybrid_init import initialize_gpu_cpu  # noqa: E402
from method30_outlier_quant import (  # noqa: E402
    _assign_nearest,
    _reconstruct,
    _sort_lut,
    _update_affine,
    _update_lut,
    method30_reconstruct_tensor as baseline_reconstruct_tensor,
    select_group_outliers,
    transform_fisher,
    weighted_loss,
)
from state_cache import clone_state, outlier_mask_from_positions  # noqa: E402


ALGORITHM_VERSION = "method30_postawq_refine_v1"
INITIALIZERS = ("sklearn", "gpu_cpu")


def _loss_denominator(weight, fisher, outlier_mask, chunk_rows):
    denominator = torch.zeros((), device=weight.device, dtype=torch.float32)
    has_zeros = bool((weight == 0).any().item())
    for start in range(0, weight.shape[0], int(chunk_rows)):
        stop = min(start + int(chunk_rows), weight.shape[0])
        importance = fisher.reshape(1, -1).expand(stop - start, -1)
        if has_zeros:
            importance = importance * (weight[start:stop] != 0).float()
        importance = importance * (~outlier_mask[start:stop]).float()
        denominator.add_(importance.sum())
    return float(denominator.item())


def _validate_inputs(weight, channel_scale, group_size):
    if weight.dim() != 2 or weight.shape[1] % int(group_size):
        raise ValueError(
            f"Weight shape {tuple(weight.shape)} must be 2D and divisible "
            f"by group_size={group_size}."
        )
    scale = torch.as_tensor(
        channel_scale, device=weight.device, dtype=torch.float32
    ).reshape(-1)
    if (
        scale.numel() != weight.shape[1]
        or not torch.isfinite(scale).all()
        or (scale <= 0).any()
    ):
        raise ValueError("Channel scale is invalid for this Linear.")
    if not torch.isfinite(weight).all():
        raise ValueError("Weight contains non-finite values.")
    return scale


@torch.no_grad()
def initialize_state(
    weight,
    channel_scale,
    fisher,
    group_size=128,
    initializer="sklearn",
    parallel_jobs=16,
    relative_tol=1e-6,
    ridge=1e-6,
    scale_eps=1e-6,
    chunk_rows=128,
    importance_chunk_rows=512,
    loss_increase_rtol=1e-7,
    gpu_iters=10,
    cpu_iters=10,
    gpu_chunk_rows=64,
):
    if initializer not in INITIALIZERS:
        raise ValueError(f"initializer must be one of {INITIALIZERS}.")
    work = weight.detach().float()
    scale = _validate_inputs(work, channel_scale, group_size)
    rows, cols = work.shape
    started = time.perf_counter()

    if initializer == "sklearn":
        _, diagnostics, base_state = baseline_reconstruct_tensor(
            work,
            scale,
            fisher,
            group_size=group_size,
            max_iter=0,
            relative_tol=relative_tol,
            ridge=ridge,
            scale_eps=scale_eps,
            chunk_rows=chunk_rows,
            loss_increase_rtol=loss_increase_rtol,
            parallelize=parallel_jobs > 1,
            parallel_jobs=parallel_jobs,
            return_state=True,
            importance_mode="broadcast",
            importance_chunk_rows=importance_chunk_rows,
            initializer="sklearn",
            outlier_selection_domain="post_awq",
        )
        assignment = base_state["assignment"]
        lut = base_state["lut"]
        scales = base_state["scales"]
        offsets = base_state["offsets"]
        scaled_fisher = base_state["scaled_fisher"]
        positions = base_state["outlier_positions"]
        exact_values = base_state["exact_outlier_values"]
        init_diagnostics = diagnostics["initializer_diagnostics"]
        init_seconds = diagnostics["initialization_seconds"]
        initial_loss = diagnostics["initial_weighted_loss"]
    else:
        scaled_weight = work * scale.reshape(1, -1)
        outlier_mask, positions, _ = select_group_outliers(
            scaled_weight, group_size
        )
        exact_values = work.reshape(
            rows, cols // group_size, group_size
        ).gather(2, positions.unsqueeze(2)).squeeze(2)
        scaled_fisher = transform_fisher(fisher, scale, normalize=True)
        init_started = time.perf_counter()
        assignment, lut, scales, offsets, init_diagnostics = initialize_gpu_cpu(
            scaled_weight,
            scaled_fisher,
            outlier_mask,
            positions,
            group_size,
            parallel_jobs,
            gpu_iters,
            cpu_iters,
            gpu_chunk_rows,
        )
        init_seconds = time.perf_counter() - init_started
        lut, assignment = _sort_lut(lut, assignment)
        initial_loss = weighted_loss(
            scaled_weight,
            scaled_fisher,
            lut,
            assignment,
            scales,
            offsets,
            group_size,
            chunk_rows=importance_chunk_rows,
            mask_zero_weights=bool((scaled_weight == 0).any().item()),
            excluded_mask=outlier_mask,
        )

    positions = positions.long()
    outlier_mask = outlier_mask_from_positions(positions, cols, group_size)
    assignment = assignment.clone()
    assignment[outlier_mask] = 0
    scaled_weight = work * scale.reshape(1, -1)
    denominator = _loss_denominator(
        scaled_weight, scaled_fisher, outlier_mask, importance_chunk_rows
    )
    return {
        "algorithm_version": ALGORITHM_VERSION,
        "weight_shape": [int(rows), int(cols)],
        "group_size": int(group_size),
        "assignment": assignment.long(),
        "lut": lut.float(),
        "scales": scales.float(),
        "offsets": offsets.float(),
        "outlier_positions": positions,
        "exact_outlier_values": exact_values.float(),
        "channel_scale": scale.float(),
        "scaled_fisher": scaled_fisher.float(),
        "initializer": initializer,
        "initializer_diagnostics": init_diagnostics,
        "iterations": 0,
        "target_iteration": 0,
        "losses": [float(initial_loss)],
        "loss_denominator": float(denominator),
        "converged": False,
        "rollback": False,
        "rollback_reason": None,
        "accepted_affine_updates": 0,
        "initialization_seconds": float(init_seconds),
        "optimization_seconds": 0.0,
        "total_seconds": float(time.perf_counter() - started),
        "optimizer": {
            "relative_tol": float(relative_tol),
            "ridge": float(ridge),
            "scale_eps": float(scale_eps),
            "chunk_rows": int(chunk_rows),
            "importance_chunk_rows": int(importance_chunk_rows),
            "loss_increase_rtol": float(loss_increase_rtol),
        },
    }


@torch.no_grad()
def refine_state(weight, state, target_iteration):
    if int(target_iteration) < int(state["iterations"]):
        raise ValueError("Cannot refine a state backwards.")
    work = weight.detach().float()
    current = clone_state(state, device=work.device)
    rows, cols = work.shape
    if [rows, cols] != list(current["weight_shape"]):
        raise ValueError("State shape does not match the source weight.")
    group_size = int(current["group_size"])
    optimizer = current["optimizer"]
    scaled_weight = work * current["channel_scale"].reshape(1, -1)
    importance = current["scaled_fisher"]
    outlier_mask = outlier_mask_from_positions(
        current["outlier_positions"], cols, group_size
    )
    mask_zeros = bool((scaled_weight == 0).any().item())
    started = time.perf_counter()

    while (
        int(current["iterations"]) < int(target_iteration)
        and not current["converged"]
        and not current["rollback"]
    ):
        old_loss = float(current["losses"][-1])
        assignment = _assign_nearest(
            scaled_weight,
            current["lut"],
            current["scales"],
            current["offsets"],
            group_size,
            optimizer["chunk_rows"],
        )
        lut = _update_lut(
            scaled_weight,
            importance,
            current["lut"],
            assignment,
            current["scales"],
            current["offsets"],
            group_size,
            chunk_rows=optimizer["importance_chunk_rows"],
            mask_zero_weights=mask_zeros,
            excluded_mask=outlier_mask,
        )
        lut, assignment = _sort_lut(lut, assignment)
        scales, offsets, accepted_affine = _update_affine(
            scaled_weight,
            importance,
            lut,
            assignment,
            current["scales"],
            current["offsets"],
            group_size,
            optimizer["ridge"],
            optimizer["scale_eps"],
            chunk_rows=optimizer["importance_chunk_rows"],
            mask_zero_weights=mask_zeros,
            excluded_mask=outlier_mask,
        )
        assignment = _assign_nearest(
            scaled_weight,
            lut,
            scales,
            offsets,
            group_size,
            optimizer["chunk_rows"],
        )
        new_loss = weighted_loss(
            scaled_weight,
            importance,
            lut,
            assignment,
            scales,
            offsets,
            group_size,
            chunk_rows=optimizer["importance_chunk_rows"],
            mask_zero_weights=mask_zeros,
            excluded_mask=outlier_mask,
        )
        if not math.isfinite(new_loss):
            current["rollback"] = True
            current["rollback_reason"] = "non_finite_loss"
            break
        if new_loss > old_loss:
            allowed = max(
                1e-12, abs(old_loss) * optimizer["loss_increase_rtol"]
            )
            current["rollback"] = True
            current["rollback_reason"] = (
                "loss_increase"
                if new_loss - old_loss > allowed
                else "numerical_loss_increase"
            )
            break

        relative = (old_loss - new_loss) / max(abs(old_loss), 1e-12)
        assignment = assignment.clone()
        assignment[outlier_mask] = 0
        current["assignment"] = assignment
        current["lut"] = lut
        current["scales"] = scales
        current["offsets"] = offsets
        current["iterations"] = int(current["iterations"]) + 1
        current["accepted_affine_updates"] = (
            int(current["accepted_affine_updates"]) + int(accepted_affine)
        )
        current["losses"].append(float(new_loss))
        if relative < optimizer["relative_tol"]:
            current["converged"] = True

    current["target_iteration"] = int(target_iteration)
    current["optimization_seconds"] = float(
        current["optimization_seconds"] + time.perf_counter() - started
    )
    current["total_seconds"] = float(
        current["initialization_seconds"] + current["optimization_seconds"]
    )
    if not torch.isfinite(current["lut"]).all():
        raise ValueError("Refined LUT contains non-finite values.")
    if not torch.isfinite(current["scales"]).all() or (current["scales"] <= 0).any():
        raise ValueError("Refined affine scales are invalid.")
    losses = current["losses"]
    if any(losses[i + 1] > losses[i] for i in range(len(losses) - 1)):
        raise AssertionError("Refinement loss is not monotonic.")
    return current


@torch.no_grad()
def reconstruct_from_state(weight, state):
    original_dtype = weight.dtype
    work = weight.detach().float()
    current = clone_state(state, device=work.device)
    rows, cols = work.shape
    group_size = int(current["group_size"])
    reconstructed = _reconstruct(
        work.shape,
        current["lut"],
        current["assignment"],
        current["scales"],
        current["offsets"],
        group_size,
    ) / current["channel_scale"].reshape(1, -1)
    grouped = reconstructed.reshape(rows, cols // group_size, group_size)
    grouped.scatter_(
        2,
        current["outlier_positions"].long().unsqueeze(2),
        current["exact_outlier_values"].float().unsqueeze(2),
    )
    if not torch.isfinite(reconstructed).all():
        raise ValueError("Reconstructed weight contains non-finite values.")
    return reconstructed.to(dtype=original_dtype)


def state_diagnostics(state):
    losses = [float(value) for value in state["losses"]]
    return {
        "initializer": state["initializer"],
        "initializer_diagnostics": state["initializer_diagnostics"],
        "iterations": int(state["iterations"]),
        "target_iteration": int(state["target_iteration"]),
        "initial_weighted_loss": losses[0],
        "final_weighted_loss": losses[-1],
        "relative_loss_improvement": float(
            (losses[0] - losses[-1]) / max(abs(losses[0]), 1e-12)
        ),
        "weighted_loss_numerator": float(
            losses[-1] * state["loss_denominator"]
        ),
        "weighted_loss_denominator": float(state["loss_denominator"]),
        "losses": losses,
        "loss_monotonic": all(
            losses[i + 1] <= losses[i] for i in range(len(losses) - 1)
        ),
        "converged": bool(state["converged"]),
        "rollback": bool(state["rollback"]),
        "rollback_reason": state["rollback_reason"],
        "accepted_affine_updates": int(state["accepted_affine_updates"]),
        "initialization_seconds": float(state["initialization_seconds"]),
        "optimization_seconds": float(state["optimization_seconds"]),
        "total_seconds": float(state["total_seconds"]),
    }
