import argparse
import gc
import json
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")

import numpy as np
import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from experiment_runtime import load_context, setup_hardware
from method30_refine import initialize_state, refine_state, state_diagnostics
from state_cache import atomic_write_json, tensor_sha256


CONFIG = json.loads((EXP_DIR / "config.json").read_text())
TARGET_LAYERS = tuple(
    f"model.layers.{block}.{local}"
    for block in (0, 7, 15)
    for local in ("self_attn.q_proj", "mlp.gate_proj")
)


def run_layer(source, stats, args, initializer, profile=None):
    options = {}
    if initializer == "gpu_cpu":
        options = {
            "gpu_iters": int(profile["gpu_iters"]),
            "cpu_iters": int(profile["cpu_iters"]),
            "gpu_chunk_rows": int(args.gpu_chunk_rows),
        }
    started = time.perf_counter()
    state = initialize_state(
        source,
        stats["channel_scale"],
        stats["fisher"],
        group_size=args.group_size,
        initializer=initializer,
        parallel_jobs=args.parallel_jobs,
        relative_tol=args.relative_tol,
        ridge=args.ridge,
        scale_eps=args.scale_eps,
        chunk_rows=args.chunk_rows,
        importance_chunk_rows=args.importance_chunk_rows,
        loss_increase_rtol=args.loss_increase_rtol,
        **options,
    )
    state = refine_state(source, state, args.refine_iters)
    torch.cuda.synchronize()
    diagnostics = state_diagnostics(state)
    diagnostics["wall_seconds"] = float(time.perf_counter() - started)
    return diagnostics


def execute(args):
    gpu, affinity = setup_hardware(args)
    bundle, model, tokenizer, linears = load_context(args)
    linear_map = {name: (module, stats) for name, module, stats in linears}
    missing = sorted(set(TARGET_LAYERS) - set(linear_map))
    if missing:
        raise ValueError(f"Missing benchmark layers: {missing}")
    profiles = CONFIG["hybrid_profiles"]
    result = {
        "status": "benchmarking",
        "physical_gpu": str(args.physical_gpu),
        "gpu_before": gpu,
        "cpu_affinity": affinity,
        "parallel_jobs": args.parallel_jobs,
        "refine_iters": args.refine_iters,
        "target_layers": list(TARGET_LAYERS),
        "variants": {"sklearn": {"layers": {}}},
        "acceptance": CONFIG["hybrid_acceptance"],
    }
    for name in profiles:
        result["variants"][name] = {"profile": profiles[name], "layers": {}}
    atomic_write_json(args.output, result)

    for layer_index, name in enumerate(TARGET_LAYERS, 1):
        module, stats = linear_map[name]
        source_hash = tensor_sha256(module.weight.detach().cpu())
        source = module.weight.detach().to(device="cuda:0")
        result["variants"]["sklearn"]["layers"][name] = run_layer(
            source, stats, args, "sklearn"
        )
        for profile_name, profile in profiles.items():
            result["variants"][profile_name]["layers"][name] = run_layer(
                source, stats, args, "gpu_cpu", profile
            )
        if tensor_sha256(module.weight.detach().cpu()) != source_hash:
            raise AssertionError(f"Benchmark modified source weight {name}.")
        atomic_write_json(args.output, result)
        print(f"[{layer_index}/{len(TARGET_LAYERS)}] benchmarked {name}", flush=True)
        del source
        torch.cuda.empty_cache()
        gc.collect()

    baseline_layers = result["variants"]["sklearn"]["layers"]
    baseline_init = sum(
        entry["initialization_seconds"] for entry in baseline_layers.values()
    )
    baseline_numerator = sum(
        entry["weighted_loss_numerator"] for entry in baseline_layers.values()
    )
    result["variants"]["sklearn"]["summary"] = {
        "initialization_seconds": float(baseline_init),
        "weighted_loss_numerator": float(baseline_numerator),
    }
    passing = []
    for profile_name in profiles:
        layers = result["variants"][profile_name]["layers"]
        init_seconds = sum(
            entry["initialization_seconds"] for entry in layers.values()
        )
        numerator = sum(
            entry["weighted_loss_numerator"] for entry in layers.values()
        )
        ratios = np.asarray([
            layers[name]["final_weighted_loss"]
            / max(baseline_layers[name]["final_weighted_loss"], 1e-20)
            for name in TARGET_LAYERS
        ])
        summary = {
            "initialization_seconds": float(init_seconds),
            "initialization_speedup": float(
                baseline_init / max(init_seconds, 1e-12)
            ),
            "aggregate_loss_ratio": float(
                numerator / max(baseline_numerator, 1e-20)
            ),
            "p95_layer_loss_ratio": float(np.quantile(ratios, 0.95)),
            "maximum_layer_loss_ratio": float(ratios.max()),
        }
        acceptance = CONFIG["hybrid_acceptance"]
        summary["proxy_pass"] = bool(
            summary["aggregate_loss_ratio"] <= acceptance["aggregate_loss_ratio"]
            and summary["p95_layer_loss_ratio"] <= acceptance["p95_layer_loss_ratio"]
            and summary["initialization_speedup"]
            >= acceptance["minimum_initialization_speedup"]
        )
        result["variants"][profile_name]["summary"] = summary
        if summary["proxy_pass"]:
            passing.append(profile_name)

    if passing:
        selected = max(
            passing,
            key=lambda name: result["variants"][name]["summary"][
                "initialization_speedup"
            ],
        )
        reason = "fastest_profile_passing_proxy_thresholds"
    else:
        selected = min(
            profiles,
            key=lambda name: result["variants"][name]["summary"][
                "aggregate_loss_ratio"
            ],
        )
        reason = "no_profile_passed_selected_lowest_loss_for_diagnostic_ppl"
    result["selection"] = {
        "profile": selected,
        "profile_parameters": profiles[selected],
        "reason": reason,
        "proxy_pass": bool(
            result["variants"][selected]["summary"]["proxy_pass"]
        ),
    }
    result["status"] = "complete"
    atomic_write_json(args.output, result)
    del model, tokenizer, bundle
    torch.cuda.empty_cache()
    gc.collect()
    return result


def build_parser():
    optimizer = CONFIG["optimizer"]
    parser = argparse.ArgumentParser(description="GPU initializer + CPU polish benchmark")
    parser.add_argument("--model-path", default=CONFIG["model_path"])
    parser.add_argument("--stats-bundle", default=CONFIG["stats_bundle"])
    parser.add_argument("--group-size", type=int, default=CONFIG["group_size"])
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--parallel-jobs", type=int, default=CONFIG["parallel_jobs"])
    parser.add_argument("--refine-iters", type=int, default=10)
    parser.add_argument("--gpu-chunk-rows", type=int, default=64)
    parser.add_argument("--relative-tol", type=float, default=optimizer["relative_tol"])
    parser.add_argument("--ridge", type=float, default=optimizer["ridge"])
    parser.add_argument("--scale-eps", type=float, default=optimizer["scale_eps"])
    parser.add_argument("--chunk-rows", type=int, default=optimizer["chunk_rows"])
    parser.add_argument(
        "--importance-chunk-rows", type=int,
        default=optimizer["importance_chunk_rows"]
    )
    parser.add_argument(
        "--loss-increase-rtol", type=float,
        default=optimizer["loss_increase_rtol"]
    )
    parser.add_argument(
        "--empty-threshold-mib", type=int,
        default=CONFIG["gpu_policy"]["max_empty_memory_mib"]
    )
    parser.add_argument(
        "--empty-utilization-percent", type=int,
        default=CONFIG["gpu_policy"]["max_utilization_percent"]
    )
    parser.add_argument(
        "--output",
        default=str(EXP_DIR / "runs" / "hybrid_initializer" / "benchmark.json"),
    )
    return parser


def main():
    args = build_parser().parse_args()
    result = execute(args)
    print(json.dumps(result["selection"], indent=2))


if __name__ == "__main__":
    main()
