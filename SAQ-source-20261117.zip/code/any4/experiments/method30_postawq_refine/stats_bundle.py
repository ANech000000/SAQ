import argparse
import importlib.util
import os
import sys
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
BASE_DIR = ROOT / "experiments" / "method30"
for path in (ROOT, EXP_DIR, BASE_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

_spec = importlib.util.spec_from_file_location(
    "method30_stats_base", BASE_DIR / "runner.py"
)
base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(base)

from layer_timing import load_activations  # noqa: E402
from state_cache import file_sha256, tensor_sha256  # noqa: E402


STATS_SCHEMA_VERSION = 1


def _atomic_torch_save(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def load_stats_bundle(path):
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("schema_version") != STATS_SCHEMA_VERSION:
        raise ValueError(f"Unsupported stats bundle schema: {path}")
    layers = payload.get("layers")
    if not isinstance(layers, dict) or not layers:
        raise ValueError(f"Stats bundle has no layers: {path}")
    return payload


def _source_metadata(args):
    return {
        "model_path": str(Path(args.model_path).resolve()),
        "alpha_selection_path": str(Path(args.alpha_selection_path).resolve()),
        "alpha_key": args.alpha_key,
        "alpha_selection_sha256": file_sha256(args.alpha_selection_path),
        "activation_cache": str(Path(args.activation_cache).resolve()),
        "fisher_path": str(Path(args.fisher_path).resolve()),
        "fisher_sha256": file_sha256(args.fisher_path),
        "group_size": int(args.group_size),
        "outlier_selection_domain": "post_awq",
        "outlier_rule": "max_abs_first_tie_scaled_post_awq",
    }


def build_current_bundle(args):
    expected_metadata = _source_metadata(args)
    output = Path(args.output)
    if output.exists():
        payload = load_stats_bundle(output)
        if payload.get("metadata") != expected_metadata:
            raise RuntimeError(
                f"Existing stats bundle metadata does not match: {output}"
            )
        return payload, False

    alphas, _ = base.load_alpha_selection(
        args.alpha_selection_path, args.alpha_key
    )
    fisher, _ = base.load_fisher(args.fisher_path)
    model, tokenizer = base.load_model_and_tokenizer(args.model_path)
    linears, _, _ = base.validate_sources(
        model, alphas, fisher, args.group_size
    )
    layers = {}
    active_block = None
    activations = None
    for index, (name, module) in enumerate(linears, 1):
        block, local_name = base.layer_and_local_name(name)
        if block != active_block:
            del activations
            activations = load_activations(args.activation_cache, block)
            active_block = block
        channel_scale, alpha = base.build_channel_scale(
            name, module, alphas, activations
        )
        source = module.weight.detach().cpu().contiguous()
        layer_fisher = fisher[name].detach().cpu().float().contiguous()
        layers[name] = {
            "weight_shape": list(source.shape),
            "weight_dtype": str(source.dtype),
            "weight_sha256": tensor_sha256(source),
            "channel_scale": channel_scale.detach().cpu().float().contiguous(),
            "channel_scale_sha256": tensor_sha256(channel_scale),
            "fisher": layer_fisher,
            "fisher_sha256": tensor_sha256(layer_fisher),
            "alpha": float(alpha),
            "alpha_source": (
                args.alpha_key if name in alphas else "o_proj_alpha0_fallback"
            ),
            "block": int(block),
            "local_name": local_name,
        }
        print(f"[{index}/{len(linears)}] prepared {name}", flush=True)

    payload = {
        "schema_version": STATS_SCHEMA_VERSION,
        "metadata": expected_metadata,
        "layers": layers,
    }
    _atomic_torch_save(output, payload)
    del activations, model, tokenizer
    return payload, True


def validate_bundle_model(model, bundle, group_size):
    module_map = dict(model.named_modules())
    ordered_names = [
        name for name, module in model.named_modules()
        if name in bundle["layers"] and isinstance(module, torch.nn.Linear)
    ]
    if set(ordered_names) != set(bundle["layers"]):
        missing = sorted(set(bundle["layers"]) - set(ordered_names))
        raise ValueError(f"Bundle references missing or non-Linear modules: {missing}")
    validated = []
    for name in ordered_names:
        module = module_map[name]
        stats = bundle["layers"][name]
        if list(module.weight.shape) != list(stats["weight_shape"]):
            raise ValueError(f"Weight shape mismatch for {name}.")
        if module.weight.shape[1] % int(group_size):
            raise ValueError(f"{name} is not divisible by group_size={group_size}.")
        current_hash = tensor_sha256(module.weight.detach().cpu().contiguous())
        if current_hash != stats["weight_sha256"]:
            raise ValueError(f"Source weight hash mismatch for {name}.")
        if stats["channel_scale"].numel() != module.weight.shape[1]:
            raise ValueError(f"Channel scale width mismatch for {name}.")
        if stats["fisher"].numel() != module.weight.shape[1]:
            raise ValueError(f"Fisher width mismatch for {name}.")
        if not torch.isfinite(stats["channel_scale"]).all() or (
            stats["channel_scale"] <= 0
        ).any():
            raise ValueError(f"Invalid channel scale for {name}.")
        if not torch.isfinite(stats["fisher"]).all():
            raise ValueError(f"Invalid Fisher values for {name}.")
        validated.append((name, module, stats))
    return validated


def build_parser():
    config = __import__("json").loads((EXP_DIR / "config.json").read_text())
    parser = argparse.ArgumentParser(description="Build Method30 portable stats bundle")
    parser.add_argument("--model-path", default=config["model_path"])
    parser.add_argument(
        "--alpha-selection-path", default=config["alpha_selection_path"]
    )
    parser.add_argument("--alpha-key", default=config["alpha_key"])
    parser.add_argument("--activation-cache", default=config["activation_cache"])
    parser.add_argument("--fisher-path", default=config["fisher_path"])
    parser.add_argument("--group-size", type=int, default=config["group_size"])
    parser.add_argument("--output", default=config["stats_bundle"])
    return parser


def main():
    args = build_parser().parse_args()
    payload, created = build_current_bundle(args)
    print({
        "created": created,
        "output": args.output,
        "layers": len(payload["layers"]),
    })


if __name__ == "__main__":
    main()
