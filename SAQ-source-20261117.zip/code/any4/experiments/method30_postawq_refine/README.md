# Method30 Post-AWQ Refine

This experiment keeps the accepted Post-AWQ 22A algorithm fixed and adds:

- resumable LUT/assignment/group-affine refinement;
- per-Linear final-state caches with packed 4-bit assignments;
- a GPU weighted-Lloyd initializer followed by sklearn CPU polishing;
- a model-independent per-Linear statistics bundle interface.

Existing Method30 and Method30 outlier files are read-only dependencies.

## Statistics bundle

`stats_bundle.py` converts the existing Llama-3.2-1B alpha, activation and
Fisher caches into the common bundle. A bundle contains a `layers` mapping.
Each key is an exact `model.named_modules()` Linear name and each value has:

- `weight_shape`, `weight_dtype`, `weight_sha256`;
- `channel_scale` and `channel_scale_sha256`;
- `fisher` and `fisher_sha256`;
- `alpha` and `alpha_source`.

The runner discovers targets from this mapping and has no fixed layer count.
Another CausalLM can use the same runner after producing this schema.

## Commands

Build or validate the current statistics bundle:

```bash
/data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/stats_bundle.py
```

Synthetic test:

```bash
/data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/smoke.py
```

Real-Linear test, with exactly one empty physical GPU exposed:

```bash
CUDA_VISIBLE_DEVICES=<GPU> /data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/smoke.py \
  --real --physical-gpu <GPU> --parallel-jobs 16
```

Run the sklearn 10/20/30/50 sweep and then evaluate all checkpoints:

```bash
CUDA_VISIBLE_DEVICES=<GPU> /data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/runner.py \
  --phase quantize --physical-gpu <GPU>
CUDA_VISIBLE_DEVICES=<GPU> /data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/runner.py \
  --phase evaluate --physical-gpu <GPU>
```

Benchmark the hybrid initializer:

```bash
CUDA_VISIBLE_DEVICES=<GPU> /data/lsz/any4/venv/bin/python \
  /data/lsz/any4/experiments/method30_postawq_refine/benchmark_hybrid.py \
  --physical-gpu <GPU>
```

All GPU entrypoints reject a GPU above 256 MiB used memory or 5 percent
utilization. They bind 16 physical CPU cores from the GPU's NUMA node. No
processes are stopped and no existing experiment cache is overwritten.
