import argparse
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
for path in (ROOT, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from method30_refine import (
    initialize_state,
    reconstruct_from_state,
    refine_state,
    state_diagnostics,
)
from state_cache import (
    atomic_write_json,
    cache_file,
    clone_state,
    load_state_cache,
    pack_assignment,
    save_state_cache,
    tensor_sha256,
    unpack_assignment,
)
from method30_outlier_quant import (
    method30_reconstruct_tensor as legacy_reconstruct_tensor,
)
from stats_bundle import base, load_stats_bundle, validate_bundle_model


def synthetic_test():
    torch.manual_seed(3030)
    weight = (torch.randn(5, 384) * 0.2).half()
    weight[0, 17] = 4.0
    weight[0, 145] = -4.5
    channel_scale = torch.rand(384) + 0.25
    fisher = torch.rand(384).square() + 0.01
    original = weight.clone()
    initial = initialize_state(
        weight,
        channel_scale,
        fisher,
        group_size=128,
        initializer="sklearn",
        parallel_jobs=1,
    )
    direct = refine_state(weight, clone_state(initial), 10)
    staged = refine_state(weight, clone_state(initial), 5)
    staged = refine_state(weight, staged, 10)
    assert torch.equal(weight, original)
    assert torch.equal(direct["assignment"], staged["assignment"])
    assert torch.equal(direct["lut"], staged["lut"])
    assert torch.equal(direct["scales"], staged["scales"])
    assert torch.equal(direct["offsets"], staged["offsets"])
    assert direct["losses"] == staged["losses"]
    assert state_diagnostics(direct)["loss_monotonic"]

    hybrid = initialize_state(
        weight,
        channel_scale,
        fisher,
        group_size=128,
        initializer="gpu_cpu",
        parallel_jobs=1,
        gpu_iters=5,
        cpu_iters=5,
        gpu_chunk_rows=3,
    )
    hybrid = refine_state(weight, hybrid, 2)
    hybrid_cpu = hybrid["initializer_diagnostics"]["cpu"]
    assert hybrid_cpu["final_inertia"] <= hybrid_cpu["initial_inertia"] + 1e-8
    assert hybrid["lut"].shape == (weight.shape[0], 16)
    assert torch.isfinite(hybrid["lut"]).all()
    assert (hybrid["scales"] > 0).all()
    assert state_diagnostics(hybrid)["loss_monotonic"]

    legacy, legacy_diagnostics = legacy_reconstruct_tensor(
        weight,
        channel_scale,
        fisher,
        group_size=128,
        max_iter=10,
        relative_tol=1e-6,
        ridge=1e-6,
        scale_eps=1e-6,
        chunk_rows=128,
        loss_increase_rtol=1e-7,
        parallelize=False,
        parallel_jobs=1,
        importance_mode="broadcast",
        importance_chunk_rows=512,
        initializer="sklearn",
        outlier_selection_domain="post_awq",
    )
    assert legacy_diagnostics["loss_monotonic"]

    scaled = weight.float() * channel_scale.reshape(1, -1)
    expected = scaled.reshape(5, 3, 128).abs().argmax(dim=2)
    assert torch.equal(direct["outlier_positions"].cpu(), expected)
    reconstructed = reconstruct_from_state(weight, direct)
    grouped_source = weight.reshape(5, 3, 128)
    grouped_result = reconstructed.reshape(5, 3, 128)
    exact = grouped_result.gather(2, expected.unsqueeze(2)).squeeze(2)
    source_exact = grouped_source.gather(2, expected.unsqueeze(2)).squeeze(2)
    assert torch.equal(exact, source_exact)
    assert torch.equal(reconstructed, legacy)

    packed, count = pack_assignment(
        direct["assignment"], direct["outlier_positions"], 128
    )
    unpacked = unpack_assignment(
        packed, count, direct["weight_shape"], direct["outlier_positions"], 128
    )
    assert torch.equal(unpacked, direct["assignment"].cpu())
    assert count == 5 * 3 * 127

    metadata = {
        "algorithm": "synthetic_smoke_v1",
        "weight_sha256": tensor_sha256(weight),
        "checkpoint": 10,
    }
    path = cache_file(
        EXP_DIR / "runs" / "smoke" / "cache",
        "synthetic_v2",
        "test.linear",
        10,
    )
    payload, created = save_state_cache(path, metadata, direct)
    loaded, loaded_payload = load_state_cache(path, metadata)
    loaded_reconstructed = reconstruct_from_state(weight, loaded)
    assert torch.equal(reconstructed, loaded_reconstructed)
    assert torch.equal(direct["assignment"].cpu(), loaded["assignment"])
    mismatch_rejected = False
    try:
        load_state_cache(path, {**metadata, "checkpoint": 11})
    except RuntimeError:
        mismatch_rejected = True
    assert mismatch_rejected
    return {
        "status": "passed",
        "shape": list(weight.shape),
        "odd_compact_assignment_count": count,
        "packed_bytes": packed.numel(),
        "cache_created": created,
        "cache_path": str(path),
        "cache_state_hash": loaded_payload["state_hash"],
        "reconstruction_sha256": tensor_sha256(reconstructed),
        "final_loss": direct["losses"][-1],
        "hybrid_final_loss": hybrid["losses"][-1],
        "continuation_exact": True,
        "legacy_reconstruction_exact": True,
        "metadata_mismatch_rejected": mismatch_rejected,
    }


def real_test(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}."
        )
    bundle = load_stats_bundle(args.stats_bundle)
    model, tokenizer = base.load_model_and_tokenizer(args.model_path)
    linears = validate_bundle_model(model, bundle, args.group_size)
    target = next(
        item for item in linears
        if item[0] == "model.layers.0.self_attn.q_proj"
    )
    name, module, stats = target
    source_hash = tensor_sha256(module.weight.detach().cpu())
    weight = module.weight.detach().to(device="cuda:0")
    common = {
        "group_size": args.group_size,
        "parallel_jobs": args.parallel_jobs,
        "importance_chunk_rows": 128,
    }
    sklearn = initialize_state(
        weight,
        stats["channel_scale"],
        stats["fisher"],
        initializer="sklearn",
        **common,
    )
    sklearn = refine_state(weight, sklearn, 2)
    hybrid = initialize_state(
        weight,
        stats["channel_scale"],
        stats["fisher"],
        initializer="gpu_cpu",
        gpu_iters=10,
        cpu_iters=10,
        **common,
    )
    hybrid = refine_state(weight, hybrid, 2)
    cpu_diag = hybrid["initializer_diagnostics"]["cpu"]
    assert cpu_diag["final_inertia"] <= cpu_diag["initial_inertia"] + 1e-8
    assert state_diagnostics(sklearn)["loss_monotonic"]
    assert state_diagnostics(hybrid)["loss_monotonic"]
    assert (sklearn["scales"] > 0).all()
    assert (hybrid["scales"] > 0).all()
    assert tensor_sha256(module.weight.detach().cpu()) == source_hash
    result = {
        "status": "passed",
        "layer": name,
        "shape": list(weight.shape),
        "source_unchanged": True,
        "sklearn": state_diagnostics(sklearn),
        "hybrid": state_diagnostics(hybrid),
    }
    del weight, model, tokenizer, sklearn, hybrid
    torch.cuda.empty_cache()
    return result


def build_parser():
    config = json.loads((EXP_DIR / "config.json").read_text())
    parser = argparse.ArgumentParser(description="Method30 refine smoke tests")
    parser.add_argument("--real", action="store_true")
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--model-path", default=config["model_path"])
    parser.add_argument("--stats-bundle", default=config["stats_bundle"])
    parser.add_argument("--group-size", type=int, default=config["group_size"])
    parser.add_argument("--parallel-jobs", type=int, default=4)
    return parser


def main():
    args = build_parser().parse_args()
    result = {"synthetic": synthetic_test()}
    if args.real:
        result["real"] = real_test(args)
    result["status"] = "passed"
    output = EXP_DIR / "runs" / "smoke" / (
        "real.json" if args.real else "synthetic.json"
    )
    atomic_write_json(output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
