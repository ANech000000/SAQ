"""Run official Table-1 numeric-format baselines with the local Any4-table protocol."""

import argparse
import gc
import json
import os
import time
from pathlib import Path

os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTHONUNBUFFERED", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

import runner_any4_table as table
from calibrate import calibrate
from data_gptq import llama_eval
from quantize import quant_methods, quantize_model
from run_local_c4_ptb_ppl import load_c4_eval, load_ptb_test
from run_wiki2_ppl import eval_wiki2


VARIANTS = {
    "fp16": {
        "method": "fp16_unquantized",
        "description": "FP16 unquantized Llama-3.2-1B baseline",
    },
    "int4": {
        "method": "official_int4_4bit",
        "description": "Official INT4: 4-bit grouped integer quantization, group_size=128, lm_head skipped",
        "quant_method": "intq",
    },
    "fp4": {
        "method": "official_fp4_4bit",
        "description": "Official FP4: 4-bit floating-point quantization, group_size=128, lm_head skipped",
        "quant_method": "fp4",
    },
    "nf4": {
        "method": "official_nf4_4bit",
        "description": "Official NF4: 4-bit NormalFloat quantization, group_size=128, lm_head skipped",
        "quant_method": "nf4",
    },
    "original_any4": {
        "method": "original_any4_4bit",
        "description": (
            "Official ANY4: 4-bit per-row LUT, group_size=128, "
            "sample_weight=calibrate, scale_sample_weight=True, lm_head skipped"
        ),
        "quant_method": "anyq",
    },
}


def build_parser():
    parser = argparse.ArgumentParser(
        description="Evaluate official Table-1 numeric formats on the local ten-dataset table."
    )
    parser.add_argument("--variant", required=True, choices=tuple(VARIANTS))
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--model-path", default=table.CONFIG["model_path"])
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--tasks",
        nargs="+",
        choices=("mmlu", "hellaswag", "gsm8k", "bbh"),
        default=("mmlu", "hellaswag", "gsm8k", "bbh"),
    )
    parser.add_argument("--harness-batch-size", type=int, default=8)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--wikitext-loader-samples", type=int, default=128)
    parser.add_argument("--c4-dir", default="/data/lsz/llm_dataset/pretraining/C4")
    parser.add_argument("--ptb-dir", default="/data/lsz/llm_dataset/language_modeling/PTB")
    parser.add_argument("--c4-eval-samples", type=int, default=256)
    parser.add_argument("--seed", type=int, default=0)
    return parser


def _result_path(args):
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir / "results.json"


def _new_result(args):
    variant = VARIANTS[args.variant]
    return {
        "method": variant["method"],
        "description": variant["description"],
        "variant": args.variant,
        "suite": "all_ten_datasets",
        "status": "starting",
        "model_path": args.model_path,
        "physical_gpu": str(args.physical_gpu),
        "limit": args.limit,
        "tasks": ["wikitext2", "c4", "ptb", "codeparrot", "humaneval", "mbpp", *args.tasks],
        "protocol": {
            "wikitext2": "run_wiki2_ppl: 128 loader samples, seqlen=2048",
            "c4": "local C4 validation: 256 samples, seed=0, seqlen=2048",
            "ptb": "local PTB test, seqlen=2048",
            "code_and_harness": "same local evaluator paths and fixed batch settings as method30_postawq_22a_refine10",
        },
        "dataset_provenance": {
            "codeparrot": {"path": str(table.CODEPARROT_PATH), "sha256": table.file_sha256(table.CODEPARROT_PATH)},
            "humaneval": {"path": str(table.HUMANEVAL_PATH), "sha256": table.file_sha256(table.HUMANEVAL_PATH)},
            "mbpp": {"path": str(table.MBPP_PATH), "sha256": table.file_sha256(table.MBPP_PATH)},
            "mmlu": {"path": str(table.MMLU_ROOT)},
            "hellaswag": {"source": "Hugging Face local Arrow cache"},
            "gsm8k": {"path": str(table.GSM8K_PATH), "sha256": table.file_sha256(table.GSM8K_PATH)},
            "bbh": {"path": str(table.BBH_ROOT)},
            "c4": {"path": str(Path(args.c4_dir))},
            "ptb": {"path": str(Path(args.ptb_dir) / "test.jsonl")},
        },
        "metrics": {},
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _load_or_create_result(args):
    path = _result_path(args)
    if path.exists():
        if not args.resume:
            raise FileExistsError(f"Result exists; pass --resume to continue: {path}")
        result = json.loads(path.read_text())
        expected = {
            "variant": args.variant,
            "model_path": args.model_path,
            "limit": args.limit,
            "tasks": ["wikitext2", "c4", "ptb", "codeparrot", "humaneval", "mbpp", *args.tasks],
        }
        observed = {key: result.get(key) for key in expected}
        if observed != expected:
            raise RuntimeError(f"Resume mismatch: {observed} != {expected}")
        return path, result
    result = _new_result(args)
    table.atomic_write_json(path, result)
    return path, result


def _load_model(args):
    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path, local_files_only=True, trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
    ).to("cuda")
    model.eval()
    quantization_seconds = 0.0
    quantization_args = None
    if args.variant != "fp16":
        quantization_args = {
            "n_bit": 4,
            "group_size": 128,
            "skip_modules": "lm_head",
        }
        if args.variant == "original_any4":
            quantization_args.update(
                sample_weight=calibrate,
                scale_sample_weight=True,
            )
        q_started = time.perf_counter()
        model = quantize_model(
            model,
            layer_from=torch.nn.Linear,
            layer_to=quant_methods[VARIANTS[args.variant]["quant_method"]],
            tokenizer=tokenizer,
            **quantization_args,
        )
        torch.cuda.synchronize()
        quantization_seconds = time.perf_counter() - q_started
    model.eval()
    return model, tokenizer, {
        "variant": args.variant,
        "dtype": "float16",
        "quantization_args": (
            None
            if quantization_args is None
            else {key: str(value) for key, value in quantization_args.items() if key != "sample_weight"}
        ),
        "load_and_apply_seconds": time.perf_counter() - started,
        "quantization_seconds": quantization_seconds,
    }


def _record_ppl(result, key, ppl, started, **metadata):
    result["metrics"][key] = {
        "ppl": float(ppl),
        **metadata,
        "evaluation_seconds": time.perf_counter() - started,
    }


def _run_ppl(args, result_path, result, model, tokenizer):
    if "wikitext2" not in result["metrics"]:
        result["status"] = "evaluating_wikitext2"
        table.atomic_write_json(result_path, result)
        started = time.perf_counter()
        ppl = eval_wiki2(model, tokenizer, args.wikitext_loader_samples, args.seqlen)
        _record_ppl(
            result, "wikitext2", ppl, started,
            seqlen=args.seqlen, loader_samples=args.wikitext_loader_samples,
        )
        table.atomic_write_json(result_path, result)
        print(f"WikiText-2 PPL={ppl:.10f}", flush=True)

    if "c4" not in result["metrics"]:
        result["status"] = "evaluating_c4"
        table.atomic_write_json(result_path, result)
        started = time.perf_counter()
        testenc = load_c4_eval(
            args.c4_dir, tokenizer, args.seqlen, args.c4_eval_samples, args.seed
        )
        ppl = llama_eval(model, testenc, "cuda", seqlen=args.seqlen)
        _record_ppl(
            result, "c4", ppl, started,
            seqlen=args.seqlen, eval_samples=args.c4_eval_samples, seed=args.seed,
            eval_tokens=int(testenc.input_ids.numel()),
        )
        del testenc
        table.atomic_write_json(result_path, result)
        print(f"C4 PPL={ppl:.10f}", flush=True)

    if "ptb" not in result["metrics"]:
        result["status"] = "evaluating_ptb"
        table.atomic_write_json(result_path, result)
        started = time.perf_counter()
        testenc = load_ptb_test(args.ptb_dir, tokenizer, args.seqlen)
        ppl = llama_eval(model, testenc, "cuda", seqlen=args.seqlen)
        _record_ppl(
            result, "ptb", ppl, started,
            seqlen=args.seqlen,
            eval_samples=int(testenc.input_ids.numel() // args.seqlen),
            eval_tokens=int(testenc.input_ids.numel()),
        )
        del testenc
        table.atomic_write_json(result_path, result)
        print(f"PTB PPL={ppl:.10f}", flush=True)


def main():
    args = build_parser().parse_args()
    result_path, result = _load_or_create_result(args)
    model, tokenizer, metadata = _load_model(args)
    result["load_metadata"] = metadata
    table.atomic_write_json(result_path, result)
    _run_ppl(args, result_path, result, model, tokenizer)
    table._run_code(args, result_path, result, model, tokenizer)
    table._run_harness(args, result_path, result, model, tokenizer)
    result["status"] = "complete"
    result["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    table.atomic_write_json(result_path, result)
    print(json.dumps(result["metrics"], indent=2), flush=True)
    del model, tokenizer
    torch.cuda.empty_cache()
    gc.collect()


if __name__ == "__main__":
    main()
