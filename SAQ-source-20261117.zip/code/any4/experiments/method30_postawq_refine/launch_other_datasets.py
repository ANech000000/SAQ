import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
METHOD30_DIR = ROOT / "experiments" / "method30"
for path in (EXP_DIR, METHOD30_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from performance_topology import allocate_cpu_sets, select_empty_gpus  # noqa: E402
from state_cache import atomic_write_json  # noqa: E402


PYTHON = ROOT / "venv" / "bin" / "python"
RUNNER = EXP_DIR / "runner_other_datasets.py"
DEFAULT_OUTPUT = EXP_DIR / "runs" / "other_datasets" / "refine10_20260715"


def build_parser():
    parser = argparse.ArgumentParser(
        description="Launch local task and PPL evaluation on at most two empty GPUs."
    )
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--max-gpus", type=int, choices=(1, 2), default=2)
    parser.add_argument("--requested-gpus")
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    return parser


def _select(args):
    requested = None
    if args.requested_gpus:
        requested = [
            item.strip()
            for item in args.requested_gpus.split(",")
            if item.strip()
        ]
        if not requested or len(requested) > 2:
            raise ValueError("--requested-gpus must contain one or two GPU ids.")
        limit = len(requested)
    else:
        limit = args.max_gpus
    selected, inspected = select_empty_gpus(
        limit=limit,
        memory_threshold_mib=args.empty_threshold_mib,
        utilization_threshold=args.empty_utilization_percent,
        requested=requested,
    )
    if not selected:
        raise RuntimeError("No empty GPU satisfies the requested thresholds.")
    return selected, inspected


def _command(args, suite, gpu, allocation, output_dir):
    command = [
        str(PYTHON),
        str(RUNNER),
        "--suite",
        suite,
        "--physical-gpu",
        gpu["index"],
        "--cpu-list",
        allocation["cpu_list"],
        "--parallel-jobs",
        str(args.parallel_jobs),
        "--empty-threshold-mib",
        str(args.empty_threshold_mib),
        "--empty-utilization-percent",
        str(args.empty_utilization_percent),
        "--output-dir",
        str(output_dir),
    ]
    if args.resume:
        command.append("--resume")
    if args.smoke and suite == "tasks":
        command.extend(["--mbpp-limit", "2", "--gsm8k-limit", "2"])
    if args.smoke and suite == "ppl":
        command.extend(
            ["--c4-eval-samples", "2", "--ptb-eval-samples", "2"]
        )
    return command


def _start_job(args, suite, gpu, allocation, output_root):
    output_dir = output_root / suite
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "run.log"
    mode = "a" if args.resume else "x"
    log_handle = log_path.open(mode)
    command = _command(args, suite, gpu, allocation, output_dir)
    env = os.environ.copy()
    env.update(
        {
            "CUDA_VISIBLE_DEVICES": gpu["index"],
            "TRANSFORMERS_OFFLINE": "1",
            "HF_DATASETS_OFFLINE": "1",
            "TOKENIZERS_PARALLELISM": "false",
            "PYTHONUNBUFFERED": "1",
        }
    )
    process = subprocess.Popen(
        command,
        cwd=ROOT,
        env=env,
        stdout=log_handle,
        stderr=subprocess.STDOUT,
        text=True,
    )
    print(
        f"started suite={suite} pid={process.pid} gpu={gpu['index']} "
        f"cpus={allocation['cpu_list']}",
        flush=True,
    )
    return {
        "suite": suite,
        "gpu": gpu,
        "allocation": allocation,
        "command": command,
        "pid": process.pid,
        "process": process,
        "log_path": str(log_path),
        "log_handle": log_handle,
        "started_at": time.time(),
    }


def _wait_jobs(jobs):
    active = list(jobs)
    completed = []
    while active:
        for job in list(active):
            returncode = job["process"].poll()
            if returncode is None:
                continue
            job["log_handle"].close()
            job["returncode"] = int(returncode)
            job["elapsed_seconds"] = float(time.time() - job["started_at"])
            active.remove(job)
            completed.append(job)
            print(
                f"completed suite={job['suite']} returncode={returncode} "
                f"elapsed={job['elapsed_seconds']:.1f}s",
                flush=True,
            )
        if active:
            time.sleep(5)
    return completed


def _public_job(job):
    return {
        key: value
        for key, value in job.items()
        if key not in {"process", "log_handle", "started_at"}
    }


def main():
    args = build_parser().parse_args()
    if args.parallel_jobs <= 0:
        raise ValueError("--parallel-jobs must be positive.")
    output_root = Path(args.output_root)
    launcher_path = output_root / "launcher.json"
    if launcher_path.exists() and not args.resume:
        raise FileExistsError(
            f"Launcher output already exists; pass --resume: {launcher_path}"
        )

    selected, inspected = _select(args)
    allocations = allocate_cpu_sets(
        selected, max_workers=args.parallel_jobs
    )
    if any(
        allocation["parallel_jobs"] < args.parallel_jobs
        for allocation in allocations.values()
    ):
        raise RuntimeError(
            f"Could not allocate {args.parallel_jobs} physical cores per GPU."
        )

    output_root.mkdir(parents=True, exist_ok=True)
    launcher = {
        "status": "running",
        "maximum_gpus": 2,
        "smoke": bool(args.smoke),
        "selected_gpus": selected,
        "inspected_gpus": inspected,
        "allocations": allocations,
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write_json(launcher_path, launcher)

    suites = ["tasks", "ppl"]
    completed = []
    if len(selected) >= 2:
        jobs = [
            _start_job(
                args,
                suite,
                selected[index],
                allocations[selected[index]["index"]],
                output_root,
            )
            for index, suite in enumerate(suites)
        ]
        completed.extend(_wait_jobs(jobs))
    else:
        gpu = selected[0]
        allocation = allocations[gpu["index"]]
        for suite in suites:
            completed.extend(
                _wait_jobs(
                    [
                        _start_job(
                            args,
                            suite,
                            gpu,
                            allocation,
                            output_root,
                        )
                    ]
                )
            )

    failures = [
        _public_job(job) for job in completed if job["returncode"] != 0
    ]
    suite_results = {}
    for suite in suites:
        result_path = output_root / suite / "results.json"
        if result_path.exists():
            suite_results[suite] = json.loads(result_path.read_text())
    summary = {
        "status": "complete" if not failures else "failed",
        "maximum_gpus": 2,
        "selected_gpus": [gpu["index"] for gpu in selected],
        "jobs": [_public_job(job) for job in completed],
        "failures": failures,
        "results": {
            suite: result.get("metrics", {})
            for suite, result in suite_results.items()
        },
        "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    atomic_write_json(output_root / "summary.json", summary)
    launcher["status"] = summary["status"]
    launcher["jobs"] = summary["jobs"]
    launcher["finished_at"] = summary["finished_at"]
    atomic_write_json(launcher_path, launcher)
    print(json.dumps(summary, indent=2), flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
