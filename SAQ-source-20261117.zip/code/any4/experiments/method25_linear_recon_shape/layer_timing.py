import argparse
import gc
import json
import math
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["NUMEXPR_MAX_THREADS"] = "64"

import torch
from transformers import AutoModelForCausalLM


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(METHOD24_DIR))

from method24_shape import build_awq_scale, shape_w2_score, write_json
from quantize import anyq_reconstruct_tensor, cluster_row_scikit


METHOD_NAME = "method25_per_linear_recon_shape_any4"
COARSE_ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)
LOCAL_OFFSETS = (-0.15, -0.05, 0.05, 0.15)
LINEAR_TO_ACTIVATION = {
    "self_attn.q_proj": "qkv",
    "self_attn.k_proj": "qkv",
    "self_attn.v_proj": "qkv",
    "mlp.gate_proj": "gate_up",
    "mlp.up_proj": "gate_up",
    "mlp.down_proj": "down",
}


def effective_weight(quantized_scaled_weight, scale):
    return quantized_scaled_weight.float() / scale.float().view(1, -1)


def select_output_only(records):
    if not records:
        raise ValueError("No candidate records")
    return min(
        records,
        key=lambda record: (record["output_rel_mse"], record["alpha"]),
    )


def select_with_shape_auxiliary(records, error_band=0.005):
    if not records:
        raise ValueError("No candidate records")
    best_error = min(record["output_rel_mse"] for record in records)
    eligible = [
        record
        for record in records
        if record["output_rel_mse"] <= best_error * (1.0 + error_band)
    ]
    return min(
        eligible,
        key=lambda record: (
            record["shape_score"],
            record["output_rel_mse"],
            record["alpha"],
        ),
    )


def select_shape_regularized(records, regularization=0.1):
    if not records:
        raise ValueError("No candidate records")
    baseline = next(
        (record for record in records if record["alpha"] == 0.0),
        None,
    )
    if baseline is None:
        raise ValueError("Shape-regularized selection requires alpha=0")
    error_baseline = max(baseline["output_rel_mse"], 1e-12)
    shape_baseline = max(baseline["shape_score"], 1e-12)

    def objective(record):
        return (
            record["output_rel_mse"] / error_baseline
            + regularization * record["shape_score"] / shape_baseline
        )

    return min(records, key=lambda record: (objective(record), record["alpha"]))


def objective_fine_alphas(coarse_records, error_band=0.005, regularization=0.1):
    centers = {
        select_output_only(coarse_records)["alpha"],
        select_with_shape_auxiliary(coarse_records, error_band)["alpha"],
        select_shape_regularized(coarse_records, regularization)["alpha"],
    }
    evaluated = {record["alpha"] for record in coarse_records}
    return sorted({
        round(min(1.0, max(0.0, center + offset)), 6)
        for center in centers
        for offset in LOCAL_OFFSETS
    } - evaluated)


def fine_alphas(coarse_records):
    best = select_with_shape_auxiliary(coarse_records)
    values = {
        round(min(1.0, max(0.0, best["alpha"] + offset)), 6)
        for offset in LOCAL_OFFSETS
    }
    evaluated = {record["alpha"] for record in coarse_records}
    return sorted(values - evaluated)


def activation_paths(cache_dir, layer_index):
    prefix = f"model.layers.{layer_index}"
    cache_dir = Path(cache_dir)
    return {
        "qkv": cache_dir
        / (
            f"{prefix}.self_attn.q_proj__{prefix}.self_attn.k_proj__"
            f"{prefix}.self_attn.v_proj_256_2048.pt"
        ),
        "gate_up": cache_dir
        / (
            f"{prefix}.mlp.gate_proj__{prefix}.mlp.up_proj_256_2048.pt"
        ),
        "down": cache_dir / f"{prefix}.mlp.down_proj_256_8192.pt",
    }


def load_activations(cache_dir, layer_index):
    activations = {}
    for key, path in activation_paths(cache_dir, layer_index).items():
        if not path.exists():
            raise FileNotFoundError(path)
        payload = torch.load(path, map_location="cpu")
        x = payload["x"].detach().float().contiguous()
        if x.shape[0] != 256:
            raise ValueError(f"Expected 256 tokens in {path}, got {tuple(x.shape)}")
        if not torch.isfinite(x).all():
            raise ValueError(f"Non-finite activation in {path}")
        activations[key] = x
    return activations


@torch.no_grad()
def output_energy(x, weight, device):
    x_device = x.to(device)
    weight_device = weight.to(device)
    energy = (x_device @ weight_device.t()).square().sum().double().item()
    del x_device, weight_device
    return max(energy, 1e-12)


@torch.no_grad()
def output_relative_mse(x, weight, reconstructed, denominator, device):
    x_device = x.to(device)
    delta_device = (weight - reconstructed).to(device)
    error = (x_device @ delta_device.t()).square().sum().double().item()
    del x_device, delta_device
    return error / denominator


@torch.no_grad()
def evaluate_candidate(
    weight,
    x,
    alpha,
    denominator,
    device,
    group_size,
    parallel_jobs,
):
    started = time.perf_counter()
    scale = build_awq_scale(x.abs().mean(dim=0), alpha).cpu()
    scaled_weight = weight * scale.view(1, -1)
    scaled_x_abs = (x / scale.view(1, -1)).abs().mean(dim=0)

    quant_started = time.perf_counter()
    quantized_scaled = anyq_reconstruct_tensor(
        scaled_weight,
        n_bit=4,
        q_group_size=group_size,
        cluster_row=cluster_row_scikit,
        sample_weight=scaled_x_abs,
        scale_sample_weight=True,
        parallelize=True,
        parallel_jobs=parallel_jobs,
        parallel_backend="loky",
        parallel_inner_threads=1,
        parallel_pre_dispatch="2*n_jobs",
    )
    quant_seconds = time.perf_counter() - quant_started

    reconstructed = effective_weight(quantized_scaled, scale)
    error_started = time.perf_counter()
    rel_mse = output_relative_mse(
        x,
        weight,
        reconstructed,
        denominator,
        device,
    )
    error_seconds = time.perf_counter() - error_started

    shape_started = time.perf_counter()
    shape, diagnostics = shape_w2_score(
        scaled_weight.to(device),
        group_size=group_size,
        row_chunk=256,
    )
    shape_seconds = time.perf_counter() - shape_started

    record = {
        "alpha": float(alpha),
        "output_rel_mse": float(rel_mse),
        "shape_score": float(shape),
        "shape_diagnostics": diagnostics,
        "timings": {
            "any4_seconds": quant_seconds,
            "output_error_seconds": error_seconds,
            "shape_seconds": shape_seconds,
            "total_seconds": time.perf_counter() - started,
        },
    }

    del scaled_weight, scaled_x_abs, quantized_scaled, reconstructed, scale
    torch.cuda.empty_cache()
    gc.collect()
    return record


@torch.no_grad()
def search_linear(
    full_name,
    module,
    x,
    device,
    group_size,
    parallel_jobs,
    error_band,
    output_path,
    all_results,
):
    weight = module.weight.detach().cpu().float().contiguous()
    original = weight.clone()
    if weight.shape[1] != x.shape[1]:
        raise ValueError(
            f"{full_name}: weight columns {weight.shape[1]} != x {x.shape[1]}"
        )

    denominator = output_energy(x, weight, device)
    started = time.perf_counter()
    candidates = []

    for alpha in COARSE_ALPHAS:
        record = evaluate_candidate(
            weight,
            x,
            alpha,
            denominator,
            device,
            group_size,
            parallel_jobs,
        )
        record["stage"] = "coarse"
        candidates.append(record)
        all_results["active"] = {
            "linear": full_name,
            "alpha": alpha,
            "stage": "coarse",
        }
        all_results["linears"][full_name] = {"candidates": candidates}
        write_json(output_path, all_results)

    for alpha in fine_alphas(candidates):
        record = evaluate_candidate(
            weight,
            x,
            alpha,
            denominator,
            device,
            group_size,
            parallel_jobs,
        )
        record["stage"] = "fine"
        candidates.append(record)
        all_results["active"] = {
            "linear": full_name,
            "alpha": alpha,
            "stage": "fine",
        }
        all_results["linears"][full_name] = {"candidates": candidates}
        write_json(output_path, all_results)

    selected = select_with_shape_auxiliary(candidates, error_band=error_band)
    elapsed = time.perf_counter() - started
    result = {
        "weight_shape": list(weight.shape),
        "activation_shape": list(x.shape),
        "candidate_count": len(candidates),
        "candidates": sorted(candidates, key=lambda item: item["alpha"]),
        "selected_alpha": selected["alpha"],
        "selected_output_rel_mse": selected["output_rel_mse"],
        "selected_shape_score": selected["shape_score"],
        "error_band": error_band,
        "elapsed_seconds": elapsed,
    }
    if not torch.equal(weight, original):
        raise AssertionError(f"Candidate search mutated {full_name}")
    del weight, original
    return result


def execute(args):
    if not 1 <= args.parallel_jobs <= 16:
        raise ValueError("parallel_jobs must be between 1 and 16")
    if os.environ.get("CUDA_VISIBLE_DEVICES") != str(args.physical_gpu):
        raise RuntimeError(
            "CUDA_VISIBLE_DEVICES must contain exactly the selected physical GPU"
        )
    device = torch.device("cuda:0")
    torch.backends.cuda.matmul.allow_tf32 = False

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "layer_timing_results.json"
    started = time.perf_counter()

    load_started = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    load_seconds = time.perf_counter() - load_started

    layer = model.model.layers[args.layer_index]
    modules = dict(layer.named_modules())
    activations = load_activations(args.activation_cache, args.layer_index)
    results = {
        "method": METHOD_NAME,
        "status": "running",
        "model_path": args.model_path,
        "layer_index": args.layer_index,
        "search_tokens": 256,
        "group_size": args.group_size,
        "parallel_jobs": args.parallel_jobs,
        "primary_objective": "relative_calibration_output_mse",
        "auxiliary_objective": "shape_w2_within_0.5_percent_error_band",
        "model_load_seconds": load_seconds,
        "linears": {},
    }
    write_json(output_path, results)

    layer_started = time.perf_counter()
    for local_name, activation_key in LINEAR_TO_ACTIVATION.items():
        full_name = f"model.layers.{args.layer_index}.{local_name}"
        result = search_linear(
            full_name,
            modules[local_name],
            activations[activation_key],
            device,
            args.group_size,
            args.parallel_jobs,
            args.error_band,
            output_path,
            results,
        )
        results["linears"][full_name] = result
        results["active"] = None
        write_json(output_path, results)
        print(
            f"{full_name}: alpha={result['selected_alpha']}, "
            f"error={result['selected_output_rel_mse']:.8e}, "
            f"seconds={result['elapsed_seconds']:.2f}",
            flush=True,
        )

    results["layer_search_seconds"] = time.perf_counter() - layer_started
    results["total_seconds"] = time.perf_counter() - started
    results["status"] = "complete"
    write_json(output_path, results)
    print(json.dumps(results, indent=2), flush=True)
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description=METHOD_NAME)
    parser.add_argument(
        "--model-path",
        default="/data/model/alpindale-Llama-3.2-1B",
    )
    parser.add_argument("--layer-index", type=int, default=0)
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--error-band", type=float, default=0.005)
    parser.add_argument(
        "--activation-cache",
        default=(
            "/data/lsz/any4/experiments/method24_shape_w2/"
            "cache/activations"
        ),
    )
    parser.add_argument("--output-dir", required=True)
    return parser


if __name__ == "__main__":
    raise SystemExit(execute(build_parser().parse_args()))
