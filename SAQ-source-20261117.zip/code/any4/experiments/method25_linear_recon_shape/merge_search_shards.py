import argparse
import json
import sys
from pathlib import Path


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
sys.path.insert(0, str(METHOD24_DIR))

from method24_shape import write_json


def execute(args):
    shards = [
        json.loads(Path(path).read_text(encoding="utf-8"))
        for path in args.shards
    ]
    for shard in shards:
        if shard.get("status") != "complete":
            raise ValueError(
                f"Incomplete shard [{shard.get('layer_start')}, "
                f"{shard.get('layer_end')})"
            )

    methods = tuple(shards[0]["selected_alphas"])
    merged = {
        "search": shards[0]["search"],
        "status": "complete",
        "model_path": shards[0]["model_path"],
        "layers": shards[0]["layers"],
        "layer_start": 0,
        "layer_end": shards[0]["layers"],
        "search_tokens": shards[0]["search_tokens"],
        "group_size": shards[0]["group_size"],
        "parallel_jobs_per_shard": shards[0]["parallel_jobs"],
        "error_band": shards[0]["error_band"],
        "regularization": shards[0]["regularization"],
        "methods": shards[0]["methods"],
        "linears": {},
        "selected_alphas": {method: {} for method in methods},
        "shards": args.shards,
        "shard_search_seconds": [
            shard["search_seconds"] for shard in shards
        ],
        "parallel_wall_estimate_seconds": max(
            shard["total_seconds"] for shard in shards
        ),
        "aggregate_search_seconds": sum(
            shard["search_seconds"] for shard in shards
        ),
    }
    ranges = []
    for shard in shards:
        ranges.extend(range(shard["layer_start"], shard["layer_end"]))
        overlap = set(merged["linears"]) & set(shard["linears"])
        if overlap:
            raise ValueError(f"Duplicate linears: {sorted(overlap)[:3]}")
        merged["linears"].update(shard["linears"])
        for method in methods:
            merged["selected_alphas"][method].update(
                shard["selected_alphas"][method]
            )

    expected_layers = list(range(merged["layers"]))
    if sorted(ranges) != expected_layers:
        raise ValueError(
            f"Shard layer coverage {sorted(ranges)} != {expected_layers}"
        )
    expected_linears = merged["layers"] * 6
    if len(merged["linears"]) != expected_linears:
        raise ValueError(
            f"Expected {expected_linears} searched linears, "
            f"got {len(merged['linears'])}"
        )
    for method in methods:
        if len(merged["selected_alphas"][method]) != expected_linears:
            raise ValueError(f"Incomplete selections for {method}")

    write_json(args.output, merged)
    print(json.dumps({
        "status": "complete",
        "linears": len(merged["linears"]),
        "parallel_wall_estimate_seconds": (
            merged["parallel_wall_estimate_seconds"]
        ),
        "output": args.output,
    }, indent=2))
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description="Merge full-search shards")
    parser.add_argument("--shards", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    return parser


if __name__ == "__main__":
    raise SystemExit(execute(build_parser().parse_args()))
