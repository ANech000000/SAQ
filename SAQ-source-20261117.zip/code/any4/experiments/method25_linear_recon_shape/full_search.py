import argparse
import gc
import hashlib
import json
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["NUMEXPR_MAX_THREADS"] = "64"

import torch
from transformers import AutoModelForCausalLM


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(METHOD_DIR))

from layer_timing import (
    COARSE_ALPHAS,
    LINEAR_TO_ACTIVATION,
    evaluate_candidate,
    load_activations,
    objective_fine_alphas,
    output_energy,
    select_output_only,
    select_shape_regularized,
    select_with_shape_auxiliary,
)
from method24_shape import write_json


SEARCH_NAME = "per_linear_any4_shared_candidate_search"
METHOD25 = "method25_per_linear_output_any4"
METHOD26 = "method26_per_linear_output_shape_band_any4"
METHOD27 = "method27_per_linear_output_shape_reg_any4"
METHODS = (METHOD25, METHOD26, METHOD27)


def safe_name(value):
    return "".join(
        character if character.isalnum() or character in "._-" else "__"
        for character in value
    )


def weight_fingerprint(weight):
    digest = hashlib.sha256()
    flat = weight.detach().reshape(-1)
    digest.update(str(tuple(weight.shape)).encode("ascii"))
    digest.update(flat[:64].float().cpu().numpy().tobytes())
    digest.update(str(float(weight.float().sum().item())).encode("ascii"))
    return digest.hexdigest()


def selections(records, error_band, regularization):
    selected = {
        METHOD25: select_output_only(records),
        METHOD26: select_with_shape_auxiliary(records, error_band),
        METHOD27: select_shape_regularized(records, regularization),
    }
    baseline = next(record for record in records if record["alpha"] == 0.0)
    output = {}
    for method, record in selected.items():
        output[method] = {
            "alpha": record["alpha"],
            "output_rel_mse": record["output_rel_mse"],
            "shape_score": record["shape_score"],
            "output_improvement_vs_alpha0": (
                baseline["output_rel_mse"] - record["output_rel_mse"]
            )
            / max(baseline["output_rel_mse"], 1e-12),
            "shape_ratio_vs_alpha0": record["shape_score"]
            / max(baseline["shape_score"], 1e-12),
        }
    return output


def load_unit(path, full_name, shape):
    if not path.exists():
        return {
            "search": SEARCH_NAME,
            "linear": full_name,
            "weight_shape": list(shape),
            "status": "running",
            "candidates": [],
        }
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("search") != SEARCH_NAME:
        raise ValueError(f"Search metadata mismatch in {path}")
    if payload.get("linear") != full_name:
        raise ValueError(f"Linear metadata mismatch in {path}")
    if payload.get("weight_shape") != list(shape):
        raise ValueError(f"Weight shape mismatch in {path}")
    return payload


def candidate_by_alpha(payload):
    return {
        round(float(record["alpha"]), 6): record
        for record in payload.get("candidates", [])
    }


@torch.no_grad()
def search_linear(
    module,
    full_name,
    x,
    device,
    args,
    unit_path,
):
    weight = module.weight.detach().cpu().float().contiguous()
    fingerprint = weight_fingerprint(module.weight)
    denominator = output_energy(x, weight, device)
    payload = load_unit(unit_path, full_name, weight.shape)
    candidates = candidate_by_alpha(payload)
    started = time.perf_counter()

    for alpha in COARSE_ALPHAS:
        key = round(float(alpha), 6)
        if key in candidates:
            continue
        record = evaluate_candidate(
            weight,
            x,
            alpha,
            denominator,
            device,
            args.group_size,
            args.parallel_jobs,
        )
        record["stage"] = "coarse"
        candidates[key] = record
        payload["candidates"] = sorted(
            candidates.values(), key=lambda item: item["alpha"]
        )
        payload["active"] = {"stage": "coarse", "alpha": alpha}
        write_json(unit_path, payload)

    coarse = [
        candidates[round(float(alpha), 6)]
        for alpha in COARSE_ALPHAS
    ]
    fine = objective_fine_alphas(
        coarse,
        error_band=args.error_band,
        regularization=args.regularization,
    )
    for alpha in fine:
        key = round(float(alpha), 6)
        if key in candidates:
            continue
        record = evaluate_candidate(
            weight,
            x,
            alpha,
            denominator,
            device,
            args.group_size,
            args.parallel_jobs,
        )
        record["stage"] = "fine"
        candidates[key] = record
        payload["candidates"] = sorted(
            candidates.values(), key=lambda item: item["alpha"]
        )
        payload["active"] = {"stage": "fine", "alpha": alpha}
        write_json(unit_path, payload)

    records = sorted(candidates.values(), key=lambda item: item["alpha"])
    payload.update({
        "status": "complete",
        "active": None,
        "candidate_count": len(records),
        "candidates": records,
        "selections": selections(
            records,
            args.error_band,
            args.regularization,
        ),
        "candidate_seconds": sum(
            record["timings"]["total_seconds"] for record in records
        ),
        "last_run_seconds": time.perf_counter() - started,
    })
    write_json(unit_path, payload)

    if weight_fingerprint(module.weight) != fingerprint:
        raise AssertionError(f"Search mutated {full_name}")
    del weight
    return payload


def execute(args):
    if not 1 <= args.parallel_jobs <= 16:
        raise ValueError("parallel_jobs must be between 1 and 16")
    layer_end = args.layer_end if args.layer_end is not None else args.layers
    if not 0 <= args.layer_start < layer_end <= args.layers:
        raise ValueError(
            f"Invalid layer range [{args.layer_start}, {layer_end}) "
            f"for {args.layers} layers"
        )
    layer_count = layer_end - args.layer_start
    if os.environ.get("CUDA_VISIBLE_DEVICES") != str(args.physical_gpu):
        raise RuntimeError(
            "CUDA_VISIBLE_DEVICES must contain exactly the selected physical GPU"
        )
    device = torch.device("cuda:0")
    torch.backends.cuda.matmul.allow_tf32 = False

    output_dir = Path(args.output_dir)
    unit_dir = output_dir / "search_units"
    unit_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "full_search_results.json"
    started = time.perf_counter()

    load_started = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    load_seconds = time.perf_counter() - load_started

    summary = {
        "search": SEARCH_NAME,
        "status": "running",
        "model_path": args.model_path,
        "layers": args.layers,
        "layer_start": args.layer_start,
        "layer_end": layer_end,
        "search_tokens": 256,
        "group_size": args.group_size,
        "parallel_jobs": args.parallel_jobs,
        "error_band": args.error_band,
        "regularization": args.regularization,
        "methods": {
            METHOD25: "normalized calibration output error only",
            METHOD26: "output error primary, minimum shape within error band",
            METHOD27: "normalized output error plus normalized shape regularizer",
        },
        "model_load_seconds": load_seconds,
        "linears": {},
        "selected_alphas": {method: {} for method in METHODS},
    }
    write_json(summary_path, summary)

    search_started = time.perf_counter()
    for layer_index in range(args.layer_start, layer_end):
        layer = model.model.layers[layer_index]
        modules = dict(layer.named_modules())
        activations = load_activations(args.activation_cache, layer_index)
        for local_name, activation_key in LINEAR_TO_ACTIVATION.items():
            full_name = f"model.layers.{layer_index}.{local_name}"
            unit_path = unit_dir / f"{safe_name(full_name)}.json"
            payload = search_linear(
                modules[local_name],
                full_name,
                activations[activation_key],
                device,
                args,
                unit_path,
            )
            summary["linears"][full_name] = {
                "unit_file": str(unit_path),
                "candidate_count": payload["candidate_count"],
                "candidate_seconds": payload["candidate_seconds"],
                "selections": payload["selections"],
            }
            for method in METHODS:
                summary["selected_alphas"][method][full_name] = (
                    payload["selections"][method]["alpha"]
                )
            summary["completed_linears"] = len(summary["linears"])
            summary["active"] = None
            write_json(summary_path, summary)
            selected_text = ", ".join(
                f"{method[6:8]}={payload['selections'][method]['alpha']}"
                for method in METHODS
            )
            print(
                f"[{summary['completed_linears']}/"
                f"{layer_count * len(LINEAR_TO_ACTIVATION)}] "
                f"{full_name}: {selected_text}",
                flush=True,
            )
        del activations
        gc.collect()
        torch.cuda.empty_cache()

    summary["search_seconds"] = time.perf_counter() - search_started
    summary["total_seconds"] = time.perf_counter() - started
    summary["status"] = "complete"
    write_json(summary_path, summary)
    print(
        json.dumps({
            "status": summary["status"],
            "completed_linears": summary["completed_linears"],
            "search_seconds": summary["search_seconds"],
            "total_seconds": summary["total_seconds"],
            "output": str(summary_path),
        }, indent=2),
        flush=True,
    )
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description=SEARCH_NAME)
    parser.add_argument(
        "--model-path",
        default="/data/model/alpindale-Llama-3.2-1B",
    )
    parser.add_argument("--layers", type=int, default=16)
    parser.add_argument("--layer-start", type=int, default=0)
    parser.add_argument("--layer-end", type=int)
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--error-band", type=float, default=0.005)
    parser.add_argument("--regularization", type=float, default=0.1)
    parser.add_argument(
        "--activation-cache",
        default=(
            "/data/lsz/any4/experiments/method24_shape_w2/"
            "cache/activations"
        ),
    )
    parser.add_argument("--output-dir", required=True)
    return parser


if __name__ == "__main__":
    raise SystemExit(execute(build_parser().parse_args()))
