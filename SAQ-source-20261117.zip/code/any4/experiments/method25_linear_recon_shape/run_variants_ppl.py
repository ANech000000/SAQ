import argparse
import gc
import json
import os
import sys
import time
from collections import Counter
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["NUMEXPR_MAX_THREADS"] = "64"

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(METHOD_DIR))
sys.path.insert(0, str(METHOD24_DIR))

from data_gptq import get_loaders, llama_eval
from full_search import METHOD25
from layer_timing import (
    LINEAR_TO_ACTIVATION,
    effective_weight,
    load_activations,
)
from method24_shape import build_awq_scale, write_json
from quantize import anyq_reconstruct_tensor, cluster_row_scikit


BASELINES = {
    "fp16_ppl": 9.750678062438965,
    "original_any4_4bit_ppl": 10.618475914001465,
    "method2_dp_ppl": 10.555562973022461,
}


def load_model(model_path):
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    return model


def layer_and_local_name(full_name):
    parts = full_name.split(".")
    layer_index = int(parts[2])
    local_name = ".".join(parts[3:])
    return layer_index, local_name


@torch.no_grad()
def reconstruct_weight(
    weight,
    alpha,
    x,
    fallback_sample_weight,
    group_size,
    parallel_jobs,
):
    weight = weight.detach().cpu().float().contiguous()
    if x is not None:
        scale = build_awq_scale(x.abs().mean(dim=0), alpha).cpu()
        sample_weight = (x / scale.view(1, -1)).abs().mean(dim=0)
    else:
        if alpha != 0.0:
            raise ValueError("Non-zero alpha requires raw calibration activations")
        scale = torch.ones(weight.shape[1], dtype=torch.float32)
        sample_weight = fallback_sample_weight.detach().cpu().float()

    scaled_weight = weight * scale.view(1, -1)
    quantized_scaled = anyq_reconstruct_tensor(
        scaled_weight,
        n_bit=4,
        q_group_size=group_size,
        cluster_row=cluster_row_scikit,
        sample_weight=sample_weight,
        scale_sample_weight=True,
        parallelize=True,
        parallel_jobs=parallel_jobs,
        parallel_backend="loky",
        parallel_inner_threads=1,
        parallel_pre_dispatch="2*n_jobs",
    )
    reconstructed = effective_weight(quantized_scaled, scale)
    if not torch.isfinite(reconstructed).all():
        raise ValueError("Non-finite reconstructed weight")
    return reconstructed


def evaluate_wiki2(model, tokenizer, seqlen, samples):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=samples,
    )
    value = llama_eval(model, testloader, "cuda", seqlen=seqlen)
    return float(value)


def execute(args):
    if not 1 <= args.parallel_jobs <= 16:
        raise ValueError("parallel_jobs must be between 1 and 16")
    if os.environ.get("CUDA_VISIBLE_DEVICES") != str(args.physical_gpu):
        raise RuntimeError(
            "CUDA_VISIBLE_DEVICES must contain exactly the selected physical GPU"
        )

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results_path = output_dir / "ppl_results.json"
    search = json.loads(Path(args.search_results).read_text(encoding="utf-8"))
    if search.get("status") != "complete":
        raise ValueError("Full search is not complete")

    methods = tuple(search.get("methods", ()))
    selected_alphas = search.get("selected_alphas", {})
    if not methods or set(methods) != set(selected_alphas):
        raise ValueError(
            "Search methods must match selected_alphas keys"
        )

    stats_payload = torch.load(args.activation_stats, map_location="cpu")
    activation_stats = stats_payload["sample_weight"]
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
    )

    load_started = time.perf_counter()
    models = {method: load_model(args.model_path) for method in methods}
    model_load_seconds = time.perf_counter() - load_started
    modules = {
        method: dict(model.named_modules())
        for method, model in models.items()
    }
    reference_modules = modules[methods[0]]
    linear_names = [
        name
        for name, module in reference_modules.items()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    ]

    results = {
        "status": "quantizing_variants",
        "methods": list(methods),
        "model_path": args.model_path,
        "search_results": args.search_results,
        "group_size": args.group_size,
        "parallel_jobs": args.parallel_jobs,
        "baselines": BASELINES,
        "model_load_seconds": model_load_seconds,
        "quantized_linears": 0,
        "unique_reconstructions": 0,
        "ppl": {},
        "timings": {},
    }
    write_json(results_path, results)

    quant_started = time.perf_counter()
    cached_layer_index = None
    cached_activations = None
    for index, full_name in enumerate(linear_names, 1):
        layer_index, local_name = layer_and_local_name(full_name)
        if layer_index != cached_layer_index:
            cached_activations = load_activations(
                args.activation_cache,
                layer_index,
            )
            cached_layer_index = layer_index

        if local_name in LINEAR_TO_ACTIVATION:
            x = cached_activations[LINEAR_TO_ACTIVATION[local_name]]
        else:
            x = None
        fallback = activation_stats[full_name]
        method_alphas = {
            method: float(
                selected_alphas.get(method, {}).get(full_name, 0.0)
            )
            for method in methods
        }
        source_weight = reference_modules[full_name].weight.detach()
        reconstructed_by_alpha = {}
        for alpha in sorted(set(method_alphas.values())):
            reconstructed_by_alpha[alpha] = reconstruct_weight(
                source_weight,
                alpha,
                x,
                fallback,
                args.group_size,
                args.parallel_jobs,
            )
            results["unique_reconstructions"] += 1

        for method, alpha in method_alphas.items():
            target = modules[method][full_name]
            target.weight.data.copy_(
                reconstructed_by_alpha[alpha].to(target.weight.dtype)
            )

        results["quantized_linears"] = index
        results["active_linear"] = full_name
        write_json(results_path, results)
        print(
            f"[{index}/{len(linear_names)}] {full_name}: "
            + ", ".join(
                f"{method[6:8]}={alpha}"
                for method, alpha in method_alphas.items()
            ),
            flush=True,
        )
        del reconstructed_by_alpha
        gc.collect()

    results["timings"]["joint_quantization_seconds"] = (
        time.perf_counter() - quant_started
    )
    results["status"] = "evaluating_ppl"
    results["active_linear"] = None
    write_json(results_path, results)

    for method in methods:
        model = models[method]
        model.to("cuda")
        model.eval()
        ppl_started = time.perf_counter()
        ppl = evaluate_wiki2(
            model,
            tokenizer,
            args.ppl_seqlen,
            args.loader_samples,
        )
        results["timings"][f"{method}_ppl_seconds"] = (
            time.perf_counter() - ppl_started
        )
        results["ppl"][method] = ppl
        results["status"] = f"ppl_complete_{method}"
        write_json(results_path, results)
        print(f"{method}: WikiText-2 PPL={ppl}", flush=True)
        model.cpu()
        torch.cuda.empty_cache()
        gc.collect()

    results["alpha_histograms"] = {
        method: dict(sorted(Counter(
            str(alpha)
            for alpha in selected_alphas[method].values()
        ).items()))
        for method in methods
    }
    results["status"] = "complete"
    write_json(results_path, results)
    print(json.dumps(results, indent=2), flush=True)
    return 0


def build_parser():
    parser = argparse.ArgumentParser(
        description="Joint reconstruction and PPL for methods 25/26/27"
    )
    parser.add_argument(
        "--model-path",
        default="/data/model/alpindale-Llama-3.2-1B",
    )
    parser.add_argument("--search-results", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--ppl-seqlen", type=int, default=2048)
    parser.add_argument(
        "--activation-cache",
        default=(
            "/data/lsz/any4/experiments/method24_shape_w2/"
            "cache/activations"
        ),
    )
    parser.add_argument(
        "--activation-stats",
        default=(
            "/data/lsz/any4/logs/llama3.2-1b/"
            "wiki2_method24_shape_w2_20260714_153906_gpu0/"
            "scaled_activation_stats.pt"
        ),
    )
    return parser


if __name__ == "__main__":
    raise SystemExit(execute(build_parser().parse_args()))
