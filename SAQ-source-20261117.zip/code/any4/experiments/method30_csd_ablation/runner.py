import argparse
import gc
import json
import math
import os
import sys
import time
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, REFINE_DIR, METHOD25_DIR, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import experiment_runtime as runtime  # noqa: E402
from layer_timing import LINEAR_TO_ACTIVATION, load_activations  # noqa: E402
from method30_refine import reconstruct_from_state, state_diagnostics  # noqa: E402
from state_cache import atomic_write_json, file_sha256, outlier_mask_from_positions  # noqa: E402


STRATEGIES = ("no_scaling", "output_only", "csd_only", "output_csd")
MODEL_EXPECTATIONS = {
    "1b": {
        "linears": 112,
        "searchable_linears": 96,
        "joint_ppl": 10.287789344787598,
        "original_runner_joint_ppl": 10.288002967834473,
    },
    "8b": {
        "linears": 224,
        "searchable_linears": 192,
        "joint_ppl": 6.3587446212768555,
    },
}


def layer_parts(name):
    parts = name.split(".")
    return int(parts[2]), ".".join(parts[3:])


@torch.no_grad()
def grouped_csd(scaled_weight, group_size, outlier_positions=None, row_chunk=256):
    rows, cols = scaled_weight.shape
    groups_per_row = cols // group_size
    if groups_per_row <= 1:
        return 0.0
    total = 0.0
    pairwise_factor = 2.0 * groups_per_row / (groups_per_row - 1)
    for start in range(0, rows, row_chunk):
        stop = min(start + row_chunk, rows)
        groups = scaled_weight[start:stop].reshape(
            stop - start, groups_per_row, group_size
        )
        if outlier_positions is not None:
            mask = torch.ones_like(groups, dtype=torch.bool)
            mask.scatter_(
                2,
                outlier_positions[start:stop].long().unsqueeze(2),
                False,
            )
            groups = groups[mask].reshape(
                stop - start, groups_per_row, group_size - 1
            )
        sorted_groups = groups.sort(dim=2).values
        minimum = sorted_groups[:, :, :1]
        value_range = sorted_groups[:, :, -1:] - minimum
        normalized = torch.where(
            value_range >= 1e-6,
            (sorted_groups - minimum) / value_range.clamp_min(1e-6),
            torch.zeros_like(sorted_groups),
        )
        mean_curve = normalized.mean(dim=1, keepdim=True)
        row_scores = (
            (normalized - mean_curve).square().mean(dim=(1, 2))
            * pairwise_factor
        )
        total += row_scores.double().sum().item()
    return float(total / max(rows, 1))


@torch.no_grad()
def final_output_error(activation, source, reconstructed):
    x = activation.to(device=source.device, dtype=torch.float32)
    source32 = source.float()
    reconstructed32 = reconstructed.float()
    reference = x @ source32.t()
    residual = x @ (source32 - reconstructed32).t()
    denominator = reference.square().sum().double().item()
    numerator = residual.square().sum().double().item()
    del x, source32, reconstructed32, reference, residual
    return float(numerator), float(max(denominator, 1e-12))


def _load_selection(args):
    payload = json.loads(Path(args.selection).read_text(encoding="utf-8"))
    if payload.get("status") != "complete":
        raise RuntimeError("Selection manifest is not complete")
    if payload.get("model_key") != args.model:
        raise ValueError("Selection manifest model key does not match runner")
    if args.strategy not in payload.get("selected_alphas", {}):
        raise ValueError(f"Selection manifest has no strategy {args.strategy!r}")
    return payload


def _prepare_readonly_result(args, result_path):
    if not args.reference_results:
        raise ValueError("output_csd readonly reuse requires --reference-results")
    reference = Path(args.reference_results)
    if not reference.exists():
        raise FileNotFoundError(reference)
    payload = {
        "method_name": "method30_csd_ablation",
        "status": "readonly_cache_reference",
        "model_key": args.model,
        "strategy": args.strategy,
        "model_path": args.model_path,
        "stats_bundle": args.stats_bundle,
        "state_cache_dir": args.state_cache_dir,
        "reference_results": str(reference.resolve()),
        "reference_results_sha256": file_sha256(reference),
        "physical_gpu": str(args.physical_gpu),
        "checkpoints": [10],
        "target_iters": 10,
        "layers": {},
    }
    atomic_write_json(result_path, payload)
    return payload


def _validate_state(diagnostics, name):
    values = diagnostics["losses"]
    if not values or not all(math.isfinite(float(value)) for value in values):
        raise AssertionError(f"Non-finite loss in {name}")
    if not diagnostics["loss_monotonic"]:
        raise AssertionError(f"Non-monotonic loss in {name}")
    if diagnostics["rollback_reason"] == "non_finite_loss":
        raise AssertionError(f"Non-finite rollback in {name}")


@torch.no_grad()
def evaluate_metrics_and_ppl(args, result_path):
    runtime.setup_hardware(args)
    selection = _load_selection(args)
    bundle, model, tokenizer, linears = runtime.load_context(args)
    identity, fingerprint = runtime.build_run_identity(args, args.stats_bundle)
    expected = MODEL_EXPECTATIONS[args.model]
    if len(linears) != expected["linears"]:
        raise AssertionError(f"Expected {expected['linears']} Linears, found {len(linears)}")

    if result_path.exists():
        result = json.loads(result_path.read_text(encoding="utf-8"))
    else:
        result = _prepare_readonly_result(args, result_path)
    result.update({
        "method_name": "method30_csd_ablation",
        "status": "evaluating_metrics",
        "model_key": args.model,
        "strategy": args.strategy,
        "selection": str(Path(args.selection).resolve()),
        "selection_sha256": file_sha256(args.selection),
        "run_identity": identity,
        "run_fingerprint": fingerprint,
        "metric_scope": "searchable_linears_only",
        "metric_layers": {},
        "metric_progress": 0,
    })
    atomic_write_json(result_path, result)

    csd_numerator = 0.0
    recomputed_csd_numerator = 0.0
    regular_csd_numerator = 0.0
    csd_rows = 0
    final_j_numerator = 0.0
    final_j_denominator = 0.0
    output_numerator = 0.0
    output_denominator = 0.0
    reconstruction_hashes = {}
    searchable_count = 0
    rollback_layers = 0
    current_block = None
    activations = None
    evaluation_started = time.perf_counter()

    for index, (name, module, stats) in enumerate(linears, 1):
        block, local_name = layer_parts(name)
        searchable = local_name in LINEAR_TO_ACTIVATION
        if searchable and block != current_block:
            activations = load_activations(args.activation_cache, block)
            current_block = block

        metadata = runtime.layer_metadata(identity, name, stats, 10)
        cache_path = runtime.cache_file(args.state_cache_dir, fingerprint, name, 10)
        if not cache_path.exists():
            raise FileNotFoundError(
                f"Required {'readonly ' if args.readonly_cache else ''}state cache is missing: {cache_path}"
            )
        state, cache_payload = runtime.load_state_cache(cache_path, metadata)
        diagnostics = state_diagnostics(state)
        _validate_state(diagnostics, name)
        rollback_layers += int(bool(diagnostics["rollback"]))
        source = module.weight.detach().to(device="cuda:0")
        reconstructed = reconstruct_from_state(source, state)

        if searchable:
            searchable_count += 1
            selected = selection["diagnostics"][args.strategy][name]
            if abs(float(stats["alpha"]) - float(selected["alpha"])) > 1e-12:
                raise AssertionError(f"Alpha mismatch in {name}")
            scaled_source = source.float() * state["channel_scale"].to(
                device=source.device, dtype=torch.float32
            ).reshape(1, -1)
            positions = state["outlier_positions"].to(device=source.device)
            csd_recomputed = grouped_csd(scaled_source, args.group_size)
            csd_regular = grouped_csd(
                scaled_source,
                args.group_size,
                outlier_positions=positions,
            )
            candidate_csd = float(selected["csd"])
            tolerance = max(2e-8, abs(candidate_csd) * 2e-5)
            if abs(csd_recomputed - candidate_csd) > tolerance:
                raise AssertionError(
                    f"CSD mismatch in {name}: candidate={candidate_csd}, recomputed={csd_recomputed}"
                )
            activation = activations[LINEAR_TO_ACTIVATION[local_name]]
            layer_output_numerator, layer_output_denominator = final_output_error(
                activation,
                source,
                reconstructed,
            )
            rows = int(source.shape[0])
            csd_numerator += candidate_csd * rows
            recomputed_csd_numerator += csd_recomputed * rows
            regular_csd_numerator += csd_regular * rows
            csd_rows += rows
            final_j_numerator += float(diagnostics["weighted_loss_numerator"])
            final_j_denominator += float(diagnostics["weighted_loss_denominator"])
            output_numerator += layer_output_numerator
            output_denominator += layer_output_denominator
            result["metric_layers"][name] = {
                "alpha": float(stats["alpha"]),
                "rows": rows,
                "cols": int(source.shape[1]),
                "candidate_csd": candidate_csd,
                "recomputed_csd": csd_recomputed,
                "regular_csd_post_outlier": csd_regular,
                "candidate_output_rel_mse": float(selected["output_rel_mse"]),
                "final_output_error_numerator": layer_output_numerator,
                "final_output_error_denominator": layer_output_denominator,
                "final_output_rel_mse": layer_output_numerator / layer_output_denominator,
                "final_j_numerator": float(diagnostics["weighted_loss_numerator"]),
                "final_j_denominator": float(diagnostics["weighted_loss_denominator"]),
                "final_j": float(diagnostics["final_weighted_loss"]),
                "iterations": int(diagnostics["iterations"]),
                "rollback": bool(diagnostics["rollback"]),
                "rollback_reason": diagnostics["rollback_reason"],
                "cache_path": str(cache_path),
                "cache_state_sha256": cache_payload["state_hash"],
            }
            del scaled_source, positions

        reconstructed_cpu = reconstructed.detach().cpu().to(module.weight.dtype)
        reconstruction_hashes[name] = runtime.tensor_sha256(reconstructed_cpu)
        module.weight.data.copy_(reconstructed_cpu)
        del source, reconstructed, reconstructed_cpu, state, cache_payload

        next_block = (
            int(linears[index][2].get("block", -1)) if index < len(linears) else None
        )
        if int(stats.get("block", -1)) != next_block:
            result["metric_progress"] = index
            atomic_write_json(result_path, result)
            del activations
            activations = None
            current_block = None
            torch.cuda.empty_cache()
            gc.collect()
        print(
            f"[{index}/{len(linears)}] {name}: strategy={args.strategy}, "
            f"alpha={float(stats['alpha']):g}",
            flush=True,
        )

    if searchable_count != expected["searchable_linears"]:
        raise AssertionError(
            f"Expected {expected['searchable_linears']} searchable Linears, found {searchable_count}"
        )
    paper_metrics = {
        "scope": "searchable_linears_only",
        "searchable_linears": searchable_count,
        "total_quantized_linears": len(linears),
        "csd": csd_numerator / max(csd_rows, 1),
        "csd_recomputed": recomputed_csd_numerator / max(csd_rows, 1),
        "regular_csd_post_outlier": regular_csd_numerator / max(csd_rows, 1),
        "csd_rows": csd_rows,
        "final_j": final_j_numerator / max(final_j_denominator, 1e-12),
        "final_j_numerator": final_j_numerator,
        "final_j_denominator": final_j_denominator,
        "output_error": output_numerator / max(output_denominator, 1e-12),
        "output_error_numerator": output_numerator,
        "output_error_denominator": output_denominator,
        "rollback_layers": rollback_layers,
    }
    if abs(paper_metrics["csd"] - paper_metrics["csd_recomputed"]) > 2e-8:
        raise AssertionError("Aggregate candidate and recomputed CSD differ")

    model.to("cuda:0")
    model.eval()
    ppl_started = time.perf_counter()
    ppl = runtime.base.evaluate_wiki2(
        model,
        tokenizer,
        args.loader_samples,
        args.seqlen,
    )
    ppl_seconds = time.perf_counter() - ppl_started
    paper_metrics["wiki2_ppl"] = float(ppl)
    paper_metrics["ppl_evaluation_seconds"] = float(ppl_seconds)
    if args.strategy == "output_csd":
        delta = abs(float(ppl) - float(expected["joint_ppl"]))
        paper_metrics["joint_reference_ppl"] = float(expected["joint_ppl"])
        paper_metrics["joint_reference_absolute_delta"] = delta
        if "original_runner_joint_ppl" in expected:
            paper_metrics["original_runner_joint_ppl"] = float(
                expected["original_runner_joint_ppl"]
            )
            paper_metrics["delta_vs_original_runner_joint_ppl"] = float(
                ppl - expected["original_runner_joint_ppl"]
            )
        if delta > 1e-6:
            raise AssertionError(
                f"Validated joint PPL was not reproduced: observed={ppl}, "
                f"expected={expected['joint_ppl']}, delta={delta}"
            )

    result.update({
        "status": "complete",
        "metric_progress": len(linears),
        "paper_metrics": paper_metrics,
        "reconstruction_hashes": reconstruction_hashes,
        "metrics_and_ppl_seconds": float(time.perf_counter() - evaluation_started),
        "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    })
    atomic_write_json(result_path, result)
    print(json.dumps({
        "status": result["status"],
        "model": args.model,
        "strategy": args.strategy,
        "paper_metrics": paper_metrics,
        "output": str(result_path),
    }, indent=2), flush=True)
    return result


def build_parser():
    parser = argparse.ArgumentParser(description="Method30 CSD alpha-selection ablation")
    parser.add_argument("--phase", choices=("quantize", "evaluate", "all"), default="all")
    parser.add_argument("--model", choices=("1b", "8b"), required=True)
    parser.add_argument("--strategy", choices=STRATEGIES, required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--selection", required=True)
    parser.add_argument("--activation-cache", required=True)
    parser.add_argument("--stats-bundle", required=True)
    parser.add_argument("--state-cache-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--reference-results")
    parser.add_argument("--readonly-cache", action="store_true")
    parser.add_argument("--dataset-cache", default="/home/ubuntu/.cache/huggingface/datasets")
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--checkpoints", default="10")
    parser.add_argument("--target-iters", type=int, default=10)
    parser.add_argument("--initializer", choices=("sklearn",), default="sklearn")
    parser.add_argument("--gpu-iters", type=int, default=10)
    parser.add_argument("--cpu-iters", type=int, default=10)
    parser.add_argument("--gpu-chunk-rows", type=int, default=64)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)
    parser.add_argument("--relative-tol", type=float, default=1e-6)
    parser.add_argument("--ridge", type=float, default=1e-6)
    parser.add_argument("--scale-eps", type=float, default=1e-6)
    parser.add_argument("--chunk-rows", type=int, default=128)
    parser.add_argument("--importance-chunk-rows", type=int, default=512)
    parser.add_argument("--loss-increase-rtol", type=float, default=1e-7)
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--loader-samples", type=int, default=128)
    return parser


def main():
    args = build_parser().parse_args()
    if args.readonly_cache != (args.strategy == "output_csd"):
        raise ValueError("Only output_csd may use --readonly-cache, and it must use it")
    os.environ["HF_DATASETS_CACHE"] = args.dataset_cache
    result_path = Path(args.output_dir) / "results.json"
    if args.phase in ("quantize", "all"):
        if args.readonly_cache:
            _prepare_readonly_result(args, result_path)
        else:
            runtime.quantize_to_checkpoints(args, result_path)
    if args.phase in ("evaluate", "all"):
        evaluate_metrics_and_ppl(args, result_path)


if __name__ == "__main__":
    main()
