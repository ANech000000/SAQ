import argparse
import collections
import hashlib
import json
import os
from pathlib import Path


STRATEGIES = ("no_scaling", "output_only", "csd_only", "output_csd")
JOINT_LAMBDA = 0.3


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, indent=2, sort_keys=False) + "\n"
    if path.exists():
        current = path.read_text(encoding="utf-8")
        if current != encoded:
            raise FileExistsError(f"Refusing to overwrite different output: {path}")
        return
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(temporary, path)


def _record_key(record, strategy, error0, csd0):
    alpha = float(record["alpha"])
    output_error = float(record["output_rel_mse"])
    csd = float(record["shape_score"])
    if strategy == "no_scaling":
        return (0.0 if alpha == 0.0 else 1.0, output_error, alpha)
    if strategy == "output_only":
        return (output_error, alpha)
    if strategy == "csd_only":
        return (csd, output_error, alpha)
    if strategy == "output_csd":
        objective = output_error / error0 + JOINT_LAMBDA * csd / csd0
        return (objective, output_error, alpha)
    raise ValueError(strategy)


def select_records(records):
    if not records:
        raise ValueError("Candidate list is empty")
    baseline = next(
        (record for record in records if float(record["alpha"]) == 0.0),
        None,
    )
    if baseline is None:
        raise ValueError("Candidate list does not contain alpha=0")
    error0 = max(float(baseline["output_rel_mse"]), 1e-12)
    csd0 = max(float(baseline["shape_score"]), 1e-12)
    selected = {}
    for strategy in STRATEGIES:
        record = min(
            records,
            key=lambda item: _record_key(item, strategy, error0, csd0),
        )
        selected[strategy] = {
            "alpha": float(record["alpha"]),
            "output_rel_mse": float(record["output_rel_mse"]),
            "csd": float(record["shape_score"]),
            "output_ratio_vs_alpha0": float(record["output_rel_mse"]) / error0,
            "csd_ratio_vs_alpha0": float(record["shape_score"]) / csd0,
            "joint_objective": (
                float(record["output_rel_mse"]) / error0
                + JOINT_LAMBDA * float(record["shape_score"]) / csd0
            ),
        }
    return selected


def load_expected_joint(path, key):
    if not path:
        return None
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    values = payload.get("selected_alphas", {}).get(key)
    if not isinstance(values, dict):
        raise ValueError(f"Expected selection key {key!r} is missing from {path}")
    return {name: float(alpha) for name, alpha in values.items()}


def execute(args):
    source_path = Path(args.source_search)
    source = json.loads(source_path.read_text(encoding="utf-8"))
    if source.get("status") != "complete":
        raise RuntimeError(f"Source search is not complete: {source_path}")
    expected_joint = load_expected_joint(args.expected_joint, args.expected_joint_key)
    selections = {strategy: {} for strategy in STRATEGIES}
    diagnostics = {strategy: {} for strategy in STRATEGIES}
    candidate_sources = {}
    candidate_counts = collections.Counter()

    for name, entry in source["linears"].items():
        unit_path = Path(entry["unit_file"])
        unit = json.loads(unit_path.read_text(encoding="utf-8"))
        if unit.get("status") != "complete" or unit.get("linear") != name:
            raise RuntimeError(f"Invalid candidate unit: {unit_path}")
        records = unit["candidates"]
        chosen = select_records(records)
        candidate_counts[len(records)] += 1
        candidate_sources[name] = {
            "path": str(unit_path.resolve()),
            "sha256": file_sha256(unit_path),
            "candidate_count": len(records),
            "weight_shape": list(unit["weight_shape"]),
        }
        for strategy, record in chosen.items():
            selections[strategy][name] = record["alpha"]
            diagnostics[strategy][name] = record

    if expected_joint is not None:
        if set(expected_joint) != set(selections["output_csd"]):
            raise AssertionError("Expected joint selection coverage differs from source search")
        mismatches = {
            name: (expected_joint[name], selections["output_csd"][name])
            for name in expected_joint
            if expected_joint[name] != selections["output_csd"][name]
        }
        if mismatches:
            first = list(mismatches.items())[:5]
            raise AssertionError(f"Joint selections do not reproduce validated results: {first}")

    alpha_histograms = {}
    for strategy, values in selections.items():
        counts = collections.Counter(float(alpha) for alpha in values.values())
        alpha_histograms[strategy] = {
            str(alpha): int(count) for alpha, count in sorted(counts.items())
        }

    payload = {
        "schema_version": 1,
        "status": "complete",
        "model_key": args.model_key,
        "model_path": source["model_path"],
        "group_size": int(source["group_size"]),
        "searchable_linears": len(source["linears"]),
        "selection_protocol": {
            "candidate_policy": "reuse_existing_per_linear_candidate_sets",
            "joint_lambda": JOINT_LAMBDA,
            "joint_objective": "E(alpha)/E(0) + 0.3 * CSD(alpha)/CSD(0)",
            "output_only": "min output_rel_mse, then lower alpha",
            "csd_only": "min CSD, then output_rel_mse, then lower alpha",
            "no_scaling": "alpha=0",
        },
        "source_search": str(source_path.resolve()),
        "source_search_sha256": file_sha256(source_path),
        "expected_joint": (
            str(Path(args.expected_joint).resolve()) if args.expected_joint else None
        ),
        "expected_joint_sha256": (
            file_sha256(args.expected_joint) if args.expected_joint else None
        ),
        "candidate_count_histogram": {
            str(count): int(layers) for count, layers in sorted(candidate_counts.items())
        },
        "alpha_histograms": alpha_histograms,
        "methods": {
            "no_scaling": "alpha=0",
            "output_only": "minimum lightweight output reconstruction error",
            "csd_only": "minimum cross-group shape discrepancy",
            "output_csd": "E/E0 + 0.3*CSD/CSD0",
        },
        "selected_alphas": selections,
        "diagnostics": diagnostics,
        "candidate_sources": candidate_sources,
    }
    atomic_write_json(args.output, payload)
    print(json.dumps({
        "output": str(Path(args.output).resolve()),
        "model_key": args.model_key,
        "searchable_linears": len(source["linears"]),
        "alpha_histograms": alpha_histograms,
    }, indent=2))
    return payload


def build_parser():
    parser = argparse.ArgumentParser(description="Build Method30 CSD ablation alpha selections")
    parser.add_argument("--model-key", choices=("1b", "8b"), required=True)
    parser.add_argument("--source-search", required=True)
    parser.add_argument("--expected-joint")
    parser.add_argument("--expected-joint-key", default="method27_lambda_0p3")
    parser.add_argument("--output", required=True)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
