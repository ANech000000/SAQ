import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


EXP_DIR = Path(__file__).resolve().parent
STRATEGIES = ("no_scaling", "output_only", "csd_only", "output_csd")


MODEL_CONFIG = {
    "1b": {
        "model_path": "/data/model/alpindale-Llama-3.2-1B",
        "selection": "selections/1b.json",
        "activation_cache": "/data/lsz/any4/experiments/method24_shape_w2/cache/activations",
        "joint_bundle": "/data/lsz/any4/experiments/method30_postawq_refine/cache/stats/llama3_2_1b_wiki2.pt",
        "joint_state": "/data/lsz/any4/experiments/method30_postawq_refine/cache/final_state",
        "joint_results": "/data/lsz/any4/experiments/method30_postawq_refine/runs/iteration_sweep/results.json",
        "gpu_offset": 0,
    },
    "8b": {
        "model_path": "/data/model/models--meta-llama--Meta-Llama-3-8B",
        "selection": "selections/8b.json",
        "activation_cache": "/data/lsz/any4/experiments/llama3_8b_reproduction/cache/activations",
        "joint_bundle": "/data/lsz/any4/experiments/llama3_8b_reproduction/cache/stats_bundle.pt",
        "joint_state": "/data/lsz/any4/experiments/llama3_8b_reproduction/cache/final_state",
        "joint_results": "/data/lsz/any4/experiments/llama3_8b_reproduction/runs/postawq_quant/results.json",
        "gpu_offset": 4,
    },
}


def atomic_write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite job manifest: {path}")
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def job_command(run_root, model, strategy, gpu):
    cfg = MODEL_CONFIG[model]
    readonly = strategy == "output_csd"
    stats_bundle = (
        cfg["joint_bundle"]
        if readonly
        else str(run_root / "stats" / model / f"{strategy}.pt")
    )
    state_cache = (
        cfg["joint_state"]
        if readonly
        else str(run_root / "state_cache" / model / strategy)
    )
    output_dir = run_root / model / strategy
    command = [
        sys.executable,
        str(EXP_DIR / "runner.py"),
        "--phase", "all",
        "--model", model,
        "--strategy", strategy,
        "--model-path", cfg["model_path"],
        "--selection", str(run_root / cfg["selection"]),
        "--activation-cache", cfg["activation_cache"],
        "--stats-bundle", stats_bundle,
        "--state-cache-dir", state_cache,
        "--output-dir", str(output_dir),
        "--physical-gpu", str(gpu),
        "--parallel-jobs", "16",
    ]
    if readonly:
        command.extend([
            "--readonly-cache",
            "--reference-results", cfg["joint_results"],
        ])
    return command, output_dir


def execute(args):
    run_root = Path(args.run_root).resolve()
    jobs_path = run_root / "jobs.json"
    if jobs_path.exists():
        raise FileExistsError(f"Job manifest already exists: {jobs_path}")
    jobs = []
    handles = []
    try:
        for model, cfg in MODEL_CONFIG.items():
            for strategy_index, strategy in enumerate(STRATEGIES):
                gpu = cfg["gpu_offset"] + strategy_index
                command, output_dir = job_command(run_root, model, strategy, gpu)
                output_dir.mkdir(parents=True, exist_ok=True)
                log_path = output_dir / "run.log"
                if log_path.exists():
                    raise FileExistsError(f"Run log already exists: {log_path}")
                handle = log_path.open("wb")
                handles.append(handle)
                environment = os.environ.copy()
                environment["CUDA_VISIBLE_DEVICES"] = str(gpu)
                process = subprocess.Popen(
                    command,
                    cwd=str(EXP_DIR),
                    env=environment,
                    stdout=handle,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
                jobs.append({
                    "model": model,
                    "strategy": strategy,
                    "gpu": gpu,
                    "pid": process.pid,
                    "command": command,
                    "output_dir": str(output_dir),
                    "log": str(log_path),
                })
        atomic_write_json(jobs_path, {"status": "launched", "jobs": jobs})
    finally:
        for handle in handles:
            handle.close()
    print(json.dumps({"status": "launched", "jobs": jobs}, indent=2))
    return jobs


def build_parser():
    parser = argparse.ArgumentParser(description="Launch all eight CSD ablation jobs")
    parser.add_argument("--run-root", required=True)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
