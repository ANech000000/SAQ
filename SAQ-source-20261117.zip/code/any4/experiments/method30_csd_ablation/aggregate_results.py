import argparse
import csv
import io
import json
import math
import os
from pathlib import Path


MODELS = ("1b", "8b")
STRATEGIES = ("no_scaling", "output_only", "csd_only", "output_csd")
MODEL_LABELS = {"1b": "Llama 3.2 1B", "8b": "Llama 3 8B"}
STRATEGY_LABELS = {
    "no_scaling": "No scaling",
    "output_only": "Output-only",
    "csd_only": "CSD-only",
    "output_csd": "Output + CSD",
}
EXPECTED = {
    "1b": {"linears": 112, "searchable": 96, "joint_ppl": 10.287789344787598},
    "8b": {"linears": 224, "searchable": 192, "joint_ppl": 6.3587446212768555},
}


def atomic_write_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def atomic_write_json(path, payload):
    atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=False) + "\n")


def stable_conditions(identity):
    keys = (
        "algorithm_version",
        "n_bit",
        "group_size",
        "outlier_selection_domain",
        "outlier_rule",
        "outliers_per_group",
        "initializer",
        "parallel_jobs",
        "optimizer",
    )
    return {key: identity[key] for key in keys}


def load_all(run_root):
    outputs = {}
    for model in MODELS:
        outputs[model] = {}
        reference_conditions = None
        for strategy in STRATEGIES:
            path = Path(run_root) / model / strategy / "results.json"
            payload = json.loads(path.read_text(encoding="utf-8"))
            if payload.get("status") != "complete":
                raise RuntimeError(f"Result is not complete: {path}")
            if payload.get("model_key") != model or payload.get("strategy") != strategy:
                raise ValueError(f"Result identity mismatch: {path}")
            metrics = payload.get("paper_metrics", {})
            required = ("csd", "final_j", "output_error", "wiki2_ppl")
            if any(key not in metrics or not math.isfinite(float(metrics[key])) for key in required):
                raise ValueError(f"Missing or non-finite metrics in {path}")
            expected = EXPECTED[model]
            if int(metrics["total_quantized_linears"]) != expected["linears"]:
                raise AssertionError(f"Total Linear coverage mismatch in {path}")
            if int(metrics["searchable_linears"]) != expected["searchable"]:
                raise AssertionError(f"Searchable Linear coverage mismatch in {path}")
            if int(metrics["rollback_layers"]) < 0:
                raise AssertionError(f"Invalid rollback count in {path}")
            conditions = stable_conditions(payload["run_identity"])
            if reference_conditions is None:
                reference_conditions = conditions
            elif conditions != reference_conditions:
                raise AssertionError(f"Controlled conditions differ in {path}")
            if strategy == "output_csd":
                delta = abs(float(metrics["wiki2_ppl"]) - expected["joint_ppl"])
                if delta > 1e-6:
                    raise AssertionError(f"Joint PPL reproduction failed in {path}: {delta}")
            outputs[model][strategy] = payload
    return outputs


def main_rows(results):
    rows = []
    for model in MODELS:
        for strategy in STRATEGIES:
            metrics = results[model][strategy]["paper_metrics"]
            rows.append({
                "model": model,
                "model_label": MODEL_LABELS[model],
                "strategy": strategy,
                "strategy_label": STRATEGY_LABELS[strategy],
                "csd": float(metrics["csd"]),
                "regular_csd_post_outlier": float(metrics["regular_csd_post_outlier"]),
                "final_j": float(metrics["final_j"]),
                "output_error": float(metrics["output_error"]),
                "wiki2_ppl": float(metrics["wiki2_ppl"]),
                "rollback_layers": int(metrics["rollback_layers"]),
            })
    return rows


def csv_text(rows):
    output = io.StringIO()
    fieldnames = list(rows[0])
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def layer_csv_text(results):
    output = io.StringIO()
    fieldnames = [
        "model", "strategy", "layer", "alpha", "rows", "cols",
        "candidate_csd", "recomputed_csd", "regular_csd_post_outlier",
        "candidate_output_rel_mse", "final_output_rel_mse", "final_j",
        "iterations", "rollback", "rollback_reason",
    ]
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    for model in MODELS:
        for strategy in STRATEGIES:
            for layer, metrics in results[model][strategy]["metric_layers"].items():
                writer.writerow({
                    "model": model,
                    "strategy": strategy,
                    "layer": layer,
                    **{key: metrics.get(key) for key in fieldnames[3:]},
                })
    return output.getvalue()


def latex_number(value, best, kind):
    if kind == "ppl":
        body = f"{value:.6f}"
    elif kind == "csd":
        body = f"{value:.8f}"
    else:
        body = f"{value:.6e}"
    return f"\\textbf{{{body}}}" if abs(value - best) <= max(1e-15, abs(best) * 1e-12) else body


def latex_table(rows):
    by_model = {model: [row for row in rows if row["model"] == model] for model in MODELS}
    lines = [
        "\\begin{table*}[t]",
        "\\caption{不同缩放选择策略的 CSD 消融。CSD、Final $\\mathcal{J}$ 和 Output error 仅在参与 $\\alpha$ 搜索的 Linear 上汇总；PPL 使用完整量化模型。}",
        "\\label{tab:csd_selection_ablation}",
        "\\centering",
        "\\footnotesize",
        "\\begin{tabular}{llrrrr}",
        "\\toprule",
        "模型 & 缩放选择策略 & CSD $\\downarrow$ & Final $\\mathcal{J}$ $\\downarrow$ & Output error $\\downarrow$ & WikiText-2 PPL $\\downarrow$ " + r"\\",
        "\\midrule",
    ]
    for model_index, model in enumerate(MODELS):
        group = by_model[model]
        best = {
            "csd": min(row["csd"] for row in group),
            "final_j": min(row["final_j"] for row in group),
            "output_error": min(row["output_error"] for row in group),
            "wiki2_ppl": min(row["wiki2_ppl"] for row in group),
        }
        for row in group:
            lines.append(
                f"{row['model_label']} & {row['strategy_label']} & "
                f"{latex_number(row['csd'], best['csd'], 'csd')} & "
                f"{latex_number(row['final_j'], best['final_j'], 'metric')} & "
                f"{latex_number(row['output_error'], best['output_error'], 'metric')} & "
                f"{latex_number(row['wiki2_ppl'], best['wiki2_ppl'], 'ppl')} \\\\"
            )
        if model_index + 1 < len(MODELS):
            lines.append("\\midrule")
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table*}", ""])
    return "\n".join(lines)


def summary_markdown(rows):
    lines = [
        "# Method30 CSD alpha-selection ablation",
        "",
        "| Model | Strategy | CSD | Final J | Output error | WikiText-2 PPL |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['model_label']} | {row['strategy_label']} | {row['csd']:.8f} | "
            f"{row['final_j']:.6e} | {row['output_error']:.6e} | {row['wiki2_ppl']:.6f} |"
        )
    lines.extend(["", "## Key comparison", ""])
    for model in MODELS:
        group = {row["strategy"]: row for row in rows if row["model"] == model}
        output = group["output_only"]
        joint = group["output_csd"]
        lines.append(
            f"- {MODEL_LABELS[model]}: Output + CSD vs Output-only: "
            f"ΔCSD={joint['csd'] - output['csd']:+.8f}, "
            f"ΔFinal J={joint['final_j'] - output['final_j']:+.6e}, "
            f"ΔOutput error={joint['output_error'] - output['output_error']:+.6e}, "
            f"ΔPPL={joint['wiki2_ppl'] - output['wiki2_ppl']:+.6f}."
        )
    lines.append("")
    return "\n".join(lines)


def diagnostics_payload(run_root, results):
    payload = {
        "status": "complete",
        "models": {},
    }
    for model in MODELS:
        selection_path = Path(run_root) / "selections" / f"{model}.json"
        selection = json.loads(selection_path.read_text(encoding="utf-8"))
        model_payload = {
            "selection_path": str(selection_path.resolve()),
            "source_search_sha256": selection["source_search_sha256"],
            "expected_joint_sha256": selection["expected_joint_sha256"],
            "candidate_count_histogram": selection["candidate_count_histogram"],
            "alpha_histograms": selection["alpha_histograms"],
            "strategies": {},
        }
        for strategy in STRATEGIES:
            result = results[model][strategy]
            metrics = result["paper_metrics"]
            model_payload["strategies"][strategy] = {
                "regular_csd_post_outlier": metrics["regular_csd_post_outlier"],
                "rollback_layers": metrics["rollback_layers"],
                "quantization_wall_seconds": result.get("quantization_wall_seconds"),
                "metrics_and_ppl_seconds": result.get("metrics_and_ppl_seconds"),
                "started_at": result.get("started_at"),
                "finished_at": result.get("finished_at"),
                "metric_layers": result["metric_layers"],
            }
        payload["models"][model] = model_payload
    return payload


def execute(args):
    results = load_all(args.run_root)
    rows = main_rows(results)
    output_dir = Path(args.output_dir)
    payload = {
        "status": "complete",
        "protocol": {
            "models": list(MODELS),
            "strategies": list(STRATEGIES),
            "group_size": 128,
            "n_bit": 4,
            "outliers_per_group": 1,
            "outlier_selection_domain": "post_awq",
            "optimizer_iterations": 10,
            "joint_lambda": 0.3,
            "metric_scope": "searchable_linears_only_except_full_model_ppl",
        },
        "rows": rows,
    }
    atomic_write_json(output_dir / "paper_table.json", payload)
    atomic_write_json(output_dir / "diagnostics.json", diagnostics_payload(args.run_root, results))
    atomic_write_text(output_dir / "paper_table.csv", csv_text(rows))
    atomic_write_text(output_dir / "layer_metrics.csv", layer_csv_text(results))
    atomic_write_text(output_dir / "paper_table.tex", latex_table(rows))
    atomic_write_text(output_dir / "summary.md", summary_markdown(rows))
    print(json.dumps({
        "status": "complete",
        "rows": len(rows),
        "output_dir": str(output_dir.resolve()),
    }, indent=2))
    return payload


def build_parser():
    parser = argparse.ArgumentParser(description="Aggregate Method30 CSD ablation")
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
