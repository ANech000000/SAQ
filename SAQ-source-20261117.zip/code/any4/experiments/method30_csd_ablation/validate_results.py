import argparse
import hashlib
import json
import math
import os
from pathlib import Path

import torch


MODELS = ("1b", "8b")
STRATEGIES = ("no_scaling", "output_only", "csd_only", "output_csd")
EXPECTED = {
    "1b": {"linears": 112, "searchable": 96, "joint_ppl": 10.287789344787598},
    "8b": {"linears": 224, "searchable": 192, "joint_ppl": 6.3587446212768555},
}
COMMON_STATS_KEYS = (
    "model_path",
    "activation_cache",
    "fisher_path",
    "fisher_sha256",
    "group_size",
    "outlier_selection_domain",
    "outlier_rule",
)
COMMON_IDENTITY_KEYS = (
    "algorithm_version",
    "n_bit",
    "group_size",
    "outlier_selection_domain",
    "outlier_rule",
    "outliers_per_group",
    "initializer",
    "parallel_jobs",
    "optimizer",
    "implementation_sha256",
)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def activation_manifest(root):
    root = Path(root)
    records = []
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        file_digest = sha256_file(path)
        size = path.stat().st_size
        record = {"path": relative, "bytes": size, "sha256": file_digest}
        records.append(record)
        digest.update(
            f"{relative}\0{size}\0{file_digest}\n".encode("utf-8")
        )
    return {
        "root": str(root.resolve()),
        "files": len(records),
        "bytes": sum(record["bytes"] for record in records),
        "manifest_sha256": digest.hexdigest(),
        "records": records,
    }


def assert_close(actual, expected, label, rtol=1e-11, atol=1e-14):
    if not math.isclose(float(actual), float(expected), rel_tol=rtol, abs_tol=atol):
        raise AssertionError(f"{label}: actual={actual}, expected={expected}")


def stable_subset(mapping, keys):
    return {key: mapping[key] for key in keys}


def stats_metadata(path):
    payload = torch.load(path, map_location="cpu", weights_only=False)
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        raise ValueError(f"Missing stats metadata: {path}")
    return metadata


def validate_result(result, expected, selected_alphas):
    if result.get("status") != "complete":
        raise RuntimeError("Result is not complete")
    metrics = result["paper_metrics"]
    layers = result["metric_layers"]
    if len(layers) != expected["searchable"]:
        raise AssertionError("Searchable metric-layer coverage mismatch")
    if int(metrics["searchable_linears"]) != expected["searchable"]:
        raise AssertionError("Searchable Linear count mismatch")
    if int(metrics["total_quantized_linears"]) != expected["linears"]:
        raise AssertionError("Total quantized Linear count mismatch")
    readonly_reference = len(result["layers"]) == 0
    if readonly_reference:
        if result.get("strategy") != "output_csd":
            raise AssertionError("Only the read-only joint strategy may omit copied state diagnostics")
        if len(result.get("reconstruction_hashes", {})) != expected["linears"]:
            raise AssertionError("Read-only reconstruction-hash coverage mismatch")
    elif len(result["layers"]) != expected["linears"]:
        raise AssertionError("Quantization state coverage mismatch")

    csd_rows = sum(int(layer["rows"]) for layer in layers.values())
    csd_sum = sum(float(layer["candidate_csd"]) * int(layer["rows"]) for layer in layers.values())
    recomputed_sum = sum(float(layer["recomputed_csd"]) * int(layer["rows"]) for layer in layers.values())
    regular_sum = sum(
        float(layer["regular_csd_post_outlier"]) * int(layer["rows"])
        for layer in layers.values()
    )
    final_j_num = sum(float(layer["final_j_numerator"]) for layer in layers.values())
    final_j_den = sum(float(layer["final_j_denominator"]) for layer in layers.values())
    output_num = sum(float(layer["final_output_error_numerator"]) for layer in layers.values())
    output_den = sum(float(layer["final_output_error_denominator"]) for layer in layers.values())

    assert_close(csd_sum / csd_rows, metrics["csd"], "CSD aggregate")
    assert_close(recomputed_sum / csd_rows, metrics["csd_recomputed"], "recomputed CSD aggregate")
    assert_close(regular_sum / csd_rows, metrics["regular_csd_post_outlier"], "regular CSD aggregate")
    assert_close(final_j_num / final_j_den, metrics["final_j"], "Final J aggregate")
    assert_close(output_num / output_den, metrics["output_error"], "output-error aggregate")
    assert_close(final_j_num, metrics["final_j_numerator"], "Final J numerator")
    assert_close(final_j_den, metrics["final_j_denominator"], "Final J denominator")
    assert_close(output_num, metrics["output_error_numerator"], "output numerator")
    assert_close(output_den, metrics["output_error_denominator"], "output denominator")
    if int(metrics["rollback_layers"]) != 0:
        raise AssertionError("Metric aggregation reports rollback layers")

    max_csd_delta = 0.0
    for name, layer in layers.items():
        if name not in selected_alphas:
            raise AssertionError(f"Metric layer missing from selection: {name}")
        assert_close(layer["alpha"], selected_alphas[name], f"selected alpha for {name}", atol=0.0)
        delta = abs(float(layer["candidate_csd"]) - float(layer["recomputed_csd"]))
        max_csd_delta = max(max_csd_delta, delta)
        if not all(math.isfinite(float(layer[key])) for key in (
            "candidate_csd", "recomputed_csd", "regular_csd_post_outlier",
            "final_output_rel_mse", "final_j",
        )):
            raise AssertionError(f"Non-finite layer metric: {name}")

    min_iterations = None
    max_iterations = None
    if readonly_reference:
        # evaluate_metrics_and_ppl loads every cached state and calls _validate_state
        # before emitting reconstruction_hashes.  Keep the audit independent of
        # copying hundreds of large state tensors into results.json.
        for name, layer in layers.items():
            if layer.get("rollback"):
                raise AssertionError(f"Unexpected read-only rollback: {name}")
            iterations = int(layer["iterations"])
            min_iterations = iterations if min_iterations is None else min(min_iterations, iterations)
            max_iterations = iterations if max_iterations is None else max(max_iterations, iterations)
    else:
        for name, layer in result["layers"].items():
            checkpoint = layer["checkpoints"]["10"]
            diagnostics = checkpoint["diagnostics"]
            losses = [float(value) for value in diagnostics["losses"]]
            if not diagnostics.get("loss_monotonic"):
                raise AssertionError(f"Non-monotonic diagnostic flag: {name}")
            if diagnostics.get("rollback"):
                raise AssertionError(f"Unexpected rollback: {name}")
            if any(not math.isfinite(value) for value in losses):
                raise AssertionError(f"Non-finite optimization loss: {name}")
            for before, after in zip(losses, losses[1:]):
                if after > before + max(1e-15, abs(before) * 1e-10):
                    raise AssertionError(f"Optimization loss increased: {name}")
            iterations = int(diagnostics["iterations"])
            min_iterations = iterations if min_iterations is None else min(min_iterations, iterations)
            max_iterations = iterations if max_iterations is None else max(max_iterations, iterations)

    return {
        "metric_layers": len(layers),
        "quantized_linears": expected["linears"] if readonly_reference else len(result["layers"]),
        "state_validation": (
            "runner_loaded_all_readonly_states_and_emitted_reconstruction_hashes"
            if readonly_reference else "independent_loss_sequence_check"
        ),
        "csd_rows": csd_rows,
        "max_candidate_vs_recomputed_csd_abs_delta": max_csd_delta,
        "rollback_layers": int(metrics["rollback_layers"]),
        "optimizer_iterations_min": min_iterations,
        "optimizer_iterations_max": max_iterations,
        "wiki2_ppl": float(metrics["wiki2_ppl"]),
        "cross_recomputed": {
            "csd": csd_sum / csd_rows,
            "regular_csd_post_outlier": regular_sum / csd_rows,
            "final_j": final_j_num / final_j_den,
            "output_error": output_num / output_den,
        },
    }


def execute(args):
    run_root = Path(args.run_root)
    report = {"status": "complete", "models": {}}
    for model in MODELS:
        expected = EXPECTED[model]
        selection_path = run_root / "selections" / f"{model}.json"
        selection = json.loads(selection_path.read_text(encoding="utf-8"))
        selection_digest = sha256_file(selection_path)
        results = {}
        metadata = {}
        common_identity = None
        common_stats = None
        checks = {}
        for strategy in STRATEGIES:
            path = run_root / model / strategy / "results.json"
            result = json.loads(path.read_text(encoding="utf-8"))
            results[strategy] = result
            if result["selection_sha256"] != selection_digest:
                raise AssertionError(f"Selection hash mismatch: {model}/{strategy}")
            identity = stable_subset(result["run_identity"], COMMON_IDENTITY_KEYS)
            if common_identity is None:
                common_identity = identity
            elif identity != common_identity:
                raise AssertionError(f"Run identity mismatch: {model}/{strategy}")
            metadata[strategy] = stats_metadata(result["stats_bundle"])
            stats_common = stable_subset(metadata[strategy], COMMON_STATS_KEYS)
            if common_stats is None:
                common_stats = stats_common
            elif stats_common != common_stats:
                raise AssertionError(f"Stats-source mismatch: {model}/{strategy}")
            checks[strategy] = validate_result(
                result,
                expected,
                selection["selected_alphas"][strategy],
            )

        joint_delta = abs(
            checks["output_csd"]["wiki2_ppl"] - expected["joint_ppl"]
        )
        if joint_delta > 1e-6:
            raise AssertionError(f"Joint PPL reproduction mismatch: {model}")
        activation = activation_manifest(common_stats["activation_cache"])
        report["models"][model] = {
            "status": "passed",
            "selection_path": str(selection_path.resolve()),
            "selection_sha256": selection_digest,
            "source_search_sha256": selection["source_search_sha256"],
            "expected_joint_sha256": selection["expected_joint_sha256"],
            "common_run_identity": common_identity,
            "common_stats_source": common_stats,
            "activation_cache_manifest": activation,
            "joint_ppl_absolute_delta": joint_delta,
            "strategies": checks,
        }

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite validation report: {output}")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "passed",
        "output": str(output.resolve()),
        "models": list(report["models"]),
    }, indent=2))
    return report


def build_parser():
    parser = argparse.ArgumentParser(description="Validate Method30 CSD ablation results")
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--output", required=True)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
