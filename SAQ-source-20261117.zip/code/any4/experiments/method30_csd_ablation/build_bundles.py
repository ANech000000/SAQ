import argparse
import json
import os
import sys
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
METHOD24_DIR = ROOT / "experiments" / "method24_shape_w2"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, REFINE_DIR, METHOD24_DIR, METHOD25_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from layer_timing import LINEAR_TO_ACTIVATION, load_activations  # noqa: E402
from method24_shape import build_awq_scale  # noqa: E402
from state_cache import file_sha256, tensor_sha256  # noqa: E402


DEFAULT_STRATEGIES = ("no_scaling", "output_only", "csd_only")


def load_fisher(path):
    payload = torch.load(path, map_location="cpu", weights_only=False)
    fisher = payload.get("fisher")
    if not isinstance(fisher, dict):
        raise ValueError("Fisher payload does not contain a dictionary")
    return {
        name: torch.as_tensor(value).float().contiguous()
        for name, value in fisher.items()
    }


def layer_parts(name):
    parts = name.split(".")
    return int(parts[2]), ".".join(parts[3:])


def atomic_torch_save(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite stats bundle: {path}")
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def execute(args):
    strategies = tuple(item.strip() for item in args.strategies.split(",") if item.strip())
    if not strategies or any(strategy not in DEFAULT_STRATEGIES for strategy in strategies):
        raise ValueError(f"Strategies must be drawn from {DEFAULT_STRATEGIES}")
    selection_path = Path(args.selection)
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    if selection.get("status") != "complete":
        raise RuntimeError("Alpha selection is not complete")
    selected = selection["selected_alphas"]
    for strategy in strategies:
        if strategy not in selected:
            raise ValueError(f"Selection does not contain strategy {strategy!r}")

    fisher = load_fisher(args.fisher)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    ).eval()
    linears = [
        (name, module)
        for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear) and name != "lm_head"
    ]
    searchable = {
        name for name, _ in linears
        if layer_parts(name)[1] in LINEAR_TO_ACTIVATION
    }
    fallback = {
        name for name, _ in linears
        if layer_parts(name)[1] == "self_attn.o_proj"
    }
    for strategy in strategies:
        if searchable != set(selected[strategy]):
            missing = sorted(searchable - set(selected[strategy]))
            extra = sorted(set(selected[strategy]) - searchable)
            raise ValueError(
                f"Alpha coverage mismatch for {strategy}: missing={missing[:3]}, extra={extra[:3]}"
            )
    if set(fisher) != {name for name, _ in linears}:
        raise ValueError("Fisher coverage does not match transformer Linears")

    common_metadata = {
        "model_path": str(Path(args.model_path).resolve()),
        "alpha_selection_path": str(selection_path.resolve()),
        "alpha_selection_sha256": file_sha256(selection_path),
        "source_search": selection["source_search"],
        "source_search_sha256": selection["source_search_sha256"],
        "activation_cache": str(Path(args.activation_cache).resolve()),
        "fisher_path": str(Path(args.fisher).resolve()),
        "fisher_sha256": file_sha256(args.fisher),
        "group_size": int(args.group_size),
        "outlier_selection_domain": "post_awq",
        "outlier_rule": "max_abs_first_tie_scaled_post_awq",
        "linears": len(linears),
        "searchable_linears": len(searchable),
        "fallback_linears": len(fallback),
    }
    bundles = {
        strategy: {
            "schema_version": 1,
            "metadata": {
                **common_metadata,
                "alpha_key": strategy,
                "selection_protocol": selection["selection_protocol"],
            },
            "layers": {},
        }
        for strategy in strategies
    }

    current_block = None
    activations = None
    for index, (name, module) in enumerate(linears, 1):
        block, local_name = layer_parts(name)
        if block != current_block:
            activations = load_activations(args.activation_cache, block)
            current_block = block
        source = module.weight.detach().cpu().contiguous()
        layer_fisher = fisher[name]
        if source.shape[1] % args.group_size or layer_fisher.numel() != source.shape[1]:
            raise ValueError(f"Invalid group or Fisher width for {name}")
        base = {
            "weight_shape": list(source.shape),
            "weight_dtype": str(source.dtype),
            "weight_sha256": tensor_sha256(source),
            "fisher": layer_fisher,
            "fisher_sha256": tensor_sha256(layer_fisher),
            "block": int(block),
            "local_name": local_name,
        }
        for strategy in strategies:
            if name in searchable:
                alpha = float(selected[strategy][name])
                activation = activations[LINEAR_TO_ACTIVATION[local_name]]
                if activation.shape[1] != source.shape[1]:
                    raise ValueError(f"Activation width mismatch for {name}")
                channel_scale = build_awq_scale(
                    activation.abs().mean(dim=0), alpha
                ).cpu().float().contiguous()
                alpha_source = strategy
            elif name in fallback:
                alpha = 0.0
                channel_scale = torch.ones(source.shape[1], dtype=torch.float32)
                alpha_source = "o_proj_alpha0_fallback"
            else:
                raise ValueError(f"No alpha policy for {name}")
            bundles[strategy]["layers"][name] = {
                **base,
                "channel_scale": channel_scale,
                "channel_scale_sha256": tensor_sha256(channel_scale),
                "alpha": alpha,
                "alpha_source": alpha_source,
            }
        print(f"[{index}/{len(linears)}] prepared {name}", flush=True)

    output_dir = Path(args.output_dir)
    outputs = {}
    for strategy, bundle in bundles.items():
        output = output_dir / f"{strategy}.pt"
        atomic_torch_save(output, bundle)
        outputs[strategy] = str(output.resolve())
    print(json.dumps({
        "model_key": args.model_key,
        "linears": len(linears),
        "searchable_linears": len(searchable),
        "outputs": outputs,
    }, indent=2))
    return outputs


def build_parser():
    parser = argparse.ArgumentParser(description="Build stats bundles for CSD ablation")
    parser.add_argument("--model-key", choices=("1b", "8b"), required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--selection", required=True)
    parser.add_argument("--activation-cache", required=True)
    parser.add_argument("--fisher", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--strategies", default=",".join(DEFAULT_STRATEGIES))
    parser.add_argument("--group-size", type=int, default=128)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
