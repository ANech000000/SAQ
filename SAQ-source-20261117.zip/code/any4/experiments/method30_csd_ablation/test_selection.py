import argparse
import json
from pathlib import Path

from select_alphas import STRATEGIES, select_records


EXPECTED_DIFFERENCES = {
    "1b": {
        ("no_scaling", "csd_only"): 1,
        ("output_only", "output_csd"): 68,
    },
    "8b": {
        ("no_scaling", "csd_only"): 1,
        ("output_only", "output_csd"): 171,
    },
}


def load_expected(path, key="method27_lambda_0p3"):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {name: float(value) for name, value in payload["selected_alphas"][key].items()}


def validate(model, source_path, expected_path):
    source = json.loads(Path(source_path).read_text(encoding="utf-8"))
    expected = load_expected(expected_path)
    chosen = {strategy: {} for strategy in STRATEGIES}
    for name, entry in source["linears"].items():
        unit = json.loads(Path(entry["unit_file"]).read_text(encoding="utf-8"))
        selection = select_records(unit["candidates"])
        for strategy in STRATEGIES:
            chosen[strategy][name] = float(selection[strategy]["alpha"])
    if chosen["output_csd"] != expected:
        raise AssertionError(f"{model}: output_csd does not reproduce validated selection")
    differences = {}
    for pair, expected_count in EXPECTED_DIFFERENCES[model].items():
        left, right = pair
        observed = sum(chosen[left][name] != chosen[right][name] for name in chosen[left])
        if observed != expected_count:
            raise AssertionError(
                f"{model}: expected {expected_count} differences for {pair}, found {observed}"
            )
        differences[f"{left}_vs_{right}"] = observed
    return {
        "model": model,
        "linears": len(source["linears"]),
        "differences": differences,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-1b", required=True)
    parser.add_argument("--expected-1b", required=True)
    parser.add_argument("--source-8b", required=True)
    parser.add_argument("--expected-8b", required=True)
    args = parser.parse_args()
    records = [
        {"alpha": 0.0, "output_rel_mse": 2.0, "shape_score": 1.0},
        {"alpha": 0.5, "output_rel_mse": 1.0, "shape_score": 2.0},
    ]
    selected = select_records(records)
    assert selected["no_scaling"]["alpha"] == 0.0
    assert selected["output_only"]["alpha"] == 0.5
    assert selected["csd_only"]["alpha"] == 0.0
    assert selected["output_csd"]["alpha"] == 0.5
    output = [
        validate("1b", args.source_1b, args.expected_1b),
        validate("8b", args.source_8b, args.expected_8b),
    ]
    print(json.dumps({"status": "passed", "models": output}, indent=2))


if __name__ == "__main__":
    main()
