import argparse
import json
import math
import os
import sys
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")

import torch


EXP_DIR = Path(__file__).resolve().parent
ROOT = next(parent for parent in EXP_DIR.parents if (parent / "quantize.py").exists())
REFINE_DIR = ROOT / "experiments" / "method30_postawq_refine"
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
for path in (ROOT, REFINE_DIR, METHOD25_DIR, EXP_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import experiment_runtime as runtime  # noqa: E402
from layer_timing import LINEAR_TO_ACTIVATION, load_activations  # noqa: E402
from method30_refine import (  # noqa: E402
    initialize_state,
    reconstruct_from_state,
    refine_state,
    state_diagnostics,
)
from state_cache import atomic_write_json, outlier_mask_from_positions  # noqa: E402


def layer_parts(name):
    parts = name.split(".")
    return int(parts[2]), ".".join(parts[3:])


@torch.no_grad()
def grouped_csd(scaled_weight, group_size, outlier_positions=None, row_chunk=256):
    rows, cols = scaled_weight.shape
    groups_per_row = cols // group_size
    total = 0.0
    factor = 2.0 * groups_per_row / (groups_per_row - 1)
    for start in range(0, rows, row_chunk):
        stop = min(start + row_chunk, rows)
        groups = scaled_weight[start:stop].reshape(
            stop - start, groups_per_row, group_size
        )
        if outlier_positions is not None:
            mask = torch.ones_like(groups, dtype=torch.bool)
            mask.scatter_(2, outlier_positions[start:stop].long().unsqueeze(2), False)
            groups = groups[mask].reshape(stop - start, groups_per_row, group_size - 1)
        sorted_groups = groups.sort(dim=2).values
        minimum = sorted_groups[:, :, :1]
        value_range = sorted_groups[:, :, -1:] - minimum
        normalized = torch.where(
            value_range >= 1e-6,
            (sorted_groups - minimum) / value_range.clamp_min(1e-6),
            torch.zeros_like(sorted_groups),
        )
        row_scores = (
            (normalized - normalized.mean(dim=1, keepdim=True))
            .square()
            .mean(dim=(1, 2))
            * factor
        )
        total += row_scores.double().sum().item()
    return float(total / rows)


@torch.no_grad()
def final_output_error(activation, source, reconstructed):
    x = activation.to(device=source.device, dtype=torch.float32)
    source32 = source.float()
    reconstructed32 = reconstructed.float()
    reference = x @ source32.t()
    residual = x @ (source32 - reconstructed32).t()
    numerator = residual.square().sum().double().item()
    denominator = reference.square().sum().double().item()
    return float(numerator), float(max(denominator, 1e-12))


@torch.no_grad()
def execute(args):
    runtime.setup_hardware(args)
    bundle, model, _, linears = runtime.load_context(args)
    name, module, stats = next(
        item for item in linears if layer_parts(item[0])[1] in LINEAR_TO_ACTIVATION
    )
    source = module.weight.detach().to("cuda:0")
    state = initialize_state(
        source,
        stats["channel_scale"],
        stats["fisher"],
        group_size=args.group_size,
        initializer="sklearn",
        parallel_jobs=args.parallel_jobs,
        relative_tol=1e-6,
        ridge=1e-6,
        scale_eps=1e-6,
        chunk_rows=128,
        importance_chunk_rows=512,
        loss_increase_rtol=1e-7,
    )
    state = refine_state(source, state, args.target_iters)
    reconstructed = reconstruct_from_state(source, state)
    diagnostics = state_diagnostics(state)
    if not diagnostics["loss_monotonic"]:
        raise AssertionError("Smoke loss is not monotonic")
    if not torch.isfinite(reconstructed).all():
        raise AssertionError("Smoke reconstruction contains non-finite values")
    rows, cols = source.shape
    positions = state["outlier_positions"].to(source.device)
    expected_positions = rows * (cols // args.group_size)
    if positions.numel() != expected_positions:
        raise AssertionError("Smoke outlier count does not equal one per group")
    if positions.min() < 0 or positions.max() >= args.group_size:
        raise AssertionError("Smoke outlier position is outside the group")
    mask = outlier_mask_from_positions(positions, cols, args.group_size)
    if not torch.equal(reconstructed[mask], source[mask]):
        raise AssertionError("Smoke exact outliers were not reconstructed exactly")
    scaled_source = source.float() * state["channel_scale"].to(source.device).reshape(1, -1)
    csd = grouped_csd(scaled_source, args.group_size)
    regular_csd = grouped_csd(scaled_source, args.group_size, positions)
    block, local_name = layer_parts(name)
    activations = load_activations(args.activation_cache, block)
    numerator, denominator = final_output_error(
        activations[LINEAR_TO_ACTIVATION[local_name]], source, reconstructed
    )
    result = {
        "status": "passed",
        "model": args.model,
        "layer": name,
        "weight_shape": [rows, cols],
        "alpha": float(stats["alpha"]),
        "outlier_count": int(mask.sum().item()),
        "expected_outlier_count": expected_positions,
        "csd": float(csd),
        "regular_csd_post_outlier": float(regular_csd),
        "final_j": float(diagnostics["final_weighted_loss"]),
        "final_output_error": float(numerator / denominator),
        "iterations": int(diagnostics["iterations"]),
        "rollback": bool(diagnostics["rollback"]),
        "all_finite": bool(
            all(math.isfinite(float(value)) for value in diagnostics["losses"])
        ),
    }
    atomic_write_json(args.output, result)
    print(json.dumps(result, indent=2))
    return result


def build_parser():
    parser = argparse.ArgumentParser(description="Single-Linear GPU smoke for CSD ablation")
    parser.add_argument("--model", choices=("1b", "8b"), required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--stats-bundle", required=True)
    parser.add_argument("--activation-cache", required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--parallel-jobs", type=int, default=8)
    parser.add_argument("--target-iters", type=int, default=2)
    parser.add_argument("--cpu-list", default="auto")
    parser.add_argument("--empty-threshold-mib", type=int, default=256)
    parser.add_argument("--empty-utilization-percent", type=int, default=5)
    return parser


if __name__ == "__main__":
    execute(build_parser().parse_args())
