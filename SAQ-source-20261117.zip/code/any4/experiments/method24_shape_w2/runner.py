import argparse
import gc
import json
import os
import sys
import time
import traceback
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from data_gptq import get_loaders, llama_eval
from pre_process.awq.pre_quant import run_awq
from quantize import quant_methods, quantize_model
from method24_shape import (
    BASELINES,
    METHOD_NAME,
    ScaledActivationCollector,
    ShapeW2Searcher,
    write_json,
)


DEFAULT_MODEL = "/data/model/alpindale-Llama-3.2-1B"
DEFAULT_DATASET_CACHE = "/home/ubuntu/.cache/huggingface/datasets"
DEFAULT_CACHE = "/data/lsz/any4/experiments/method24_shape_w2/cache"


def _gpu_memory(physical_gpu):
    import subprocess

    output = subprocess.check_output(
        [
            "nvidia-smi",
            f"--id={physical_gpu}",
            "--query-gpu=memory.used",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    return int(output.strip().splitlines()[0])


def _load_model(model_path):
    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
        low_cpu_mem_usage=True,
    )
    model.eval()
    return model, tokenizer


def _eval_wiki2(model, tokenizer, loader_samples, seqlen):
    _, testloader = get_loaders(
        "wikitext-2",
        tokenizer=tokenizer,
        seed=0,
        seqlen=seqlen,
        nsamples=loader_samples,
    )
    return llama_eval(model, testloader, "cuda", seqlen=seqlen)


def _write_state(run_dir, state, status, **updates):
    state.update(updates)
    state["status"] = status
    write_json(Path(run_dir) / "summary.json", state)


def execute(args):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible != str(args.physical_gpu):
        raise RuntimeError(
            f"Expected CUDA_VISIBLE_DEVICES={args.physical_gpu}, got {visible!r}"
        )
    initial_memory = _gpu_memory(args.physical_gpu)
    if initial_memory > args.empty_threshold_mib:
        raise RuntimeError(
            f"GPU {args.physical_gpu} is not empty: {initial_memory} MiB"
        )

    if not 1 <= args.parallel_jobs <= 16:
        raise ValueError(
            f"parallel_jobs must be between 1 and 16, got {args.parallel_jobs}"
        )
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
    os.environ.setdefault("HF_DATASETS_CACHE", DEFAULT_DATASET_CACHE)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    run_dir = Path(args.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    timings = {}
    total_started = time.perf_counter()
    state = {
        "method": METHOD_NAME,
        "physical_gpu": str(args.physical_gpu),
        "initial_gpu_memory_mib": initial_memory,
        "model_path": args.model_path,
        "dataset": "wikitext-2-raw-v1",
        "baselines": BASELINES,
        "parameters": vars(args),
        "timings": timings,
    }
    _write_state(run_dir, state, "loading_model")

    load_started = time.perf_counter()
    model, tokenizer = _load_model(args.model_path)
    timings["model_load_seconds"] = time.perf_counter() - load_started

    searcher = ShapeW2Searcher(
        model=model,
        run_dir=run_dir,
        cache_dir=args.cache_dir,
        model_path=args.model_path,
        search_tokens=args.search_tokens,
        group_size=args.group_size,
        row_chunk=args.row_chunk,
    )
    collector = ScaledActivationCollector(model)

    _write_state(run_dir, state, "shape_search")
    awq_started = time.perf_counter()
    awq_results = run_awq(
        model=model,
        enc=tokenizer,
        w_bit=4,
        q_config={
            "q_group_size": args.group_size,
            "zero_point": True,
        },
        n_samples=args.awq_calib_samples,
        seqlen=args.awq_calib_seqlen,
        auto_scale=True,
        mse_range=False,
        calib_data="wikitext2",
        scale_search_fn=searcher,
        input_feat_callback=collector,
    )
    awq_elapsed = time.perf_counter() - awq_started
    shape_elapsed = sum(
        record["elapsed_seconds"] for record in searcher.records
    )
    timings["shape_search_seconds"] = shape_elapsed
    timings["activation_collection_and_scale_fusion_seconds"] = max(
        awq_elapsed - shape_elapsed,
        0.0,
    )
    timings["awq_total_seconds"] = awq_elapsed

    torch.save(
        {
            "method": METHOD_NAME,
            "model_path": args.model_path,
            "scale": awq_results["scale"],
            "records": searcher.records,
        },
        run_dir / "selected_scales.pt",
    )
    torch.save(
        {
            "method": METHOD_NAME,
            "model_path": args.model_path,
            "dataset": "wikitext-2-raw-v1",
            "sample_weight": collector.weights,
        },
        run_dir / "scaled_activation_stats.pt",
    )
    if not collector.weights:
        raise RuntimeError("No scaled activation statistics were collected")

    _write_state(
        run_dir,
        state,
        "full_any4_quantization",
        selected_scale_units=len(searcher.records),
        scaled_activation_layers=len(collector.weights),
    )
    quant_weights = {
        name: value.clone() for name, value in collector.weights.items()
    }
    quant_started = time.perf_counter()
    model = quantize_model(
        model,
        layer_from=torch.nn.Linear,
        layer_to=quant_methods["anyq"],
        skip_modules="lm_head",
        n_bit=4,
        group_size=args.group_size,
        cluster_row="scikit",
        sample_weight=quant_weights,
        scale_sample_weight=True,
        parallelize=True,
        parallel_jobs=args.parallel_jobs,
        parallel_backend="loky",
        parallel_inner_threads=1,
        parallel_pre_dispatch="2*n_jobs",
        pseudo=True,
    )
    timings["full_any4_quantization_seconds"] = (
        time.perf_counter() - quant_started
    )

    _write_state(run_dir, state, "wiki2_ppl")
    model.to("cuda")
    model.eval()
    ppl_started = time.perf_counter()
    ppl = _eval_wiki2(
        model,
        tokenizer,
        loader_samples=args.loader_samples,
        seqlen=args.ppl_seqlen,
    )
    timings["wiki2_ppl_seconds"] = time.perf_counter() - ppl_started
    timings["total_seconds"] = time.perf_counter() - total_started

    results = {
        "method": METHOD_NAME,
        "wiki2_ppl": float(ppl),
        "fp16_ppl": BASELINES["fp16_ppl"],
        "original_any4_4bit_ppl": BASELINES["original_any4_4bit_ppl"],
        "method2_dp_ppl": BASELINES["method2_dp_ppl"],
        "selected_scale_units": len(searcher.records),
        "scaled_activation_layers": len(collector.weights),
        "timings": timings,
    }
    write_json(run_dir / "results.json", results)
    _write_state(run_dir, state, "complete", results=results)

    print(json.dumps(results, indent=2), flush=True)
    del model, tokenizer
    gc.collect()
    torch.cuda.empty_cache()
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description=METHOD_NAME)
    parser.add_argument("--model-path", default=DEFAULT_MODEL)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--physical-gpu", required=True)
    parser.add_argument("--empty-threshold-mib", type=int, default=100)
    parser.add_argument("--search-tokens", type=int, default=256)
    parser.add_argument("--group-size", type=int, default=128)
    parser.add_argument("--row-chunk", type=int, default=256)
    parser.add_argument("--parallel-jobs", type=int, default=16)
    parser.add_argument("--awq-calib-samples", type=int, default=128)
    parser.add_argument("--awq-calib-seqlen", type=int, default=512)
    parser.add_argument("--loader-samples", type=int, default=128)
    parser.add_argument("--ppl-seqlen", type=int, default=2048)
    parser.add_argument("--cache-dir", default=DEFAULT_CACHE)
    return parser


def main():
    args = build_parser().parse_args()
    run_dir = Path(args.run_dir)
    try:
        return execute(args)
    except Exception as exc:
        run_dir.mkdir(parents=True, exist_ok=True)
        failure = {
            "method": METHOD_NAME,
            "status": "failed",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        write_json(run_dir / "failure.json", failure)
        print(failure["traceback"], file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

