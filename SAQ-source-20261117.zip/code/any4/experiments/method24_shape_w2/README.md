# Method24: AWQ shape-W2 search followed by Any4

Method24 searches AWQ alpha using only the mean within-row pairwise squared
Wasserstein-2 distance between sorted, independently min-max-normalized groups.
The score is computed through the equivalent mean-curve variance identity.

The search does not call sklearn, DP, Lloyd, or any quantizer. After all selected
scales are fused with the existing AWQ propagation rules, activation statistics
are collected from the scaled model and the original scikit Any4 fake
quantization runs exactly once.

Smoke test:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  /data/lsz/any4/venv/bin/python tests/test_method24_shape_w2.py
```

Single-empty-GPU run:

```bash
/data/lsz/any4/venv/bin/python run_method24_shape_w2.py --max-gpus 1
```

Logs are written below
`logs/llama3.2-1b/wiki2_method24_shape_w2_<timestamp>_gpu<id>/`.

