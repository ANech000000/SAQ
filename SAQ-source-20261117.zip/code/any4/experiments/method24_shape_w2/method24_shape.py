import hashlib
import json
import math
import time
from pathlib import Path

import torch

from pre_process.awq.utils import get_op_name


METHOD_NAME = "method24_shape_w2_awq_any4"
COARSE_ALPHAS = (0.0, 0.25, 0.5, 0.75, 1.0)
LOCAL_OFFSETS = (-0.15, -0.05, 0.05, 0.15)
BASELINES = {
    "fp16_ppl": 9.750678062438965,
    "original_any4_4bit_ppl": 10.618475914001465,
    "method2_dp_ppl": 10.555562973022461,
}


def _safe_name(value):
    return "".join(ch if ch.isalnum() or ch in "._-" else "__" for ch in value)


def _json_ready(value):
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if torch.is_tensor(value):
        return value.detach().cpu().tolist()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_ready(payload), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def sample_tokens(x, limit):
    flat = x.detach().reshape(-1, x.shape[-1])
    if flat.shape[0] <= limit:
        return flat.float()
    indices = torch.linspace(
        0,
        flat.shape[0] - 1,
        steps=limit,
        device=flat.device,
    ).round().long()
    return flat.index_select(0, indices).float()


def build_awq_scale(x_abs, alpha):
    scale = x_abs.float().pow(float(alpha)).clamp(min=1e-4)
    normalizer = (scale.max() * scale.min()).sqrt().clamp(min=1e-8)
    scale = scale / normalizer
    if not torch.isfinite(scale).all():
        raise ValueError(f"Non-finite AWQ scale for alpha={alpha}")
    return scale


@torch.no_grad()
def shape_w2_score(
    scaled_weight,
    group_size=128,
    row_chunk=256,
    include_row_scores=False,
):
    if scaled_weight.dim() != 2:
        raise ValueError(f"Expected 2D weight, got {tuple(scaled_weight.shape)}")
    rows, cols = scaled_weight.shape
    if cols % group_size:
        raise ValueError(
            f"Input columns {cols} are not divisible by group_size={group_size}"
        )
    if not torch.isfinite(scaled_weight).all():
        raise ValueError("Shape score received non-finite weights")

    groups_per_row = cols // group_size
    if groups_per_row == 1:
        row_scores = torch.zeros(rows, dtype=torch.float64)
        diagnostics = {
            "score": 0.0,
            "rows": int(rows),
            "groups_per_row": 1,
            "constant_groups": 0,
            "row_score_min": 0.0,
            "row_score_mean": 0.0,
            "row_score_median": 0.0,
            "row_score_max": 0.0,
        }
        if include_row_scores:
            diagnostics["row_scores"] = row_scores
        return 0.0, diagnostics

    total_score = 0.0
    constant_groups = 0
    row_score_parts = []
    pairwise_factor = 2.0 * groups_per_row / (groups_per_row - 1)

    work = scaled_weight.detach().float()
    for start in range(0, rows, row_chunk):
        stop = min(start + row_chunk, rows)
        groups = work[start:stop].reshape(
            stop - start,
            groups_per_row,
            group_size,
        )
        sorted_groups = groups.sort(dim=2).values
        group_min = sorted_groups[:, :, :1]
        group_range = sorted_groups[:, :, -1:] - group_min
        valid_range = group_range >= 1e-6
        normalized = torch.where(
            valid_range,
            (sorted_groups - group_min) / group_range.clamp_min(1e-6),
            torch.zeros_like(sorted_groups),
        )
        mean_curve = normalized.mean(dim=1, keepdim=True)
        curve_variance = (normalized - mean_curve).square().mean(dim=(1, 2))
        row_scores = curve_variance * pairwise_factor
        total_score += row_scores.double().sum().item()
        constant_groups += int((~valid_range).sum().item())
        row_score_parts.append(row_scores.detach().double().cpu())

    all_row_scores = torch.cat(row_score_parts)
    score = total_score / max(rows, 1)
    diagnostics = {
        "score": float(score),
        "rows": int(rows),
        "groups_per_row": int(groups_per_row),
        "constant_groups": int(constant_groups),
        "row_score_min": all_row_scores.min().item(),
        "row_score_mean": all_row_scores.mean().item(),
        "row_score_median": all_row_scores.median().item(),
        "row_score_max": all_row_scores.max().item(),
    }
    if include_row_scores:
        diagnostics["row_scores"] = all_row_scores
    return float(score), diagnostics


@torch.no_grad()
def explicit_pairwise_shape_w2(scaled_weight, group_size=128):
    rows, cols = scaled_weight.shape
    groups_per_row = cols // group_size
    if groups_per_row <= 1:
        return 0.0
    groups = scaled_weight.float().reshape(rows, groups_per_row, group_size)
    sorted_groups = groups.sort(dim=2).values
    group_min = sorted_groups[:, :, :1]
    group_range = sorted_groups[:, :, -1:] - group_min
    normalized = torch.where(
        group_range >= 1e-6,
        (sorted_groups - group_min) / group_range.clamp_min(1e-6),
        torch.zeros_like(sorted_groups),
    )
    pair_scores = []
    for left in range(groups_per_row):
        for right in range(left + 1, groups_per_row):
            pair_scores.append(
                (normalized[:, left] - normalized[:, right]).square().mean(dim=1)
            )
    return torch.stack(pair_scores, dim=1).mean().item()


@torch.no_grad()
def evaluate_shape_unit(
    linears,
    x,
    alpha,
    group_size=128,
    row_chunk=256,
):
    x_abs = x.detach().float().abs().mean(dim=0)
    scale = build_awq_scale(x_abs, alpha).to(x.device)
    per_linear = []
    weighted_sum = 0.0
    total_rows = 0
    started = time.perf_counter()

    for linear in linears:
        weight = linear.weight.detach().to(x.device)
        scaled_weight = weight.float() * scale.view(1, -1)
        score, diagnostics = shape_w2_score(
            scaled_weight,
            group_size=group_size,
            row_chunk=row_chunk,
        )
        rows = int(weight.shape[0])
        weighted_sum += score * rows
        total_rows += rows
        per_linear.append(diagnostics)
        del scaled_weight

    return {
        "shape_score": weighted_sum / max(total_rows, 1),
        "rows": int(total_rows),
        "per_linear": per_linear,
        "elapsed_seconds": time.perf_counter() - started,
    }


def candidate_alphas(coarse_scores):
    coarse_best = min(
        COARSE_ALPHAS,
        key=lambda alpha: (coarse_scores[float(alpha)]["shape_score"], alpha),
    )
    local = tuple(coarse_best + offset for offset in LOCAL_OFFSETS)
    return sorted(
        {
            round(min(1.0, max(0.0, float(alpha))), 6)
            for alpha in tuple(COARSE_ALPHAS) + local
        }
    )


def select_best_alpha(scores):
    return min(
        scores,
        key=lambda alpha: (scores[alpha]["shape_score"], float(alpha)),
    )


def _weight_fingerprint(linears):
    digest = hashlib.sha256()
    for linear in linears:
        weight = linear.weight.detach()
        digest.update(str(tuple(weight.shape)).encode("ascii"))
        digest.update(weight.reshape(-1)[:64].float().cpu().numpy().tobytes())
        digest.update(str(float(weight.float().sum().item())).encode("ascii"))
    return digest.hexdigest()


class ShapeW2Searcher:
    def __init__(
        self,
        model,
        run_dir,
        cache_dir,
        model_path,
        search_tokens=256,
        group_size=128,
        row_chunk=256,
    ):
        self.model = model
        self.run_dir = Path(run_dir)
        self.cache_dir = Path(cache_dir)
        self.model_path = str(model_path)
        self.search_tokens = int(search_tokens)
        self.group_size = int(group_size)
        self.row_chunk = int(row_chunk)
        self.module_names = {
            id(module): name for name, module in model.named_modules()
        }
        self.records = []

    def _unit_names(self, parent_module, linears):
        parent_name = self.module_names[id(parent_module)]
        local_names = [get_op_name(parent_module, linear) for linear in linears]
        full_names = [f"{parent_name}.{name}" for name in local_names]
        return parent_name, local_names, full_names

    def _cached_x(self, unit_name, x):
        current = sample_tokens(x, self.search_tokens).detach().cpu()
        suffix = f"{self.search_tokens}_{current.shape[-1]}"
        cache_path = (
            self.cache_dir
            / "activations"
            / f"{_safe_name(unit_name)}_{suffix}.pt"
        )
        if cache_path.exists():
            payload = torch.load(
                cache_path,
                map_location="cpu",
                weights_only=False,
            )
            cached = payload.get("x")
            if (
                payload.get("method") == METHOD_NAME
                and payload.get("model_path") == self.model_path
                and payload.get("unit_name") == unit_name
                and torch.is_tensor(cached)
                and tuple(cached.shape) == tuple(current.shape)
            ):
                return cached.to(x.device), True
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        if not cache_path.exists():
            torch.save(
                {
                    "method": METHOD_NAME,
                    "model_path": self.model_path,
                    "unit_name": unit_name,
                    "search_tokens": self.search_tokens,
                    "shape": list(current.shape),
                    "x": current,
                },
                cache_path,
            )
        return current.to(x.device), False

    def __call__(
        self,
        parent_module,
        prev_op,
        block,
        linears2scale,
        x,
        kwargs,
    ):
        parent_name, local_names, full_names = self._unit_names(
            parent_module,
            linears2scale,
        )
        unit_name = "+".join(full_names)
        x_search, activation_cache_hit = self._cached_x(unit_name, x)
        fingerprint_before = _weight_fingerprint(linears2scale)
        started = time.perf_counter()

        scores = {}
        for alpha in COARSE_ALPHAS:
            scores[float(alpha)] = evaluate_shape_unit(
                linears2scale,
                x_search,
                alpha,
                group_size=self.group_size,
                row_chunk=self.row_chunk,
            )
        alphas = candidate_alphas(scores)
        for alpha in alphas:
            if alpha not in scores:
                scores[alpha] = evaluate_shape_unit(
                    linears2scale,
                    x_search,
                    alpha,
                    group_size=self.group_size,
                    row_chunk=self.row_chunk,
                )

        selected_alpha = select_best_alpha(scores)
        fingerprint_after = _weight_fingerprint(linears2scale)
        if fingerprint_before != fingerprint_after:
            raise RuntimeError(f"Shape search modified weights for {unit_name}")

        x_abs = x_search.abs().mean(dim=0)
        selected_scale = build_awq_scale(x_abs, selected_alpha).detach()
        for score in scores.values():
            for name, diagnostics in zip(full_names, score["per_linear"]):
                diagnostics["linear_name"] = name

        record = {
            "method": METHOD_NAME,
            "unit_name": unit_name,
            "parent_module": parent_name,
            "prev_op": self.module_names.get(
                id(prev_op),
                get_op_name(parent_module, prev_op),
            ),
            "linear_names": full_names,
            "candidate_alphas": alphas,
            "scores": {str(alpha): scores[alpha] for alpha in alphas},
            "selected_alpha": selected_alpha,
            "selected_shape_score": scores[selected_alpha]["shape_score"],
            "search_tokens": int(x_search.shape[0]),
            "activation_cache_hit": activation_cache_hit,
            "weight_fingerprint": fingerprint_before,
            "elapsed_seconds": time.perf_counter() - started,
        }
        self.records.append(record)
        write_json(
            self.run_dir / "shape_units" / f"{_safe_name(unit_name)}.json",
            record,
        )
        write_json(
            self.run_dir / "shape_search_results.json",
            self.records,
        )
        print(
            f"Shape search complete: {unit_name}, "
            f"alpha={selected_alpha}, score={record['selected_shape_score']:.8f}",
            flush=True,
        )
        del x_search
        return selected_scale


class ScaledActivationCollector:
    def __init__(self, model):
        self.module_names = {
            id(module): name for name, module in model.named_modules()
        }
        self.weights = {}

    def __call__(self, model, layer, input_feat):
        prefix = self.module_names[id(layer)]
        for local_name, activation in input_feat.items():
            full_name = f"{prefix}.{local_name}"
            values = activation.detach().reshape(
                -1,
                activation.shape[-1],
            ).float()
            self.weights[full_name] = values.abs().mean(dim=0).cpu()

