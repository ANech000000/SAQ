#!/usr/bin/env bash
set -euo pipefail

cd /data/lsz/any4

GPU="${1:-7}"
STAMP="$(date +%Y%m%d_%H%M%S)"
EXP="logs/llama3.2-1b/wiki2_method8_spin_any4_${STAMP}_gpu${GPU}"
mkdir -p "$EXP"
echo "$EXP" > /tmp/any4_method8_latest_exp.txt
export HF_DATASETS_OFFLINE=1
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

{
  echo "start_$(date +%Y%m%d_%H%M%S)"
  echo "gpu=$GPU"
  echo "gpu_before"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
  CUDA_VISIBLE_DEVICES="$GPU" ./venv/bin/python run_method8_spin_any4_wiki2.py \
    --log-dir "$EXP" \
    --seed 0 \
    --loader-samples 128 \
    --seqlen 2048
  echo "gpu_after"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
  echo "done_$(date +%Y%m%d_%H%M%S)"
} | tee "$EXP/run.log"
