import inspect
import sys
from pathlib import Path

import torch

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent / "quantize.py").exists())
METHOD_DIR = ROOT / "experiments" / "method21_awq_any4"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(METHOD_DIR))

from awq_any4_proxy import (
    build_awq_scale,
    evaluate_proxy,
    evaluate_true_any4,
    quantile_proxy_quantize,
)
from pre_process.awq.auto_scale import auto_scale_block
from pre_process.awq.pre_quant import run_awq


def test_proxy_shape_and_finite():
    torch.manual_seed(0)
    weight = torch.randn(12, 256)
    reconstructed, diagnostics = quantile_proxy_quantize(weight, group_size=128)
    assert reconstructed.shape == weight.shape
    assert torch.isfinite(reconstructed).all()
    assert diagnostics["proxy_shared_lut_sse"] >= 0
    assert diagnostics["mean_group_range"] > 0


def test_proxy_constant_groups():
    weight = torch.ones(4, 256)
    reconstructed, _ = quantile_proxy_quantize(weight, group_size=128)
    assert torch.allclose(reconstructed, weight, atol=1e-5)


def test_awq_float_equivalence_and_no_mutation():
    torch.manual_seed(1)
    linear = torch.nn.Linear(256, 32, bias=False)
    x = torch.randn(64, 256)
    original = linear.weight.detach().clone()
    scale = build_awq_scale(x.abs().mean(0), 0.5)
    restored = (original.float() * scale.view(1, -1)) / scale.view(1, -1)
    assert torch.allclose(restored, original.float(), rtol=1e-6, atol=1e-7)
    result = evaluate_proxy([linear], x, alpha=0.5, group_size=128)
    assert result["output_error"] >= 0
    assert torch.equal(linear.weight, original)


def test_true_any4_small_linear_no_mutation():
    torch.manual_seed(2)
    linear = torch.nn.Linear(256, 16, bias=False)
    x = torch.randn(32, 256)
    original = linear.weight.detach().clone()
    result = evaluate_true_any4(
        [linear],
        x,
        alpha=0.5,
        group_size=128,
        parallel_jobs=2,
    )
    assert result["output_error"] >= 0
    assert torch.equal(linear.weight, original)


def test_awq_callbacks_are_additive():
    assert "scale_search_fn" in inspect.signature(auto_scale_block).parameters
    signature = inspect.signature(run_awq)
    assert "scale_search_fn" in signature.parameters
    assert "input_feat_callback" in signature.parameters


if __name__ == "__main__":
    test_proxy_shape_and_finite()
    test_proxy_constant_groups()
    test_awq_float_equivalence_and_no_mutation()
    test_true_any4_small_linear_no_mutation()
    test_awq_callbacks_are_additive()
    print("method21 proxy smoke passed")

