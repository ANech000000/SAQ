import os
import sys
from pathlib import Path

os.environ["NUMEXPR_MAX_THREADS"] = "64"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

import numpy as np
import torch


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
sys.path.insert(0, str(ROOT))

import quantize


def _input(rows=24, columns=128):
    rng = np.random.default_rng(20260714)
    values = rng.normal(size=(rows, columns)).astype(np.float32)
    sample_weight = np.abs(rng.normal(size=(columns,))).astype(np.float32)
    return values, sample_weight


def test_loky_matches_serial_scikit_kmeans():
    values, sample_weight = _input()
    serial = quantize.cluster_rows_parallel(
        values,
        cluster_row=quantize.cluster_row_scikit,
        n_bit=4,
        sample_weight=sample_weight,
        parallel_jobs=1,
        parallel_backend="threading",
        parallel_inner_threads=1,
    )
    parallel = quantize.cluster_rows_parallel(
        values,
        cluster_row=quantize.cluster_row_scikit,
        n_bit=4,
        sample_weight=sample_weight,
        parallel_jobs=2,
        parallel_backend="loky",
        parallel_inner_threads=1,
    )

    for serial_tensor, parallel_tensor in zip(serial, parallel):
        assert torch.equal(serial_tensor, parallel_tensor)


def test_parallel_backend_options():
    values, sample_weight = _input(rows=2)
    captured = {}

    class InlineParallel:
        def __init__(self, **kwargs):
            captured.clear()
            captured.update(kwargs)

        def __call__(self, tasks):
            return [
                function(*args, **kwargs)
                for function, args, kwargs in tasks
            ]

    original_parallel = quantize.Parallel
    quantize.Parallel = InlineParallel
    quantize.cluster_rows_parallel(
        values,
        cluster_row=quantize.cluster_row_scikit,
        n_bit=4,
        sample_weight=sample_weight,
        parallel_jobs=16,
        parallel_backend="loky",
        parallel_inner_threads=1,
    )
    assert captured == {
        "n_jobs": 16,
        "backend": "loky",
        "batch_size": "auto",
        "pre_dispatch": "2*n_jobs",
        "inner_max_num_threads": 1,
    }

    quantize.cluster_rows_parallel(
        values,
        cluster_row=quantize.cluster_row_scikit,
        n_bit=4,
        sample_weight=sample_weight,
        parallel_jobs=1,
        parallel_backend="threading",
        parallel_inner_threads=1,
    )
    assert captured == {
        "n_jobs": 1,
        "backend": "threading",
        "batch_size": "auto",
        "pre_dispatch": "2*n_jobs",
    }
    quantize.Parallel = original_parallel


if __name__ == "__main__":
    test_loky_matches_serial_scikit_kmeans()
    test_parallel_backend_options()
    print("parallel sklearn KMeans backend tests passed")
