import sys
from pathlib import Path

import torch


ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD25_DIR = ROOT / "experiments" / "method25_linear_recon_shape"
sys.path.insert(0, str(METHOD25_DIR))

from layer_timing import (
    effective_weight,
    fine_alphas,
    objective_fine_alphas,
    select_output_only,
    select_shape_regularized,
    select_with_shape_auxiliary,
)


def test_effective_weight_inverts_channel_scale():
    torch.manual_seed(25)
    weight = torch.randn(4, 8)
    scale = torch.rand(8) + 0.1
    scaled = weight * scale.view(1, -1)
    reconstructed = effective_weight(scaled, scale)
    assert torch.allclose(reconstructed, weight, rtol=1e-6, atol=1e-7)


def test_shape_is_auxiliary_inside_output_error_band():
    records = [
        {"alpha": 0.0, "output_rel_mse": 0.1, "shape_score": 0.2},
        {"alpha": 0.25, "output_rel_mse": 0.1004, "shape_score": 0.1},
        {"alpha": 0.5, "output_rel_mse": 0.101, "shape_score": 0.0},
    ]
    selected = select_with_shape_auxiliary(records, error_band=0.005)
    assert selected["alpha"] == 0.25


def test_output_only_and_normalized_shape_regularization():
    records = [
        {"alpha": 0.0, "output_rel_mse": 0.2, "shape_score": 0.1},
        {"alpha": 0.25, "output_rel_mse": 0.18, "shape_score": 0.2},
        {"alpha": 0.5, "output_rel_mse": 0.17, "shape_score": 0.4},
    ]
    assert select_output_only(records)["alpha"] == 0.5
    selected = select_shape_regularized(records, regularization=0.1)
    assert selected["alpha"] == 0.25


def test_objective_fine_search_covers_distinct_coarse_winners():
    coarse = [
        {"alpha": 0.0, "output_rel_mse": 0.2, "shape_score": 0.1},
        {"alpha": 0.25, "output_rel_mse": 0.18, "shape_score": 0.2},
        {"alpha": 0.5, "output_rel_mse": 0.17, "shape_score": 0.4},
        {"alpha": 0.75, "output_rel_mse": 0.3, "shape_score": 0.5},
        {"alpha": 1.0, "output_rel_mse": 0.4, "shape_score": 0.6},
    ]
    fine = objective_fine_alphas(coarse, regularization=0.1)
    assert set((0.1, 0.2, 0.3, 0.35, 0.45, 0.55, 0.65)) <= set(fine)


def test_fine_search_is_local_and_deduplicated():
    coarse = [
        {"alpha": 0.0, "output_rel_mse": 0.3, "shape_score": 0.3},
        {"alpha": 0.25, "output_rel_mse": 0.2, "shape_score": 0.2},
        {"alpha": 0.5, "output_rel_mse": 0.1, "shape_score": 0.1},
        {"alpha": 0.75, "output_rel_mse": 0.2, "shape_score": 0.2},
        {"alpha": 1.0, "output_rel_mse": 0.3, "shape_score": 0.3},
    ]
    assert fine_alphas(coarse) == [0.35, 0.45, 0.55, 0.65]


if __name__ == "__main__":
    test_effective_weight_inverts_channel_scale()
    test_shape_is_auxiliary_inside_output_error_band()
    test_output_only_and_normalized_shape_regularization()
    test_objective_fine_search_covers_distinct_coarse_winners()
    test_fine_search_is_local_and_deduplicated()
    print("method25 per-linear reconstruction objective tests passed")
