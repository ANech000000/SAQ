import sys
from pathlib import Path

import torch

ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "quantize.py").exists()
)
METHOD_DIR = ROOT / "experiments" / "method24_shape_w2"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(METHOD_DIR))

from method24_shape import (
    build_awq_scale,
    evaluate_shape_unit,
    explicit_pairwise_shape_w2,
    select_best_alpha,
    shape_w2_score,
)
from pre_process.awq.auto_scale import scale_ln_fcs


def test_toy_pairwise_equivalence():
    weight = torch.tensor(
        [[-2.0, -1.0, 1.0, 2.0, 10.0, 14.0, 18.0, 26.0, 3.0, 5.0, 9.0, 11.0]]
    )
    fast, _ = shape_w2_score(weight, group_size=4)
    explicit = explicit_pairwise_shape_w2(weight, group_size=4)
    expected = (0.015625 + 0.0 + 0.015625) / 3.0
    assert abs(fast - explicit) < 1e-8
    assert abs(fast - expected) < 1e-8


def test_group_affine_invariance():
    base = torch.tensor(
        [[-2.0, -1.0, 1.0, 2.0, 10.0, 14.0, 18.0, 26.0, 3.0, 5.0, 9.0, 11.0]]
    )
    groups = base.reshape(1, 3, 4)
    scales = torch.tensor([2.5, 0.25, 4.0]).view(1, 3, 1)
    shifts = torch.tensor([7.0, -3.0, 20.0]).view(1, 3, 1)
    transformed = (groups * scales + shifts).reshape_as(base)
    original_score, _ = shape_w2_score(base, group_size=4)
    transformed_score, _ = shape_w2_score(transformed, group_size=4)
    assert abs(original_score - transformed_score) < 1e-8


def test_rows_are_independent():
    first = torch.tensor(
        [-2.0, -1.0, 1.0, 2.0, 10.0, 14.0, 18.0, 26.0, 3.0, 5.0, 9.0, 11.0]
    )
    second = torch.arange(12, dtype=torch.float32)
    weight = torch.stack([first, second])
    _, before = shape_w2_score(
        weight,
        group_size=4,
        include_row_scores=True,
    )
    changed = weight.clone()
    changed[1] = torch.tensor(
        [0.0, 0.0, 0.0, 8.0, -4.0, -1.0, 1.0, 4.0, 2.0, 2.0, 3.0, 20.0]
    )
    _, after = shape_w2_score(
        changed,
        group_size=4,
        include_row_scores=True,
    )
    assert before["row_scores"][0] == after["row_scores"][0]


def test_constant_and_single_groups():
    constant = torch.tensor([[2.0] * 4 + [9.0] * 4])
    score, diagnostics = shape_w2_score(constant, group_size=4)
    assert score == 0.0
    assert diagnostics["constant_groups"] == 2

    single = torch.randn(3, 4)
    score, diagnostics = shape_w2_score(single, group_size=4)
    assert score == 0.0
    assert diagnostics["groups_per_row"] == 1


def test_nonfinite_rejected():
    weight = torch.randn(2, 8)
    weight[0, 0] = float("nan")
    try:
        shape_w2_score(weight, group_size=4)
    except ValueError as exc:
        assert "non-finite" in str(exc)
    else:
        raise AssertionError("Non-finite weight was accepted")


def test_multiple_linears_are_row_weighted():
    torch.manual_seed(4)
    first = torch.nn.Linear(12, 1, bias=False)
    second = torch.nn.Linear(12, 3, bias=False)
    x = torch.randn(16, 12)
    result = evaluate_shape_unit(
        [first, second],
        x,
        alpha=0.0,
        group_size=4,
    )
    first_score, _ = shape_w2_score(first.weight, group_size=4)
    second_score, _ = shape_w2_score(second.weight, group_size=4)
    expected = (first_score + 3.0 * second_score) / 4.0
    assert abs(result["shape_score"] - expected) < 1e-7


def test_tie_selects_smaller_alpha():
    scores = {
        0.5: {"shape_score": 0.1},
        0.25: {"shape_score": 0.1},
        0.0: {"shape_score": 0.2},
    }
    assert select_best_alpha(scores) == 0.25


def test_search_has_no_kmeans_and_no_weight_mutation():
    import sklearn.cluster

    torch.manual_seed(5)
    linear = torch.nn.Linear(12, 4, bias=False)
    x = torch.randn(16, 12)
    original = linear.weight.detach().clone()
    old_kmeans = sklearn.cluster.KMeans

    class FailKMeans:
        def __init__(self, *args, **kwargs):
            raise AssertionError("Shape search called sklearn KMeans")

    sklearn.cluster.KMeans = FailKMeans
    try:
        result = evaluate_shape_unit(
            [linear],
            x,
            alpha=0.5,
            group_size=4,
        )
    finally:
        sklearn.cluster.KMeans = old_kmeans
    assert result["shape_score"] >= 0
    assert torch.equal(linear.weight, original)


def test_awq_fusion_keeps_scaled_weight_and_float_output():
    torch.manual_seed(6)
    norm = torch.nn.LayerNorm(12)
    first = torch.nn.Linear(12, 8)
    second = torch.nn.Linear(12, 4)
    x = torch.randn(5, 12)
    first_weight = first.weight.detach().clone()
    second_weight = second.weight.detach().clone()
    before_first = first(norm(x))
    before_second = second(norm(x))
    scale = build_awq_scale(x.abs().mean(0), 0.5)

    scale_ln_fcs(norm, [first, second], scale)

    assert torch.allclose(
        first.weight,
        first_weight * scale.view(1, -1),
        rtol=1e-6,
        atol=1e-7,
    )
    assert torch.allclose(
        second.weight,
        second_weight * scale.view(1, -1),
        rtol=1e-6,
        atol=1e-7,
    )
    assert torch.allclose(first(norm(x)), before_first, rtol=1e-5, atol=1e-6)
    assert torch.allclose(second(norm(x)), before_second, rtol=1e-5, atol=1e-6)


if __name__ == "__main__":
    test_toy_pairwise_equivalence()
    test_group_affine_invariance()
    test_rows_are_independent()
    test_constant_and_single_groups()
    test_nonfinite_rejected()
    test_multiple_linears_are_row_weighted()
    test_tie_selects_smaller_alpha()
    test_search_has_no_kmeans_and_no_weight_mutation()
    test_awq_fusion_keeps_scaled_weight_and_float_output()
    print("method24 shape-W2 tests passed")

