import gc
import hashlib
import json
import math
import os
import time
from pathlib import Path

import torch

import method12_quant
import method14_quant


METHOD16_NAME = "method16_hessian_sparse_repair"
METHOD16_VERSION = "method16_hessian_sparse_repair_v1"
_METHOD16_LAYER_STATS = {}


def reset_method16_stats():
    _METHOD16_LAYER_STATS.clear()


def get_method16_stats():
    return json.loads(json.dumps(_METHOD16_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD16_LAYER_STATS[layer_name or "<tensor>"] = stats


def _prepare_hessian(hessian, rows, cols, device):
    if not isinstance(hessian, dict):
        raise ValueError("Method16 requires a Hessian dictionary.")
    diag = hessian.get("diag")
    factors = hessian.get("factors")
    if not isinstance(diag, torch.Tensor) or not isinstance(factors, torch.Tensor):
        raise ValueError("Method16 Hessian must contain tensor diag and factors.")
    diag = torch.nan_to_num(
        diag.detach().to(device=device, dtype=torch.float32),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    ).clamp_min_(0.0)
    factors = torch.nan_to_num(
        factors.detach().to(device=device, dtype=torch.float32),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )
    if diag.ndim != 3 or factors.ndim != 4:
        raise ValueError("Method16 Hessian has invalid rank.")
    if tuple(factors.shape[:3]) != tuple(diag.shape):
        raise ValueError("Method16 Hessian diag and factors are incompatible.")
    output_groups, blocks, block_size = diag.shape
    if blocks * block_size != cols:
        raise ValueError("Method16 Hessian does not cover all input columns.")
    if rows % output_groups != 0:
        raise ValueError("Output rows must be divisible by Hessian output groups.")
    empty = (
        diag.sum(dim=(1, 2))
        + factors.square().sum(dim=(1, 2, 3))
    ) <= 0
    if empty.any():
        diag[empty] = 1.0
        factors[empty] = 0.0
    return diag, factors


def _guided_row_losses(error, diag, factors):
    rows, cols = error.shape
    output_groups, blocks, block_size = diag.shape
    rows_per_group = rows // output_groups
    losses = torch.empty(rows, device=error.device, dtype=torch.float32)
    for output_group in range(output_groups):
        row_start = output_group * rows_per_group
        row_stop = row_start + rows_per_group
        grouped = error[row_start:row_stop].reshape(
            rows_per_group,
            blocks,
            block_size,
        )
        diagonal = (
            grouped.square() * diag[output_group].unsqueeze(0)
        ).sum(dim=(1, 2))
        projection = torch.einsum(
            "rbi,bik->rbk",
            grouped,
            factors[output_group],
        )
        losses[row_start:row_stop] = diagonal + projection.square().sum(
            dim=(1, 2)
        )
    return losses


def _single_coordinate_gains(error, diag, factors):
    rows, cols = error.shape
    output_groups, blocks, block_size = diag.shape
    rows_per_group = rows // output_groups
    gains = torch.empty_like(error, dtype=torch.float32)
    for output_group in range(output_groups):
        row_start = output_group * rows_per_group
        row_stop = row_start + rows_per_group
        grouped = error[row_start:row_stop].reshape(
            rows_per_group,
            blocks,
            block_size,
        )
        group_factors = factors[output_group]
        projection = torch.einsum(
            "rbi,bik->rbk",
            grouped,
            group_factors,
        )
        gradient = grouped * diag[output_group].unsqueeze(0)
        gradient = gradient + torch.einsum(
            "rbk,bik->rbi",
            projection,
            group_factors,
        )
        hessian_diagonal = (
            diag[output_group]
            + group_factors.square().sum(dim=-1)
        ).unsqueeze(0)
        group_gains = (
            2.0 * grouped * gradient
            - grouped.square() * hessian_diagonal
        )
        gains[row_start:row_stop] = group_gains.reshape(
            rows_per_group,
            cols,
        )
    return torch.nan_to_num(
        gains,
        nan=-float("inf"),
        posinf=float("inf"),
        neginf=-float("inf"),
    )


def _storage_stats(rows, cols, group_size, top_k, residual_bits=16):
    if residual_bits not in {4, 8, 16}:
        raise ValueError("residual_bits must be one of 4, 8, or 16.")
    base = method12_quant._storage_stats(rows, cols, group_size)
    index_bits = max(1, math.ceil(math.log2(cols)))
    sparse_slots = rows * top_k
    scale_bits = rows * 16 if residual_bits < 16 else 0
    sparse_payload_bits = sparse_slots * (index_bits + residual_bits)
    sparse_bits = sparse_payload_bits + scale_bits
    total_bits = base["logical_total_bytes"] * 8 + sparse_bits
    return {
        **base,
        "sparse_slots": int(sparse_slots),
        "sparse_index_bits": int(index_bits),
        "sparse_value_bits": int(residual_bits),
        "sparse_payload_bits": int(sparse_payload_bits),
        "residual_scale_bits": int(scale_bits),
        "sparse_residual_bits": int(sparse_bits),
        "logical_total_bits_with_sparse": int(total_bits),
        "effective_bits_per_weight": float(total_bits / (rows * cols)),
    }


@torch.no_grad()
def repair_reconstruction(
    weight, reconstruction, hessian, fraction, group_size=128, residual_bits=16
):
    if weight.ndim != 2 or reconstruction.shape != weight.shape:
        raise ValueError("Method16 expects matching rank-2 weight tensors.")
    if not 0.0 < float(fraction) < 1.0:
        raise ValueError("Method16 fraction must be in (0, 1).")
    if residual_bits not in {4, 8, 16}:
        raise ValueError("residual_bits must be one of 4, 8, or 16.")
    rows, cols = weight.shape
    top_k = max(1, min(cols - 1, int(round(cols * float(fraction)))))
    diag, factors = _prepare_hessian(hessian, rows, cols, weight.device)
    original = weight.detach().float()
    base = reconstruction.detach().to(weight.device).float()
    error = original - base
    before_rows = _guided_row_losses(error, diag, factors)
    gains = _single_coordinate_gains(error, diag, factors)
    selected_gain, indices = torch.topk(gains, k=top_k, dim=1)
    positive = selected_gain > 0

    base_values = torch.gather(base, 1, indices)
    original_values = torch.gather(original, 1, indices)
    selected_residual = torch.where(
        positive,
        original_values - base_values,
        torch.zeros_like(base_values),
    )
    if residual_bits == 16:
        quantized_residual = selected_residual
        active_slot = positive
    else:
        qmax = (1 << (residual_bits - 1)) - 1
        residual_scale = (
            selected_residual.abs().amax(dim=1, keepdim=True)
            / float(qmax)
        ).clamp_min(1e-12)
        residual_codes = torch.round(
            selected_residual / residual_scale
        ).clamp(-qmax, qmax)
        quantized_residual = residual_codes * residual_scale
        active_slot = residual_codes != 0
    replacements = base_values + quantized_residual

    candidate = base.clone()
    candidate.scatter_(1, indices, replacements)
    after_rows = _guided_row_losses(original - candidate, diag, factors)
    tolerance = torch.maximum(
        before_rows.abs() * 1e-6,
        torch.full_like(before_rows, 1e-8),
    )
    accepted = torch.isfinite(after_rows) & (
        after_rows <= before_rows + tolerance
    )
    repaired = torch.where(accepted.unsqueeze(1), candidate, base)
    final_rows = torch.where(accepted, after_rows, before_rows)
    active = active_slot & accepted.unsqueeze(1)

    stats = {
        "requested_fraction": float(fraction),
        "residual_bits": int(residual_bits),
        "top_k_per_row": int(top_k),
        "actual_slot_fraction": float(top_k / cols),
        "accepted_rows": int(accepted.sum().item()),
        "rejected_rows": int((~accepted).sum().item()),
        "active_repairs": int(active.sum().item()),
        "initial_loss": float(before_rows.sum().item()),
        "final_loss": float(final_rows.sum().item()),
        "loss_monotonic": bool(
            torch.all(final_rows <= before_rows + tolerance).item()
        ),
    }
    stats.update(
        _storage_stats(rows, cols, group_size, top_k, residual_bits)
    )
    return repaired.to(dtype=weight.dtype), indices.cpu(), stats


def _base_metadata(
    weight,
    hessian,
    layer_name,
    model_path,
    source_cache_dir,
    group_size,
    init_importance,
):
    return {
        "algorithm": METHOD16_VERSION,
        "artifact": "method12_base_reconstruction",
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(weight.shape),
        "weight_dtype": str(weight.dtype),
        "weight_hash": method14_quant._tensor_hash(weight),
        "hessian_diag_hash": method14_quant._tensor_hash(hessian["diag"]),
        "hessian_factors_hash": method14_quant._tensor_hash(hessian["factors"]),
        "importance_hash": (
            method14_quant._tensor_hash(init_importance)
            if isinstance(init_importance, torch.Tensor)
            else None
        ),
        "source_cache_dir": str(source_cache_dir or ""),
        "method12_algorithm": method12_quant.METHOD12_VERSION,
        "group_size": int(group_size),
        "method12_max_iter": 2,
        "method12_cd_sweeps": 2,
        "method12_joint_affine": True,
        "method12_ridge": 1e-6,
        "method12_scale_eps": 1e-6,
    }


def _base_cache_file(cache_dir, layer_name, metadata):
    safe = (layer_name or "tensor").replace(".", "__").replace("/", "_")
    digest = hashlib.sha256(
        json.dumps(metadata, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]
    return Path(cache_dir) / f"{safe}.{digest}.pt"


def _load_base_cache(cache_dir, layer_name, metadata, overwrite):
    if not cache_dir or overwrite:
        return None
    path = _base_cache_file(cache_dir, layer_name, metadata)
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("metadata") != metadata:
        return None
    reconstruction = payload.get("reconstruction")
    if not isinstance(reconstruction, torch.Tensor):
        return None
    if list(reconstruction.shape) != metadata["weight_shape"]:
        return None
    return payload


def _save_base_cache(cache_dir, layer_name, metadata, reconstruction):
    if not cache_dir:
        return None
    path = _base_cache_file(cache_dir, layer_name, metadata)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "metadata": metadata,
        "reconstruction": reconstruction.detach().cpu().half(),
    }, temporary)
    os.replace(temporary, path)
    return path


def _load_or_build_base(
    weight,
    *,
    hessian,
    layer_name,
    model_path,
    init_importance,
    method11_init_cache_dir,
    method12_source_cache_dir,
    base_cache_dir,
    overwrite_base_cache,
    group_size,
    parallel_jobs,
):
    metadata = _base_metadata(
        weight,
        hessian,
        layer_name,
        model_path,
        method12_source_cache_dir,
        group_size,
        init_importance,
    )
    cached = _load_base_cache(
        base_cache_dir,
        layer_name,
        metadata,
        overwrite_base_cache,
    )
    if cached is not None:
        path = _base_cache_file(base_cache_dir, layer_name, metadata)
        return (
            cached["reconstruction"].to(
                device=weight.device,
                dtype=weight.dtype,
            ),
            True,
            str(path),
            None,
        )

    reconstructed = method12_quant.method12_hlut_reconstruct_tensor(
        weight,
        hessian=hessian,
        n_bit=2,
        q_group_size=group_size,
        per_row=True,
        scale_only=False,
        layer_name=layer_name,
        model_path=model_path,
        init_importance=init_importance,
        method11_init_cache_dir=method11_init_cache_dir,
        method12_cache_dir=method12_source_cache_dir,
        method12_use_cache=True,
        method12_overwrite_cache=False,
        method12_max_iter=2,
        method12_cd_sweeps=2,
        method12_joint_affine=True,
        method12_ridge=1e-6,
        method12_scale_eps=1e-6,
        method12_parallel_jobs=parallel_jobs,
        method12_parallel_backend="loky",
        parallelize=True,
    )
    source_stats = method12_quant.get_method12_stats().get(layer_name)
    path = _save_base_cache(
        base_cache_dir,
        layer_name,
        metadata,
        reconstructed,
    )
    return reconstructed, False, str(path) if path else None, source_stats


def method16_sparse_repair_tensor(
    weight,
    *,
    hessian,
    fraction,
    layer_name=None,
    model_path=None,
    init_importance=None,
    method11_init_cache_dir=None,
    method12_source_cache_dir=None,
    residual_bits=16,
    base_cache_dir=None,
    use_base_cache=True,
    overwrite_base_cache=False,
    group_size=128,
    parallel_jobs=16,
    base_reconstruction=None,
):
    if weight.ndim != 2 or weight.shape[1] % group_size != 0:
        raise ValueError(
            "Method16 expects rank-2 weights divisible by group_size."
        )
    started = time.time()
    if base_reconstruction is None:
        reconstruction, base_cache_hit, cache_path, source_stats = (
            _load_or_build_base(
                weight,
                hessian=hessian,
                layer_name=layer_name,
                model_path=model_path,
                init_importance=init_importance,
                method11_init_cache_dir=method11_init_cache_dir,
                method12_source_cache_dir=method12_source_cache_dir,
                base_cache_dir=base_cache_dir if use_base_cache else None,
                overwrite_base_cache=overwrite_base_cache,
                group_size=group_size,
                parallel_jobs=parallel_jobs,
            )
        )
        base_source = "cache" if base_cache_hit else "method12"
    else:
        if base_reconstruction.shape != weight.shape:
            raise ValueError("Injected base reconstruction has the wrong shape.")
        reconstruction = base_reconstruction.to(
            device=weight.device,
            dtype=weight.dtype,
        )
        base_cache_hit = False
        cache_path = None
        source_stats = None
        base_source = "injected"

    repaired, indices, stats = repair_reconstruction(
        weight,
        reconstruction,
        hessian,
        fraction,
        group_size=group_size,
        residual_bits=residual_bits,
    )
    stats.update({
        "method_name": METHOD16_NAME,
        "layer_name": layer_name,
        "base_source": base_source,
        "base_cache_hit": bool(base_cache_hit),
        "base_cache_path": cache_path,
        "method12_source_cache_hit": (
            bool(source_stats.get("cache_hit"))
            if isinstance(source_stats, dict)
            else None
        ),
        "elapsed_seconds": float(time.time() - started),
    })
    _record_stats(layer_name, stats)
    del reconstruction, indices
    torch.cuda.empty_cache()
    gc.collect()
    return repaired
