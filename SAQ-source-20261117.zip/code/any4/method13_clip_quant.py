import gc
import json
import math
import os
from pathlib import Path

import numpy as np
import torch

import quantize


METHOD13_CLIP_NAME = "method13_any4_clipping"
METHOD13_CLIP_VERSION = "method13_any4_clipping_v1"
_METHOD13_CLIP_STATS = {}


def reset_method13_clip_stats():
    _METHOD13_CLIP_STATS.clear()


def get_method13_clip_stats():
    return json.loads(json.dumps(_METHOD13_CLIP_STATS))


def _safe_name(value):
    return (value or "tensor").replace(".", "__").replace("/", "_")


def _cache_file(cache_root, namespace, layer_name):
    return Path(cache_root) / namespace / (_safe_name(layer_name) + ".pt")


def _load_cache(path, metadata):
    if not path.exists():
        return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if payload.get("metadata") != metadata:
        return None
    reconstructed = payload.get("reconstructed")
    return payload if isinstance(reconstructed, torch.Tensor) else None


def _save_cache(path, metadata, reconstructed, extra):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "metadata": metadata,
        "reconstructed": reconstructed.detach().cpu().half(),
        "extra": extra,
    }, temporary)
    os.replace(temporary, path)


def _quantile_values(weight, quantiles):
    values = weight.detach().abs().float().cpu().numpy().reshape(-1)
    result = np.quantile(values, np.asarray(quantiles, dtype=np.float64))
    return [float(value) for value in np.atleast_1d(result)]


def _logical_storage(rows, cols, group_size, sparse_count=0):
    weights = rows * cols
    code_bits = weights * 4
    lut_bits = rows * 16 * 16
    affine_bits = rows * (cols // group_size) * 2 * 16
    base_bits = code_bits + lut_bits + affine_bits
    index_bits = max(1, math.ceil(math.log2(weights)))
    sparse_bits = sparse_count * (index_bits + 16)
    total_bits = base_bits + sparse_bits
    return {
        "logical_weight_count": int(weights),
        "base_code_bits": int(code_bits),
        "base_lut_bits": int(lut_bits),
        "base_affine_bits": int(affine_bits),
        "base_total_bits": int(base_bits),
        "sparse_count": int(sparse_count),
        "sparse_index_bits": int(index_bits if sparse_count else 0),
        "sparse_value_bits": int(16 if sparse_count else 0),
        "sparse_total_bits": int(sparse_bits),
        "logical_total_bits": int(total_bits),
        "effective_bits_per_weight": float(total_bits / weights),
    }


def _flatten_activations(sample_activations, cols, device, max_rows):
    if not sample_activations:
        raise ValueError("Method13-B requires calibration activations X.")
    flattened = []
    for value in sample_activations:
        tensor = torch.as_tensor(value)
        if tensor.shape[-1] != cols:
            raise ValueError(
                f"Activation width {tensor.shape[-1]} does not match weight columns {cols}."
            )
        flattened.append(tensor.reshape(-1, cols).float())
    x = torch.cat(flattened, dim=0)
    if x.shape[0] > max_rows:
        indices = torch.linspace(0, x.shape[0] - 1, max_rows).long()
        x = x.index_select(0, indices)
    return x.to(device=device, dtype=torch.float32)


@torch.no_grad()
def _output_mse(x, original, reconstructed, row_chunk=256):
    delta = original.detach().float() - reconstructed.detach().float()
    squared_error = 0.0
    count = 0
    for start in range(0, delta.shape[0], row_chunk):
        stop = min(start + row_chunk, delta.shape[0])
        error = torch.matmul(x, delta[start:stop].t())
        squared_error += float(error.square().sum().item())
        count += error.numel()
    return squared_error / max(count, 1)


@torch.no_grad()
def _any4_reconstruct(weight, threshold, sample_weight, group_size, parallel_jobs):
    clipped = weight.detach().float().clamp(min=-threshold, max=threshold)
    reconstructed = quantize.anyq_reconstruct_tensor(
        clipped.to(dtype=weight.dtype),
        n_bit=4,
        q_group_size=group_size,
        per_row=True,
        scale_only=False,
        cluster_row=quantize.cluster_row_scikit,
        sample_weight=sample_weight,
        scale_sample_weight=True,
        parallelize=True,
        parallel_jobs=parallel_jobs,
    )
    return reconstructed.to(device=weight.device, dtype=weight.dtype)


def _metadata(weight, layer_name, model_path, namespace, group_size, extra):
    return {
        "algorithm": METHOD13_CLIP_VERSION,
        "model_path": str(model_path or ""),
        "layer_name": str(layer_name or ""),
        "weight_shape": list(weight.shape),
        "weight_dtype": str(weight.dtype),
        "namespace": namespace,
        "n_bit": 4,
        "group_size": int(group_size),
        "cluster_row": "scikit",
        "scale_sample_weight": True,
        **extra,
    }


def _save_sparse_table(path, metadata, indices, values):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({
        "metadata": metadata,
        "flat_indices": indices.detach().cpu().to(torch.int32),
        "fp16_values": values.detach().cpu().half(),
    }, temporary)
    os.replace(temporary, path)


@torch.no_grad()
def method13_clip_reconstruct_tensor(
    weight,
    *,
    mode,
    sample_weight,
    sample_activations=None,
    layer_name=None,
    model_path=None,
    quantile=0.999,
    search_quantiles=(0.995, 0.9975, 0.999, 0.9995, 1.0),
    group_size=128,
    parallel_jobs=8,
    max_activation_rows=512,
    cache_root=None,
    sparse_table_root=None,
    use_cache=True,
):
    if mode not in {"A", "B", "C"}:
        raise ValueError(f"Unsupported method13 clipping mode {mode!r}.")
    if weight.ndim != 2 or weight.shape[1] % group_size:
        raise ValueError("Method13 clipping expects a 2D Linear weight divisible by group size.")
    if not 0.0 < float(quantile) <= 1.0:
        raise ValueError("quantile must be in (0, 1].")

    rows, cols = weight.shape
    original = weight.detach()
    cache_hit = False
    candidate_losses = {}
    selected_quantile = float(quantile)

    if mode in {"A", "C"}:
        namespace = f"shared_q{int(round(float(quantile) * 1000000)):06d}"
        metadata = _metadata(
            weight, layer_name, model_path, namespace, group_size,
            {"quantile": float(quantile)},
        )
        path = _cache_file(cache_root, namespace, layer_name) if cache_root else None
        payload = _load_cache(path, metadata) if use_cache and path else None
        if payload is not None:
            reconstructed = payload["reconstructed"].to(weight.device, weight.dtype)
            threshold = float(payload["extra"]["threshold"])
            cache_hit = True
        else:
            threshold = _quantile_values(weight, [quantile])[0]
            reconstructed = _any4_reconstruct(
                weight, threshold, sample_weight, group_size, parallel_jobs
            )
            if path:
                _save_cache(path, metadata, reconstructed, {"threshold": threshold})
    else:
        candidates = tuple(float(value) for value in search_quantiles)
        if not candidates or any(value <= 0.0 or value > 1.0 for value in candidates):
            raise ValueError("search_quantiles must contain values in (0, 1].")
        namespace = "output_mse_" + "_".join(
            f"{int(round(value * 10000)):05d}" for value in candidates
        )
        x = _flatten_activations(
            sample_activations, cols, weight.device, int(max_activation_rows)
        )
        metadata = _metadata(
            weight, layer_name, model_path, namespace, group_size,
            {
                "search_quantiles": list(candidates),
                "max_activation_rows": int(max_activation_rows),
                "activation_rows": int(x.shape[0]),
                "activation_sum": float(x.sum().item()),
                "activation_square_sum": float(x.square().sum().item()),
            },
        )
        path = _cache_file(cache_root, namespace, layer_name) if cache_root else None
        payload = _load_cache(path, metadata) if use_cache and path else None
        if payload is not None:
            reconstructed = payload["reconstructed"].to(weight.device, weight.dtype)
            extra = payload["extra"]
            threshold = float(extra["threshold"])
            selected_quantile = float(extra["selected_quantile"])
            candidate_losses = {
                str(key): float(value)
                for key, value in extra["candidate_output_mse"].items()
            }
            cache_hit = True
        else:
            thresholds = _quantile_values(weight, candidates)
            best = None
            for candidate_quantile, candidate_threshold in zip(candidates, thresholds):
                candidate = _any4_reconstruct(
                    weight, candidate_threshold, sample_weight,
                    group_size, parallel_jobs,
                )
                loss = _output_mse(x, original, candidate)
                candidate_losses[str(candidate_quantile)] = float(loss)
                if best is None or loss < best[0]:
                    best = (
                        loss, candidate_quantile, candidate_threshold,
                        candidate.detach().clone(),
                    )
                del candidate
                torch.cuda.empty_cache()
                gc.collect()
            _, selected_quantile, threshold, reconstructed = best
            if path:
                _save_cache(
                    path, metadata, reconstructed,
                    {
                        "threshold": float(threshold),
                        "selected_quantile": float(selected_quantile),
                        "candidate_output_mse": candidate_losses,
                    },
                )
        del x

    outlier_mask = original.detach().abs().float() > float(threshold)
    outlier_count = int(outlier_mask.sum().item())
    sparse_path = None
    if mode == "C":
        flat_indices = torch.nonzero(
            outlier_mask.reshape(-1), as_tuple=False
        ).flatten()
        flat_values = original.reshape(-1).index_select(0, flat_indices)
        repaired = reconstructed.reshape(-1).clone()
        repaired.index_copy_(0, flat_indices, flat_values)
        reconstructed = repaired.reshape_as(original)
        if sparse_table_root:
            sparse_path = Path(sparse_table_root) / (_safe_name(layer_name) + ".pt")
            sparse_metadata = {
                "algorithm": METHOD13_CLIP_VERSION,
                "artifact": "fp16_sparse_outlier_table",
                "model_path": str(model_path or ""),
                "layer_name": str(layer_name or ""),
                "weight_shape": list(weight.shape),
                "threshold": float(threshold),
                "quantile": float(quantile),
            }
            _save_sparse_table(
                sparse_path, sparse_metadata, flat_indices, flat_values
            )
        sparse_count = outlier_count
    else:
        sparse_count = 0

    weight_mse = float(torch.mean(
        (original.detach().float() - reconstructed.detach().float()).square()
    ).item())
    stats = {
        "mode": mode,
        "layer_name": str(layer_name or ""),
        "shape": [int(rows), int(cols)],
        "threshold": float(threshold),
        "selected_quantile": float(selected_quantile),
        "outlier_count": int(outlier_count),
        "outlier_fraction": float(outlier_count / original.numel()),
        "weight_mse": weight_mse,
        "cache_hit": bool(cache_hit),
        "candidate_output_mse": candidate_losses,
        "sparse_table_path": str(sparse_path) if sparse_path else None,
    }
    stats.update(_logical_storage(rows, cols, group_size, sparse_count))
    _METHOD13_CLIP_STATS[layer_name or "<tensor>"] = stats
    return reconstructed.to(device=weight.device, dtype=weight.dtype)
