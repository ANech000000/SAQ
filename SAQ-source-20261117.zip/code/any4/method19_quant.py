import gc
import json
import math
import time

import torch

import method12_quant
import method16_quant


METHOD19_NAME = "method19_guided_residual_scale_search"
METHOD19_VERSION = "method19_guided_residual_scale_search_v1"
DEFAULT_SCALE_FACTORS = (
    1.0,
    0.95,
    0.90,
    0.85,
    0.80,
    0.75,
    0.70,
    0.65,
    0.60,
    0.55,
    0.50,
    0.45,
    0.40,
)
_METHOD19_LAYER_STATS = {}


def reset_method19_stats():
    _METHOD19_LAYER_STATS.clear()


def get_method19_stats():
    return json.loads(json.dumps(_METHOD19_LAYER_STATS))


def _record_stats(layer_name, stats):
    _METHOD19_LAYER_STATS[layer_name or "<tensor>"] = stats


def _validated_scale_factors(scale_factors):
    values = tuple(float(value) for value in scale_factors)
    if not values:
        raise ValueError("Method19 requires at least one scale factor.")
    if any(not 0.0 < value <= 1.0 for value in values):
        raise ValueError("Method19 scale factors must be in (0, 1].")
    if 1.0 not in values:
        raise ValueError("Method19 scale factors must include 1.0.")
    return values


def _storage_stats(
    rows,
    cols,
    group_size,
    top_k,
    residual_bits,
):
    if not 3 <= int(residual_bits) <= 8:
        raise ValueError("Method19 storage expects residual_bits in [3, 8].")
    base = method12_quant._storage_stats(rows, cols, group_size)
    index_bits = max(1, math.ceil(math.log2(cols)))
    sparse_slots = rows * top_k
    residual_scale_bits = rows * 16
    sparse_payload_bits = sparse_slots * (
        index_bits + residual_bits
    )
    sparse_bits = sparse_payload_bits + residual_scale_bits
    total_bits = base["logical_total_bytes"] * 8 + sparse_bits
    return {
        **base,
        "sparse_slots": int(sparse_slots),
        "sparse_index_bits": int(index_bits),
        "sparse_value_bits": int(residual_bits),
        "sparse_payload_bits": int(sparse_payload_bits),
        "residual_scale_bits": int(residual_scale_bits),
        "sparse_residual_bits": int(sparse_bits),
        "logical_total_bits_with_sparse": int(total_bits),
        "effective_bits_per_weight": float(total_bits / (rows * cols)),
    }


@torch.no_grad()
def repair_reconstruction_scale_search(
    weight,
    reconstruction,
    hessian,
    fraction,
    group_size=128,
    residual_bits=4,
    scale_factors=DEFAULT_SCALE_FACTORS,
):
    if weight.ndim != 2 or reconstruction.shape != weight.shape:
        raise ValueError("Method19 expects matching rank-2 weight tensors.")
    if not 0.0 < float(fraction) < 1.0:
        raise ValueError("Method19 fraction must be in (0, 1).")
    if not 3 <= int(residual_bits) <= 8:
        raise ValueError("Method19 residual_bits must be in [3, 8].")
    scale_factors = _validated_scale_factors(scale_factors)

    rows, cols = weight.shape
    top_k = max(1, min(cols - 1, int(round(cols * float(fraction)))))
    diag, factors = method16_quant._prepare_hessian(
        hessian,
        rows,
        cols,
        weight.device,
    )
    original = weight.detach().float()
    base = reconstruction.detach().to(weight.device).float()
    error = original - base
    before_rows = method16_quant._guided_row_losses(
        error,
        diag,
        factors,
    )
    gains = method16_quant._single_coordinate_gains(
        error,
        diag,
        factors,
    )
    selected_gain, indices = torch.topk(gains, k=top_k, dim=1)
    positive = torch.isfinite(selected_gain) & (selected_gain > 0)
    base_values = torch.gather(base, 1, indices)
    original_values = torch.gather(original, 1, indices)
    selected_residual = torch.where(
        positive,
        original_values - base_values,
        torch.zeros_like(base_values),
    )


    qmax = (1 << (residual_bits - 1)) - 1
    absmax_scale = (
        selected_residual.abs().amax(dim=1, keepdim=True)
        / float(qmax)
    ).clamp_min(1e-12)
    best_trial_loss = torch.full_like(before_rows, float("inf"))
    best_quantized = torch.zeros_like(selected_residual)
    best_codes = torch.zeros_like(selected_residual)
    chosen_factor = torch.ones(
        rows,
        device=weight.device,
        dtype=torch.float32,
    )

    for scale_factor in scale_factors:
        candidate_scale = absmax_scale * scale_factor
        residual_codes = torch.round(
            selected_residual / candidate_scale
        ).clamp(-qmax, qmax)
        quantized_residual = torch.where(
            positive,
            residual_codes * candidate_scale,
            torch.zeros_like(selected_residual),
        )
        trial = base.clone()
        trial.scatter_(
            1,
            indices,
            base_values + quantized_residual,
        )
        trial_loss = method16_quant._guided_row_losses(
            original - trial,
            diag,
            factors,
        )
        better = torch.isfinite(trial_loss) & (
            trial_loss < best_trial_loss
        )
        best_trial_loss = torch.where(
            better,
            trial_loss,
            best_trial_loss,
        )
        best_quantized = torch.where(
            better.unsqueeze(1),
            quantized_residual,
            best_quantized,
        )
        best_codes = torch.where(
            better.unsqueeze(1),
            residual_codes,
            best_codes,
        )
        chosen_factor = torch.where(
            better,
            torch.full_like(chosen_factor, scale_factor),
            chosen_factor,
        )

    candidate = base.clone()
    candidate.scatter_(1, indices, base_values + best_quantized)
    after_rows = method16_quant._guided_row_losses(
        original - candidate,
        diag,
        factors,
    )
    tolerance = torch.maximum(
        before_rows.abs() * 1e-6,
        torch.full_like(before_rows, 1e-8),
    )
    accepted = torch.isfinite(after_rows) & (
        after_rows <= before_rows + tolerance
    )
    repaired = torch.where(accepted.unsqueeze(1), candidate, base)
    final_rows = torch.where(accepted, after_rows, before_rows)
    active = positive & (best_codes != 0) & accepted.unsqueeze(1)

    factor_histogram = {}
    for scale_factor in scale_factors:
        factor_histogram[f"{scale_factor:.2f}"] = int(
            torch.isclose(
                chosen_factor,
                torch.tensor(
                    scale_factor,
                    device=chosen_factor.device,
                    dtype=chosen_factor.dtype,
                ),
            ).sum().item()
        )
    stats = {
        "requested_fraction": float(fraction),
        "residual_bits": int(residual_bits),
        "top_k_per_row": int(top_k),
        "actual_slot_fraction": float(top_k / cols),
        "scale_search_factors": list(scale_factors),
        "scale_factor_histogram": factor_histogram,
        "mean_scale_factor": float(chosen_factor.mean().item()),
        "absmax_scale_rows": int(
            torch.isclose(
                chosen_factor,
                torch.ones_like(chosen_factor),
            ).sum().item()
        ),
        "accepted_rows": int(accepted.sum().item()),
        "rejected_rows": int((~accepted).sum().item()),
        "active_repairs": int(active.sum().item()),
        "initial_loss": float(before_rows.sum().item()),
        "final_loss": float(final_rows.sum().item()),
        "loss_monotonic": bool(
            torch.all(final_rows <= before_rows + tolerance).item()
        ),
    }
    stats.update(
        _storage_stats(
            rows,
            cols,
            group_size,
            top_k,
            residual_bits,
        )
    )
    return repaired.to(dtype=weight.dtype), indices.cpu(), stats


def method19_scale_search_sparse_repair_tensor(
    weight,
    *,
    hessian,
    fraction,
    layer_name=None,
    model_path=None,
    init_importance=None,
    method11_init_cache_dir=None,
    method12_source_cache_dir=None,
    residual_bits=4,
    base_cache_dir=None,
    use_base_cache=True,
    overwrite_base_cache=False,
    group_size=128,
    parallel_jobs=16,
    base_reconstruction=None,
    scale_factors=DEFAULT_SCALE_FACTORS,
):
    if weight.ndim != 2 or weight.shape[1] % group_size != 0:
        raise ValueError(
            "Method19 expects rank-2 weights divisible by group_size."
        )
    started = time.time()
    if base_reconstruction is None:
        reconstruction, base_cache_hit, cache_path, source_stats = (
            method16_quant._load_or_build_base(
                weight,
                hessian=hessian,
                layer_name=layer_name,
                model_path=model_path,
                init_importance=init_importance,
                method11_init_cache_dir=method11_init_cache_dir,
                method12_source_cache_dir=method12_source_cache_dir,
                base_cache_dir=base_cache_dir if use_base_cache else None,
                overwrite_base_cache=overwrite_base_cache,
                group_size=group_size,
                parallel_jobs=parallel_jobs,
            )
        )
        base_source = "cache" if base_cache_hit else "method12"
    else:
        if base_reconstruction.shape != weight.shape:
            raise ValueError(
                "Injected base reconstruction has the wrong shape."
            )
        reconstruction = base_reconstruction.to(
            device=weight.device,
            dtype=weight.dtype,
        )
        base_cache_hit = False
        cache_path = None
        source_stats = None
        base_source = "injected"

    repaired, indices, stats = repair_reconstruction_scale_search(
        weight,
        reconstruction,
        hessian,
        fraction,
        group_size=group_size,
        residual_bits=residual_bits,
        scale_factors=scale_factors,
    )
    stats.update({
        "method_name": METHOD19_NAME,
        "algorithm_version": METHOD19_VERSION,
        "layer_name": layer_name,
        "base_source": base_source,
        "base_cache_hit": bool(base_cache_hit),
        "base_cache_path": cache_path,
        "method12_source_cache_hit": (
            bool(source_stats.get("cache_hit"))
            if isinstance(source_stats, dict)
            else None
        ),
        "elapsed_seconds": float(time.time() - started),
    })
    _record_stats(layer_name, stats)
    del reconstruction, indices
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()
    return repaired
