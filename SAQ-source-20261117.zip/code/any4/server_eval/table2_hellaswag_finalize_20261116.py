"""Audit six completed runs and emit the HellaSwag replacement column."""
import csv
import json
from pathlib import Path

RUN = Path('/data/lsz/any4/experiments/method30_weightonly_1b/runs/hellaswag_table1_protocol_20261116_v1')
DISPLAY = dict(fp16='FP16', rtn='RTN', gptq='GPTQ', awq='AWQ', any4='Any4', csd_lut='CSD-LUT')


def main():
    rows = []
    config = None
    versions = None
    for variant, name in DISPLAY.items():
        folder = 'gptq_bridge_v7' if variant == 'gptq' else variant
        path = RUN / folder / 'results.json'
        data = json.loads(path.read_text())
        if data['status'] != 'complete':
            raise RuntimeError(f'{variant}: {data["status"]}')
        metric = data['metrics']['hellaswag']
        if metric['n-shot']['hellaswag'] != 0:
            raise RuntimeError(f'{variant}: few-shot mismatch')
        current_config = metric['configs']['hellaswag']
        if config is None:
            config = current_config
            versions = data['versions']
        if current_config != config or data['versions'] != versions:
            raise RuntimeError(f'{variant}: task config or environment mismatch')
        provenance = json.loads((RUN / folder / 'harness_provenance.json').read_text())
        if provenance['n-samples']['hellaswag'] != dict(original=10042, effective=10042):
            raise RuntimeError(f'{variant}: sample count mismatch')
        if not data['weight_reproduction_check']['passed']:
            raise RuntimeError(f'{variant}: PPL validation failed')
        rows.append(dict(method=name, accuracy_percent=data['table2_replacement_percent'],
                         acc=data['hellaswag_acc'], acc_norm_secondary=data['hellaswag_acc_norm_secondary'],
                         wikitext2_validation=data['weight_reproduction_check']['observed_ppl'],
                         historical_wikitext2=data['weight_reproduction_check']['historical_ppl'],
                         ppl_difference=data['weight_reproduction_check']['difference'], result_path=str(path)))
    fp = json.loads((RUN / 'fp16/results.json').read_text())
    if not fp['table1_fp16_gate']['passed']:
        raise RuntimeError('Table I FP16 gate not passed')
    csd = json.loads((RUN / 'csd_lut/results.json').read_text())
    if csd['load_metadata']['reconstruction_hashes_equal'] is not True:
        raise RuntimeError('CSD-LUT weight hashes mismatch')
    bridge = json.loads((RUN / 'gptq_bridge_v7/historical_gptq_transfer.json').read_text())
    if not bridge['packed_tensor_hashes_equal'] or bridge['verified_linears'] != 112:
        raise RuntimeError('GPTQ packed transfer hashes mismatch')
    if abs(bridge['producer_historical_ppl'] - bridge['expected_historical_ppl']) > 1e-5:
        raise RuntimeError('GPTQ historical reconstruction mismatch')
    audit = dict(status='complete', methods=6, samples_per_method=10042,
                 environment=versions, all_task_configs_equal=True,
                 fp16_matches_table1_exactly=True, csd_weight_hashes_equal=True,
                 gptq_historical_ppl=bridge['producer_historical_ppl'],
                 gptq_transferred_linears=112, gptq_transfer_hashes_equal=True)
    with (RUN / 'comparison.json').open('x') as f:
        json.dump(rows, f, indent=2)
    with (RUN / 'comparison.csv').open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (RUN / 'validation.json').open('x') as f:
        json.dump(audit, f, indent=2)
    report = ['# Table II HellaSwag 统一协议补测', '',
              '六种方法均采用 Table I 原 lm-eval 0.4.5 入口、zero-shot、validation 全集 10,042 条、batch=8、max_length=2048。',
              '主指标为未归一化 acc；acc_norm 仅作辅助记录。六种方法的任务配置及最终评测环境完全一致。', '',
              '| 方法 | HellaSwag Acc. (%) | 辅助 acc_norm (%) |', '|---|---:|---:|']
    report += [f"| {r['method']} | {r['accuracy_percent']:.2f} | {r['acc_norm_secondary']*100:.2f} |" for r in rows]
    report += ['', '## 核验', '',
               '- FP16 主指标和辅助指标均精确复现 Table I；CSD-LUT 重构哈希与原缓存一致。',
               '- GPTQ 在历史 torch 2.4.1 / transformers 4.45.2 环境重建，并严格核对历史 PPL；112 层 packed 张量经内存管道传入统一评测环境，全部哈希一致，没有持久化 checkpoint。',
               '- GPTQ 在新评测环境下的 PPL 仅作运行时诊断，完整差异见 comparison.csv；不把辅助检查值直接改写到原论文其他列。',
               '- 失败尝试、旧环境 FP16 辅助结果不进入汇总。',
               '- 本次只补测 HellaSwag；未修改论文及其余指标。', '',
               '代码目录：`/data/lsz/any4/experiments/method30_weightonly_1b/review_hellaswag_20261116/`。']
    with (RUN / 'SUMMARY.md').open('x') as f:
        f.write('\n'.join(report) + '\n')
    print(json.dumps(dict(audit=audit, results=rows), indent=2))


if __name__ == '__main__':
    main()
