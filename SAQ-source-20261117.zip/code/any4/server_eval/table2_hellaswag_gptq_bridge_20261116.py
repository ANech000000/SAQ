"""Reconstruct historical GPTQ in its old runtime; evaluate in Table I runtime.

Only packed quantization buffers cross an unnamed pipe; no weight file is saved.
"""
import hashlib
import importlib
import importlib.abc
import importlib.machinery
import io
import json
import os
from pathlib import Path
import random
import runpy
import subprocess
import sys

ROOT = Path('/data/lsz/any4')
HERE = Path(__file__).resolve().parent
RUN = ROOT / 'experiments/method30_weightonly_1b/runs/hellaswag_table1_protocol_20261116_v1'
OUT = RUN / 'gptq_bridge_v7'
OLD_PYTHON = '/home/ubuntu/anaconda3/envs/denserlhf-qwen/bin/python'
PYTHON = ROOT / 'venv/bin/python'
LEGACY = ROOT / 'experiments/method30_weightonly_1b/scripts'
REFINE = ROOT / 'experiments/method30_postawq_refine'


def imports():
    for path in (ROOT, REFINE, LEGACY, HERE):
        sys.path.insert(0, str(path))
    import table2_hellaswag_table1_protocol_20261116 as base
    old = base.import_file('table2_original_runner', LEGACY / 'runner.py')
    return base, old


def tensor_hash(t):
    t = t.detach().cpu().contiguous()
    return hashlib.sha256(t.numpy().tobytes()).hexdigest()


def produce(fd):
    class MissingXML(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname == 'lxml':
                return importlib.machinery.PathFinder.find_spec(fullname,
                    ['/home/ubuntu/anaconda3/envs/verl/lib/python3.10/site-packages'])
            return None

    sys.meta_path.append(MissingXML())
    import torch
    base, old = imports()
    random.seed(0)
    torch.manual_seed(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    model, tokenizer = base.load_official_gptq(old)
    ppl = float(old.eval_wiki2(model, tokenizer, 128, 2048))
    expected = base.EXPECTED_PPL['gptq']
    if abs(ppl - expected) > 1e-5:
        raise RuntimeError(f'Historical GPTQ reproduction failed: {ppl} != {expected}')
    packed = {}
    for name, mod in model.named_modules():
        if not all(hasattr(mod, k) for k in ('qweight', 'qzeros', 'scales', 'g_idx')):
            continue
        state = {k: t.detach().cpu().contiguous() for k, t in mod.state_dict().items()}
        packed[name] = dict(class_module=type(mod).__module__,
                            bits=mod.bits, group_size=mod.group_size,
                            infeatures=mod.infeatures, outfeatures=mod.outfeatures,
                            bias=mod.bias is not None,
                            state=state, hashes={k: tensor_hash(t) for k, t in state.items()})
    if len(packed) != 112:
        raise RuntimeError(f'Expected 112 quantized linears, got {len(packed)}')
    payload = dict(historical_ppl=ppl, expected_ppl=expected,
                   producer_torch=torch.__version__, packed=packed)
    print(f'HISTORICAL_GPTQ_VERIFIED ppl={ppl}, linears={len(packed)}', flush=True)
    with os.fdopen(fd, 'wb') as stream:
        torch.save(payload, stream)


def consume():
    import torch
    base, old = imports()

    def load_exact_historical_gptq(unused):
        read_fd, write_fd = os.pipe()
        env = os.environ.copy()
        env['PYTHONPATH'] = str(ROOT / 'venv/lib/python3.10/site-packages')
        env['CUDA_VISIBLE_DEVICES'] = '2'
        with (RUN / 'gptq_bridge_v7_producer.log').open('x') as log:
            producer = subprocess.Popen([OLD_PYTHON, '-u', str(Path(__file__).resolve()),
                                         '--producer', str(write_fd)], cwd=ROOT, env=env,
                                         pass_fds=(write_fd,), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=subprocess.STDOUT)
            os.close(write_fd)
            with os.fdopen(read_fd, 'rb') as stream:
                blob = stream.read()
            code = producer.wait()
        if code:
            raise RuntimeError(f'Historical GPTQ producer failed, exit={code}')
        payload = torch.load(io.BytesIO(blob), map_location='cpu', weights_only=False)
        del blob
        model, tokenizer = old.load_base_model(base.MODEL)
        hashes = {}
        sys.path.insert(0, str(LEGACY.parent / 'third_party/auto_gptq'))
        for name, record in payload['packed'].items():
            cls = importlib.import_module(record['class_module']).QuantLinear
            mod = cls(bits=record['bits'], group_size=record['group_size'],
                      infeatures=record['infeatures'], outfeatures=record['outfeatures'],
                      bias=record['bias'], weight_dtype=torch.float16)
            mod.load_state_dict(record['state'], strict=True)
            actual = {k: tensor_hash(t) for k, t in mod.state_dict().items()}
            if actual != record['hashes']:
                raise RuntimeError(f'Packed tensor transfer mismatch: {name}')
            hashes[name] = actual
            parent_name, leaf = name.rsplit('.', 1)
            setattr(model.get_submodule(parent_name), leaf, mod)
        audit = dict(producer_torch=payload['producer_torch'],
                     producer_historical_ppl=payload['historical_ppl'],
                     expected_historical_ppl=payload['expected_ppl'],
                     consumer_torch=torch.__version__,
                     verified_linears=len(hashes), packed_tensor_hashes_equal=True,
                     packed_tensor_sha256=hashes,
                     transfer='unnamed OS pipe, CPU tensors, no persistent checkpoint')
        base.write_json(OUT / 'historical_gptq_transfer.json', audit)
        del payload
        model.to('cuda:0').eval()
        return model, tokenizer

    base.load_official_gptq = load_exact_historical_gptq
    # Historical reproduction is checked strictly by the producer. A small
    # diagnostic PPL drift from the modern inference runtime is allowed here.
    sys.argv = [str(HERE / 'table2_hellaswag_table1_protocol_20261116.py'),
                '--variant', 'gptq', '--physical-gpu', '2', '--cpu-list', '16-31',
                '--ppl-tolerance', '0.001', '--output-dir', str(OUT)]
    base.main()


if __name__ == '__main__':
    if '--producer' in sys.argv:
        produce(int(sys.argv[-1]))
    elif '--consume' in sys.argv:
        consume()
    else:
        env = os.environ.copy()
        env.update(CUDA_VISIBLE_DEVICES='2', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', PYTHONUNBUFFERED='1',
                   HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        with (RUN / 'gptq_bridge_v7.log').open('x') as log:
            p = subprocess.Popen(['taskset', '-c', '16-31', str(PYTHON), '-u',
                                  str(Path(__file__).resolve()), '--consume'],
                                 cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        print(f'GPU 2 historical GPTQ bridge worker PID={p.pid}')
