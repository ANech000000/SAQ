"""Re-evaluate Table II HellaSwag using the unchanged Table I harness entry."""

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback
from types import SimpleNamespace

ROOT = Path('/data/lsz/any4')
REFINE = ROOT / 'experiments/method30_postawq_refine'
LEGACY = ROOT / 'experiments/method30_weightonly_1b/scripts'
MODEL = '/data/model/alpindale-Llama-3.2-1B'
EXPECTED_PPL = dict(fp16=9.750678062438965, rtn=11.723580360412598,
                    gptq=10.714824676513672, awq=10.789726257324219,
                    any4=10.618475914001465, csd_lut=10.287789344787598)
EXPECTED_ACC = 0.4772953594901414
EXPECTED_NORM = 0.6363274248157738


def write_json(path, obj):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str) + '\n')
    os.replace(temporary, path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def import_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_official_gptq(old):
    # Identical quantization arguments to official_gptq_v4 (not legacy GPTQ).
    sys.path.insert(0, str(LEGACY.parent / 'third_party/auto_gptq'))
    from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
    import torch
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    train_loader, _ = old.get_loaders('wikitext-2', nsamples=128, seed=0,
                                    seqlen=2048, tokenizer=tok)
    examples = [{'input_ids': x, 'attention_mask': torch.ones_like(x)}
                for x, _ in train_loader]
    cfg = BaseQuantizeConfig(bits=4, group_size=128, damp_percent=0.01,
                            desc_act=True, static_groups=False, sym=True,
                            true_sequential=True)
    wrapped = AutoGPTQForCausalLM.from_pretrained(
        MODEL, quantize_config=cfg, trust_remote_code=True,
        torch_dtype=torch.float16, low_cpu_mem_usage=True, local_files_only=True)
    if hasattr(wrapped.model.model, 'rotary_emb'):
        wrapped.model.model.rotary_emb = wrapped.model.model.rotary_emb.to('cuda:0')
    # AutoGPTQ 0.7.1 reads decoder outputs with [0]. Transformers 4.57
    # returns a Tensor instead of the historical one-element tuple. Adapt
    # only that API during quantization, then restore the unmodified forward.
    from transformers.models.llama.modeling_llama import LlamaDecoderLayer
    original_forward = LlamaDecoderLayer.forward

    def legacy_decoder_forward(self, *a, **kw):
        output = original_forward(self, *a, **kw)
        return (output,) if isinstance(output, torch.Tensor) else output

    LlamaDecoderLayer.forward = legacy_decoder_forward
    try:
        wrapped.quantize(examples, batch_size=1, use_triton=False,
                         use_cuda_fp16=True, cache_examples_on_gpu=False)
    finally:
        LlamaDecoderLayer.forward = original_forward
    wrapped.model.to('cuda:0').eval()
    tok.padding_side = 'left'
    return wrapped.model, tok


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--variant', required=True, choices=tuple(EXPECTED_PPL))
    p.add_argument('--physical-gpu', required=True)
    p.add_argument('--cpu-list', required=True)
    p.add_argument('--output-dir', required=True)
    p.add_argument('--model-path', default=MODEL)
    p.add_argument('--ppl-tolerance', type=float, default=1e-5)
    args = p.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    result_path = output / 'results.json'
    if result_path.exists():
        raise FileExistsError(result_path)
    result = dict(variant=args.variant, status='preflight', metrics={},
                  model_path=MODEL, physical_gpu=args.physical_gpu,
                  cpu_list=args.cpu_list, started_at=time.strftime('%Y-%m-%d %H:%M:%S'),
                  protocol='Table I: unchanged _run_harness; lm-eval 0.4.5; zero-shot; raw acc',
                  official_gptq=args.variant == 'gptq')
    write_json(result_path, result)
    try:
        if os.environ.get('CUDA_VISIBLE_DEVICES') != args.physical_gpu:
            raise RuntimeError('GPU visibility mismatch')
        for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
            os.environ[key] = '1'
        os.environ.update(TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
                          HF_DATASETS_CACHE='/home/ubuntu/.cache/huggingface/datasets',
                          TOKENIZERS_PARALLELISM='false')
        for path in (ROOT, REFINE, LEGACY):
            sys.path.insert(0, str(path))
        import torch
        old = import_file('table2_legacy_runner', LEGACY / 'runner.py')
        initial = old.gpu_snapshot(args.physical_gpu)
        result['initial_gpu'] = initial
        if initial['memory_used_mib'] > 256 or initial['utilization_percent'] > 5:
            raise RuntimeError(f'GPU is occupied: {initial}')
        random.seed(0)
        torch.manual_seed(0)
        torch.backends.cuda.matmul.allow_tf32 = False
        import runner_any4_table as table
        result['versions'] = {k: importlib.metadata.version(k)
                              for k in ('lm_eval', 'transformers', 'torch', 'datasets')}
        if result['versions']['lm_eval'] != '0.4.5':
            raise RuntimeError('lm-eval version differs from Table I')
        result['source_sha256'] = {str(x): digest(x) for x in
                                  (Path(__file__), LEGACY / 'runner.py',
                                   LEGACY / 'official_gptq_runner.py', REFINE / 'runner_any4_table.py')}
        historical = (LEGACY.parent / 'runs/official_gptq_v4/results.json'
                      if args.variant == 'gptq' else LEGACY.parent /
                      f'runs/comparison_20260816_v3/{args.variant}/results.json')
        result['historical_result'] = dict(path=str(historical), sha256=digest(historical))
        result['status'] = 'loading_or_quantizing'
        write_json(result_path, result)
        started = time.perf_counter()
        if args.variant == 'csd_lut':
            model, tokenizer, metadata = old.load_csd_model(args)
            result['load_metadata'] = metadata
        elif args.variant == 'gptq':
            model, tokenizer = load_official_gptq(old)
        else:
            model, tokenizer = old.load_base_model(MODEL)
            if args.variant in ('fp16', 'rtn', 'any4'):
                model.to('cuda:0')
            if args.variant == 'rtn':
                old.quantize_rtn(model, 128)
            elif args.variant == 'awq':
                old.quantize_awq(model, tokenizer, 128)
                model.to('cuda:0')
            elif args.variant == 'any4':
                model = old.quantize_model(model, layer_from=torch.nn.Linear,
                    layer_to=old.quant_methods['anyq'], tokenizer=tokenizer,
                    skip_modules='lm_head', n_bit=4, group_size=128,
                    sample_weight=old.calibrate, scale_sample_weight=True, pseudo=True)
        model.eval()
        result['load_seconds'] = time.perf_counter() - started
        result['status'] = 'checking_historical_wikitext2'
        write_json(result_path, result)
        ppl = float(old.eval_wiki2(model, tokenizer, 128, 2048))
        difference = ppl - EXPECTED_PPL[args.variant]
        result['weight_reproduction_check'] = dict(
            observed_ppl=ppl, historical_ppl=EXPECTED_PPL[args.variant],
            difference=difference, tolerance=args.ppl_tolerance,
            passed=abs(difference) <= args.ppl_tolerance)
        if abs(difference) > args.ppl_tolerance:
            raise RuntimeError(f'Historical model PPL mismatch: {difference}')
        harness_args = SimpleNamespace(harness_batch_size=8, tasks=['hellaswag'],
                                       limit=None, output_dir=str(output))
        # Preserve the original HFLM creation, task loader, seeds and task config.
        # Additionally record provenance discarded by the historical wrapper.
        original_evaluate = table.lm_eval.simple_evaluate

        def audited_evaluate(*a, **kw):
            evaluated = original_evaluate(*a, **kw)
            extra = {k: evaluated.get(k) for k in
                     ('n-samples', 'config', 'git_hash', 'date', 'task_hashes')}
            write_json(output / 'harness_provenance.json', extra)
            return evaluated

        table.lm_eval.simple_evaluate = audited_evaluate
        table._run_harness(harness_args, result_path, result, model, tokenizer)
        metric = result['metrics']['hellaswag']
        scores = metric['results']['hellaswag']
        result['hellaswag_acc'] = scores['acc,none']
        result['hellaswag_acc_norm_secondary'] = scores['acc_norm,none']
        result['table2_replacement_percent'] = 100 * scores['acc,none']
        task_cfg = metric['configs']['hellaswag']
        if metric['n-shot']['hellaswag'] != 0 or task_cfg['validation_split'] != 'validation':
            raise RuntimeError('HellaSwag task protocol mismatch')
        if args.variant == 'fp16':
            passed = abs(scores['acc,none'] - EXPECTED_ACC) < 1e-12 and abs(
                scores['acc_norm,none'] - EXPECTED_NORM) < 1e-12
            result['table1_fp16_gate'] = dict(passed=passed,
                expected_acc=EXPECTED_ACC, expected_acc_norm=EXPECTED_NORM)
            if not passed:
                raise RuntimeError('FP16 does not exactly reproduce Table I')
        result['status'] = 'complete'
        result['finished_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        write_json(result_path, result)
        print(json.dumps({k: result[k] for k in
              ('variant', 'status', 'hellaswag_acc', 'hellaswag_acc_norm_secondary')}, indent=2), flush=True)
    except Exception:
        result['status'] = 'failed'
        result['error'] = traceback.format_exc()
        write_json(result_path, result)
        raise


if __name__ == '__main__':
    main()
