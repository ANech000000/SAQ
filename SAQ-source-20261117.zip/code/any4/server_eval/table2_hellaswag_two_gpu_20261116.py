"""Launch two sequential lanes, gated by exact Table I FP16 reproduction."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/data/lsz/any4')
PYTHON = ROOT / 'venv/bin/python'
HERE = Path(__file__).resolve().parent
RUNNER = HERE / 'table2_hellaswag_table1_protocol_20261116.py'
RUN = ROOT / 'experiments/method30_weightonly_1b/runs/hellaswag_table1_protocol_20261116_v1'
LANES = {'0': dict(cpus='0-15', variants=['fp16', 'awq', 'any4']),
         '2': dict(cpus='16-31', variants=['rtn', 'gptq', 'csd_lut'])}


def write_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temp, path)


def worker(gpu):
    lane = LANES[gpu]
    if gpu != '0':
        gate = RUN / 'fp16/results.json'
        while True:
            data = json.loads(gate.read_text()) if gate.exists() else {}
            if data.get('status') == 'failed':
                raise RuntimeError('FP16 validation failed; second lane not started')
            if data.get('status') == 'complete':
                if data.get('table1_fp16_gate', {}).get('passed') is not True:
                    raise RuntimeError('Missing passed FP16 gate')
                break
            time.sleep(5)
    for variant in lane['variants']:
        command = ['taskset', '-c', lane['cpus'], str(PYTHON), '-u', str(RUNNER),
                   '--variant', variant, '--physical-gpu', gpu,
                   '--cpu-list', lane['cpus'], '--output-dir', str(RUN / variant)]
        env = os.environ.copy()
        env.update(CUDA_VISIBLE_DEVICES=gpu, PYTHONUNBUFFERED='1',
                   OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                   TOKENIZERS_PARALLELISM='false', HF_DATASETS_OFFLINE='1',
                   TRANSFORMERS_OFFLINE='1', HF_DATASETS_CACHE='/home/ubuntu/.cache/huggingface/datasets')
        print(f'START gpu={gpu} variant={variant}', flush=True)
        with (RUN / f'{variant}.log').open('x') as log:
            completed = subprocess.run(command, cwd=ROOT, env=env,
                                       stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        if completed.returncode:
            raise RuntimeError(f'{variant} failed: exit={completed.returncode}')
        print(f'COMPLETE gpu={gpu} variant={variant}', flush=True)
    write_json(RUN / f'lane_{gpu}_done.json', dict(gpu=gpu, status='complete', variants=lane['variants']))
    aggregate()


def aggregate():
    variants = ('fp16', 'rtn', 'gptq', 'awq', 'any4', 'csd_lut')
    rows = []
    for variant in variants:
        path = RUN / variant / 'results.json'
        if not path.exists():
            return
        result = json.loads(path.read_text())
        if result.get('status') != 'complete':
            return
        rows.append(dict(variant=variant, hellaswag_acc=result['hellaswag_acc'],
                         hellaswag_percent=result['table2_replacement_percent'],
                         acc_norm_secondary=result['hellaswag_acc_norm_secondary'],
                         ppl_check=result['weight_reproduction_check']['observed_ppl'],
                         result_path=str(path)))
    write_json(RUN / 'comparison.json', rows)
    with (RUN / 'comparison.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    report = ['# Table II HellaSwag: Table I 协议补测', '',
              'lm-eval 0.4.5，zero-shot，validation 全集，batch=8，max_length=2048。',
              '主结果为原始 acc；acc_norm 仅作为辅助结果。其他 Table II 列保持历史值。', '',
              '| 方法 | HellaSwag Acc. (%) | 辅助 acc_norm (%) |', '|---|---:|---:|']
    report += [f"| {r['variant']} | {r['hellaswag_percent']:.2f} | {100*r['acc_norm_secondary']:.2f} |" for r in rows]
    (RUN / 'SUMMARY.md').write_text('\n'.join(report) + '\n')


def launch():
    if RUN.exists():
        raise FileExistsError(RUN)
    snapshot = subprocess.check_output(['nvidia-smi', '--query-gpu=index,memory.used,utilization.gpu',
                                        '--format=csv,noheader,nounits'], text=True)
    for line in snapshot.splitlines():
        gpu, mem, util = [x.strip() for x in line.split(',')]
        if gpu in LANES and (int(mem) > 256 or int(util) > 5):
            raise RuntimeError(f'Chosen GPU {gpu} is occupied: {line}')
    RUN.mkdir(parents=True)
    plan = dict(started_at=time.strftime('%Y-%m-%d %H:%M:%S'), lanes=LANES,
                protocol='original Table I _run_harness, lm-eval 0.4.5, hellaswag only',
                guard='exact FP16 Table I match and historical WikiText-2 PPL check',
                source_files=[str(RUNNER), str(Path(__file__).resolve())], jobs=[])
    for gpu in LANES:
        with (RUN / f'lane_{gpu}.log').open('x') as log:
            proc = subprocess.Popen([str(PYTHON), '-u', str(Path(__file__).resolve()), '--worker', gpu],
                                    cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
        plan['jobs'].append(dict(gpu=gpu, pid=proc.pid))
    write_json(RUN / 'plan.json', plan)
    print(json.dumps(dict(run_dir=str(RUN), **plan), indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--worker', choices=tuple(LANES))
    args = p.parse_args()
    if args.worker is None:
        launch()
    else:
        worker(args.worker)
