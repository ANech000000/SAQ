# Table II HellaSwag 补测

- 服务器：01，项目 `/data/lsz/any4`。
- GPU：0、2；CPU 分别绑定 0–15、16–31。每路串行。
- GPU 0：FP16 → AWQ → Any4；GPU 2：FP16 验证通过后，RTN → GPTQ → CSD-LUT。
- 评测复用 `experiments/method30_postawq_refine/runner_any4_table.py::_run_harness`，lm-eval 0.4.5，HellaSwag validation 全集 10,042 条，zero-shot，batch=8，max_length=2048；主指标为原始 `acc`，辅助保留 `acc_norm`。
- 先核对每个模型的历史 WikiText-2 PPL，容差 1e-5；FP16 的 HellaSwag acc 和 acc_norm 必须分别复现 0.4772953594901414、0.6363274248157738，才允许后续队列启动。
- GPTQ 沿用 `official_gptq_v4` 的 AutoGPTQ 0.7.1 参数：W4、G128、damp=0.01、desc_act=True、true_sequential=True、WikiText-2 128×2048。
- CSD-LUT 使用原最终状态缓存加载，并沿用原重构哈希校验。
- GPTQ 的历史环境为 `/home/ubuntu/anaconda3/envs/denserlhf-qwen/bin/python`（torch 2.4.1、transformers 4.45.2）。新环境直接重建会改变 PPL，因此最终采用 `table2_hellaswag_gptq_bridge_20261116.py`：先在历史环境严格复现 PPL 10.714824676513672，再通过未命名内存管道传输 112 层 packed 张量；消费端逐张量 SHA256 核对，统一在 torch 2.8.0、transformers 4.57.1 的 Table I 环境评测。
- GPTQ 历史重建 PPL 与新环境推理诊断值分开记录；最终诊断值为 10.714512825012207，差异约 -0.000312，未持久化任何模型权重。
- 无持久化新模型权重，不改历史配置与结果；只补测 HellaSwag，其他下游列不更新。

服务器脚本：`/data/lsz/any4/experiments/method30_weightonly_1b/review_hellaswag_20261116/`。

服务器结果：`/data/lsz/any4/experiments/method30_weightonly_1b/runs/hellaswag_table1_protocol_20261116_v1/`。

任务清单为 `plan.json`；逐方法日志为 `<variant>.log`，结果为 `<variant>/results.json`。GPTQ 最终结果使用 `gptq_bridge_v7/results.json`；此前 GPTQ 尝试及旧环境 FP16 检查不纳入最终结果。全部完成后用 `table2_hellaswag_finalize_20261116.py` 核对并生成 `comparison.csv`、`comparison.json`、`validation.json`、`SUMMARY.md`。

最终状态：六种方法已全部完成并通过汇总核验；GPU 0、2 均已释放。结果下载到 `C:\Users\111\Desktop\project\any4\output\hellaswag_table1_protocol_20261116_v1`。FP16 47.73%、RTN 45.08%、GPTQ 46.14%、AWQ 46.38%、Any4 46.37%、CSD-LUT 46.86%。
