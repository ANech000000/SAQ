import argparse
import gc
import gzip
import json
import math
import os
import random
import sys
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from calibrate import calibrate
from data_gptq import llama_eval
from quantize import quant_methods, quantize_model


METHODS = {
    "fp16": {
        "description": "full precision fp16",
        "quant_args": None,
    },
    "original_any4": {
        "description": "original any4 4bit",
        "quant_args": {
            "n_bit": 4,
            "skip_modules": "lm_head",
            "sample_weight": calibrate,
            "scale_sample_weight": True,
        },
    },
    "method2_dp_kmeans": {
        "description": "method2: fixed group size 128 + DP 1D k-means",
        "quant_args": {
            "group_size": 128,
            "cluster_row": "dp",
            "n_bit": 4,
            "skip_modules": "lm_head",
            "sample_weight": calibrate,
            "scale_sample_weight": True,
            "pseudo": True,
            "parallelize": True,
            "parallel_jobs": 32,
        },
    },
}


class TokenizerWrapper:
    def __init__(self, input_ids):
        self.input_ids = input_ids


def current_gpu_index():
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    return visible if visible else "all-visible"


def load_model_and_tokenizer(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map=None,
    ).to("cuda")
    model.eval()
    return model, tokenizer


def load_ptb_test(ptb_dir, tokenizer, seqlen):
    test_path = Path(ptb_dir) / "test.jsonl"
    sentences = []
    with test_path.open("r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            sentence = item.get("sentence", "")
            if sentence:
                sentences.append(sentence)
    encoded = tokenizer(" ".join(sentences), return_tensors="pt")
    usable = (encoded.input_ids.numel() // seqlen) * seqlen
    if usable <= 0:
        raise ValueError(f"PTB test set produced fewer than {seqlen} tokens.")
    return TokenizerWrapper(encoded.input_ids[:, :usable])


def iter_c4_texts(c4_dir):
    root = Path(c4_dir)
    files = sorted((root / "en").glob("c4-validation.*.json.gz"))
    if not files:
        files = sorted(root.glob("**/c4-validation.*.json.gz"))
    if not files:
        raise FileNotFoundError(f"No C4 validation json.gz files found under {root}")
    for path in files:
        with gzip.open(path, "rt") as f:
            for line in f:
                if not line.strip():
                    continue
                text = json.loads(line).get("text", "")
                if text:
                    yield text


def load_c4_eval(c4_dir, tokenizer, seqlen, samples, seed):
    rng = random.Random(seed)
    chunks = []
    scanned = 0
    for text in iter_c4_texts(c4_dir):
        scanned += 1
        encoded = tokenizer(text, return_tensors="pt")
        ntok = encoded.input_ids.shape[1]
        if ntok < seqlen:
            continue
        start = rng.randint(0, ntok - seqlen - 1) if ntok > seqlen else 0
        chunks.append(encoded.input_ids[:, start:start + seqlen])
        if len(chunks) >= samples:
            break
    if len(chunks) < samples:
        raise ValueError(f"Only found {len(chunks)} C4 samples with at least {seqlen} tokens after scanning {scanned} records.")
    return TokenizerWrapper(torch.hstack(chunks))


def load_eval_dataset(dataset, tokenizer, args):
    if dataset == "ptb":
        return load_ptb_test(args.ptb_dir, tokenizer, args.seqlen)
    if dataset == "c4":
        return load_c4_eval(args.c4_dir, tokenizer, args.seqlen, args.c4_eval_samples, args.seed)
    raise ValueError(f"Unsupported dataset {dataset}")


def run_one(args):
    method = METHODS[args.method]
    method_dir = Path(args.log_dir) / args.dataset / args.method
    method_dir.mkdir(parents=True, exist_ok=True)
    (method_dir / "command.txt").write_text(" ".join(sys.argv) + "\n")

    started = time.time()
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    qargs = dict(method["quant_args"]) if method["quant_args"] is not None else None
    dp_cache_stats_path = None
    if args.method == "method2_dp_kmeans" and args.dp_cache_dir:
        dp_cache_stats_path = method_dir / "dp_cache_stats.json"
        qargs.update({
            "dp_cache_dir": args.dp_cache_dir,
            "dp_cache_mode": args.dp_cache_mode,
            "dp_cache_verify": False,
            "dp_cache_stats_path": str(dp_cache_stats_path),
        })

    quant_elapsed = 0.0
    if qargs is not None:
        quant_started = time.time()
        model = quantize_model(
            model,
            layer_from=torch.nn.Linear,
            layer_to=quant_methods["anyq"],
            tokenizer=tokenizer,
            **qargs,
        )
        quant_elapsed = time.time() - quant_started
    model.eval()

    testenc = load_eval_dataset(args.dataset, tokenizer, args)
    eval_tokens = int(testenc.input_ids.numel())
    eval_samples = eval_tokens // args.seqlen
    ppl = llama_eval(model, testenc, "cuda", seqlen=args.seqlen)
    elapsed = time.time() - started

    cache_stats = None
    if dp_cache_stats_path and dp_cache_stats_path.exists():
        cache_stats = json.loads(dp_cache_stats_path.read_text())

    result = {
        "method": args.method,
        "description": method["description"],
        "dataset": args.dataset,
        "model_path": args.model_path,
        "seqlen": args.seqlen,
        "eval_tokens": eval_tokens,
        "eval_samples": eval_samples,
        "c4_eval_samples_requested": args.c4_eval_samples if args.dataset == "c4" else None,
        "gpu": current_gpu_index(),
        "quant_elapsed_sec": quant_elapsed,
        "elapsed_sec": elapsed,
        "ppl": ppl,
        "quant_args": None if qargs is None else {k: str(v) for k, v in qargs.items() if k != "sample_weight"},
        "dp_cache_stats": cache_stats,
    }
    (method_dir / "results.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(result, indent=2, ensure_ascii=False))

    del model, tokenizer, testenc
    torch.cuda.empty_cache()
    gc.collect()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", default="/data/model/alpindale-Llama-3.2-1B")
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("--dataset", choices=["c4", "ptb"], required=True)
    parser.add_argument("--method", choices=list(METHODS.keys()), required=True)
    parser.add_argument("--c4-dir", default="/data/lsz/llm_dataset/pretraining/C4")
    parser.add_argument("--ptb-dir", default="/data/lsz/llm_dataset/language_modeling/PTB")
    parser.add_argument("--seqlen", type=int, default=2048)
    parser.add_argument("--c4-eval-samples", type=int, default=256)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--dp-cache-dir", default=None)
    parser.add_argument("--dp-cache-mode", choices=["off", "readwrite", "readonly"], default="readonly")
    args = parser.parse_args()
    run_one(args)


if __name__ == "__main__":
    main()
