#!/usr/bin/env bash
set -euo pipefail

for i in $(seq 1 120); do
  echo "poll_$i"
  nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits
  free_gpu=$(
    nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader,nounits |
      awk -F, '$2 + 0 < 100 && $3 + 0 < 5 {print $1; exit}'
  )
  if [ -n "$free_gpu" ]; then
    echo "FREE_GPU=$free_gpu"
    exit 0
  fi
  sleep 60
done

echo "NO_FREE_GPU"
exit 2
